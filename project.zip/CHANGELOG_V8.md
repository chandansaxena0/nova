# Nova v8.0 Ultimate Changelog

- **Strict "Hello Nova" Wake Engine:** Added negative distractor grammar (`hello`, `hey`, `hi`, `okay`, etc.) + finalized utterance & word-level confidence/duration validation so standalone "Hello" no longer triggers Nova.
- **Custom Hexagon NOVA Branding:** Bundled transparent Hexagon NOVA adaptive launcher icon (`mipmap-anydpi-v26` / `v33` + all mipmap densities) and top-bar badge.
- **AI Buddy Battery-Friendly UI:** Pure OLED `#060608` dark canvas, Neon Lime `#C8F63A` + Lavender `#C5A3FF` + Soft Pink `#FBC4DE` asymmetric Bento Dashboard, dark rounded History pills, and static 3D iridescent glass orb (zero GPU animation drain).
- **Ultimate Voice Automation:** Multi-command chaining, exact volume %, silent/vibrate/normal ringer, screen brightness control, hands-free OS navigation (back/home/recents/notifications/quick settings/screenshot/lock/scroll/tap text/type text), camera/selfie/video, Google Maps turn-by-turn navigation, website & UPI quick launch, offline unit converter, coin toss, dice roll, stopwatch, and voice notes.

## v8.1 Hotfix
- Fixed crash when opening the Settings tab or tapping the top-left menu button (Material3 Slider `stepSize = 0.05` rejected non-step `0.62f` default threshold on measure). Default threshold is now `0.65f` with strict `0.05` step-snapping for both Wake Threshold and TTS Speed sliders.
