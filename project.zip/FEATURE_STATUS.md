# Nova v6.0 Feature Status & Honest Technical Limitations

## Implemented & Verified in Source + Unit Tests
- Wake Word Detection (`Hey Nova`, `Hi Nova`, `Hello Nova`, `Okay Nova`, `Nova`) via Vosk constrained grammar + partial results.
- Continuous Listening Session Timer (30s default, 40s option in Settings) with automatic reset on each command.
- Priority #0 Stop Interception (`Stop`, `Stop Listening`, `Nova Stop`, `Nova Band Ho Jao`, `Band Karo`, `Band Ho Jao`, `Listening Band Karo`, `Bas Nova`).
- Hinglish-first Roman conversion & proper-noun cleanup (`HinglishConverter`).
- Smart Command Resolver (Local -> Gemini `gemini-3.5-flash-lite` -> Google Search fallback).
- Confirmation safety for Calls, Duplicate Contacts, WhatsApp/SMS, WhatsApp Inline Replies, Similar Apps, and Emergency Location Share.
- On-demand Nearby Places (Petrol Pump, Hospital, ATM, Railway Station, Medical Store, Restaurant) with real distance + Google Maps route.
- YouTube Search + Accessibility first-video play, Roblox Place ID resolution + `roblox://` deep link launch.
- Music & Volume controls, Reminders & Alarms CRUD, Weather & Daily Briefing, Phone Info & Screen Time, Clipboard Assistant, Study Assistant (offline math + Gemini), Translation, Smart Memory, Emergency 112/SOS.

## Honest Android Platform Limitations
1. **100% Speech Accuracy**: No speech engine achieves 100% accuracy in loud traffic/music; hybrid Google `en-IN` + `HinglishConverter` maximizes real-world accuracy, while offline Vosk fallback has a smaller vocabulary when internet is off.
2. **Android 10+ Clipboard Privacy**: Android allows reading the system clipboard only while Nova is in the foreground (not silently from the background).
3. **Android 14+ Reboot Policy**: Android restricts apps from auto-starting microphone foreground services silently after reboot; `BootReceiver` restores all Reminders automatically and shows a 1-tap notification to resume Wake Word listening.
4. **OEM Battery Restrictions**: Some devices (Vivo/OriginOS, Xiaomi, Oppo) aggressively kill background services unless Battery Optimization is set to Unrestricted for Nova.
5. **Overpass / Open-Meteo Coverage**: Nearby place names depend on OpenStreetMap data in rural areas; if a rural pump isn't mapped in OSM, Nova automatically opens Google Maps search as fallback.
