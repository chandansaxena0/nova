# Nova V6 feature status

This file distinguishes code already present from items not implemented in this archive.

## Present in source (still requires device testing)
- Installed-app discovery and app launch.
- App/web search and supported music/video search/play intents.
- Offline Vosk Hindi wake-word service (model bundled by the repository's current Actions workflow).
- Hey/Hi/Hello-style wake phrase handling plus standalone Nova phrase.
- 30-second default command window; session refresh after commands.
- Priority spoken stop phrase matching for common English/Hinglish variants.
- Hindi TTS acknowledgements and spoken command result.
- Local command parser and optional Gemini command interpretation.
- Contact lookup, call/dial, SMS/WhatsApp launch/send integration.
- Notification-listener reply integration.
- Accessibility-driven limited UI actions.

## Not implemented as complete user-facing features
- Full free-form conversational Gemini voice chat with streaming.
- Complete 30/40-second selector in the app settings UI.
- Weather and daily briefing.
- Full reminders/alarms create-edit-delete and repeat UI.
- Clipboard tools.
- Smart memory UI with view/delete controls.
- Full dashboard for battery/network/storage/screen time.
- Full device controls for Bluetooth/Wi-Fi/volume.
- Reliable general-purpose YouTube autoplay and Roblox game launching.
- Comprehensive permission onboarding and automated Android-version QA.

Do not treat items in the second list as working features. Some require additional Android permissions, external APIs, app-specific integration, or user confirmation.
