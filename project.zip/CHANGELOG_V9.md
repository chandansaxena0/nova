# Nova v9.0 Perfection Edition Changelog

- **Zero-False-Trigger Hybrid Wake Engine:**
  - Adaptive room-noise floor SNR VAD (ignores fan, TV, traffic, and background chatter).
  - Automatic 1.44s silence decoder reset so older words never combine with later syllables.
  - Second-stage **Full-Vocabulary Ring-Buffer Verifier** (2.2s rolling PCM buffer) that validates every ONNX and Vosk candidate before triggering, blocking standalone `"Hello"`, `"Hello bhai"`, `"Kya hua"`, and TV dialogue.
  - Settings toggle: **Strict Anti-False-Trigger Verification** (default ON) + blocked false-trigger counter in Diagnostics.
- **Hands-Free Connectivity & Quick System Toggles (`ConnectivityControlHelper.kt` + `NovaAccessibility.kt`):**
  - Voice ON / OFF / Toggle for **Wi-Fi, Bluetooth, Mobile Data, Hotspot, Airplane Mode, Auto-Rotate, Do Not Disturb, Battery Saver, Location/GPS**, and **Power Menu** using state-aware Quick Settings tile automation (with page-2 swipe & Android 12+ Internet panel support) + native panel fallback.
- **Smart TV Voice Control & Built-in Remote (`SmartTvController.kt`):**
  - Pure-Kotlin ADB-over-Wi-Fi/Hotspot engine (persistent RSA-2048 key, zero PC required) with automatic Wi-Fi/Hotspot subnet TV scanner.
  - Voice control for Power/Sleep/Wake, Volume Up/Down/Mute, Play/Pause/Next/Previous, Home/Back/D-Pad/OK/Menu, HDMI Input, Channels, YouTube/Netflix/Prime/Hotstar/JioCinema/SonyLIV/Zee5/Spotify/Settings launch, direct TV YouTube search/play, and text typing.
  - Dedicated Smart TV Remote Control pad in the Hub tab.
- **Custom Voice Shortcuts (Macros) & Offline GST/Discount Calculator (`MacroStore.kt` + `MathEvaluator.kt`):**
  - Create custom voice triggers that chain multiple phone and Smart TV actions together.
