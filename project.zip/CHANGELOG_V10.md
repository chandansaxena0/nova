# Nova v10.0 Ultimate Upgrade Changelog

- **Background Wake Reliability Fix (`OpenWakeWordEngine.kt` + `ListenService.kt`):**
  - Calibrated adaptive SNR VAD floors (`50` High / `75` Balanced / `140` Saver) so arm's-length and background speech triggers reliably.
  - Automatic `VOICE_RECOGNITION` -> `MIC` audio source recovery if OEM firmware delivers silenced PCM in background.
  - 15-second background wake health watchdog + 4.5-second OEM mic-conflict auto-recovery probe.
  - Fast 2-frame partial spotter + full-vocabulary 2.4s ring-buffer verification that accepts wake phrases followed by commands (`"Hello Nova battery kitni hai"`) while strictly blocking standalone `"Hello"`, `"Hello bhai"`, and long chatter.
- **Central AI Orchestrator (`NovaOrchestrator.kt`):** Typed `ActionStatus` outcomes, active multi-turn task state, and consolidated multi-agent Travel Plan workflow.
- **Multi-Provider AI Router (`AiRouter.kt`):** Primary + configured secondary fallback, exponential backoff, active HTTP request cancellation, health/latency monitor, token & USD usage estimate, daily call limit, and Clear API Key button.
- **Encrypted SQLite Personal Memory (`NovaMemoryDb.kt` + `SmartMemory.kt`):** AES-256-GCM encrypted SQLite storage with auto legacy migration, categories, expiry, duplicate detection, search, JSON export, and frequent command tracking.
- **Complete File & Multimodal AI (`FileAssistant.kt`):** Multi-page PDF (`FlateDecode` stream extractor + `[Page X]` citations + on-demand `PdfRenderer` page inspection), DOCX, XLSX, PPTX, CSV, MD, TXT, Images, and honest encrypted/unreadable file handling.
- **Advanced Workflow Engine (`MacroStore.kt`) & Routines:** Conditions (`if battery < 25`, `if night`, `if charging`), inline delays (`wait 3s`), retry-once recovery, sensitive-step confirmation, cancellation, SQLite run history, + Work Routine.
- **Study Progress & Offline Decks (`StudyProgressStore.kt` + `VoiceFlashcardManager.kt`):** Chemistry, Biology, English Grammar offline decks, accuracy tracking, weak-topic detection, and spaced revision schedule.
- **Multi-Device Smart TV (`SmartTvController.kt`):** Named trusted TVs list, voice TV matching, transient socket retry recovery, and connection status.
- **Bonus Powerhouse Features:** Android Quick Settings Tile (`NovaQuickTileService`), Offline Indian INR Voice Expense Ledger (`ExpenseTrackerStore`), SOS Flashlight Beacon, 3 Power Profiles, Searchable Settings, Free RAM Telemetry, Sanitized Diagnostic Export, and `backup_rules.xml`.
