plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nova.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nova.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "6.4"

        // Keep APK lightweight: real ARM devices only
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Release signing is configured only from GitHub/local environment variables.
    // Never commit a keystore or passwords into the repository.
    val releaseKeystorePath = System.getenv("NOVA_KEYSTORE_PATH")
    val releaseStorePassword = System.getenv("NOVA_KEYSTORE_PASSWORD")
    val releaseKeyAlias = System.getenv("NOVA_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("NOVA_KEY_PASSWORD")
    val releaseKeystore = releaseKeystorePath?.let { file(it) }
    val hasReleaseSigning = releaseKeystore?.exists() == true &&
        !releaseStorePassword.isNullOrBlank() &&
        !releaseKeyAlias.isNullOrBlank() &&
        !releaseKeyPassword.isNullOrBlank()

    if (hasReleaseSigning) {
        signingConfigs {
            create("release") {
                storeFile = requireNotNull(releaseKeystore)
                storePassword = requireNotNull(releaseStorePassword)
                keyAlias = requireNotNull(releaseKeyAlias)
                keyPassword = requireNotNull(releaseKeyPassword)
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Neural Wake Word Engine (openWakeWord via ONNX Runtime)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")

    // Offline speech recognition fallback (Vosk)
    implementation("net.java.dev.jna:jna:5.18.1@aar")
    implementation("com.alphacephei:vosk-android:0.3.75@aar")

    // Automated unit test suite
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
