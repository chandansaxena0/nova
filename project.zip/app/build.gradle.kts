plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nova.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nova.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 13
        versionName = "9.0"

        // Keep APK lightweight: real ARM devices only
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Uses existing repo debug.keystore if present (installs cleanly over v5/v6),
    // otherwise falls back safely to default debug keystore.
    val fixedKeystore = file("debug.keystore")
    if (fixedKeystore.exists()) {
        signingConfigs {
            getByName("debug") {
                storeFile = fixedKeystore
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Neural Wake Word Engine (openWakeWord via ONNX Runtime)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")

    // Multi-phrase wake word spotting & offline speech recognition (Vosk)
    implementation("net.java.dev.jna:jna:5.18.1@aar")
    implementation("com.alphacephei:vosk-android:0.3.75@aar")

    // Automated unit test suite
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
