package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NovaUnitTests {

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    @Before
    fun setUp() {
        index = AppIndex(null)
        index.setAppsForTest(
            listOf(
                AppInfo("WhatsApp", "com.whatsapp"),
                AppInfo("YouTube", "com.google.android.youtube"),
                AppInfo("Spotify", "com.spotify.music"),
                AppInfo("Roblox", "com.roblox.client"),
                AppInfo("Maps", "com.google.android.apps.maps"),
                AppInfo("Settings", "com.android.settings"),
                AppInfo("Instagram", "com.instagram.android"),
                AppInfo("Free Fire MAX", "com.dts.freefiremax")
            )
        )
        parser = CommandParser(index)
    }

    @Test
    fun testWakeWordsHeyHiOkayNova() {
        assertEquals("", WakeStopDetector.stripWake("Hey Nova"))
        assertEquals("", WakeStopDetector.stripWake("Hi Nova"))
        assertEquals("", WakeStopDetector.stripWake("Okay Nova"))
        assertEquals("", WakeStopDetector.stripWake("Ok Nova"))
        assertEquals("WhatsApp kholo", WakeStopDetector.stripWake("Hey Nova WhatsApp kholo"))
        assertEquals("YouTube par kahani search karo", WakeStopDetector.stripWake("Okay Nova YouTube par kahani search karo"))
        assertEquals("", WakeStopDetector.stripWake("hey nova", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("hi nova", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("okay nova", isPartial = true))
        assertNull(WakeStopDetector.stripWake("hello everyone how are you", isPartial = true))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("hey nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("hi nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("okay nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("hello nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("\"hello\""))
        assertEquals("", WakeStopDetector.stripWake("Hello Nova"))
        assertNull(WakeStopDetector.stripWake("Hello"))
        assertNull(WakeStopDetector.stripWake("Hello", isPartial = true))
    }

    @Test
    fun testCriticalCreativeIntentRoutingNotYouTube() {
        // Test #9: "Nova kahani sunao" -> STORY (NEVER YouTube!)
        val story = parser.parse("Nova kahani sunao")
        assertEquals(Kind.STORY, story.kind)
        assertNull(story.app)
        assertEquals(AgentType.MAIN_ASSISTANT, MainAssistantAgent.selectAgent(story))

        val story2 = parser.parse("Nova, mujhe ek kahani sunao")
        assertEquals(Kind.STORY, story2.kind)

        // Test #10: "Nova joke sunao" -> JOKE
        val joke = parser.parse("Nova joke sunao")
        assertEquals(Kind.JOKE, joke.kind)
        assertNull(joke.app)

        // Shayari -> SHAYARI
        val shayari = parser.parse("Nova shayari sunao")
        assertEquals(Kind.SHAYARI, shayari.kind)
        assertNull(shayari.app)

        // "Nova gaana chalao" -> PLAY (music service, NOT YouTube search)
        val music = parser.parse("Nova gaana chalao")
        assertEquals(Kind.PLAY, music.kind)
        assertEquals("", music.query)

        // Test #11: "YouTube par kahani search karo" -> SEARCH on YouTube!
        val ytSearch = parser.parse("YouTube par kahani search karo")
        assertEquals(Kind.SEARCH, ytSearch.kind)
        assertEquals("com.google.android.youtube", ytSearch.app?.pkg)
        assertEquals("kahani", ytSearch.query)
    }

    @Test
    fun testUnknownCommandDoesNotRouteToYouTubeOrGoogle() {
        val unknown = parser.parse("aaj mujhe kuch samajh nahi aa raha kya karun")
        assertEquals(Kind.UNKNOWN, unknown.kind)
        assertNotEquals(Kind.SEARCH, unknown.kind)
        assertNotEquals(Kind.PLAY, unknown.kind)
    }

    @Test
    fun testPhase3And4VoiceCommandsAndAgents() {
        val bat = parser.parse("Hey Nova, battery kitni hai?")
        assertEquals(Kind.PHONE_INFO, bat.kind)
        assertEquals("battery", bat.query)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(bat))

        val wifi = parser.parse("Nova, Wi-Fi settings kholo")
        assertEquals(Kind.OPEN_SETTINGS, wifi.kind)
        assertEquals("wifi", wifi.query)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(wifi))

        val flashOn = parser.parse("Nova, flashlight on karo")
        assertEquals(Kind.FLASHLIGHT, flashOn.kind)
        assertEquals("on", flashOn.query)

        val flashOff = parser.parse("Nova, flashlight band karo")
        assertEquals(Kind.FLASHLIGHT, flashOff.kind)
        assertEquals("off", flashOff.query)

        val rem = parser.parse("Nova, kal subah reminder lagao")
        assertEquals(Kind.REMINDER, rem.kind)
        assertEquals(8, rem.extraHour)
        assertEquals(AgentType.DAILY_PLANNER, MainAssistantAgent.selectAgent(rem))

        val timer = parser.parse("Nova, 10 minute ka timer lagao")
        assertEquals(Kind.TIMER, timer.kind)
        assertEquals(10, timer.extraMinutes)
        assertEquals(AgentType.DAILY_PLANNER, MainAssistantAgent.selectAgent(timer))

        val notif = parser.parse("Nova, mere notifications summarize karo")
        assertEquals(Kind.SUMMARIZE_NOTIFICATIONS, notif.kind)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(notif))

        val storage = parser.parse("Nova, mere phone ki storage batao")
        assertEquals(Kind.PHONE_INFO, storage.kind)
        assertEquals("storage", storage.query)

        val ytOpen = parser.parse("Nova, YouTube kholo")
        assertEquals(Kind.OPEN, ytOpen.kind)
        assertEquals("com.google.android.youtube", ytOpen.app?.pkg)

        val weather = parser.parse("Nova, aaj ka weather batao")
        assertEquals(Kind.WEATHER, weather.kind)
        assertEquals(AgentType.TRAVEL, MainAssistantAgent.selectAgent(weather))

        val research = parser.parse("Nova, latest news batao")
        assertEquals(Kind.WEB_RESEARCH, research.kind)
        assertEquals(AgentType.RESEARCH, MainAssistantAgent.selectAgent(research))

        val screen = parser.parse("Nova, screen samjhao")
        assertEquals(Kind.SCREEN_ANALYZE, screen.kind)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(screen))

        val fileQ = parser.parse("Nova, pdf file summarize karo")
        assertEquals(Kind.FILE_ANALYZE, fileQ.kind)
        assertEquals(AgentType.FILE, MainAssistantAgent.selectAgent(fileQ))

        val task = parser.parse("Nova, task add karo physics revision")
        assertEquals(Kind.TASK_MANAGE, task.kind)
        assertEquals(AgentType.DAILY_PLANNER, MainAssistantAgent.selectAgent(task))
    }

    @Test
    fun testRailRadarTrainFlashcardsMemorySafetyAndMath() {
        val train = parser.parse("Nova, train 12562 ka live status batao")
        assertEquals(Kind.TRAIN_STATUS, train.kind)
        assertEquals("12562", RailRadarHelper.extractTrainNumber(train.query))
        assertEquals(AgentType.TRAVEL, MainAssistantAgent.selectAgent(train))

        val sampleJson = """{"success":true,"data":{"train":{"trainNumber":"12562","trainName":"Swatantrata Senani Exp"},"liveData":{"currentLocation":{"stationName":"Kanpur Central"},"overallDelayMinutes":18,"nextStationName":"Prayagraj Jn","nextStationDeparture":"05:35"}}}"""
        val spoken = RailRadarHelper.parseRailRadarLiveJson(sampleJson, "12562")
        assertNotNull(spoken)
        assertTrue(spoken!!.contains("Kanpur Central"))
        assertTrue(spoken.contains("18 minute late"))

        // Sensitive memory protection
        assertTrue(SmartMemory.isSensitive("Mera password 12345 hai"))
        assertTrue(SmartMemory.isSensitive("UPI PIN 4455 hai"))
        assertFalse(SmartMemory.isSensitive("Mera favourite music app Spotify hai"))

        // Offline math
        assertEquals("60", MathEvaluator.trySolve("25 plus 35 kitna hota hai"))
        assertEquals("12", MathEvaluator.trySolve("square root of 144"))

        // Stop commands & false-stop guards
        assertTrue(WakeStopDetector.isStopCommand("Nova Stop"))
        assertTrue(WakeStopDetector.isStopCommand("Band Karo"))
        assertFalse(WakeStopDetector.isStopCommand("bus stop near me"))
    }

    @Test
    fun testTrainNumberIsRemembered() {
        RailRadarHelper.rememberTrain("19619")
        assertEquals("19619", RailRadarHelper.recentTrainNo())
    }

    @Test
    fun testOpenAiCompatDefaults() {
        assertEquals("openrouter/free", OpenAiCompat.defaultModel(OpenAiCompat.OPENROUTER))
        assertEquals("Grok (xAI)", OpenAiCompat.label(OpenAiCompat.GROK))
        assertTrue(OpenAiCompat.friendly(OpenAiCompat.GROK, "HTTP 401: bad").contains("invalid"))
    }

    @Test
    fun testNovaV8UltimatePowerCommands() {
        val vol = parser.parse("Volume 75 percent karo")
        assertEquals(Kind.DEVICE_ACTION, vol.kind)
        assertEquals("volume_percent", vol.query)
        assertEquals("75", vol.body)

        val bright = parser.parse("Brightness 60 percent karo")
        assertEquals(Kind.DEVICE_ACTION, bright.kind)
        assertEquals("brightness_set", bright.query)
        assertEquals("60", bright.body)

        val ss = parser.parse("Nova screenshot lo")
        assertEquals(Kind.DEVICE_ACTION, ss.kind)
        assertEquals("screenshot", ss.query)

        val nav = parser.parse("Jaipur ka rasta dikhao")
        assertEquals(Kind.NAVIGATE, nav.kind)
        assertEquals("jaipur", nav.query)
        assertEquals(AgentType.TRAVEL, MainAssistantAgent.selectAgent(nav))

        val conv = UltimatePowerHelper.convertUnitsOffline("10 km ko miles me convert karo")
        assertNotNull(conv)
        assertTrue(conv!!.contains("6.21"))

        val note = parser.parse("Note likho kal physics notes lene hain")
        assertEquals(Kind.NOTE, note.kind)
        assertEquals("add", note.query)
        assertEquals(AgentType.MEMORY, MainAssistantAgent.selectAgent(note))

        val chain = UltimatePowerHelper.splitChainedCommands("Flashlight on karo aur volume 80 percent karo aur 5 minute ka timer lagao")
        assertEquals(3, chain.size)
    }
}
