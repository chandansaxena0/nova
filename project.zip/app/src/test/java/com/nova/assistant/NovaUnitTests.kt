package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NovaUnitTests {

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    @Before
    fun setUp() {
        index = AppIndex(null)
        index.setAppsForTest(
            listOf(
                AppInfo("WhatsApp", "com.whatsapp"),
                AppInfo("YouTube", "com.google.android.youtube"),
                AppInfo("Spotify", "com.spotify.music"),
                AppInfo("Roblox", "com.roblox.client"),
                AppInfo("Maps", "com.google.android.apps.maps"),
                AppInfo("Settings", "com.android.settings"),
                AppInfo("Instagram", "com.instagram.android"),
                AppInfo("Free Fire MAX", "com.dts.freefiremax")
            )
        )
        parser = CommandParser(index)
    }

    @Test
    fun testAllFiveWakeWords() {
        assertEquals("", WakeStopDetector.stripWake("Hey Nova"))
        assertEquals("", WakeStopDetector.stripWake("Hi Nova"))
        assertEquals("", WakeStopDetector.stripWake("Hello Nova"))
        assertEquals("", WakeStopDetector.stripWake("Okay Nova"))
        assertEquals("", WakeStopDetector.stripWake("Ok Nova"))
        assertEquals("", WakeStopDetector.stripWake("Nova"))
        assertEquals("WhatsApp kholo", WakeStopDetector.stripWake("Hey Nova WhatsApp kholo"))
        assertEquals("YouTube par MrBeast search karo", WakeStopDetector.stripWake("Okay Nova YouTube par MrBeast search karo"))
        // Partial trigger checks
        assertEquals("", WakeStopDetector.stripWake("hey nova", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("okay nova", isPartial = true))
        assertNull(WakeStopDetector.stripWake("hello everyone how are you", isPartial = true))
        assertNull(WakeStopDetector.stripWake("now let us go home", isPartial = false))
        // Repeated wake words & Vosk Indian-English / Hindi phonetic variants
        assertEquals("", WakeStopDetector.stripWake("hey nova hey nova", isPartial = true))
        assertEquals("WhatsApp kholo", WakeStopDetector.stripWake("hey nova hey nova WhatsApp kholo"))
        assertEquals("", WakeStopDetector.stripWake("hey noah", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("hey no war", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("hey know a", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("हे नोवा"))
        assertEquals("", WakeStopDetector.stripWake("ओके नोवा"))
    }

    @Test
    fun testAllStopCommandsAndFalseStopGuards() {
        val validStops = listOf(
            "Stop",
            "Stop Listening",
            "Nova Stop",
            "Nova Band Ho Jao",
            "Band Karo",
            "Band Ho Jao",
            "Listening Band Karo",
            "Bas Nova",
            "नोवा स्टॉप",
            "बंद करो"
        )
        for (phrase in validStops) {
            assertTrue("Should detect stop for: $phrase", WakeStopDetector.isStopCommand(phrase))
        }

        // Guard against false stop activations
        assertFalse(WakeStopDetector.isStopCommand("bus stop near me"))
        assertFalse(WakeStopDetector.isStopCommand("YouTube par non stop songs chalao"))
        assertFalse(WakeStopDetector.isStopCommand("stopwatch kholo"))
    }

    @Test
    fun testHinglishConversionAndProperNounFixes() {
        val hiSearch = HinglishConverter.toHinglish("यूट्यूब पर मिस्टर बीस्ट सर्च करो")
        assertFalse("Must not contain Devanagari", HinglishConverter.hasDevanagari(hiSearch))
        assertTrue("Must contain YouTube", hiSearch.contains("YouTube"))
        assertTrue("Must contain MrBeast", hiSearch.contains("MrBeast"))

        assertEquals("MrBeast", HinglishConverter.toHinglish("mr beast"))
        assertEquals("Roblox", HinglishConverter.toHinglish("rob locks"))
        assertEquals("WhatsApp", HinglishConverter.toHinglish("whats app"))
    }

    @Test
    fun testSmartCommandParsing() {
        val yt = parser.parse("YouTube par mr beast search karo")
        assertEquals(Kind.SEARCH, yt.kind)
        assertEquals("com.google.android.youtube", yt.app?.pkg)
        assertEquals("MrBeast", yt.query)

        val wa = parser.parse("Rahul ko WhatsApp par message bhejo ki main 5 minute me aa raha hoon")
        assertEquals(Kind.MESSAGE, wa.kind)
        assertEquals("Rahul", wa.contact)
        assertEquals("main 5 minute me aa raha hoon", wa.body)

        val pump = parser.parse("Mere sabse paas kaun sa petrol pump hai")
        assertEquals(Kind.NEARBY, pump.kind)
        assertEquals("Petrol Pump", pump.query)

        val roblox = parser.parse("Roblox me Brookhaven chalao")
        assertEquals(Kind.ROBLOX, roblox.kind)
        assertEquals("Brookhaven", roblox.query)

        val rem = parser.parse("15 minute baad pani peene ka reminder lagao")
        assertEquals(Kind.REMINDER, rem.kind)
        assertEquals(15, rem.extraMinutes)

        val bat = parser.parse("Battery kitni percent hai")
        assertEquals(Kind.PHONE_INFO, bat.kind)
        assertEquals("battery", bat.query)

        val music = parser.parse("Volume badha do")
        assertEquals(Kind.MUSIC_CONTROL, music.kind)
        assertEquals("volume_up", music.query)

        val mem = parser.parse("Yaad rakho mera favourite music app Spotify hai")
        assertEquals(Kind.MEMORY_SAVE, mem.kind)
        assertTrue(mem.body.contains("Spotify"))

        val emerg = parser.parse("Emergency location share karo")
        assertEquals(Kind.EMERGENCY, emerg.kind)
        assertEquals("location", emerg.query)
    }

    @Test
    fun testOfflineMathEvaluator() {
        assertEquals("60", MathEvaluator.trySolve("25 plus 35 kitna hota hai"))
        assertEquals("30", MathEvaluator.trySolve("15 percent of 200"))
        assertEquals("12", MathEvaluator.trySolve("square root of 144"))
        assertEquals("60", MathEvaluator.trySolve("(12 + 8) * 3"))
        assertNotNull(MathEvaluator.trySolve("96 divided by 8"))
    }

    @Test
    fun testConfirmationParsing() {
        assertEquals(WakeStopDetector.ConfirmAnswer.YES, WakeStopDetector.parseConfirmation("Haan bhejo"))
        assertEquals(WakeStopDetector.ConfirmAnswer.YES, WakeStopDetector.parseConfirmation("Yes confirm"))
        assertEquals(WakeStopDetector.ConfirmAnswer.NO, WakeStopDetector.parseConfirmation("Nahi cancel karo"))
        assertEquals(WakeStopDetector.ConfirmAnswer.NO, WakeStopDetector.parseConfirmation("No"))
    }

    @Test
    fun testRailRadarTrainAndChecklistParsing() {
        val trainNum = parser.parse("Train 12562 kahan pahunchi aur depart time kya hai")
        assertEquals(Kind.TRAIN_STATUS, trainNum.kind)
        assertEquals("12562", RailRadarHelper.extractTrainNumber(trainNum.query))

        val trainName = parser.parse("Swatantrata Senani Express kitni late hai")
        assertEquals(Kind.TRAIN_STATUS, trainName.kind)
        assertTrue(RailRadarHelper.extractTrainQuery(trainName.query).contains("Swatantrata"))

        // Verify RailRadar JSON parsing produces natural spoken Hinglish reply
        val sampleJson = """{"success":true,"data":{"train":{"trainNumber":"12562","trainName":"Swatantrata Senani Exp"},"liveData":{"currentLocation":{"stationName":"Kanpur Central"},"overallDelayMinutes":18,"nextStationName":"Prayagraj Jn","nextStationDeparture":"05:35"}}}"""
        val spoken = RailRadarHelper.parseRailRadarLiveJson(sampleJson, "12562")
        assertNotNull(spoken)
        assertTrue(spoken!!.contains("Kanpur Central"))
        assertTrue(spoken.contains("18 minute late"))
        assertTrue(spoken.contains("05:35"))

        // Nearest railway station must stay NEARBY
        val nearbyStation = parser.parse("Mere sabse paas railway station kahan hai")
        assertEquals(Kind.NEARBY, nearbyStation.kind)
        assertEquals("Railway Station", nearbyStation.query)

        val checklist = parser.parse("Travel checklist me charger tick karo")
        assertEquals(Kind.TRAVEL_CHECKLIST, checklist.kind)
    }

    @Test
    fun testVoiceFlashcardsPrivacyAndFollowUps() {
        val fc = parser.parse("Maths ke voice flashcards shuru karo")
        assertEquals(Kind.VOICE_FLASHCARD, fc.kind)

        val parsedCards = VoiceFlashcardManager.parseFlashcardLines(
            "Q: Force ki unit? | A: Newton | K: newton\n" +
            "Q: sin x derivative? | A: cos x | K: cos\n" +
            "Q: India capital? | A: New Delhi | K: delhi"
        )
        assertNotNull(parsedCards)
        assertEquals(3, parsedCards!!.size)

        val card = VoiceFlashcardManager.Flashcard("Force ki SI unit kya hai?", "Newton", listOf("newton"))
        assertTrue(VoiceFlashcardManager.matchesAnswer("newton hoti hai", card))
        assertFalse(VoiceFlashcardManager.matchesAnswer("meter", card))

        val privOn = parser.parse("Privacy mode on karo")
        assertEquals(Kind.PRIVACY_PAUSE, privOn.kind)
        assertEquals("on", privOn.query)

        val pauseAll = parser.parse("Pause everything")
        assertEquals(Kind.PRIVACY_PAUSE, pauseAll.kind)
        assertEquals("on", pauseAll.query)

        FollowUpTracker.markActive()
        val followUp = parser.parse("Isko aur simple samjhao")
        assertEquals(Kind.CHAT, followUp.kind)
        val shortFollowUp = parser.parse("Kyun?")
        assertEquals(Kind.CHAT, shortFollowUp.kind)
        FollowUpTracker.reset()
    }
}
