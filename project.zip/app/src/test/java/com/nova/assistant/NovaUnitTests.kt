package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NovaUnitTests {

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    @Before
    fun setUp() {
        index = AppIndex(null)
        index.setAppsForTest(
            listOf(
                AppInfo("WhatsApp", "com.whatsapp"),
                AppInfo("YouTube", "com.google.android.youtube"),
                AppInfo("Spotify", "com.spotify.music"),
                AppInfo("Roblox", "com.roblox.client"),
                AppInfo("Maps", "com.google.android.apps.maps"),
                AppInfo("Settings", "com.android.settings"),
                AppInfo("Instagram", "com.instagram.android"),
                AppInfo("Free Fire MAX", "com.dts.freefiremax")
            )
        )
        parser = CommandParser(index)
    }

    @Test
    fun testWakeWordsHeyHiOkayNova() {
        assertEquals("", WakeStopDetector.stripWake("Hey Nova"))
        assertEquals("", WakeStopDetector.stripWake("Hi Nova"))
        assertEquals("", WakeStopDetector.stripWake("Okay Nova"))
        assertEquals("", WakeStopDetector.stripWake("Ok Nova"))
        assertEquals("WhatsApp kholo", WakeStopDetector.stripWake("Hey Nova WhatsApp kholo"))
        assertEquals("YouTube par kahani search karo", WakeStopDetector.stripWake("Okay Nova YouTube par kahani search karo"))
        assertEquals("", WakeStopDetector.stripWake("hey nova", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("hi nova", isPartial = true))
        assertEquals("", WakeStopDetector.stripWake("okay nova", isPartial = true))
        assertNull(WakeStopDetector.stripWake("hello everyone how are you", isPartial = true))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("hey nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("hi nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("okay nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("hello nova"))
        assertTrue(OpenWakeWordEngine.MULTI_PHRASE_GRAMMAR.contains("\"hello\""))
        assertEquals("", WakeStopDetector.stripWake("Hello Nova"))
        assertNull(WakeStopDetector.stripWake("Hello"))
        assertNull(WakeStopDetector.stripWake("Hello", isPartial = true))
    }

    @Test
    fun testCriticalCreativeIntentRoutingNotYouTube() {
        // Test #9: "Nova kahani sunao" -> STORY (NEVER YouTube!)
        val story = parser.parse("Nova kahani sunao")
        assertEquals(Kind.STORY, story.kind)
        assertNull(story.app)
        assertEquals(AgentType.MAIN_ASSISTANT, MainAssistantAgent.selectAgent(story))

        val story2 = parser.parse("Nova, mujhe ek kahani sunao")
        assertEquals(Kind.STORY, story2.kind)

        // Test #10: "Nova joke sunao" -> JOKE
        val joke = parser.parse("Nova joke sunao")
        assertEquals(Kind.JOKE, joke.kind)
        assertNull(joke.app)

        // Shayari -> SHAYARI
        val shayari = parser.parse("Nova shayari sunao")
        assertEquals(Kind.SHAYARI, shayari.kind)
        assertNull(shayari.app)

        // "Nova gaana chalao" -> PLAY (music service, NOT YouTube search)
        val music = parser.parse("Nova gaana chalao")
        assertEquals(Kind.PLAY, music.kind)
        assertEquals("", music.query)

        // Test #11: "YouTube par kahani search karo" -> SEARCH on YouTube!
        val ytSearch = parser.parse("YouTube par kahani search karo")
        assertEquals(Kind.SEARCH, ytSearch.kind)
        assertEquals("com.google.android.youtube", ytSearch.app?.pkg)
        assertEquals("kahani", ytSearch.query)
    }

    @Test
    fun testUnknownCommandDoesNotRouteToYouTubeOrGoogle() {
        val unknown = parser.parse("aaj mujhe kuch samajh nahi aa raha kya karun")
        assertEquals(Kind.UNKNOWN, unknown.kind)
        assertNotEquals(Kind.SEARCH, unknown.kind)
        assertNotEquals(Kind.PLAY, unknown.kind)
    }

    @Test
    fun testPhase3And4VoiceCommandsAndAgents() {
        val bat = parser.parse("Hey Nova, battery kitni hai?")
        assertEquals(Kind.PHONE_INFO, bat.kind)
        assertEquals("battery", bat.query)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(bat))

        val wifi = parser.parse("Nova, Wi-Fi settings kholo")
        assertEquals(Kind.OPEN_SETTINGS, wifi.kind)
        assertEquals("wifi", wifi.query)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(wifi))

        val flashOn = parser.parse("Nova, flashlight on karo")
        assertEquals(Kind.FLASHLIGHT, flashOn.kind)
        assertEquals("on", flashOn.query)

        val flashOff = parser.parse("Nova, flashlight band karo")
        assertEquals(Kind.FLASHLIGHT, flashOff.kind)
        assertEquals("off", flashOff.query)

        val rem = parser.parse("Nova, kal subah reminder lagao")
        assertEquals(Kind.REMINDER, rem.kind)
        assertEquals(8, rem.extraHour)
        assertEquals(AgentType.DAILY_PLANNER, MainAssistantAgent.selectAgent(rem))

        val timer = parser.parse("Nova, 10 minute ka timer lagao")
        assertEquals(Kind.TIMER, timer.kind)
        assertEquals(10, timer.extraMinutes)
        assertEquals(AgentType.DAILY_PLANNER, MainAssistantAgent.selectAgent(timer))

        val notif = parser.parse("Nova, mere notifications summarize karo")
        assertEquals(Kind.SUMMARIZE_NOTIFICATIONS, notif.kind)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(notif))

        val storage = parser.parse("Nova, mere phone ki storage batao")
        assertEquals(Kind.PHONE_INFO, storage.kind)
        assertEquals("storage", storage.query)

        val ytOpen = parser.parse("Nova, YouTube kholo")
        assertEquals(Kind.OPEN, ytOpen.kind)
        assertEquals("com.google.android.youtube", ytOpen.app?.pkg)

        val weather = parser.parse("Nova, aaj ka weather batao")
        assertEquals(Kind.WEATHER, weather.kind)
        assertEquals(AgentType.TRAVEL, MainAssistantAgent.selectAgent(weather))

        val research = parser.parse("Nova, latest news batao")
        assertEquals(Kind.WEB_RESEARCH, research.kind)
        assertEquals(AgentType.RESEARCH, MainAssistantAgent.selectAgent(research))

        val screen = parser.parse("Nova, screen samjhao")
        assertEquals(Kind.SCREEN_ANALYZE, screen.kind)
        assertEquals(AgentType.PHONE, MainAssistantAgent.selectAgent(screen))

        val fileQ = parser.parse("Nova, pdf file summarize karo")
        assertEquals(Kind.FILE_ANALYZE, fileQ.kind)
        assertEquals(AgentType.FILE, MainAssistantAgent.selectAgent(fileQ))

        val task = parser.parse("Nova, task add karo physics revision")
        assertEquals(Kind.TASK_MANAGE, task.kind)
        assertEquals(AgentType.DAILY_PLANNER, MainAssistantAgent.selectAgent(task))
    }

    @Test
    fun testRailRadarTrainFlashcardsMemorySafetyAndMath() {
        val train = parser.parse("Nova, train 12562 ka live status batao")
        assertEquals(Kind.TRAIN_STATUS, train.kind)
        assertEquals("12562", RailRadarHelper.extractTrainNumber(train.query))
        assertEquals(AgentType.TRAVEL, MainAssistantAgent.selectAgent(train))

        val sampleJson = """{"success":true,"data":{"train":{"trainNumber":"12562","trainName":"Swatantrata Senani Exp"},"liveData":{"currentLocation":{"stationName":"Kanpur Central"},"overallDelayMinutes":18,"nextStationName":"Prayagraj Jn","nextStationDeparture":"05:35"}}}"""
        val spoken = RailRadarHelper.parseRailRadarLiveJson(sampleJson, "12562")
        assertNotNull(spoken)
        assertTrue(spoken!!.contains("Kanpur Central"))
        assertTrue(spoken.contains("18 minute late"))

        // Sensitive memory protection
        assertTrue(SmartMemory.isSensitive("Mera password 12345 hai"))
        assertTrue(SmartMemory.isSensitive("UPI PIN 4455 hai"))
        assertFalse(SmartMemory.isSensitive("Mera favourite music app Spotify hai"))

        // Offline math
        assertEquals("60", MathEvaluator.trySolve("25 plus 35 kitna hota hai"))
        assertEquals("12", MathEvaluator.trySolve("square root of 144"))

        // Stop commands & false-stop guards
        assertTrue(WakeStopDetector.isStopCommand("Nova Stop"))
        assertTrue(WakeStopDetector.isStopCommand("Band Karo"))
        assertFalse(WakeStopDetector.isStopCommand("bus stop near me"))
    }

    @Test
    fun testTrainNumberIsRemembered() {
        RailRadarHelper.rememberTrain("19619")
        assertEquals("19619", RailRadarHelper.recentTrainNo())
    }

    @Test
    fun testOpenAiCompatDefaults() {
        assertEquals("openrouter/free", OpenAiCompat.defaultModel(OpenAiCompat.OPENROUTER))
        assertEquals("Grok (xAI)", OpenAiCompat.label(OpenAiCompat.GROK))
        assertTrue(OpenAiCompat.friendly(OpenAiCompat.GROK, "HTTP 401: bad").contains("invalid"))
    }

    @Test
    fun testNovaV8UltimatePowerCommands() {
        val vol = parser.parse("Volume 75 percent karo")
        assertEquals(Kind.DEVICE_ACTION, vol.kind)
        assertEquals("volume_percent", vol.query)
        assertEquals("75", vol.body)

        val bright = parser.parse("Brightness 60 percent karo")
        assertEquals(Kind.DEVICE_ACTION, bright.kind)
        assertEquals("brightness_set", bright.query)
        assertEquals("60", bright.body)

        val ss = parser.parse("Nova screenshot lo")
        assertEquals(Kind.DEVICE_ACTION, ss.kind)
        assertEquals("screenshot", ss.query)

        val nav = parser.parse("Jaipur ka rasta dikhao")
        assertEquals(Kind.NAVIGATE, nav.kind)
        assertEquals("jaipur", nav.query)
        assertEquals(AgentType.TRAVEL, MainAssistantAgent.selectAgent(nav))

        val conv = UltimatePowerHelper.convertUnitsOffline("10 km ko miles me convert karo")
        assertNotNull(conv)
        assertTrue(conv!!.contains("6.21"))

        val note = parser.parse("Note likho kal physics notes lene hain")
        assertEquals(Kind.NOTE, note.kind)
        assertEquals("add", note.query)
        assertEquals(AgentType.MEMORY, MainAssistantAgent.selectAgent(note))

        val chain = UltimatePowerHelper.splitChainedCommands("Flashlight on karo aur volume 80 percent karo aur 5 minute ka timer lagao")
        assertEquals(3, chain.size)
    }

    @Test
    fun testSliderStepSnappingNeverProducesInvalidStep() {
        // 0.62f previously crashed Material3 Slider (stepSize = 0.05f) when opening Settings tab!
        assertEquals(0.60f, Prefs.snapStep05(0.62f, 0.45f, 0.85f), 0.0001f)
        assertEquals(0.65f, Prefs.snapStep05(0.65f, 0.45f, 0.85f), 0.0001f)
        assertEquals(0.45f, Prefs.snapStep05(0.10f, 0.45f, 0.85f), 0.0001f)
        assertEquals(0.85f, Prefs.snapStep05(0.99f, 0.45f, 0.85f), 0.0001f)
        assertEquals(1.05f, Prefs.snapStep05(1.03f, 0.75f, 1.50f), 0.0001f)
        assertEquals(0.75f, Prefs.snapStep05(Float.NaN, 0.75f, 1.50f), 0.0001f)
    }

    @Test
    fun testNovaV9AntiFalseTriggerWakeVerification() {
        // Must accept genuine 2-word wake phrases
        assertEquals("Hello Nova", OpenWakeWordEngine.verifyFullVocabTranscript("hello nova"))
        assertEquals("Hey Nova", OpenWakeWordEngine.verifyFullVocabTranscript("hey nova"))
        assertEquals("Hi Nova", OpenWakeWordEngine.verifyFullVocabTranscript("hi nova"))
        assertEquals("Okay Nova", OpenWakeWordEngine.verifyFullVocabTranscript("okay nova"))
        assertEquals("Hello Nova", OpenWakeWordEngine.verifyFullVocabTranscript("hello noah"))
        assertEquals("Hey Nova", OpenWakeWordEngine.verifyFullVocabTranscript("hey no va"))

        // Must STRICTLY REJECT standalone greetings, Hindi chatter, and long TV/room sentences!
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hello"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hey"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hi"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("okay"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hello bhai"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hello sir kaise ho"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hey there how are you doing today"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hello nova how are you doing today my friend"))
        assertEquals("Hello Nova", OpenWakeWordEngine.verifyFullVocabTranscript("hello nova battery kitni hai"))
        assertEquals("Hey Nova", OpenWakeWordEngine.verifyFullVocabTranscript("hey nova open whatsapp"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("kya hua bhai"))
        assertNull(OpenWakeWordEngine.verifyFullVocabTranscript("hello no"))
    }

    @Test
    fun testNovaV9ConnectivityAndSmartTvAndMacrosAndGst() {
        val wifiOff = parser.parse("Wi-Fi off karo")
        assertEquals(Kind.CONNECTIVITY, wifiOff.kind)
        assertEquals("wifi", wifiOff.query)
        assertEquals("off", wifiOff.body)

        val hsOn = parser.parse("Hotspot on karo")
        assertEquals(Kind.CONNECTIVITY, hsOn.kind)
        assertEquals("hotspot", hsOn.query)
        assertEquals("on", hsOn.body)

        val btOff = parser.parse("Bluetooth band karo")
        assertEquals(Kind.CONNECTIVITY, btOff.kind)
        assertEquals("bluetooth", btOff.query)
        assertEquals("off", btOff.body)

        val dataOn = parser.parse("Mobile data on karo")
        assertEquals(Kind.CONNECTIVITY, dataOn.kind)
        assertEquals("mobile_data", dataOn.query)
        assertEquals("on", dataOn.body)

        val tvYt = parser.parse("TV par YouTube kholo")
        assertEquals(Kind.SMART_TV, tvYt.kind)
        assertEquals("open_app", tvYt.query)
        assertEquals("youtube", tvYt.body)

        val tvVol = parser.parse("TV volume 5 badhao")
        assertEquals(Kind.SMART_TV, tvVol.kind)
        assertEquals("vol_up", tvVol.query)
        assertEquals("5", tvVol.body)

        val tvPlay = parser.parse("TV par Arijit Singh chalao")
        assertEquals(Kind.SMART_TV, tvPlay.kind)
        assertEquals("youtube_play", tvPlay.query)
        assertEquals("arijit singh", tvPlay.body)

        val tvOff = parser.parse("Smart TV off karo")
        assertEquals(Kind.SMART_TV, tvOff.kind)
        assertEquals("power_off", tvOff.query)

        val macro = parser.parse("Shortcut banao: raat ka mode matlab wifi off karo aur silent mode")
        assertEquals(Kind.MACRO_SAVE, macro.kind)
        assertEquals("raat ka mode", macro.query)

        val gst = MathEvaluator.trySolve("5000 par 18 percent GST kitna hoga")
        assertNotNull(gst)
        assertTrue(gst!!.contains("5900"))

        val disc = MathEvaluator.trySolve("2000 par 25 percent discount kitna hoga")
        assertNotNull(disc)
        assertTrue(disc!!.contains("1500"))

        // Verify Smart TV ADB RSA-2048 public key binary struct is exact 524 bytes & valid packet checksum
        val kpg = java.security.KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val kp = kpg.generateKeyPair()
        val pubBin = SmartTvController.buildAdbPublicKeyBinary(kp.public as java.security.interfaces.RSAPublicKey)
        assertEquals(524, pubBin.size)
        val pkt = SmartTvController.buildPacketBytes(0x4e584e43, 0x01000000, 4096, "host::nova".toByteArray())
        assertEquals(24 + 10, pkt.size)
    }

    @Test
    fun testNovaV10OrchestratorAiRouterMemoryWorkflowPdfAndExpenses() {
        // 1) Central Orchestrator: Travel Plan destination extraction & ActionStatus classification
        assertEquals("Jaipur", NovaOrchestrator.extractTravelDestination("Prepare my travel plan for Jaipur"))
        assertEquals("Delhi", NovaOrchestrator.extractTravelDestination("Delhi ka travel plan banao"))
        assertEquals("", NovaOrchestrator.extractTravelDestination("Nova prepare my travel plan"))
        assertEquals(ActionStatus.NEEDS_CONFIRMATION, NovaOrchestrator.classifyOutcome("Call Rahul? Haan ya Nahi bolo."))
        assertEquals(ActionStatus.NEEDS_PERMISSION, NovaOrchestrator.classifyOutcome("Accessibility permission allow karo."))
        assertEquals(ActionStatus.COMPLETED, NovaOrchestrator.classifyOutcome("Flashlight ON kar di hai."))

        // 2) Multi-Provider AI Router: primary + secondary fallback & exponential backoff
        assertEquals(
            listOf(OpenAiCompat.GEMINI, OpenAiCompat.GROK),
            AiRouter.selectProviders(OpenAiCompat.GEMINI, OpenAiCompat.GROK, hasPrimaryKey = true, hasSecondaryKey = true)
        )
        assertEquals(
            listOf(OpenAiCompat.GEMINI),
            AiRouter.selectProviders(OpenAiCompat.GEMINI, "none", hasPrimaryKey = true, hasSecondaryKey = false)
        )
        assertEquals(1200L, AiRouter.backoffDelayMs(0))
        assertEquals(2400L, AiRouter.backoffDelayMs(1))
        assertEquals(4800L, AiRouter.backoffDelayMs(2))

        // 3) SmartMemory: category inference, expiry parsing, duplicate detection
        assertEquals("study", SmartMemory.inferCategory("My physics exam is next month"))
        assertEquals("travel", SmartMemory.inferCategory("Preferred train is 12562"))
        assertTrue(SmartMemory.parseExpiryMs("7 din ke liye yaad rakho", 1000L) > 1000L)
        assertTrue(SmartMemory.isDuplicateText("Mera favourite app Spotify hai", listOf("mera favourite app spotify hai")))
        assertFalse(SmartMemory.isDuplicateText("Mera favourite app YouTube hai", listOf("Mera college Neem Ka Thana me hai")))

        // 4) Workflow Engine: delays, conditions, sensitive-step guard
        assertEquals(3, MacroStore.parseDelaySeconds("wait 3s"))
        assertEquals(5, MacroStore.parseDelaySeconds("delay 5 seconds"))
        assertTrue(MacroStore.evaluateCondition("if battery < 25: battery saver on karo", batteryPct = 18, charging = false, hourOfDay = 14, isOnline = true).first)
        assertFalse(MacroStore.evaluateCondition("if battery < 25: battery saver on karo", batteryPct = 80, charging = false, hourOfDay = 14, isOnline = true).first)
        assertTrue(MacroStore.evaluateCondition("if night: silent mode", batteryPct = 50, charging = false, hourOfDay = 23, isOnline = true).first)
        assertTrue(MacroStore.hasSensitiveStep("wifi off karo aur call Rahul"))
        assertFalse(MacroStore.hasSensitiveStep("wifi off karo aur brightness 20 percent karo"))

        // 5) Multi-Page PDF chunking & evidence selection
        val chunks = listOf(
            FileAssistant.DocChunk("Page 1", "Introduction to Newton laws of motion and inertia."),
            FileAssistant.DocChunk("Page 2", "Thermodynamics first law energy conservation formula."),
            FileAssistant.DocChunk("Page 3", "Optics Snell law refraction index calculation.")
        )
        val pickPage3 = FileAssistant.selectRelevantChunks(chunks, "Explain page 3")
        assertTrue(pickPage3.startsWith("[Page 3]"))
        val pickThermo = FileAssistant.selectRelevantChunks(chunks, "What is thermodynamics formula?")
        assertTrue(pickThermo.startsWith("[Page 2]"))

        // 6) Study Progress spaced revision intervals
        assertEquals(1L, StudyProgressStore.recommendedRevisionDays(55))
        assertEquals(3L, StudyProgressStore.recommendedRevisionDays(78))
        assertEquals(7L, StudyProgressStore.recommendedRevisionDays(92))

        // 7) Diagnostics secret sanitization
        val redacted = NovaDiagnostics.sanitizeDiagnosticText("Failed with AIzaSyAbCdEfGhIjKlMnOpQrStUvWxYz and Bearer secret_token_12345")
        assertFalse(redacted.contains("AIzaSy"))
        assertFalse(redacted.contains("secret_token_12345"))
        assertTrue(redacted.contains("[REDACTED_KEY]"))

        // 8) Multi-device Smart TV matching
        val tvs = listOf(TvDevice("Xiaomi Living Room TV", "192.168.1.10"), TvDevice("Bedroom TV", "192.168.1.25"))
        assertEquals("192.168.1.25", SmartTvController.matchDeviceBySpeech(tvs, "Bedroom TV off karo")?.ip)

        // 9) Offline INR Voice Expense Tracker & CommandParser routing
        val exp = ExpenseTrackerStore.parseExpense("250 rupaye kharch kiye chai nashta par")
        assertNotNull(exp)
        assertEquals(250.0, exp!!.amount, 0.01)
        assertEquals("Food", exp.category)

        val expCmd = parser.parse("500 rupaye kharch kiye petrol par")
        assertEquals(Kind.EXPENSE, expCmd.kind)
        val tpCmd = parser.parse("Nova Jaipur ka travel plan banao")
        assertEquals(Kind.TRAVEL_PLAN, tpCmd.kind)
        assertEquals("Jaipur", tpCmd.query)
        val spCmd = parser.parse("Nova mera study progress batao")
        assertEquals(Kind.STUDY_PROGRESS, spCmd.kind)
    }

    @Test
    fun testNovaV11VaultVivaCameraCallDigestAndOverlayParsers() {
        // 1) Multi-File Local RAG Knowledge Base Ranking
        val kbChunks = listOf(
            KbChunkRecord(1L, "Physics_Notes.pdf", "Page 2", "Newton second law states that force equals mass times acceleration F = ma."),
            KbChunkRecord(2L, "Organic_Chemistry.pdf", "Page 5", "Alkanes undergo free radical halogenation in presence of sunlight."),
            KbChunkRecord(3L, "Calculus.pdf", "Page 1", "Derivative of sin x is cos x and chain rule applies to composite functions.")
        )
        val topPhys = KnowledgeBaseStore.rankChunks(kbChunks, "Mere saved physics notes me se Newton second law explain karo", limit = 2)
        assertTrue(topPhys.isNotEmpty())
        assertEquals("Physics_Notes.pdf", topPhys.first().docName)

        val topChem = KnowledgeBaseStore.rankChunks(kbChunks, "Vault me se halogenation alkanes batao", limit = 2)
        assertTrue(topChem.isNotEmpty())
        assertEquals("Organic_Chemistry.pdf", topChem.first().docName)

        // 2) Viva / Interview Mode parsing & offline scoring
        val parsedQs = InterviewVivaManager.parseQuestions(
            "Q: What is Newton first law? | K: inertia, rest, motion\n" +
                "Q: Define work done in physics. | K: force, displacement, cos\n" +
                "Q: What is ohm law? | K: voltage, current, resistance"
        )
        assertNotNull(parsedQs)
        assertEquals(3, parsedQs!!.size)
        val (goodScore, _) = InterviewVivaManager.scoreAnswerOffline(
            "Newton first law defines inertia where a body stays at rest or uniform motion unless an external force acts",
            parsedQs.first()
        )
        assertTrue(goodScore >= 8)
        val (skipScore, _) = InterviewVivaManager.scoreAnswerOffline("pata nahi", parsedQs.first())
        assertTrue(skipScore <= 3)

        // 3) New v11.0 CommandParser intents
        assertEquals(Kind.CAMERA_LENS, parser.parse("Nova ye kya likha hai").kind)
        assertEquals(Kind.CAMERA_LENS, parser.parse("Camera lens kholo").kind)
        assertEquals(Kind.SCREEN_TRANSLATE, parser.parse("Isko translate karo").kind)
        assertEquals(Kind.SCREEN_REPLY, parser.parse("Iska reply draft karo").kind)
        assertEquals(Kind.VIVA_INTERVIEW, parser.parse("Airforce interview practice shuru karo").kind)
        assertEquals(Kind.VIVA_INTERVIEW, parser.parse("Physics viva shuru karo").kind)

        val ansCall = parser.parse("Call uthao")
        assertEquals(Kind.CALL_CONTROL, ansCall.kind)
        assertEquals("answer", ansCall.query)

        val rejCall = parser.parse("Call cut karo")
        assertEquals(Kind.CALL_CONTROL, rejCall.kind)
        assertEquals("reject", rejCall.query)

        assertEquals(Kind.UNREAD_DIGEST, parser.parse("Kis kis ke message aaye hain").kind)
        assertEquals(Kind.KB_SAVE, parser.parse("Is file ko vault me save karo").kind)
        assertEquals(Kind.KB_QUERY, parser.parse("Mere saved notes me se Newton laws explain karo").kind)
        assertEquals(Kind.KB_LIST, parser.parse("Vault files dikhao").kind)
    }
}
