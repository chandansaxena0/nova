package com.nova.assistant

import android.Manifest
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale

/**
 * Reads only Android-permitted device diagnostics:
 * Battery %, Battery Health, Internet, Wi-Fi, Bluetooth, Storage, Screen Time & App Usage.
 */
object PhoneInfoHelper {

    data class BatterySnapshot(val percent: Int, val charging: Boolean, val health: String, val tempC: Float)

    fun battery(context: Context): BatterySnapshot {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale else -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val healthCode = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val health = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Weak/Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Normal"
        }
        val tempC = (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return BatterySnapshot(pct, charging, health, tempC)
    }

    fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun internetStatus(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return "Offline (No Internet)"
        val caps = cm.getNetworkCapabilities(net) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Connected (Wi-Fi)"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Connected (Mobile Data)"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Connected (Ethernet)"
            else -> "Connected"
        }
    }

    fun wifiStatus(context: Context): String {
        return try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wm.isWifiEnabled) "Wi-Fi ON hai" else "Wi-Fi OFF hai"
        } catch (_: Exception) {
            "Wi-Fi status uplabdh nahi hai"
        }
    }

    fun bluetoothStatus(context: Context): String {
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            return "Bluetooth status ke liye Nearby Devices permission chahiye"
        }
        return try {
            val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = bm.adapter ?: return "Bluetooth hardware nahi mila"
            if (adapter.isEnabled) "Bluetooth ON hai" else "Bluetooth OFF hai"
        } catch (_: SecurityException) {
            "Bluetooth permission allow nahi hai"
        } catch (_: Exception) {
            "Bluetooth status check nahi ho paya"
        }
    }

    fun storageStatus(): String {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val availGb = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
            val totalGb = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
            String.format(Locale.US, "%.1f GB free hai (total %.1f GB me se)", availGb, totalGb)
        } catch (_: Exception) {
            "Storage info read nahi ho payi"
        }
    }

    fun hasUsageAccess(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    fun screenTimeAndUsage(context: Context, index: AppIndex): String {
        if (!hasUsageAccess(context)) {
            return "Screen time aur app usage dekhne ke liye Settings > Usage Access me Nova ko allow karo."
        }
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis())
                .orEmpty()
                .filter { it.totalTimeInForeground > 60_000L }
                .sortedByDescending { it.totalTimeInForeground }

            if (stats.isEmpty()) return "Aaj ka koi significant screen time record nahi hua hai."
            val totalMs = stats.sumOf { it.totalTimeInForeground }
            val totalMin = totalMs / 60_000L
            val hrs = totalMin / 60
            val mins = totalMin % 60
            val topApps = stats.take(3).joinToString(", ") { st ->
                val label = index.byPackage(st.packageName)?.label ?: st.packageName.substringAfterLast('.')
                val m = st.totalTimeInForeground / 60_000L
                "$label (${m}m)"
            }
            "Aaj ka total screen time lagbhag ${hrs} ghante ${mins} minute hai. Top apps: $topApps."
        } catch (_: Exception) {
            "App usage read karne me error aaya."
        }
    }

    fun memoryRamStatus(context: Context): String {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val availGb = String.format(Locale.US, "%.2f", mi.availMem / (1024.0 * 1024.0 * 1024.0))
            val totalGb = String.format(Locale.US, "%.2f", mi.totalMem / (1024.0 * 1024.0 * 1024.0))
            "RAM: ${availGb}GB free / ${totalGb}GB total" + if (mi.lowMemory) " (Low Memory)" else ""
        } catch (_: Exception) {
            "RAM info unavailable"
        }
    }

    fun fullSummary(context: Context, index: AppIndex): String {
        val b = battery(context)
        val chargeTag = if (b.charging) ", charging" else ""
        return buildString {
            append("Battery: ${b.percent}% (${b.health}$chargeTag, ${b.tempC}°C)\n")
            append("Internet: ${internetStatus(context)}\n")
            append("${wifiStatus(context)} | ${bluetoothStatus(context)}\n")
            append("Storage: ${storageStatus()}\n")
            append("${memoryRamStatus(context)}\n")
            if (hasUsageAccess(context)) {
                append(screenTimeAndUsage(context, index))
            } else {
                append("Screen Time: Usage Access permission chahiye")
            }
        }
    }
}
