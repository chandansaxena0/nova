package com.nova.assistant

import android.content.Context
import java.util.Locale

/**
 * Local Multi-File RAG Knowledge Base Vault for Nova v11.0:
 *   - Permanently indexes user-selected PDFs, DOCX, XLSX, PPTX, CSV, MD, and TXT files in SQLite.
 *   - Answers questions across ALL saved documents simultaneously with [Document • Page/Section] citations.
 *   - Zero external vector server required; runs 100% locally with weighted term + document-title scoring.
 */
object KnowledgeBaseStore {

    private val stopWords = setOf(
        "the", "and", "for", "with", "from", "that", "this", "what", "how", "why", "who",
        "mere", "mera", "meri", "saved", "notes", "vault", "file", "pdf", "explain", "batao",
        "karo", "mein", "me", "se", "ke", "ki", "ka", "ko", "hai", "hain", "kya", "about"
    )

    fun saveCurrentLoadedDoc(context: Context): String {
        val doc = FileAssistant.activeDoc
            ?: return "Abhi koi file loaded nahi hai. Pehle Hub tab me 'Pick File' se PDF/DOCX/TXT load karo, phir 'Save to Vault' dabao."
        val chunks: List<Pair<String, String>> = when {
            doc.chunks.isNotEmpty() -> doc.chunks.map { it.label to it.text }
            doc.textContent.isNotBlank() -> FileAssistant.chunkText(doc.textContent, 2200, "Section").map { it.label to it.text }
            else -> return "${doc.name} ek image ya scanned PDF hai jisme text extract nahi hua. Text-based PDF, DOCX, TXT, MD, CSV, XLSX ya PPTX Vault me save kar sakte ho."
        }
        val id = NovaMemoryDb.get(context).upsertKbDocument(doc.name, doc.kind, chunks)
        return if (id > 0L) {
            "'${doc.name}' (${chunks.size} indexed sections) Knowledge Vault me permanently save ho gayi! Ab bina file select kiye kabhi bhi sawal puchh sakte ho."
        } else {
            "File Knowledge Vault me save nahi ho payi."
        }
    }

    fun listDocs(context: Context): List<KbDocRecord> = NovaMemoryDb.get(context).getKbDocuments()

    fun deleteDoc(context: Context, docId: Long) {
        NovaMemoryDb.get(context).deleteKbDocument(docId)
    }

    fun clearVault(context: Context) {
        NovaMemoryDb.get(context).clearKbVault()
    }

    fun listDocsSummary(context: Context): String {
        val docs = listDocs(context)
        if (docs.isEmpty()) {
            return "Knowledge Vault abhi khali hai. Hub tab me koi PDF/DOCX/TXT load karke 'Save to Vault' dabao."
        }
        val lines = docs.take(8).mapIndexed { idx, d ->
            "${idx + 1}. ${d.name} (${d.kind.uppercase(Locale.ROOT)}, ${d.chunkCount} sections)"
        }
        return "Aapke Knowledge Vault me ${docs.size} saved files hain:\n" + lines.joinToString("\n")
    }

    /** Pure JVM-testable weighted multi-document chunk retriever (title match + keyword TF + rare-term boost). */
    fun rankChunks(chunks: List<KbChunkRecord>, query: String, limit: Int = 5): List<KbChunkRecord> {
        if (chunks.isEmpty()) return emptyList()
        val qTokens = query.lowercase(Locale.ROOT)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 3 && it !in stopWords }
            .distinct()
        if (qTokens.isEmpty()) return chunks.take(limit)

        val scored = chunks.map { ch ->
            val textLow = ch.text.lowercase(Locale.ROOT)
            val nameLow = ch.docName.lowercase(Locale.ROOT)
            var score = 0.0
            for (tok in qTokens) {
                if (nameLow.contains(tok)) score += 4.5
                var idx = textLow.indexOf(tok)
                var tf = 0
                while (idx >= 0 && tf < 6) {
                    tf++
                    idx = textLow.indexOf(tok, idx + tok.length)
                }
                if (tf > 0) {
                    val lenBoost = if (tok.length >= 6) 1.5 else 1.0
                    score += (2.0 + (tf - 1) * 0.7) * lenBoost
                }
            }
            ch to score
        }.filter { it.second > 0.0 }
            .sortedByDescending { it.second }

        return scored.take(limit).map { it.first }
    }

    fun queryVault(context: Context, userQuestion: String): String {
        val docs = listDocs(context)
        if (docs.isEmpty()) {
            return "Knowledge Vault khali hai. Hub me kisi PDF ya notes file ko load karke 'Save to Vault' dabao."
        }
        val allChunks = NovaMemoryDb.get(context).getAllKbChunks()
        val topChunks = rankChunks(allChunks, userQuestion, limit = 5)
        if (topChunks.isEmpty()) {
            val names = docs.take(4).joinToString(", ") { it.name }
            return "Aapke saved Vault files ($names) me '$userQuestion' se milta-julta direct content nahi mila."
        }

        val evidence = buildString {
            for (ch in topChunks) {
                val block = "[${ch.docName} • ${ch.label}]\n${ch.text.trim()}\n\n"
                if (length + block.length > 10_500 && isNotEmpty()) break
                append(block)
            }
        }.trim()

        if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
            val first = topChunks.first()
            return "Offline Vault match (${first.docName}, ${first.label}): ${first.text.replace(Regex("\\s+"), " ").take(380)}"
        }

        val sys = "You are Nova's Personal Knowledge Vault Agent. Answer STRICTLY from the user's saved study notes/documents below. Always cite the document name and page/section clearly (no markdown stars or hashtags). If the exact answer is not in the notes, say so honestly."
        val prompt = "User Question: $userQuestion\n\nMatched Passages from User's Vault:\n$evidence"
        return GeminiClient.askWithAgentPrompt(context, sys, prompt, keepContext = true, maxTokens = 750)
    }
}
