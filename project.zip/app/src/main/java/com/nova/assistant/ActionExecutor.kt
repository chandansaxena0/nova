package com.nova.assistant

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.MediaStore
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Asynchronous, non-blocking Action Executor with built-in Confirmation safety for sensitive actions:
 * Calls, WhatsApp/SMS messages, WhatsApp replies, Emergency location sharing, Duplicate contacts,
 * and Similar app names.
 */
object ActionExecutor {

    private const val YOUTUBE = "com.google.android.youtube"

    private val musicApps = listOf(
        "com.spotify.music",
        "com.google.android.apps.youtube.music",
        "com.jio.media.jiobeats",
        "com.gaana",
        "com.bsbportal.music",
        "com.amazon.mp3"
    )

    private val searchLinks = mapOf(
        "com.google.android.youtube" to "https://www.youtube.com/results?search_query={q}",
        "com.google.android.apps.youtube.music" to "https://music.youtube.com/search?q={q}",
        "com.spotify.music" to "spotify:search:{q}",
        "com.google.android.apps.maps" to "geo:0,0?q={q}",
        "com.android.chrome" to "https://www.google.com/search?q={q}",
        "com.google.android.googlequicksearchbox" to "https://www.google.com/search?q={q}",
        "com.amazon.mShop.android.shopping" to "https://www.amazon.in/s?k={q}",
        "in.amazon.mShop.android.shopping" to "https://www.amazon.in/s?k={q}",
        "com.flipkart.android" to "https://www.flipkart.com/search?q={q}",
        "com.jio.media.jiobeats" to "https://www.jiosaavn.com/search/{q}"
    )

    data class PendingConfirmation(
        val prompt: String,
        val createdAtMs: Long = SystemClock.elapsedRealtime(),
        val onConfirm: () -> String,
        val onChoice: ((String) -> String?)? = null
    )

    @Volatile
    var pending: PendingConfirmation? = null

    fun clearPending() {
        pending = null
    }

    fun hasActivePending(): Boolean {
        val p = pending ?: return false
        if (SystemClock.elapsedRealtime() - p.createdAtMs > 45_000L) {
            pending = null
            return false
        }
        return true
    }

    /** Handles voice/text reply to an active confirmation prompt ("Haan" / "Nahi" / choice). */
    fun handleConfirmationInput(raw: String, onDone: (String) -> Unit) {
        val p = pending ?: run {
            onDone("")
            return
        }
        val main = Handler(Looper.getMainLooper())
        thread {
            val answer = WakeStopDetector.parseConfirmation(raw)
            val result: String? = when {
                answer == WakeStopDetector.ConfirmAnswer.NO -> {
                    pending = null
                    "Theek hai, cancel kar diya."
                }
                p.onChoice != null -> {
                    val picked = p.onChoice.invoke(raw)
                    if (picked != null) {
                        pending = null
                        picked
                    } else if (answer == WakeStopDetector.ConfirmAnswer.YES) {
                        pending = null
                        p.onConfirm()
                    } else null
                }
                answer == WakeStopDetector.ConfirmAnswer.YES -> {
                    pending = null
                    p.onConfirm()
                }
                else -> null
            }
            main.post { onDone(result ?: "") }
        }
    }

    /** Executes [c] off the UI thread so network/location/AI work never freezes the app. */
    fun runAsync(context: Context, index: AppIndex, c: Command, onResult: (String) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        thread {
            val reply = try {
                executeInternal(context, index, c)
            } catch (e: Exception) {
                "Command chalane me error aaya: ${e.message?.take(100)}"
            }
            SmartMemory.recordCommand(context, c.heard, reply)
            main.post { onResult(reply) }
        }
    }

    private fun executeInternal(context: Context, index: AppIndex, c: Command): String = when (c.kind) {
        Kind.OPEN -> openApp(context, c)
        Kind.SEARCH -> search(context, c)
        Kind.PLAY -> play(context, index, c)
        Kind.ROBLOX -> RobloxHelper.launchGame(context, index, c.query)
        Kind.CALL -> prepareCall(context, c)
        Kind.MESSAGE -> prepareMessage(context, index, c)
        Kind.REPLY -> prepareReply(context, c)
        Kind.READ_WHATSAPP -> NovaNotificationListener.readLatestSummary()
        Kind.NEARBY -> {
            val place = NearbyPlacesHelper.detectPlaceType(c.query.ifEmpty { c.heard })
                ?: NearbyPlacesHelper.PlaceType("Petrol Pump", "\"amenity\"=\"fuel\"", "petrol pump near me")
            NearbyPlacesHelper.findNearestAndOpenMaps(context, place)
        }
        Kind.TRAIN_STATUS -> RailRadarHelper.getLiveTrainStatusVoice(context, c.query.ifEmpty { c.heard })
        Kind.TRAVEL_CHECKLIST -> RailRadarHelper.handleChecklistVoice(context, c.query.ifEmpty { c.heard })
        Kind.VOICE_FLASHCARD -> VoiceFlashcardManager.startSession(context, c.query.ifEmpty { c.heard })
        Kind.PRIVACY_PAUSE -> handlePrivacyPause(context, c.query)
        Kind.MUSIC_CONTROL -> musicControl(context, index, c.query)
        Kind.REMINDER -> createReminder(context, c)
        Kind.ALARM -> createAlarm(context, c)
        Kind.PHONE_INFO -> phoneInfo(context, index, c.query)
        Kind.WEATHER -> NearbyPlacesHelper.fetchWeather(context)
        Kind.DAILY_BRIEFING -> NearbyPlacesHelper.dailyBriefing(context, index)
        Kind.DATE_TIME -> currentDateTime()
        Kind.CLIPBOARD -> handleClipboard(context, c.query)
        Kind.TRANSLATE -> handleTranslate(context, c.query)
        Kind.STUDY -> handleStudy(context, c.query)
        Kind.MEMORY_SAVE -> {
            if (c.body.isBlank()) "Kya yaad rakhna hai? Bolo: yaad rakho mera favourite app Spotify hai."
            else {
                SmartMemory.addMemory(context, c.body)
                "Yaad rakh liya: \"${c.body}\"."
            }
        }
        Kind.MEMORY_LIST -> {
            val list = SmartMemory.getMemories(context)
            if (list.isEmpty()) "Abhi koi saved memory nahi hai."
            else "Aapki saved memories: " + list.take(5).joinToString("; ") { it.text }
        }
        Kind.EMERGENCY -> handleEmergency(context, c.query)
        Kind.CHAT -> {
            FollowUpTracker.markActive()
            GeminiClient.ask(context, c.query.ifEmpty { c.heard }, keepContext = !Prefs.privacyPaused(context))
        }
        Kind.AGENT -> startAgent(context, c.body)
        Kind.UNKNOWN ->
            "Samajh nahi aaya. Bolo jaise: \"WhatsApp kholo\", \"YouTube par MrBeast search karo\", ya \"mere sabse paas petrol pump\"."
    }

    // ---- Apps, Search, YouTube, Music ----
    private fun openApp(context: Context, c: Command): String {
        if (c.candidateApps.size >= 2) {
            val names = c.candidateApps.joinToString(" ya ") { it.label }
            val prompt = "Ek jaise apps mile: $names. Kaunsa kholun?"
            pending = PendingConfirmation(
                prompt = prompt,
                onConfirm = {
                    val first = c.candidateApps.first()
                    if (launch(context, first.pkg)) "${first.label} khul gaya." else "${first.label} khol nahi paya."
                },
                onChoice = { spoken ->
                    val k = Normalizer.key(HinglishConverter.toHinglish(spoken))
                    val picked = c.candidateApps.maxByOrNull { Normalizer.similarity(k, it.key) }
                    if (picked != null && Normalizer.similarity(k, picked.key) >= 0.45) {
                        if (launch(context, picked.pkg)) "${picked.label} khul gaya." else "${picked.label} khol nahi paya."
                    } else null
                }
            )
            return prompt
        }
        val app = c.app ?: return "Is naam ka installed app nahi mila: \"${c.heard}\""
        return if (launch(context, app.pkg)) "${app.label} khul gaya." else "${app.label} khol nahi paya."
    }

    private fun search(context: Context, c: Command): String {
        val q = HinglishConverter.toHinglish(c.query)
        val app = c.app
        if (q.isEmpty()) {
            return if (app != null) openApp(context, c)
            else "Kya search karun? Jaise: \"YouTube par MrBeast search karo\"."
        }
        if (app == null) {
            return if (view(context, "https://www.google.com/search?q=${Uri.encode(q)}", null))
                "Google par '$q' search kar raha hoon."
            else "Search nahi khul paya."
        }
        if (app.pkg == RobloxHelper.ROBLOX_PKG) {
            return RobloxHelper.launchGame(context, AppIndex(context).apply { refresh(true) }, q)
        }
        if (searchInApp(context, app, q)) return "${app.label} me '$q' search kar raha hoon."

        if (Prefs.geminiKey(context).isNotEmpty() && NovaAccessibility.instance != null) {
            launch(context, app.pkg)
            return startAgent(context, "In ${app.label}, search for \"$q\".")
        }
        copyToClipboard(context, q)
        launch(context, app.pkg)
        return "${app.label} khul gaya. '$q' copy kar diya hai, search box me paste kar do."
    }

    private fun play(context: Context, index: AppIndex, c: Command): String {
        val q = HinglishConverter.toHinglish(c.query)
        val prefPkg = Prefs.preferredMusicPkg(context)
        val installedMusic = musicApps.mapNotNull { index.byPackage(it) }
        val app: AppInfo? = c.app
            ?: (if (prefPkg.isNotEmpty()) index.byPackage(prefPkg) else null)
            ?: installedMusic.firstOrNull()

        if (q.isEmpty()) {
            if (installedMusic.isEmpty()) {
                return "Koi supported music app (Spotify, YouTube Music, JioSaavn) installed nahi mila. YouTube par gaana chalane ke liye gaane ka naam bolo."
            }
            return musicControl(context, index, "play_resume")
        }

        if (app?.pkg == YOUTUBE) return playYoutube(context, q)

        if (app == null) {
            // Do not blindly launch random apps — fall back cleanly to YouTube search
            return playYoutube(context, q)
        }

        val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(app.pkg)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (start(context, playIntent)) return "${app.label} me '$q' chala raha hoon."
        return search(context, c.copy(app = app))
    }

    private fun playYoutube(context: Context, q: String): String {
        val ok = view(context, "https://www.youtube.com/results?search_query=${Uri.encode(q)}", YOUTUBE)
            || view(context, "https://www.youtube.com/results?search_query=${Uri.encode(q)}", null)
        if (!ok) return "YouTube nahi khul paya."
        val acc = NovaAccessibility.instance
        return if (acc != null) {
            acc.playFirstYoutubeVideo()
            "YouTube par '$q' search karke pehla video chala raha hoon."
        } else {
            "YouTube par '$q' ke search results khol diye hain."
        }
    }

    private fun musicControl(context: Context, index: AppIndex, action: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (action) {
            "volume_up" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "Volume badha diya."
            }
            "volume_down" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "Volume kam kar diya."
            }
            "volume_max" -> {
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
                "Volume full kar diya."
            }
            "mute" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                "Volume mute kar diya."
            }
            "pause" -> {
                sendMediaKey(am, KeyEvent.KEYCODE_MEDIA_PAUSE)
                "Music pause kar diya."
            }
            "play_resume" -> {
                if (am.isMusicActive) {
                    "Music pehle se chal raha hai."
                } else {
                    val installedMusic = musicApps.mapNotNull { index.byPackage(it) }
                    if (installedMusic.isEmpty()) {
                        "Koi supported music app installed nahi hai. Kaunsa gaana YouTube par chalana hai bolo."
                    } else {
                        sendMediaKey(am, KeyEvent.KEYCODE_MEDIA_PLAY)
                        "Music play command bhej diya."
                    }
                }
            }
            "next" -> {
                sendMediaKey(am, KeyEvent.KEYCODE_MEDIA_NEXT)
                "Agla gaana laga diya."
            }
            "previous" -> {
                sendMediaKey(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "Pichla gaana laga diya."
            }
            else -> "Music control samajh nahi aaya."
        }
    }

    private fun sendMediaKey(am: AudioManager, keyCode: Int) {
        val now = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
        am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
    }

    // ---- Calling with Confirmation & Duplicate Contact Handling ----
    private fun prepareCall(context: Context, c: Command): String {
        val raw = c.contact.trim()
        if (raw.isEmpty()) return "Kisko call karun? Jaise: \"Rahul ko call karo\"."

        // Spoken numeric phone number
        if (raw.none { it.isLetter() }) {
            val digits = raw.filter { it.isDigit() || it == '+' }
            if (digits.length >= 3) {
                val prompt = "$digits par call lagau? Haan ya Nahi bolo."
                pending = PendingConfirmation(prompt = prompt, onConfirm = { executeCall(context, digits, digits) })
                return prompt
            }
        }

        if (!granted(context, Manifest.permission.READ_CONTACTS)) {
            return "Contacts ki permission chahiye. Nova ke Settings tab se Contacts allow karo."
        }

        val hits = Contacts.findAll(context, c.contactKey, limit = 3)
        if (hits.isEmpty()) return "\"$raw\" naam ka contact nahi mila."

        if (hits.size > 1) {
            val listText = hits.mapIndexed { idx, h -> "${idx + 1}. ${h.name}" }.joinToString(", ")
            val prompt = "Ek se zyada contacts mile: $listText. Kisko call lagau? Naam ya number 1, 2 bolo."
            pending = PendingConfirmation(
                prompt = prompt,
                onConfirm = { executeCall(context, hits.first().name, hits.first().number) },
                onChoice = { spoken ->
                    val chosen = pickContactChoice(hits, spoken)
                    if (chosen != null) executeCall(context, chosen.name, chosen.number) else null
                }
            )
            return prompt
        }

        val hit = hits.first()
        val prompt = "Kya main ${hit.name} ko call lagau? Haan ya Nahi bolo."
        pending = PendingConfirmation(
            prompt = prompt,
            onConfirm = { executeCall(context, hit.name, hit.number) }
        )
        return prompt
    }

    private fun executeCall(context: Context, name: String, number: String): String {
        val canCall = granted(context, Manifest.permission.CALL_PHONE)
        val i = Intent(
            if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL,
            Uri.parse("tel:" + Uri.encode(number))
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return when {
            !start(context, i) -> "Call nahi lag paya."
            canCall -> "$name ko call laga raha hoon."
            else -> "$name ka number dialer me khol diya hai."
        }
    }

    // ---- WhatsApp / SMS Messaging with Mandatory Confirmation ----
    private fun prepareMessage(context: Context, index: AppIndex, c: Command): String {
        if (c.contact.isBlank()) return "Kisko message bhejun? Jaise: \"Rahul ko WhatsApp par message bhejo ki main aa raha hoon\"."
        val body = HinglishConverter.toHinglish(c.body)
        if (body.isBlank()) return "Kya message likhun? Jaise: \"Rahul ko message bhejo ki main 5 minute me aa raha hoon\"."

        if (!granted(context, Manifest.permission.READ_CONTACTS)) {
            return "Contacts permission allow karo taaki contact dhoondh sakun."
        }

        val hits = Contacts.findAll(context, c.contactKey, limit = 3)
        if (hits.isEmpty()) return "\"${c.contact}\" naam ka contact nahi mila."

        val waPkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { index.isInstalled(it) }
        val useSms = c.sms || (c.app != null && c.app.label.lowercase().contains("messag")) || waPkg == null
        val channelName = if (useSms) "SMS" else "WhatsApp"

        if (hits.size > 1) {
            val listText = hits.mapIndexed { i, h -> "${i + 1}. ${h.name}" }.joinToString(", ")
            val prompt = "$listText me se kisko $channelName message bhejun: \"$body\"? Naam ya 1, 2 bolo."
            pending = PendingConfirmation(
                prompt = prompt,
                onConfirm = { dispatchMessage(context, hits.first(), body, useSms, waPkg) },
                onChoice = { spoken ->
                    val chosen = pickContactChoice(hits, spoken)
                    if (chosen != null) dispatchMessage(context, chosen, body, useSms, waPkg) else null
                }
            )
            return prompt
        }

        val hit = hits.first()
        val prompt = "${hit.name} ko $channelName par bhejun: \"$body\"? Haan ya Nahi bolo."
        pending = PendingConfirmation(
            prompt = prompt,
            onConfirm = { dispatchMessage(context, hit, body, useSms, waPkg) }
        )
        return prompt
    }

    private fun dispatchMessage(context: Context, hit: ContactHit, body: String, useSms: Boolean, waPkg: String?): String {
        return if (!useSms && waPkg != null) {
            val digits = waNumber(hit.number)
            val ok = view(context, "https://wa.me/$digits?text=${Uri.encode(body)}", waPkg)
            if (!ok) return "WhatsApp nahi khul paya."
            val acc = NovaAccessibility.instance
            if (acc != null) {
                acc.sendWhatsApp()
                "${hit.name} ko WhatsApp par message bhej raha hoon: \"$body\""
            } else {
                "${hit.name} ka WhatsApp chat khol diya aur message Hinglish me likh diya hai. Send dabao."
            }
        } else {
            sendSms(context, hit, body)
        }
    }

    private fun prepareReply(context: Context, c: Command): String {
        val body = HinglishConverter.toHinglish(c.body)
        if (body.isBlank()) return "Kya reply bhejun? Jaise: \"Reply karo main thodi der me call karta hoon\"."
        if (!NovaNotificationListener.connected) {
            return "WhatsApp reply ke liye Nova me Notification Access ON karo."
        }
        val target = NovaNotificationListener.findTarget(c.contactKey)
            ?: return if (c.contact.isBlank()) "Abhi koi naya chat notification nahi hai."
            else "\"${c.contact}\" ka koi naya notification nahi mila."

        val prompt = "${target.sender} ko reply bhejun: \"$body\"? Haan ya Nahi bolo."
        pending = PendingConfirmation(
            prompt = prompt,
            onConfirm = { NovaNotificationListener.sendInlineReply(context, target, body) }
        )
        return prompt
    }

    private fun pickContactChoice(hits: List<ContactHit>, spoken: String): ContactHit? {
        val lower = HinglishConverter.toHinglish(spoken).lowercase(Locale.ROOT)
        return when {
            lower.contains("1") || lower.contains("first") || lower.contains("pehla") -> hits.getOrNull(0)
            lower.contains("2") || lower.contains("second") || lower.contains("doosra") || lower.contains("dusra") -> hits.getOrNull(1)
            lower.contains("3") || lower.contains("third") || lower.contains("teesra") -> hits.getOrNull(2)
            else -> {
                val k = Normalizer.key(lower)
                hits.maxByOrNull { Normalizer.similarity(k, Normalizer.key(HinglishConverter.toHinglish(it.name))) }
                    ?.takeIf { Normalizer.similarity(k, Normalizer.key(HinglishConverter.toHinglish(it.name))) >= 0.45 }
            }
        }
    }

    // ---- Reminders & Alarms ----
    private fun createReminder(context: Context, c: Command): String {
        val triggerMs = computeTriggerTime(c)
        val item = ReminderStore.add(context, c.body, triggerMs, repeatDaily = c.heard.lowercase().contains("daily") || c.heard.lowercase().contains("roz"))
        return "Reminder set ho gaya: \"${item.title}\" — ${ReminderStore.formatTime(item.triggerAtMs)}."
    }

    private fun createAlarm(context: Context, c: Command): String {
        val cal = Calendar.getInstance()
        if (c.extraHour in 0..23) {
            cal.set(Calendar.HOUR_OF_DAY, c.extraHour)
            cal.set(Calendar.MINUTE, c.extraMinute.coerceIn(0, 59))
        } else {
            cal.add(Calendar.MINUTE, if (c.extraMinutes > 0) c.extraMinutes else 10)
        }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, cal.get(Calendar.HOUR_OF_DAY))
            putExtra(AlarmClock.EXTRA_MINUTES, cal.get(Calendar.MINUTE))
            putExtra(AlarmClock.EXTRA_MESSAGE, c.body)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (start(context, intent)) {
            "Alarm set ho gaya ${cal.get(Calendar.HOUR_OF_DAY)}:${String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE))} ke liye."
        } else {
            // Fallback to Nova's own exact reminder alarm
            val item = ReminderStore.add(context, "Alarm: ${c.body}", cal.timeInMillis)
            "Nova alarm set ho gaya: ${ReminderStore.formatTime(item.triggerAtMs)}."
        }
    }

    private fun computeTriggerTime(c: Command): Long {
        val cal = Calendar.getInstance()
        if (c.extraMinutes > 0) {
            cal.add(Calendar.MINUTE, c.extraMinutes)
            return cal.timeInMillis
        }
        if (c.extraHour in 0..23) {
            cal.set(Calendar.HOUR_OF_DAY, c.extraHour)
            cal.set(Calendar.MINUTE, c.extraMinute.coerceIn(0, 59))
            cal.set(Calendar.SECOND, 0)
            if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
            return cal.timeInMillis
        }
        cal.add(Calendar.MINUTE, 10)
        return cal.timeInMillis
    }

    // ---- Phone Info, Date/Time, Clipboard, Translate, Study, Emergency ----
    private fun phoneInfo(context: Context, index: AppIndex, topic: String): String = when (topic) {
        "battery" -> {
            val b = PhoneInfoHelper.battery(context)
            val ch = if (b.charging) "charging par hai" else "charging par nahi hai"
            "Phone battery ${b.percent}% hai, $ch. Battery health ${b.health} aur temperature ${b.tempC} degree Celsius hai."
        }
        "wifi" -> PhoneInfoHelper.wifiStatus(context)
        "bluetooth" -> PhoneInfoHelper.bluetoothStatus(context)
        "internet" -> "Internet status: ${PhoneInfoHelper.internetStatus(context)}."
        "storage" -> "Phone me ${PhoneInfoHelper.storageStatus()}."
        "screentime" -> PhoneInfoHelper.screenTimeAndUsage(context, index)
        else -> PhoneInfoHelper.fullSummary(context, index)
    }

    private fun currentDateTime(): String {
        val dateStr = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.ENGLISH).format(Date())
        val timeStr = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date())
        return "Aaj $dateStr hai aur abhi $timeStr baj rahe hain."
    }

    private fun handleClipboard(context: Context, op: String): String {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = try {
            cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
        if (clip.isEmpty()) {
            return "Clipboard khali hai (Android privacy ke karan clipboard sirf tab read hota hai jab Nova screen par ho)."
        }
        return when (op) {
            "read" -> "Clipboard me likha hai: ${clip.take(300)}"
            "summarize" -> GeminiClient.ask(context, "Summarize this copied text in 2-3 short Hinglish sentences:\n$clip", keepContext = false)
            "translate" -> GeminiClient.ask(context, "Translate this text between Hindi/Hinglish and English clearly:\n$clip", keepContext = false)
            "grammar" -> GeminiClient.ask(context, "Fix grammar and make this text clean and natural:\n$clip", keepContext = false)
            "reply" -> GeminiClient.ask(context, "Draft a short polite Hinglish reply to this message:\n$clip", keepContext = false)
            else -> "Clipboard: ${clip.take(300)}"
        }
    }

    private fun handleTranslate(context: Context, query: String): String {
        return GeminiClient.ask(
            context,
            "Handle this translation, grammar correction, or simplification request clearly (no markdown):\n$query",
            keepContext = false
        )
    }

    private fun handleStudy(context: Context, query: String): String {
        MathEvaluator.trySolve(query)?.let { ans ->
            return "Iska answer hai: $ans."
        }
        FollowUpTracker.markActive()
        return GeminiClient.ask(
            context,
            "Act as a clear Indian Maths & Science tutor. Answer in simple Hinglish/English step-by-step (no markdown symbols):\n$query",
            keepContext = !Prefs.privacyPaused(context)
        )
    }

    private fun handleEmergency(context: Context, mode: String): String {
        val savedName = Prefs.emergencyName(context)
        val savedNum = Prefs.emergencyNumber(context)

        if (mode == "location") {
            val targetName = savedName.ifEmpty { "Emergency Contact" }
            val prompt = if (savedNum.isNotEmpty()) {
                "Kya main aapki current GPS location $targetName ($savedNum) ke saath share karun? Haan ya Nahi bolo."
            } else {
                "Kya main aapki current GPS location share karne ke liye Android Share sheet kholun? Haan ya Nahi bolo."
            }
            pending = PendingConfirmation(
                prompt = prompt,
                onConfirm = {
                    val link = NearbyPlacesHelper.getLocationShareLink(context)
                        ?: return@PendingConfirmation "Location nahi mili. Location permission aur GPS ON karo."
                    val msg = "EMERGENCY: Mujhe madad chahiye. Meri live location: $link"
                    if (savedNum.isNotEmpty()) {
                        sendSms(context, ContactHit(targetName, savedNum, 1.0), msg)
                    } else {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, msg)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        if (start(context, Intent.createChooser(share, "Share Emergency Location").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))) {
                            "Emergency location share sheet khol diya."
                        } else "Share nahi khul paya."
                    }
                }
            )
            return prompt
        }

        val dialNum = if (mode == "call" && savedNum.isNotEmpty()) savedNum else "112"
        val label = if (dialNum == "112") "Emergency Helpline 112" else savedName
        val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$dialNum")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (start(context, i)) {
            "$label dialer me khol diya hai. India Emergency: 112 (All), 100 (Police), 108 (Ambulance)."
        } else "Emergency dialer nahi khul paya."
    }

    fun pauseEverything(context: Context): String {
        Prefs.setPrivacyPaused(context, true)
        Prefs.setWake(context, false)
        clearPending()
        VoiceFlashcardManager.stopSession()
        FollowUpTracker.reset()
        GeminiClient.clearChatHistory()
        NovaAccessibility.instance?.stopAgent()
        context.stopService(Intent(context, ListenService::class.java))
        NovaState.update(
            mode = ListenMode.STOPPED,
            status = "Privacy Pause ON — Wake, Mic, History & AI Context paused.",
            micActive = false,
            remainingSec = 0
        )
        return "Privacy mode ON. Wake word, background mic, history saving aur AI chat context sab pause kar diye hain."
    }

    fun resumeFromPrivacyPause(context: Context): String {
        Prefs.setPrivacyPaused(context, false)
        NovaState.update(status = "Privacy Pause OFF — Nova ready hai.")
        return "Privacy mode OFF. Nova dobara normal mode me ready hai."
    }

    private fun handlePrivacyPause(context: Context, mode: String): String =
        if (mode == "off") resumeFromPrivacyPause(context) else pauseEverything(context)

    // ---- Helpers ----
    private fun startAgent(context: Context, goal: String): String {
        val key = Prefs.geminiKey(context)
        val acc = NovaAccessibility.instance
        return when {
            goal.isBlank() -> "Kya karna hai samajh nahi aaya."
            key.isEmpty() -> "Screen automation ke liye Settings me Gemini key save karo."
            acc == null -> "Screen automation ke liye Accessibility ON karo."
            else -> {
                acc.startAgent(goal, key, Prefs.geminiModel(context))
                "Nova ye kaam kar raha hai: $goal"
            }
        }
    }

    private fun waNumber(number: String): String {
        var d = number.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        else if (d.length == 11 && d.startsWith("0")) d = "91" + d.drop(1)
        else if (d.length == 10) d = "91$d"
        return d
    }

    private fun sendSms(context: Context, hit: ContactHit, body: String): String {
        if (granted(context, Manifest.permission.SEND_SMS)) {
            try {
                val sm = smsManager(context)
                sm.sendMultipartTextMessage(hit.number, null, sm.divideMessage(body), null, null)
                return "${hit.name} ko SMS bhej diya."
            } catch (_: Exception) {}
        }
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(hit.number)))
            .putExtra("sms_body", body)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (start(context, i)) "${hit.name} ka SMS khul gaya, Send dabao." else "SMS nahi khul paya."
    }

    @Suppress("DEPRECATION")
    private fun smsManager(context: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) context.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()

    private fun granted(context: Context, p: String): Boolean =
        ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    private fun searchInApp(context: Context, app: AppInfo, q: String): Boolean {
        val link = searchLinks[app.pkg]
        if (link != null && view(context, link.replace("{q}", Uri.encode(q)), app.pkg)) return true
        val i = Intent(Intent.ACTION_SEARCH).apply {
            setPackage(app.pkg)
            putExtra(SearchManager.QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return start(context, i)
    }

    private fun launch(context: Context, pkg: String): Boolean {
        val i = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return start(context, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun view(context: Context, url: String, pkg: String?): Boolean {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        return start(context, i)
    }

    private fun start(context: Context, i: Intent): Boolean = try {
        context.startActivity(i)
        true
    } catch (_: ActivityNotFoundException) {
        false
    } catch (_: SecurityException) {
        false
    }

    private fun copyToClipboard(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("nova", text))
    }
}
