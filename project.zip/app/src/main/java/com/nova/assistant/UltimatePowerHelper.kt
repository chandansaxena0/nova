package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Nova v8.0 Ultimate Power Engine:
 * - Multi-command chaining ("Flashlight on karo aur volume 80 percent karo")
 * - Full device & hardware controls (exact volume %, silent/vibrate/normal, brightness, camera/selfie/video, UPI launcher, websites, email)
 * - Hands-free OS navigation (back, home, recents, notifications, quick settings, screenshot, lock, scroll, click text, type text)
 * - Turn-by-turn Google Maps navigation
 * - Offline utilities: Unit Converter, Coin Toss, Dice Roll, Random Number, Stopwatch, persistent Voice Notes
 */
object UltimatePowerHelper {

    private const val PREFS_NOTES = "nova_voice_notes"
    private const val KEY_NOTES = "notes_json"

    @Volatile
    private var stopwatchStartMs: Long = 0L

    private val upiPackages = listOf(
        "net.one97.paytm",
        "com.phonepe.app",
        "com.google.android.apps.nbu.paisa.user",
        "in.org.npci.upiapp",
        "com.amazon.mShop.android.shopping"
    )

    private val chainSplitRegex = Regex(
        "\\s+(?:and\\s+then|uske\\s+baad|phir|fir|then)\\s+|\\s+(?:aur|and)\\s+",
        RegexOption.IGNORE_CASE
    )

    fun splitChainedCommands(raw: String): List<String> {
        val clean = HinglishConverter.toHinglish(raw).trim()
        if (clean.length < 14) return listOf(clean)
        val lower = clean.lowercase(Locale.ROOT)
        if (lower.contains("shortcut banao") || lower.contains("macro banao") || lower.contains("message") || lower.contains("whatsapp") || lower.contains("sms") ||
            lower.contains("kahani") || lower.contains("story") || lower.contains("train") ||
            lower.contains("depart") || lower.contains("note ") || lower.contains("yaad rakho") ||
            lower.contains("email")
        ) {
            return listOf(clean)
        }
        val parts = chainSplitRegex.split(clean).map { it.trim() }.filter { it.length >= 4 }
        if (parts.size < 2 || parts.size > 4) return listOf(clean)

        val actionHint = Regex(
            "\\b(on|off|band|chalu|kholo|open|karo|lagao|batao|badhao|kam|mute|unmute|silent|vibrate|scroll|tap|click|screenshot|lock|back|home|timer|alarm|reminder|flashlight|torch|volume|brightness|camera|selfie|navigate|rasta|play|chalao|pause|next|stop|coin|dice|stopwatch|battery|weather|wifi|wi-fi|bluetooth|hotspot|data|airplane|rotate|dnd|tv)\\b"
        )
        return if (parts.count { actionHint.containsMatchIn(it.lowercase(Locale.ROOT)) } >= 2) parts else listOf(clean)
    }

    fun executeDeviceAction(context: Context, index: AppIndex, op: String, arg: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (op) {
            "volume_percent" -> {
                val pct = arg.toIntOrNull()?.coerceIn(0, 100) ?: 50
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val target = ((pct / 100.0) * max).roundToInt().coerceIn(0, max)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
                "Media volume $pct percent par set kar diya hai."
            }
            "unmute" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                if (am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {
                    val half = (am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 2).coerceAtLeast(1)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, half, AudioManager.FLAG_SHOW_UI)
                }
                "Volume unmute kar diya hai."
            }
            "ringer_silent" -> setRingerMode(am, AudioManager.RINGER_MODE_SILENT, "Phone silent mode par kar diya hai.")
            "ringer_vibrate" -> setRingerMode(am, AudioManager.RINGER_MODE_VIBRATE, "Phone vibrate mode par kar diya hai.")
            "ringer_normal" -> setRingerMode(am, AudioManager.RINGER_MODE_NORMAL, "Phone normal sound mode par kar diya hai.")
            "brightness_set" -> setBrightness(context, arg.toIntOrNull()?.coerceIn(5, 100) ?: 60)
            "brightness_up" -> adjustBrightness(context, +25)
            "brightness_down" -> adjustBrightness(context, -25)

            "nav_back" -> runAcc("Back chala gaya.") { it.performBack() }
            "nav_home" -> runAcc("Home screen par aa gaya.") { it.performHome() }
            "nav_recents" -> runAcc("Recent apps khol diye hain.") { it.performRecents() }
            "nav_notifs" -> runAcc("Notification panel khol diya hai.") { it.performNotifications() }
            "nav_quick_settings" -> runAcc("Quick Settings panel khol diya hai.") { it.performQuickSettings() }
            "screenshot" -> runAcc("Screenshot le liya hai.") { it.performScreenshot() }
            "lock_screen" -> runAcc("Screen lock kar di hai.") { it.performLockScreen() }
            "scroll_down" -> runAcc("Neeche scroll kar diya hai.") { it.scrollScreen(down = true) }
            "scroll_up" -> runAcc("Upar scroll kar diya hai.") { it.scrollScreen(down = false) }
            "tap_text" -> {
                val acc = NovaAccessibility.instance
                    ?: return "Screen par tap karne ke liye Settings me Nova Accessibility enable karo."
                if (arg.isBlank()) return "Screen par kis button ya text par tap karna hai?"
                if (acc.clickByText(arg)) "\"$arg\" par tap kar diya hai."
                else "Screen par \"$arg\" nahi mila."
            }
            "type_text" -> {
                val acc = NovaAccessibility.instance
                    ?: return "Hands-free type karne ke liye Settings me Nova Accessibility enable karo."
                if (arg.isBlank()) return "Kya type karna hai?"
                if (acc.typeIntoFocused(arg)) "Type kar diya: \"$arg\"."
                else "Koi active text box screen par nahi mila."
            }

            "camera_photo" -> launchIntent(
                context,
                Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                "Camera khol diya hai."
            )
            "camera_selfie" -> {
                val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    putExtra("android.intent.extras.CAMERA_FACING", 1)
                    putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
                    putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntent(context, i, "Selfie camera khol diya hai.")
            }
            "camera_video" -> launchIntent(
                context,
                Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                "Video camera khol diya hai."
            )
            "open_upi" -> {
                val installed = upiPackages.mapNotNull { index.byPackage(it) }.firstOrNull()
                if (installed != null) {
                    val li = context.packageManager.getLaunchIntentForPackage(installed.pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (li != null) {
                        context.startActivity(li)
                        "${installed.label} khol diya hai. Payment aap khud verify karke karo."
                    } else "UPI app open nahi ho paya."
                } else "Koi UPI app (Paytm, PhonePe, GPay, BHIM) installed nahi mila."
            }
            "open_website" -> {
                val url = if (arg.startsWith("http://") || arg.startsWith("https://")) arg else "https://$arg"
                launchIntent(
                    context,
                    Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    "Website khol raha hoon: $arg"
                )
            }
            "compose_email" -> {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
                    if (arg.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, arg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntent(context, i, "Email app khol diya hai.")
            }
            else -> "Device action samajh nahi aaya."
        }
    }

    private fun setRingerMode(am: AudioManager, mode: Int, okMsg: String): String = try {
        am.ringerMode = mode
        okMsg
    } catch (_: SecurityException) {
        "Silent/Vibrate mode change karne ke liye Do Not Disturb access chahiye."
    } catch (e: Exception) {
        "Ringer mode change nahi ho paya: ${e.message?.take(60)}"
    }

    private fun setBrightness(context: Context, pct: Int): String {
        if (!Settings.System.canWrite(context)) {
            runCatching {
                val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
            }
            return "Brightness control ke liye 'Modify system settings' permission allow karo — settings khol di hain."
        }
        return try {
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            val val255 = ((pct / 100.0) * 255.0).roundToInt().coerceIn(10, 255)
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, val255)
            "Screen brightness $pct percent set kar di hai."
        } catch (_: Exception) {
            PhoneControlHelper.openSettingsPage(context, "display")
        }
    }

    private fun adjustBrightness(context: Context, deltaPct: Int): String {
        val cur = runCatching {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        }.getOrDefault(128)
        val curPct = ((cur / 255.0) * 100.0).roundToInt()
        return setBrightness(context, (curPct + deltaPct).coerceIn(10, 100))
    }

    private fun runAcc(successMsg: String, block: (NovaAccessibility) -> Boolean): String {
        val acc = NovaAccessibility.instance
            ?: return "Is hands-free command ke liye Settings tab me Nova Accessibility service ON karo."
        return if (block(acc)) successMsg else "Ye action abhi execute nahi ho paya."
    }

    private fun launchIntent(context: Context, intent: Intent, okMsg: String): String = try {
        context.startActivity(intent)
        okMsg
    } catch (_: Exception) {
        "Ye app ya action is phone par available nahi hai."
    }

    fun navigateToPlace(context: Context, destination: String): String {
        val dest = destination.trim()
        if (dest.isEmpty()) return "Kahan ka rasta dikhana hai? Bolo jaise: 'Jaipur ka rasta dikhao'."
        val navIntent = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(dest)}")).apply {
            setPackage("com.google.android.apps.maps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(navIntent)
            "Google Maps me $dest ke liye navigation shuru kar diya hai."
        } catch (_: Exception) {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${Uri.encode(dest)}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            launchIntent(context, web, "$dest ka rasta Maps me khol diya hai.")
        }
    }

    fun handleUtility(op: String, rawQuery: String): String = when (op) {
        "coin" -> "Sikka uchhala... result hai: ${if (Random.nextBoolean()) "Heads" else "Tails"}!"
        "dice" -> "Dice roll kiya... number aaya hai: ${Random.nextInt(1, 7)}!"
        "random" -> {
            val nums = Regex("\\d+").findAll(rawQuery).mapNotNull { it.value.toIntOrNull() }.toList()
            val lo = if (nums.size >= 2) minOf(nums[0], nums[1]) else 1
            val hi = if (nums.size >= 2) maxOf(nums[0], nums[1]) else if (nums.size == 1 && nums[0] > 1) nums[0] else 100
            "Random number ($lo se $hi ke beech): ${Random.nextInt(lo, hi + 1)}."
        }
        "stopwatch_start" -> {
            stopwatchStartMs = SystemClock.elapsedRealtime()
            "Stopwatch shuru kar diya hai."
        }
        "stopwatch_check" -> {
            if (stopwatchStartMs <= 0L) "Abhi koi stopwatch nahi chal raha."
            else {
                val sec = (SystemClock.elapsedRealtime() - stopwatchStartMs) / 1000L
                "Stopwatch time: ${sec / 60L} minute ${sec % 60L} second."
            }
        }
        "stopwatch_stop" -> {
            if (stopwatchStartMs <= 0L) "Koi stopwatch active nahi tha."
            else {
                val sec = (SystemClock.elapsedRealtime() - stopwatchStartMs) / 1000L
                stopwatchStartMs = 0L
                "Stopwatch rok diya. Total time: ${sec / 60L} minute ${sec % 60L} second."
            }
        }
        "unit_convert" -> convertUnitsOffline(rawQuery) ?: "Unit conversion samajh nahi aaya. Bolo jaise: '10 km ko miles me convert karo'."
        else -> "Utility command samajh nahi aaya."
    }

    fun convertUnitsOffline(raw: String): String? {
        val lower = raw.lowercase(Locale.ROOT)
        val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*(km|kilometer|kilometre|miles?|mi|kg|kilogram|pounds?|lbs?|cm|centimeter|feet|foot|ft|inch|inches|meter|metre|m|celsius|c|fahrenheit|f|gb|mb|liter|litre|l|gallon)\\b.*?(?:to|in|me|mein|into|ko)\\s*(km|kilometer|kilometre|miles?|mi|kg|kilogram|pounds?|lbs?|cm|centimeter|feet|foot|ft|inch|inches|meter|metre|m|celsius|c|fahrenheit|f|gb|mb|liter|litre|l|gallon)\\b")
            .find(lower) ?: return null

        val value = m.groupValues[1].toDoubleOrNull() ?: return null
        val from = normalizeUnit(m.groupValues[2])
        val to = normalizeUnit(m.groupValues[3])
        if (from == to) return "${fmt(value)} $from = ${fmt(value)} $to."

        val result: Double? = when ("$from->$to") {
            "km->miles" -> value * 0.621371
            "miles->km" -> value / 0.621371
            "km->m" -> value * 1000.0
            "m->km" -> value / 1000.0
            "m->feet" -> value * 3.28084
            "feet->m" -> value / 3.28084
            "feet->cm" -> value * 30.48
            "cm->feet" -> value / 30.48
            "inch->cm" -> value * 2.54
            "cm->inch" -> value / 2.54
            "feet->inch" -> value * 12.0
            "inch->feet" -> value / 12.0
            "kg->lbs" -> value * 2.20462
            "lbs->kg" -> value / 2.20462
            "celsius->fahrenheit" -> (value * 9.0 / 5.0) + 32.0
            "fahrenheit->celsius" -> (value - 32.0) * 5.0 / 9.0
            "gb->mb" -> value * 1024.0
            "mb->gb" -> value / 1024.0
            "liter->gallon" -> value * 0.264172
            "gallon->liter" -> value / 0.264172
            else -> null
        }
        return result?.let { "${fmt(value)} $from lagbhag ${fmt(it)} $to hota hai." }
    }

    private fun normalizeUnit(u: String): String = when {
        u.startsWith("km") || (u.startsWith("kilo") && u.contains("met")) -> "km"
        u.startsWith("mi") -> "miles"
        u.startsWith("kg") || u.startsWith("kilogram") -> "kg"
        u.startsWith("lb") || u.startsWith("pound") -> "lbs"
        u.startsWith("cm") || u.startsWith("centi") -> "cm"
        u == "ft" || u.startsWith("foot") || u.startsWith("feet") -> "feet"
        u.startsWith("inch") -> "inch"
        u == "m" || u.startsWith("met") -> "m"
        u == "c" || u.startsWith("cel") -> "celsius"
        u == "f" || u.startsWith("fah") -> "fahrenheit"
        u == "gb" -> "gb"
        u == "mb" -> "mb"
        u == "l" || u.startsWith("lit") -> "liter"
        u.startsWith("gal") -> "gallon"
        else -> u
    }

    private fun fmt(v: Double): String =
        if (v % 1.0 == 0.0) v.toLong().toString() else String.format(Locale.US, "%.2f", v)

    fun handleNotes(context: Context, op: String, body: String): String {
        val prefs = context.getSharedPreferences(PREFS_NOTES, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(KEY_NOTES, "[]")) }.getOrElse { JSONArray() }
        return when (op) {
            "add" -> {
                if (body.isBlank()) return "Note me kya likhna hai? Bolo jaise: 'Note likho kal physics notes lene hain'."
                if (SmartMemory.isSensitive(body)) return "Security ke liye password, OTP ya PIN notes me save nahi karta."
                arr.put(body.trim())
                prefs.edit().putString(KEY_NOTES, arr.toString()).apply()
                "Voice note save kar liya: \"${body.trim()}\"."
            }
            "list" -> {
                if (arr.length() == 0) "Abhi koi saved voice note nahi hai."
                else {
                    val items = (0 until arr.length()).map { "${it + 1}. ${arr.optString(it)}" }
                    "Aapke saved notes: " + items.takeLast(5).joinToString("; ")
                }
            }
            "clear" -> {
                prefs.edit().putString(KEY_NOTES, "[]").apply()
                "Saare voice notes clear kar diye hain."
            }
            else -> "Notes command samajh nahi aaya."
        }
    }
}
