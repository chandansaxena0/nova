package com.nova.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class ActiveTimer(val id: Int, val label: String, val endAtMs: Long)

/** Real countdown timer manager backed by Android AlarmManager. Works 100% offline. */
object TimerManager {
    private const val PREF = "nova_timers"
    private const val KEY = "timers_json"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun activeTimers(c: Context): List<ActiveTimer> {
        val now = System.currentTimeMillis()
        val list = loadRaw(c).filter { it.endAtMs > now }.sortedBy { it.endAtMs }
        save(c, list)
        return list
    }

    fun startTimer(c: Context, durationSeconds: Long, label: String = "Nova Timer"): ActiveTimer {
        val safeSec = durationSeconds.coerceIn(5L, 24 * 3600L)
        val endAt = System.currentTimeMillis() + safeSec * 1000L
        val id = ((System.currentTimeMillis() / 1000L) % 900_000L).toInt() + 1000
        val timer = ActiveTimer(id, label.trim().ifEmpty { "Nova Timer" }, endAt)
        val list = activeTimers(c).toMutableList().apply { add(timer) }
        save(c, list)
        schedule(c, timer)
        return timer
    }

    fun cancelTimer(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(c, id, ""))
        save(c, loadRaw(c).filterNot { it.id == id })
    }

    fun cancelAll(c: Context): Int {
        val list = loadRaw(c)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        list.forEach { am.cancel(pendingIntent(c, it.id, it.label)) }
        save(c, emptyList())
        return list.size
    }

    fun rescheduleAll(c: Context) {
        activeTimers(c).forEach { schedule(c, it) }
    }

    fun formatRemaining(endAtMs: Long): String {
        val remSec = ((endAtMs - System.currentTimeMillis()) / 1000L).coerceAtLeast(0L)
        val hrs = remSec / 3600
        val mins = (remSec % 3600) / 60
        val secs = remSec % 60
        return when {
            hrs > 0 -> "${hrs}h ${mins}m ${secs}s"
            mins > 0 -> "${mins}m ${secs}s"
            else -> "${secs}s"
        }
    }

    fun handleVoiceCommand(c: Context, rawRequest: String, extraMinutes: Int = 0): String {
        val lower = HinglishConverter.toHinglish(rawRequest).lowercase(Locale.ROOT)

        if (lower.contains("cancel") || lower.contains("band") || lower.contains("stop") || lower.contains("hatao") || lower.contains("delete")) {
            val count = cancelAll(c)
            return if (count > 0) "Sabhi $count active timers cancel kar diye hain." else "Abhi koi active timer nahi chal raha."
        }

        if (lower.contains("kitna") || lower.contains("bacha") || lower.contains("status") || lower.contains("remaining") || lower.contains("left") || lower.contains("check")) {
            val list = activeTimers(c)
            if (list.isEmpty()) return "Abhi koi timer nahi chal raha hai."
            return list.joinToString("; ") { "${it.label}: ${formatRemaining(it.endAtMs)} bacha hai" }
        }

        var totalSec = 0L
        Regex("(\\d+)\\s*(?:hr|hrs|hour|hours|ghante|ghanta)").find(lower)?.let {
            totalSec += (it.groupValues[1].toLongOrNull() ?: 0L) * 3600L
        }
        Regex("(\\d+)\\s*(?:min|mins|minute|minutes)").find(lower)?.let {
            totalSec += (it.groupValues[1].toLongOrNull() ?: 0L) * 60L
        }
        Regex("(\\d+)\\s*(?:sec|secs|second|seconds)").find(lower)?.let {
            totalSec += (it.groupValues[1].toLongOrNull() ?: 0L)
        }
        if (totalSec <= 0L && extraMinutes > 0) totalSec = extraMinutes * 60L
        if (totalSec <= 0L) {
            return "Kitne minute ya second ka timer lagau? Jaise: 10 minute ka timer lagao."
        }

        val timer = startTimer(c, totalSec, "Timer (${formatDuration(totalSec)})")
        return "${formatDuration(totalSec)} ka timer shuru kar diya hai."
    }

    fun formatDuration(totalSec: Long): String {
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return buildString {
            if (h > 0) append("$h hour ")
            if (m > 0) append("$m minute ")
            if (s > 0 && h == 0L) append("$s second")
        }.trim().ifEmpty { "${totalSec} second" }
    }

    private fun schedule(c: Context, timer: ActiveTimer) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(c, timer.id, timer.label)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endAtMs, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endAtMs, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timer.endAtMs, pi)
        }
    }

    private fun pendingIntent(c: Context, id: Int, label: String): PendingIntent {
        val i = Intent(c, TimerReceiver::class.java).putExtra("id", id).putExtra("label", label)
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun loadRaw(c: Context): List<ActiveTimer> {
        val raw = p(c).getString(KEY, "[]") ?: "[]"
        val out = mutableListOf<ActiveTimer>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(ActiveTimer(o.optInt("id"), o.optString("label"), o.optLong("endAtMs")))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(c: Context, list: List<ActiveTimer>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("label", it.label).put("endAtMs", it.endAtMs)) }
        p(c).edit().putString(KEY, arr.toString()).apply()
    }
}
