package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Resolves a Roblox game name to its official Place ID using Roblox's public discovery API,
 * then launches the exact game via the official roblox:// deep link (or Roblox game page)
 * instead of dumping the user on the generic home screen.
 */
object RobloxHelper {

    const val ROBLOX_PKG = "com.roblox.client"

    data class RobloxGame(val name: String, val placeId: Long)

    // Verified popular game Place IDs for instant offline launch
    private val knownPlaceIds = mapOf(
        "brookhaven" to RobloxGame("Brookhaven RP", 4924922222L),
        "bloxfruits" to RobloxGame("Blox Fruits", 2753915549L),
        "adoptme" to RobloxGame("Adopt Me!", 920587237L),
        "murdermystery2" to RobloxGame("Murder Mystery 2", 142823291L),
        "mm2" to RobloxGame("Murder Mystery 2", 142823291L),
        "doors" to RobloxGame("DOORS", 6516141723L),
        "bedwars" to RobloxGame("BedWars", 6872265039L),
        "towerofhell" to RobloxGame("Tower of Hell", 1962086868L),
        "jailbreak" to RobloxGame("Jailbreak", 606849621L),
        "naturaldisaster" to RobloxGame("Natural Disaster Survival", 189707L),
        "pet simulator 99" to RobloxGame("Pet Simulator 99", 8737899170L),
        "dress to impress" to RobloxGame("Dress To Impress", 15101393044L)
    )

    /** Runs on background thread. */
    fun launchGame(context: Context, index: AppIndex, rawQuery: String): String {
        val q = HinglishConverter.toHinglish(rawQuery).trim()
        val installed = index.isInstalled(ROBLOX_PKG)
        if (q.isEmpty()) {
            return if (installed) {
                val i = context.packageManager.getLaunchIntentForPackage(ROBLOX_PKG)
                    ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (i != null && startSafe(context, i)) "Roblox khul gaya." else "Roblox khol nahi paya."
            } else {
                "Phone me Roblox installed nahi hai."
            }
        }

        val key = Normalizer.key(q)
        val localHit = knownPlaceIds.entries.firstOrNull { (k, _) ->
            Normalizer.similarity(key, Normalizer.key(k)) >= 0.82
        }?.value

        val game = localHit ?: if (PhoneInfoHelper.isOnline(context)) searchRobloxApi(q) else null

        if (game != null) {
            if (installed) {
                val deep = Intent(Intent.ACTION_VIEW, Uri.parse("roblox://experiences/start?placeId=${game.placeId}"))
                    .setPackage(ROBLOX_PKG)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (startSafe(context, deep)) {
                    return "Roblox me '${game.name}' directly launch kar raha hoon."
                }
            }
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.roblox.com/games/${game.placeId}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (startSafe(context, web)) {
                return "Roblox game '${game.name}' khol raha hoon."
            }
        }

        // Fallback: open official Roblox discover search page for the game
        val discoverUrl = "https://www.roblox.com/discover/?Keyword=${URLEncoder.encode(q, "UTF-8")}"
        val fallback = Intent(Intent.ACTION_VIEW, Uri.parse(discoverUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (startSafe(context, fallback)) {
            "Roblox Discover me '$q' search khol diya hai."
        } else {
            "Roblox me '$q' nahi khul paya."
        }
    }

    private fun searchRobloxApi(query: String): RobloxGame? {
        // Endpoint 1: Roblox Omni Search API
        try {
            val enc = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://apis.roblox.com/search-api/omni-search?searchQuery=$enc&pageToken=&sessionId=nova6&pageType=all")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 7000
                setRequestProperty("User-Agent", "NovaAssistant/6.0")
            }
            if (conn.responseCode in 200..299) {
                val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val groups = root.optJSONArray("searchResults")
                if (groups != null) {
                    val qKey = Normalizer.key(query)
                    var best: Pair<RobloxGame, Double>? = null
                    for (i in 0 until groups.length()) {
                        val contents = groups.getJSONObject(i).optJSONArray("contents") ?: continue
                        for (j in 0 until contents.length()) {
                            val item = contents.getJSONObject(j)
                            val placeId = item.optLong("rootPlaceId", 0L)
                            val name = item.optString("name", "").trim()
                            if (placeId > 0L && name.isNotEmpty()) {
                                val score = Normalizer.similarity(qKey, Normalizer.key(name))
                                if (best == null || score > best.second) {
                                    best = RobloxGame(name, placeId) to score
                                }
                            }
                        }
                    }
                    if (best != null) return best.first
                }
            }
        } catch (_: Exception) {}

        // Endpoint 2: Legacy games list endpoint
        try {
            val enc = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://games.roblox.com/v1/games/list?model.keyword=$enc&model.maxRows=5")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 7000
                setRequestProperty("User-Agent", "NovaAssistant/6.0")
            }
            if (conn.responseCode in 200..299) {
                val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val games = root.optJSONArray("games")
                if (games != null && games.length() > 0) {
                    val first = games.getJSONObject(0)
                    val pid = first.optLong("placeId", 0L)
                    val name = first.optString("name", query).trim()
                    if (pid > 0L) return RobloxGame(name, pid)
                }
            }
        } catch (_: Exception) {}

        return null
    }

    private fun startSafe(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent)
        true
    } catch (_: Exception) {
        false
    }
}
