package com.nova.assistant

import android.content.Context
import java.util.Locale

object StudyProgressStore {

    fun recordSession(context: Context, topic: String, correct: Int, total: Int) {
        if (total <= 0) return
        NovaMemoryDb.get(context).recordStudyOutcome(topic, correct, total)
    }

    fun buildProgressSummary(context: Context): String {
        val stats = NovaMemoryDb.get(context).getStudyStats()
        if (stats.isEmpty()) {
            return "Abhi koi study quiz ya flashcard progress record nahi hua hai. Bolo: 'Physics ke voice flashcards shuru karo' ya 'Chemistry flashcards'."
        }
        val weak = stats.filter { it.isWeak }
        val lines = stats.take(6).map { s ->
            val daysAgo = ((System.currentTimeMillis() - s.lastPracticedMs) / (24L * 3600_000L)).coerceAtLeast(0L)
            val interval = recommendedRevisionDays(s.accuracyPct)
            val due = if (daysAgo >= interval) "Revision Due!" else "Next revision in ${interval - daysAgo}d"
            "${s.topic.replaceFirstChar { it.uppercase(Locale.ROOT) }}: ${s.correct}/${s.total} (${s.accuracyPct}%) — $due"
        }
        val weakNote = if (weak.isNotEmpty()) {
            "\nWeak topics to revise first: " + weak.joinToString(", ") { it.topic }
        } else {
            "\nGreat job! Sabhi practiced topics 70%+ accuracy par hain."
        }
        return "Study Progress:\n" + lines.joinToString("\n") + weakNote
    }

    fun recommendedRevisionDays(accuracyPct: Int): Long = when {
        accuracyPct < 70 -> 1L
        accuracyPct < 85 -> 3L
        else -> 7L
    }
}
