package com.nova.assistant

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * Hands-Free Connectivity & Quick System Toggles for Nova v9.0 Perfection Edition:
 *   - Wi-Fi ON / OFF
 *   - Bluetooth ON / OFF
 *   - Mobile Data ON / OFF
 *   - Personal Hotspot ON / OFF
 *   - Airplane Mode ON / OFF
 *   - Auto-Rotate ON / OFF (direct API when WRITE_SETTINGS granted, else Quick Settings tile)
 *   - Do Not Disturb ON / OFF (direct API when DND access granted, else Quick Settings tile)
 *   - Battery Saver ON / OFF
 *   - Location / GPS ON / OFF
 *   - Power Menu
 *
 * Uses direct system APIs where Android permits, and state-aware Quick Settings tile automation
 * via NovaAccessibility on Android 10-16 (with clean native Settings Panel fallback if Accessibility is OFF).
 */
object ConnectivityControlHelper {

    fun toggle(context: Context, feature: String, desiredOn: Boolean?): String {
        return when (feature) {
            "wifi" -> toggleViaAccessibilityOrPanel(
                context = context,
                aliases = listOf("wi-fi", "wifi", "wlan"),
                label = "Wi-Fi",
                desiredOn = desiredOn,
                tryInternetSubmenu = true
            ) {
                openPanelOrSetting(
                    context,
                    if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS,
                    Settings.ACTION_WIFI_SETTINGS,
                    "Wi-Fi Panel"
                )
            }

            "bluetooth" -> toggleViaAccessibilityOrPanel(
                context = context,
                aliases = listOf("bluetooth"),
                label = "Bluetooth",
                desiredOn = desiredOn
            ) {
                openPanelOrSetting(context, Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS, "Bluetooth Settings")
            }

            "mobile_data" -> toggleViaAccessibilityOrPanel(
                context = context,
                aliases = listOf("mobile data", "data network", "cellular data", "cellular", "mobile network", "5g", "sim data"),
                label = "Mobile Data",
                desiredOn = desiredOn,
                tryInternetSubmenu = true
            ) {
                openPanelOrSetting(
                    context,
                    if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_DATA_ROAMING_SETTINGS,
                    Settings.ACTION_WIRELESS_SETTINGS,
                    "Mobile Data Panel"
                )
            }

            "hotspot" -> toggleViaAccessibilityOrPanel(
                context = context,
                aliases = listOf("hotspot", "personal hotspot", "wi-fi hotspot", "wifi hotspot", "portable hotspot", "mobile hotspot", "tethering"),
                label = "Hotspot",
                desiredOn = desiredOn
            ) {
                openHotspotSettings(context)
            }

            "airplane" -> toggleViaAccessibilityOrPanel(
                context = context,
                aliases = listOf("airplane mode", "aeroplane mode", "flight mode", "airplane", "aeroplane"),
                label = "Airplane Mode",
                desiredOn = desiredOn
            ) {
                openPanelOrSetting(context, Settings.ACTION_AIRPLANE_MODE_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS, "Airplane Mode Settings")
            }

            "auto_rotate" -> {
                if (Settings.System.canWrite(context)) {
                    val cur = runCatching {
                        Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
                    }.getOrDefault(0)
                    val target = when (desiredOn) {
                        true -> 1
                        false -> 0
                        null -> if (cur == 1) 0 else 1
                    }
                    Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, target)
                    if (target == 1) "Auto-Rotate ON kar diya hai." else "Auto-Rotate OFF kar diya hai."
                } else {
                    toggleViaAccessibilityOrPanel(
                        context = context,
                        aliases = listOf("auto-rotate", "auto rotate", "screen rotation", "portrait", "rotation"),
                        label = "Auto-Rotate",
                        desiredOn = desiredOn
                    ) {
                        openPanelOrSetting(context, Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SETTINGS, "Display Settings")
                    }
                }
            }

            "dnd" -> {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.isNotificationPolicyAccessGranted) {
                    val targetOn = desiredOn ?: (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL)
                    nm.setInterruptionFilter(
                        if (targetOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        else NotificationManager.INTERRUPTION_FILTER_ALL
                    )
                    if (targetOn) "Do Not Disturb ON kar diya hai." else "Do Not Disturb OFF kar diya hai."
                } else {
                    toggleViaAccessibilityOrPanel(
                        context = context,
                        aliases = listOf("do not disturb", "dnd"),
                        label = "Do Not Disturb",
                        desiredOn = desiredOn
                    ) {
                        openPanelOrSetting(context, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, Settings.ACTION_SOUND_SETTINGS, "Do Not Disturb Settings")
                    }
                }
            }

            "battery_saver" -> toggleViaAccessibilityOrPanel(
                context = context,
                aliases = listOf("battery saver", "power saving", "power saver", "low power", "super power"),
                label = "Battery Saver",
                desiredOn = desiredOn
            ) {
                openPanelOrSetting(context, Settings.ACTION_BATTERY_SAVER_SETTINGS, Settings.ACTION_SETTINGS, "Battery Saver Settings")
            }

            "location" -> toggleViaAccessibilityOrPanel(
                context = context,
                aliases = listOf("location", "gps"),
                label = "Location",
                desiredOn = desiredOn
            ) {
                openPanelOrSetting(context, Settings.ACTION_LOCATION_SOURCE_SETTINGS, Settings.ACTION_SETTINGS, "Location Settings")
            }

            "power_menu" -> {
                val acc = NovaAccessibility.instance
                    ?: return "Power menu kholne ke liye Settings me Nova Accessibility ON karo."
                if (acc.performPowerDialog()) "Power menu khol diya hai." else "Power menu nahi khul paya."
            }

            else -> "Connectivity control samajh nahi aaya."
        }
    }

    private fun toggleViaAccessibilityOrPanel(
        context: Context,
        aliases: List<String>,
        label: String,
        desiredOn: Boolean?,
        tryInternetSubmenu: Boolean = false,
        fallback: () -> String
    ): String {
        val acc = NovaAccessibility.instance
        if (acc != null) {
            return acc.toggleQuickSettingTile(aliases, label, desiredOn, tryInternetSubmenu)
        }
        val fb = fallback()
        return "$fb (100% hands-free $label ON/OFF ke liye Nova Settings me Accessibility ON karo.)"
    }

    private fun openHotspotSettings(context: Context): String {
        val intents = listOf(
            Intent().setComponent(ComponentName("com.android.settings", "com.android.settings.TetherSettings")),
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return "Hotspot settings khol di hain."
            } catch (_: Exception) {}
        }
        return "Hotspot settings nahi khul payi."
    }

    private fun openPanelOrSetting(context: Context, primaryAction: String, secondaryAction: String, label: String): String {
        for (act in listOf(primaryAction, secondaryAction, Settings.ACTION_SETTINGS)) {
            try {
                context.startActivity(Intent(act).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return "$label khol diya hai."
            } catch (_: Exception) {}
        }
        return "$label nahi khul paya."
    }
}
