package com.nova.assistant

import java.util.Locale
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Fast offline math solver for Study Assistant & voice calculations.
 * Supports +, -, *, /, ^, %, parentheses, and Hinglish math words
 * ("25 plus 35", "12 into 8", "square root of 144", "15 percent of 200").
 */
object MathEvaluator {

    fun trySolve(raw: String): String? {
        val norm = HinglishConverter.toHinglish(raw).lowercase(Locale.ROOT)

        // Handle "X percent of Y" / "Y ka X percent"
        Regex("(\\d+(?:\\.\\d+)?)\\s*(?:%|percent|pratishat)\\s*(?:of|ka)\\s*(\\d+(?:\\.\\d+)?)")
            .find(norm)?.let { m ->
                val pct = m.groupValues[1].toDoubleOrNull() ?: return@let
                val base = m.groupValues[2].toDoubleOrNull() ?: return@let
                return formatResult(pct * base / 100.0)
            }
        Regex("(\\d+(?:\\.\\d+)?)\\s*(?:ka|of)\\s*(\\d+(?:\\.\\d+)?)\\s*(?:%|percent|pratishat)")
            .find(norm)?.let { m ->
                val base = m.groupValues[1].toDoubleOrNull() ?: return@let
                val pct = m.groupValues[2].toDoubleOrNull() ?: return@let
                return formatResult(pct * base / 100.0)
            }

        // Handle square root
        Regex("(?:square\\s+root\\s+(?:of)?|sqrt|vargmul)\\s*(\\d+(?:\\.\\d+)?)")
            .find(norm)?.let { m ->
                val v = m.groupValues[1].toDoubleOrNull() ?: return@let
                if (v >= 0) return formatResult(sqrt(v))
            }

        // Normalize spoken operators into arithmetic expression
        var expr = norm
            .replace(Regex("\\b(solve|calculate|kitna hota hai|kitna hoga|kya hoga|barabar|equals|equal to|what is|batao|karo|hisab|math|maths)\\b"), " ")
            .replace(Regex("\\b(plus|jodo|add)\\b"), "+")
            .replace(Regex("\\b(minus|ghatao|subtract)\\b"), "-")
            .replace(Regex("\\b(into|guna|times|multiplied by|multiply by|x)\\b"), "*")
            .replace(Regex("\\b(divided by|divide by|bhag|bata)\\b"), "/")
            .replace(Regex("\\b(power|to the power of)\\b"), "^")
            .replace("×", "*")
            .replace("÷", "/")
            .replace(Regex("[^0-9.+\\-*/^()\\s]"), "")
            .replace(Regex("\\s+"), "")

        if (expr.isEmpty() || !expr.any { it in "+-*/^" }) return null
        if (!expr.any { it.isDigit() }) return null

        return try {
            val value = Parser(expr).parse()
            if (value.isNaN() || value.isInfinite()) null else formatResult(value)
        } catch (_: Exception) {
            null
        }
    }

    private fun formatResult(v: Double): String {
        val longVal = v.toLong()
        return if (kotlin.math.abs(v - longVal.toDouble()) < 1e-9) {
            longVal.toString()
        } else {
            String.format(Locale.US, "%.4f", v).trimEnd('0').trimEnd('.')
        }
    }

    private class Parser(private val s: String) {
        private var pos = 0

        fun parse(): Double {
            val v = parseExpression()
            if (pos != s.length) throw IllegalArgumentException("Unexpected char")
            return v
        }

        private fun parseExpression(): Double {
            var v = parseTerm()
            while (pos < s.length) {
                v = when (s[pos]) {
                    '+' -> { pos++; v + parseTerm() }
                    '-' -> { pos++; v - parseTerm() }
                    else -> break
                }
            }
            return v
        }

        private fun parseTerm(): Double {
            var v = parsePower()
            while (pos < s.length) {
                v = when (s[pos]) {
                    '*' -> { pos++; v * parsePower() }
                    '/' -> {
                        pos++
                        val d = parsePower()
                        if (d == 0.0) throw ArithmeticException("Divide by zero")
                        v / d
                    }
                    else -> break
                }
            }
            return v
        }

        private fun parsePower(): Double {
            var v = parseFactor()
            if (pos < s.length && s[pos] == '^') {
                pos++
                v = v.pow(parsePower())
            }
            return v
        }

        private fun parseFactor(): Double {
            if (pos < s.length && s[pos] == '+') { pos++; return parseFactor() }
            if (pos < s.length && s[pos] == '-') { pos++; return -parseFactor() }
            if (pos < s.length && s[pos] == '(') {
                pos++
                val v = parseExpression()
                if (pos >= s.length || s[pos] != ')') throw IllegalArgumentException("Missing )")
                pos++
                return v
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Expected number")
            return s.substring(start, pos).toDouble()
        }
    }
}
