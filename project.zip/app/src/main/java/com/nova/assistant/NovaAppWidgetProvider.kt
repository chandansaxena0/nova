package com.nova.assistant

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.concurrent.thread

/**
 * Home Screen 4x2 Bento Glass Widget for Nova v11.0:
 *   - 1-Tap Neon Lime Talk (Mic), Lavender Camera Lens, and Soft Pink Smart TV Mute/Power quick buttons.
 *   - Live Today's Expense & Next Reminder ticker.
 */
class NovaAppWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_WIDGET_TV_MUTE = "com.nova.assistant.WIDGET_TV_MUTE"
        const val ACTION_WIDGET_REFRESH = "com.nova.assistant.WIDGET_REFRESH"

        fun requestUpdate(context: Context) {
            runCatching {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, NovaAppWidgetProvider::class.java))
                if (ids.isNotEmpty()) {
                    for (id in ids) updateSingleWidget(context, mgr, id)
                }
            }
        }

        private fun updateSingleWidget(context: Context, mgr: AppWidgetManager, widgetId: Int) {
            val rv = RemoteViews(context.packageName, R.layout.widget_nova_bento)

            val status = when {
                Prefs.privacyPaused(context) -> "PRIVACY PAUSED"
                ListenService.running -> "WAKE READY"
                else -> "TAP TO TALK"
            }
            rv.setTextViewText(R.id.widgetStatusPill, status)

            val expSummary = runCatching { ExpenseTrackerStore.quickDashboardSummary(context) }.getOrDefault("Today: Rs 0")
            val nextRem = runCatching {
                ReminderStore.all(context).minByOrNull { it.triggerAtMs }?.let { "Next: ${it.title}" }
            }.getOrNull() ?: "No upcoming reminders"
            rv.setTextViewText(R.id.widgetInfoLine, "$expSummary  •  $nextRem")

            // Open App on header tap
            val openAppPi = PendingIntent.getActivity(
                context, 201,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.widgetHeaderRow, openAppPi)

            // 1-Tap Mic via AssistActivity
            val micPi = PendingIntent.getActivity(
                context, 202,
                Intent(context, AssistActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.widgetBtnTalk, micPi)

            // 1-Tap Camera Lens
            val lensPi = PendingIntent.getActivity(
                context, 203,
                Intent(context, CameraLensActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.widgetBtnLens, lensPi)

            // 1-Tap TV Mute Toggle
            val tvPi = PendingIntent.getBroadcast(
                context, 204,
                Intent(context, NovaAppWidgetProvider::class.java).setAction(ACTION_WIDGET_TV_MUTE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.widgetBtnTv, tvPi)

            mgr.updateAppWidget(widgetId, rv)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) updateSingleWidget(context, appWidgetManager, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_WIDGET_REFRESH -> requestUpdate(context)
            ACTION_WIDGET_TV_MUTE -> {
                thread {
                    SmartTvController.handleVoiceCommand(context, "mute", "")
                    requestUpdate(context)
                }
            }
        }
    }
}
