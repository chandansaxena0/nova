package com.nova.assistant

import android.content.Context
import android.content.Intent

/** One app on the phone: launcher label + package name. */
data class AppInfo(val label: String, val pkg: String) {
    val key: String = Normalizer.key(label)
}

object Normalizer {
    fun key(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    fun similarity(q: String, k: String): Double {
        if (q.isEmpty() || k.isEmpty()) return 0.0
        if (q == k) return 1.0
        val shorter = minOf(q.length, k.length)
        val longer = maxOf(q.length, k.length)
        if (shorter >= 3 && (k.contains(q) || q.contains(k))) {
            return 0.72 + 0.28 * shorter / longer
        }
        return (1.0 - levenshtein(q, k).toDouble() / longer).coerceAtLeast(0.0)
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }
}

/**
 * Cached index of all installed launcher apps.
 * Refreshes lazily (at most once per 60 seconds unless forced) to avoid unnecessary re-indexing.
 */
class AppIndex(private val context: Context?) {

    var apps: List<AppInfo> = emptyList()
        private set

    private var lastRefreshMs = 0L

    // Common phonetic / alias overrides -> normalized key
    private val aliases = mapOf(
        "yt" to "youtube",
        "wa" to "whatsapp",
        "insta" to "instagram",
        "fb" to "facebook",
        "gpay" to "googlepay",
        "maps" to "maps",
        "googlemaps" to "maps",
        "playstore" to "googleplaystore",
        "calc" to "calculator",
        "ff" to "freefire",
        "ffmax" to "freefiremax"
    )

    /** Constructor helper for unit tests. */
    fun setAppsForTest(list: List<AppInfo>) {
        apps = list
        lastRefreshMs = Long.MAX_VALUE
    }

    fun refresh(force: Boolean = false) {
        val ctx = context ?: return
        val now = System.currentTimeMillis()
        if (!force && apps.isNotEmpty() && now - lastRefreshMs < 60_000L) return
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName && it.key.isNotEmpty() }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        lastRefreshMs = now
    }

    fun isInstalled(pkg: String): Boolean = apps.any { it.pkg == pkg }

    fun byPackage(pkg: String): AppInfo? = apps.firstOrNull { it.pkg == pkg }

    /** Returns best matching installed app and score (0..1). */
    fun bestMatch(rawKey: String): Pair<AppInfo, Double>? {
        return topMatches(rawKey, limit = 1).firstOrNull()
    }

    /** Returns top matching installed apps above [minScore] for disambiguation when names are similar. */
    fun topMatches(rawKey: String, minScore: Double = 0.62, limit: Int = 3): List<Pair<AppInfo, Double>> {
        val q = aliases[rawKey] ?: rawKey
        if (q.length < 2) return emptyList()
        return apps.map { a ->
            val s1 = Normalizer.similarity(q, a.key)
            val s2 = if (q != rawKey) Normalizer.similarity(rawKey, a.key) else 0.0
            a to maxOf(s1, s2)
        }
            .filter { it.second >= minScore }
            .sortedByDescending { it.second }
            .take(limit)
    }
}
