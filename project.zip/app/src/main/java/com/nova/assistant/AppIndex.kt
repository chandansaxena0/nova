package com.nova.assistant

import android.content.Context
import android.content.Intent

/** One app on the phone: the name you see on the home screen + its package id. */
data class AppInfo(val label: String, val pkg: String) {
    val key: String = Normalizer.key(label)
}

object Normalizer {
    /** "Google Maps" -> "googlemaps" (lowercase, letters and digits only) */
    fun key(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }
}

/**
 * Knows every app on the phone that has a launcher icon.
 * This is what lets the app open ANY app, not just a fixed list.
 */
class AppIndex(private val context: Context) {

    var apps: List<AppInfo> = emptyList()
        private set

    fun refresh() {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != context.packageName && it.key.isNotEmpty() }
            .distinctBy { it.pkg }
    }

    fun isInstalled(pkg: String): Boolean = apps.any { it.pkg == pkg }

    /** Closest installed app for a name, with a score from 0 to 1 (1 = exact). */
    fun bestMatch(key: String): Pair<AppInfo, Double>? {
        if (key.length < 2) return null
        var best: AppInfo? = null
        var bestScore = 0.0
        for (a in apps) {
            val s = score(key, a.key)
            if (s > bestScore) {
                bestScore = s
                best = a
            }
        }
        return best?.let { it to bestScore }
    }

    private fun score(q: String, k: String): Double {
        if (q == k) return 1.0
        val shorter = minOf(q.length, k.length)
        val longer = maxOf(q.length, k.length)
        if (shorter >= 3 && (k.contains(q) || q.contains(k))) {
            return 0.7 + 0.3 * shorter / longer
        }
        return 1.0 - Normalizer.levenshtein(q, k).toDouble() / longer
    }
}
