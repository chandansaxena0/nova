package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TaskItem(val id: Long, val title: String, val done: Boolean)

/**
 * Daily Planner Store:
 * - Persistent To-Do Task List (voice + Hub UI CRUD)
 * - Built-in & runnable Routines (Morning Briefing, Study Session, Sleep Prep, Travel Prep)
 * - Android Calendar integration (reads upcoming events when READ_CALENDAR granted, or opens Calendar insert)
 */
object DailyPlannerStore {
    private const val PREF = "nova_planner"
    private const val KEY_TASKS = "tasks_json"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun getTasks(c: Context): List<TaskItem> {
        val raw = p(c).getString(KEY_TASKS, "[]") ?: "[]"
        val out = mutableListOf<TaskItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(TaskItem(o.optLong("id"), o.optString("title"), o.optBoolean("done", false)))
            }
        } catch (_: Exception) {}
        return out
    }

    fun addTask(c: Context, title: String): TaskItem? {
        val clean = HinglishConverter.toHinglish(title).trim()
        if (clean.isEmpty()) return null
        val item = TaskItem(System.currentTimeMillis(), clean, false)
        val list = getTasks(c).toMutableList().apply { add(0, item) }
        saveTasks(c, list.take(60))
        return item
    }

    fun toggleTask(c: Context, id: Long) {
        val list = getTasks(c).map { if (it.id == id) it.copy(done = !it.done) else it }
        saveTasks(c, list)
    }

    fun deleteTask(c: Context, id: Long) {
        saveTasks(c, getTasks(c).filterNot { it.id == id })
    }

    private fun saveTasks(c: Context, list: List<TaskItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done)) }
        p(c).edit().putString(KEY_TASKS, arr.toString()).apply()
    }

    fun handleTaskVoice(c: Context, rawRequest: String, extractedBody: String = ""): String {
        val lower = HinglishConverter.toHinglish(rawRequest).lowercase(Locale.ROOT)
        if (lower.contains("add") || lower.contains("jodo") || lower.contains("likho") || lower.contains("create") || lower.contains("banao")) {
            val title = extractedBody.ifBlank {
                HinglishConverter.toHinglish(rawRequest)
                    .replace(Regex("\\b(task|todo|to-do|list|me|mein|add|jodo|likho|create|banao|karo|ek|naya|new)\\b", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("\\s+"), " ").trim()
            }
            val added = addTask(c, title) ?: return "Task list me kya add karun? Bolo: task add karo physics notes revise karna."
            return "Task add ho gaya: '${added.title}'."
        }
        if (lower.contains("done") || lower.contains("complete") || lower.contains("tick")) {
            val pending = getTasks(c).filter { !it.done }
            val hit = pending.firstOrNull { t ->
                t.title.lowercase(Locale.ROOT).split(" ").any { w -> w.length >= 3 && lower.contains(w) }
            } ?: pending.firstOrNull()
            return if (hit != null) {
                toggleTask(c, hit.id)
                "Task complete mark kar diya: '${hit.title}'."
            } else "Koi pending task nahi hai."
        }
        val pending = getTasks(c).filter { !it.done }
        return if (pending.isEmpty()) {
            "Aapki task list abhi khali hai. Task add karne ke liye bolo: task add karo aur kaam ka naam."
        } else {
            "Aapke ${pending.size} pending tasks hain: " + pending.take(5).joinToString("; ") { it.title }
        }
    }

    fun runRoutine(c: Context, index: AppIndex, rawRequest: String): String {
        val lower = HinglishConverter.toHinglish(rawRequest).lowercase(Locale.ROOT)
        return when {
            lower.contains("study") || lower.contains("padhai") -> {
                val timer = TimerManager.startTimer(c, 25 * 60L, "Study Focus (25m)")
                "Study routine shuru! ${timer.label} timer laga diya hai. Focus rakho — break ke liye 25 minute baad bolunga."
            }
            lower.contains("sleep") || lower.contains("sone") || lower.contains("night") -> {
                PhoneControlHelper.setFlashlight(c, false)
                val bat = PhoneInfoHelper.battery(c)
                val remCount = ReminderStore.upcoming(c).size
                "Good night routine: flashlight OFF kar di hai. Battery ${bat.percent}% hai aur kal ke liye $remCount reminders set hain."
            }
            lower.contains("travel") || lower.contains("safar") || lower.contains("commute") -> {
                val checklist = RailRadarHelper.spokenChecklistSummary(c)
                val bat = PhoneInfoHelper.battery(c)
                "Travel prep routine: phone battery ${bat.percent}% hai. $checklist"
            }
            else -> {
                // Morning / Daily routine
                val briefing = NearbyPlacesHelper.dailyBriefing(c, index)
                val pendingTasks = getTasks(c).count { !it.done }
                val calEvents = upcomingCalendarSummary(c)
                "$briefing Pending tasks: $pendingTasks. $calEvents"
            }
        }
    }

    fun upcomingCalendarSummary(c: Context): String {
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            return ""
        }
        return try {
            val now = System.currentTimeMillis()
            val end = now + 24 * 3600_000L
            val proj = arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART)
            val sel = "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} <= ?"
            val args = arrayOf(now.toString(), end.toString())
            val hits = mutableListOf<String>()
            c.contentResolver.query(CalendarContract.Events.CONTENT_URI, proj, sel, args, "${CalendarContract.Events.DTSTART} ASC")?.use { cur ->
                val fmt = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
                while (cur.moveToNext() && hits.size < 3) {
                    val title = cur.getString(0)?.trim().orEmpty()
                    val start = cur.getLong(1)
                    if (title.isNotEmpty()) hits.add("$title (${fmt.format(Date(start))})")
                }
            }
            if (hits.isEmpty()) "Aaj koi upcoming calendar event nahi hai."
            else "Calendar events: ${hits.joinToString(", ")}."
        } catch (_: Exception) {
            ""
        }
    }

    fun handleCalendarVoice(c: Context, rawRequest: String, extractedBody: String = ""): String {
        val lower = HinglishConverter.toHinglish(rawRequest).lowercase(Locale.ROOT)
        if (lower.contains("add") || lower.contains("create") || lower.contains("event") || lower.contains("schedule")) {
            val title = extractedBody.ifBlank {
                HinglishConverter.toHinglish(rawRequest)
                    .replace(Regex("\\b(calendar|event|add|create|schedule|me|mein|karo|ek)\\b", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("\\s+"), " ").trim().ifEmpty { "Nova Event" }
            }
            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, title)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                c.startActivity(intent)
                "Calendar me '$title' event banane ki screen khol di hai."
            } catch (_: Exception) {
                "Calendar app nahi mila."
            }
        }
        val summary = upcomingCalendarSummary(c)
        return summary.ifEmpty { "Calendar events padhne ke liye Calendar permission chahiye, ya bolo: calendar me meeting event add karo." }
    }
}
