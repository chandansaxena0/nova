package com.nova.assistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper

/**
 * Android-compliant Screen Understanding & Contextual Overlay Actions (Nova v11.0):
 *   1) Explain current screen via Accessibility UI tree (skips password fields).
 *   2) Contextual Overlay Translate ("Isko translate karo" / "Screen translate karo").
 *   3) Contextual Overlay Smart Reply Draft ("Iska reply draft karo" -> copies ready reply to clipboard).
 *   4) User-selected screenshot / Camera Lens analysis via Multimodal Vision.
 */
object ScreenAnalyzer {

    fun analyzeCurrentScreen(context: Context, userQuestion: String = "Explain what is shown on my screen right now."): String {
        val acc = NovaAccessibility.instance
            ?: return "Current screen samajhne ke liye Settings tab me Accessibility ON karo, ya Hub tab se Camera Lens / screenshot analyze karo."

        val snapshot = acc.captureReadableScreen()
        if (snapshot.isNullOrBlank()) {
            return "Screen ka readable text abhi capture nahi ho paya. Dobara try karo."
        }

        if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
            val preview = snapshot.lines().take(8).joinToString(" | ")
            return "Offline screen preview: $preview"
        }

        val sys = "You are Nova's Screen Understanding Assistant. Explain what is currently visible on the user's Android screen in 2 to 4 clear, helpful sentences (no markdown). Never guess hidden sensitive details."
        val prompt = "User question: $userQuestion\n\nVisible UI elements:\n${snapshot.take(5000)}"
        return GeminiClient.askWithAgentPrompt(context, sys, prompt, keepContext = true, maxTokens = 450)
    }

    fun translateCurrentScreen(context: Context, rawRequest: String): String {
        val acc = NovaAccessibility.instance
            ?: return "Screen translate karne ke liye Settings tab me Nova Accessibility ON karo."
        val snapshot = acc.captureReadableScreen()
        if (snapshot.isNullOrBlank()) return "Screen par translate karne ke liye readable text nahi mila."
        if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
            return "Screen translate karne ke liye internet aur AI API key chahiye."
        }
        val target = if (rawRequest.lowercase().contains("english")) "clear natural English" else "simple Roman Hinglish"
        val sys = "You are Nova's Overlay Translator. Extract the main visible message/article text from the Android screen elements and translate it cleanly into $target in 2 to 4 concise sentences (no markdown, ignore UI button labels)."
        val reply = GeminiClient.askWithAgentPrompt(context, sys, snapshot.take(4500), keepContext = false, maxTokens = 380)
        copyToClipboardSafe(context, reply)
        return "$reply (Clipboard par copy kar diya hai.)"
    }

    fun draftReplyForCurrentScreen(context: Context, rawRequest: String): String {
        val acc = NovaAccessibility.instance
            ?: return "Screen ke message ka reply draft karne ke liye Settings tab me Nova Accessibility ON karo."
        val snapshot = acc.captureReadableScreen()
        if (snapshot.isNullOrBlank()) return "Screen par koi readable chat ya message nahi mila."
        if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
            return "Smart reply draft karne ke liye internet aur AI API key chahiye."
        }
        val sys = "You are Nova's Smart Reply Drafter. Read the latest incoming chat/email message visible on the Android screen and write ONLY ONE short, natural, polite reply in Roman Hinglish or English matching the conversation language (no quotes, no explanation, no markdown)."
        val prompt = "User instruction: $rawRequest\n\nVisible screen elements:\n${snapshot.take(4500)}"
        val draft = GeminiClient.askWithAgentPrompt(context, sys, prompt, keepContext = false, maxTokens = 160).trim()
        if (draft.isNotBlank() && !draft.startsWith("No AI key") && !draft.contains("error", ignoreCase = true)) {
            copyToClipboardSafe(context, draft)
            return "Suggested reply (copied to clipboard — paste karke bhej do): $draft"
        }
        return draft
    }

    private fun copyToClipboardSafe(context: Context, text: String) {
        Handler(Looper.getMainLooper()).post {
            runCatching {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("nova_overlay", text))
            }
        }
    }

    fun analyzeScreenshotUri(context: Context, uri: Uri, question: String = "Explain what is displayed in this screen capture."): String {
        return FileAssistant.loadAndSummarize(context, uri).let { summary ->
            if (question.isNotBlank() && !question.startsWith("Explain what is displayed")) {
                FileAssistant.answerQuestion(context, question)
            } else summary
        }
    }
}
