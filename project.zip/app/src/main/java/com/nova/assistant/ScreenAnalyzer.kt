package com.nova.assistant

import android.content.Context
import android.net.Uri

/**
 * Android-compliant Screen Understanding:
 * 1) Accessibility UI Tree analysis (only when user explicitly enables Accessibility Service).
 *    Automatically skips password fields for privacy.
 * 2) User-selected screenshot / image analysis via Gemini Vision.
 */
object ScreenAnalyzer {

    fun analyzeCurrentScreen(context: Context, userQuestion: String = "Explain what is shown on my screen right now."): String {
        val acc = NovaAccessibility.instance
        if (acc == null) {
            return "Current screen samajhne ke liye Settings tab me Accessibility ON karo, ya Hub tab se kisi screenshot/image ko analyze karo."
        }

        val snapshot = acc.captureReadableScreen()
        if (snapshot.isNullOrBlank()) {
            return "Screen ka readable text abhi capture nahi ho paya. Dobara try karo."
        }

        if (!PhoneInfoHelper.isOnline(context) || Prefs.geminiKey(context).isEmpty()) {
            val preview = snapshot.lines().take(8).joinToString(" | ")
            return "Offline screen preview: $preview"
        }

        val sys = "You are Nova's Screen Understanding Assistant. Explain what is currently visible on the user's Android screen in 2 to 4 clear, helpful sentences (no markdown). Never guess hidden sensitive details."
        val prompt = "User question: $userQuestion\n\nVisible UI elements:\n${snapshot.take(5000)}"
        return GeminiClient.askWithAgentPrompt(context, sys, prompt, keepContext = true, maxTokens = 450)
    }

    fun analyzeScreenshotUri(context: Context, uri: Uri, question: String = "Explain what is displayed in this screen capture."): String {
        return FileAssistant.loadAndSummarize(context, uri).let { summary ->
            if (question.isNotBlank() && !question.startsWith("Explain what is displayed")) {
                FileAssistant.answerQuestion(context, question)
            } else summary
        }
    }
}
