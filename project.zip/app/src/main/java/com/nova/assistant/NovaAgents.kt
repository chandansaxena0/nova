package com.nova.assistant

import android.content.Context

enum class AgentType(val displayName: String) {
    MAIN_ASSISTANT("Main Assistant Agent"),
    PHONE("Phone Agent"),
    RESEARCH("Research Agent"),
    STUDY("Study Agent"),
    TRAVEL("Travel Agent"),
    MEMORY("Memory Agent"),
    FILE("File Agent"),
    DAILY_PLANNER("Daily Planner Agent")
}

/**
 * Multi-Agent Orchestrator for Nova v7.0.
 * MainAssistantAgent automatically selects the right specialized agent for every command
 * and updates NovaState.activeAgent so the UI reflects which specialist handled the request.
 */
object MainAssistantAgent {

    fun selectAgent(c: Command): AgentType = when (c.kind) {
        Kind.OPEN, Kind.SEARCH, Kind.PLAY, Kind.ROBLOX, Kind.MUSIC_CONTROL,
        Kind.CALL, Kind.MESSAGE, Kind.REPLY, Kind.READ_WHATSAPP, Kind.SUMMARIZE_NOTIFICATIONS,
        Kind.FLASHLIGHT, Kind.OPEN_SETTINGS, Kind.PHONE_INFO, Kind.SCREEN_ANALYZE,
        Kind.CLIPBOARD, Kind.EMERGENCY, Kind.PRIVACY_PAUSE, Kind.CONNECTIVITY, Kind.SMART_TV, Kind.DEVICE_ACTION, Kind.AGENT -> AgentType.PHONE

        Kind.WEB_RESEARCH -> AgentType.RESEARCH

        Kind.STUDY, Kind.TRANSLATE, Kind.VOICE_FLASHCARD -> AgentType.STUDY

        Kind.TRAIN_STATUS, Kind.TRAVEL_CHECKLIST, Kind.NEARBY, Kind.WEATHER, Kind.NAVIGATE -> AgentType.TRAVEL

        Kind.MEMORY_SAVE, Kind.MEMORY_LIST, Kind.NOTE, Kind.MACRO_SAVE -> AgentType.MEMORY

        Kind.FILE_ANALYZE -> AgentType.FILE

        Kind.TIMER, Kind.REMINDER, Kind.ALARM, Kind.DAILY_BRIEFING,
        Kind.DATE_TIME, Kind.TASK_MANAGE, Kind.ROUTINE_RUN, Kind.CALENDAR -> AgentType.DAILY_PLANNER

        Kind.STORY, Kind.JOKE, Kind.SHAYARI, Kind.UTILITY, Kind.CHAT, Kind.CLARIFY, Kind.UNKNOWN -> AgentType.MAIN_ASSISTANT
    }

    fun dispatch(context: Context, index: AppIndex, c: Command, phoneExecutor: (Command) -> String): String {
        val agent = selectAgent(c)
        NovaState.update(activeAgent = agent.displayName)
        return when (agent) {
            AgentType.MAIN_ASSISTANT -> handleMain(context, c)
            AgentType.PHONE -> PhoneAgent.handle(context, index, c, phoneExecutor)
            AgentType.RESEARCH -> ResearchAgent.handle(context, c)
            AgentType.STUDY -> StudyAgent.handle(context, c)
            AgentType.TRAVEL -> TravelAgent.handle(context, c)
            AgentType.MEMORY -> MemoryAgent.handle(context, c)
            AgentType.FILE -> FileAgent.handle(context, c)
            AgentType.DAILY_PLANNER -> DailyPlannerAgent.handle(context, index, c, phoneExecutor)
        }
    }

    private fun handleMain(context: Context, c: Command): String = when (c.kind) {
        Kind.STORY -> CreativeContentHelper.tellStory(context, c.query.ifEmpty { c.heard })
        Kind.JOKE -> CreativeContentHelper.tellJoke(context, c.query.ifEmpty { c.heard })
        Kind.SHAYARI -> CreativeContentHelper.tellShayari(context, c.query.ifEmpty { c.heard })
        Kind.UTILITY -> UltimatePowerHelper.handleUtility(c.query, c.body.ifEmpty { c.heard })
        Kind.CLARIFY -> c.body.ifBlank { "Mujhe ye command clear nahi hua. Thoda aur detail me bolo." }
        Kind.CHAT -> GeminiClient.ask(context, c.query.ifEmpty { c.heard }, keepContext = !Prefs.privacyPaused(context))
        else -> "Mujhe ye command clear nahi hua. Bolo jaise: 'kahani sunao', 'battery kitni hai', ya '10 minute ka timer lagao'."
    }
}

object PhoneAgent {
    fun handle(context: Context, index: AppIndex, c: Command, phoneExecutor: (Command) -> String): String = when (c.kind) {
        Kind.CONNECTIVITY -> {
            val desiredOn = when (c.body) {
                "on" -> true
                "off" -> false
                else -> null
            }
            ConnectivityControlHelper.toggle(context, c.query, desiredOn)
        }
        Kind.SMART_TV -> SmartTvController.handleVoiceCommand(context, c.query, c.body)
        Kind.DEVICE_ACTION -> UltimatePowerHelper.executeDeviceAction(context, index, c.query, c.body)
        Kind.FLASHLIGHT -> PhoneControlHelper.setFlashlight(context, c.query != "off")
        Kind.OPEN_SETTINGS -> PhoneControlHelper.openSettingsPage(context, c.query)
        Kind.SUMMARIZE_NOTIFICATIONS -> NovaNotificationListener.summarizeAllNotifications(context)
        Kind.SCREEN_ANALYZE -> ScreenAnalyzer.analyzeCurrentScreen(context, c.query.ifEmpty { c.heard })
        else -> phoneExecutor(c)
    }
}

object ResearchAgent {
    fun handle(context: Context, c: Command): String =
        WebResearchHelper.research(context, c.query.ifEmpty { c.heard })
}

object StudyAgent {
    fun handle(context: Context, c: Command): String = when (c.kind) {
        Kind.VOICE_FLASHCARD -> VoiceFlashcardManager.startSession(context, c.query.ifEmpty { c.heard })
        Kind.TRANSLATE -> GeminiClient.askWithAgentPrompt(
            context,
            "You are Nova's Study & Language Agent. Translate, rewrite, or correct grammar clearly in Hindi/Hinglish/English (no markdown).",
            c.query.ifEmpty { c.heard },
            keepContext = false,
            maxTokens = 500
        )
        else -> {
            val q = c.query.ifEmpty { c.heard }
            MathEvaluator.trySolve(q)?.let { ans -> return "Iska answer hai: $ans." }
            val sys = """
You are Nova's Study Agent for Indian students (supports Hindi-medium Hinglish & English-medium).
Explain concepts step by step in simple language, show math steps clearly, and give concise revision takeaways.
Do NOT use markdown stars or hashtags because replies are read aloud.
""".trimIndent()
            GeminiClient.askWithAgentPrompt(context, sys, q, keepContext = !Prefs.privacyPaused(context), maxTokens = 800)
        }
    }
}

object TravelAgent {
    fun handle(context: Context, c: Command): String = when (c.kind) {
        Kind.TRAIN_STATUS -> RailRadarHelper.getLiveTrainStatusVoice(context, c.query.ifEmpty { c.heard })
            .also { GeminiClient.rememberExchange(context, c.heard.ifEmpty { c.query }, it) }
        Kind.TRAVEL_CHECKLIST -> RailRadarHelper.handleChecklistVoice(context, c.query.ifEmpty { c.heard })
        Kind.NAVIGATE -> UltimatePowerHelper.navigateToPlace(context, c.query)
        Kind.WEATHER -> NearbyPlacesHelper.fetchWeather(context)
        Kind.NEARBY -> {
            val place = NearbyPlacesHelper.detectPlaceType(c.query.ifEmpty { c.heard })
                ?: NearbyPlacesHelper.PlaceType("Petrol Pump", "\"amenity\"=\"fuel\"", "petrol pump near me")
            NearbyPlacesHelper.findNearestAndOpenMaps(context, place)
        }
        else -> "Travel request samajh nahi aaya."
    }
}

object MemoryAgent {
    fun handle(context: Context, c: Command): String = when (c.kind) {
        Kind.MEMORY_SAVE -> {
            if (c.body.isBlank()) {
                "Kya yaad rakhna hai? Bolo: yaad rakho mera favourite app Spotify hai."
            } else if (SmartMemory.isSensitive(c.body)) {
                "Security ke liye main passwords, OTP, PIN ya sensitive ID numbers bina permission ke memory me save nahi karta."
            } else {
                SmartMemory.addMemory(context, c.body)
                "Yaad rakh liya: \"${c.body}\"."
            }
        }
        Kind.NOTE -> UltimatePowerHelper.handleNotes(context, c.query, c.body)
        Kind.MACRO_SAVE -> {
            if (MacroStore.save(context, c.query, c.body)) {
                "Voice shortcut save kar diya! Ab '${c.query}' bolne par '${c.body}' chalega."
            } else {
                "Shortcut save nahi hua. Bolo jaise: 'Shortcut banao: raat ka mode matlab wifi off karo aur silent mode'."
            }
        }
        Kind.MEMORY_LIST -> {
            val list = SmartMemory.getMemories(context)
            if (list.isEmpty()) "Abhi koi saved memory nahi hai."
            else "Aapki saved memories: " + list.take(5).joinToString("; ") { it.text }
        }
        else -> "Memory command samajh nahi aaya."
    }
}

object FileAgent {
    fun handle(context: Context, c: Command): String =
        FileAssistant.answerQuestion(context, c.query.ifEmpty { c.heard })
}

object DailyPlannerAgent {
    fun handle(context: Context, index: AppIndex, c: Command, fallbackExecutor: (Command) -> String): String = when (c.kind) {
        Kind.TIMER -> TimerManager.handleVoiceCommand(context, c.query.ifEmpty { c.heard }, c.extraMinutes)
        Kind.TASK_MANAGE -> DailyPlannerStore.handleTaskVoice(context, c.query.ifEmpty { c.heard }, c.body)
        Kind.ROUTINE_RUN -> DailyPlannerStore.runRoutine(context, index, c.query.ifEmpty { c.heard })
        Kind.CALENDAR -> DailyPlannerStore.handleCalendarVoice(context, c.query.ifEmpty { c.heard }, c.body)
        Kind.DAILY_BRIEFING -> {
            val base = NearbyPlacesHelper.dailyBriefing(context, index)
            val tasks = DailyPlannerStore.getTasks(context).count { !it.done }
            val timers = TimerManager.activeTimers(context).size
            val cal = DailyPlannerStore.upcomingCalendarSummary(context)
            "$base Active timers: $timers. Pending tasks: $tasks. $cal".trim()
        }
        else -> fallbackExecutor(c)
    }
}
