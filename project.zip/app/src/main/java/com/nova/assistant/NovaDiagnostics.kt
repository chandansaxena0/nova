package com.nova.assistant

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Honest Service Health, Battery Efficiency & Vivo/iQOO Background Reliability Diagnostics.
 * Never claims background listening is active when ListenService is not actually running.
 */
object NovaDiagnostics {

    fun isServiceTrulyActive(): Boolean =
        ListenService.running && NovaState.mode != ListenMode.STOPPED

    fun isBatteryUnrestricted(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun buildDiagnosticsReport(context: Context): String {
        val running = isServiceTrulyActive()
        val wakePref = Prefs.wake(context)
        val paused = Prefs.privacyPaused(context)
        val micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val overlayOk = Settings.canDrawOverlays(context)
        val batteryOk = isBatteryUnrestricted(context)
        val bat = PhoneInfoHelper.battery(context)

        val uptimeStr = if (running && NovaState.serviceStartedAtMs > 0L) {
            val mins = ((System.currentTimeMillis() - NovaState.serviceStartedAtMs) / 60_000L).coerceAtLeast(0L)
            "${mins}m"
        } else "0m"

        val batteryDelta = if (running && NovaState.batteryAtStartPct >= 0 && bat.percent >= 0) {
            val diff = NovaState.batteryAtStartPct - bat.percent
            if (diff >= 0) "-${diff}% since start" else "+${-diff}% (charging)"
        } else "N/A"

        val wakeEngineStr = buildString {
            append("Hey Nova (ONNX): ").append(if (NovaState.neuralWakeReady) "READY" else "OFF/INIT")
            append(" | Hi & Okay Nova (Vosk): ").append(if (NovaState.multiPhraseWakeReady) "READY" else "LOADING/OFF")
        }

        val lastReason = NovaState.lastErrorReason.ifEmpty { Prefs.lastServiceFailure(context) }.ifEmpty { "None" }

        return buildString {
            append("Service State: ").append(
                when {
                    paused -> "PAUSED (Privacy Mode)"
                    running -> "RUNNING (${NovaState.mode.name}, uptime $uptimeStr)"
                    wakePref -> "STOPPED UNEXPECTEDLY (Wake toggle ON, service not running)"
                    else -> "STOPPED (Off)"
                }
            ).append('\n')
            append("Wake Engines: ").append(wakeEngineStr).append('\n')
            append("Triggers: ").append(NovaState.wakeTriggerCount)
            if (NovaState.lastWakePhrase.isNotEmpty()) append(" (last: ${NovaState.lastWakePhrase})")
            append(" | Threshold: ").append(String.format("%.2f", Prefs.wakeThreshold(context))).append('\n')
            append("Battery: ").append(bat.percent).append("% (").append(batteryDelta).append(") | Unrestricted: ")
            append(if (batteryOk) "YES" else "NO (Recommended)").append('\n')
            append("Permissions: Mic=").append(if (micGranted) "OK" else "MISSING")
            append(", Overlay=").append(if (overlayOk) "OK" else "MISSING")
            append(", Device=").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append('\n')
            append("Last Failure / Stop Reason: ").append(lastReason)
        }
    }

    /** Opens Vivo / iQOO / OriginOS / FuntouchOS background power or autostart settings with safe fallback. */
    fun openOemBackgroundSettings(context: Context): String {
        val candidates = listOf(
            Intent().setComponent(ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")),
            Intent().setComponent(ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
            Intent().setComponent(ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}")),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        )
        for (i in candidates) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return "Background battery / autostart settings khol di hain."
            } catch (_: Exception) {}
        }
        return "Settings > Apps > Nova > Battery me jakar 'Unrestricted / High background power consumption' aur Autostart ON karo."
    }

    fun vivoSetupInstructions(): String =
        "Vivo / iQOO (OriginOS / FuntouchOS) Best Reliability Steps:\n\n" +
        "1. Settings > Apps > Nova > Battery > select 'Unrestricted' (or Allow high background power consumption).\n" +
        "2. Settings > Apps > Nova > Permissions > enable Autostart / Background Start.\n" +
        "3. Open Recent Apps, tap the menu above Nova, and select 'Lock' so the system doesn't clear it.\n" +
        "4. Note: Android OS still enforces microphone & Doze limits on all apps; Nova automatically recovers where permitted."
}
