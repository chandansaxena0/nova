package com.nova.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ReminderItem(
    val id: Int,
    val title: String,
    val triggerAtMs: Long,
    val repeatDaily: Boolean = false
)

/** Persistent Reminders + Android AlarmManager scheduler. */
object ReminderStore {
    private const val PREF = "nova_reminders"
    private const val KEY = "items_json"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun all(c: Context): List<ReminderItem> {
        val raw = p(c).getString(KEY, "[]") ?: "[]"
        val out = mutableListOf<ReminderItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    ReminderItem(
                        id = o.optInt("id"),
                        title = o.optString("title"),
                        triggerAtMs = o.optLong("triggerAtMs"),
                        repeatDaily = o.optBoolean("repeatDaily", false)
                    )
                )
            }
        } catch (_: Exception) {}
        return out.sortedBy { it.triggerAtMs }
    }

    fun upcoming(c: Context): List<ReminderItem> {
        val now = System.currentTimeMillis()
        return all(c).filter { it.triggerAtMs >= now - 60_000L || it.repeatDaily }
    }

    fun add(c: Context, title: String, triggerAtMs: Long, repeatDaily: Boolean = false): ReminderItem {
        val list = all(c).toMutableList()
        val id = ((System.currentTimeMillis() / 1000L) % 1_000_000L).toInt() + list.size + 1
        val item = ReminderItem(id, title.trim(), triggerAtMs, repeatDaily)
        list.add(item)
        save(c, list)
        schedule(c, item)
        return item
    }

    fun update(c: Context, id: Int, newTitle: String, newTriggerMs: Long, repeatDaily: Boolean) {
        val list = all(c).map {
            if (it.id == id) it.copy(title = newTitle.trim(), triggerAtMs = newTriggerMs, repeatDaily = repeatDaily)
            else it
        }
        save(c, list)
        list.firstOrNull { it.id == id }?.let { schedule(c, it) }
    }

    fun delete(c: Context, id: Int) {
        cancel(c, id)
        save(c, all(c).filterNot { it.id == id })
    }

    fun rescheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        all(c).forEach { item ->
            if (item.triggerAtMs > now) {
                schedule(c, item)
            } else if (item.repeatDaily) {
                var next = item.triggerAtMs
                while (next <= now) next += 86_400_000L
                update(c, item.id, item.title, next, true)
            }
        }
    }

    fun schedule(c: Context, item: ReminderItem) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(c, item.id, item.title, item.repeatDaily)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.triggerAtMs, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.triggerAtMs, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.triggerAtMs, pi)
        }
    }

    private fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(c, id, "", false))
    }

    private fun pendingIntent(c: Context, id: Int, title: String, repeatDaily: Boolean): PendingIntent {
        val intent = Intent(c, ReminderReceiver::class.java).apply {
            putExtra("id", id)
            putExtra("title", title)
            putExtra("repeatDaily", repeatDaily)
        }
        return PendingIntent.getBroadcast(
            c, id, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun save(c: Context, list: List<ReminderItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("triggerAtMs", it.triggerAtMs)
                    .put("repeatDaily", it.repeatDaily)
            )
        }
        p(c).edit().putString(KEY, arr.toString()).apply()
    }

    fun formatTime(ms: Long): String =
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ms))
}
