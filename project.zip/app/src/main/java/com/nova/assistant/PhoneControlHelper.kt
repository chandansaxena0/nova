package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.Settings
import java.util.Locale

/**
 * Android-compliant Phone Control helpers:
 * - Flashlight ON/OFF via CameraManager.setTorchMode()
 * - Open specific Android Settings screens (honest: does NOT claim to bypass OS Wi-Fi/Mobile Data toggle blocks)
 */
object PhoneControlHelper {

    @Volatile
    var torchOn: Boolean = false
        private set

    fun setFlashlight(context: Context, enable: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                val chars = cm.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val isBack = chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                hasFlash && isBack
            } ?: cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Is device par flashlight hardware nahi mila."

            cm.setTorchMode(cameraId, enable)
            torchOn = enable
            if (enable) "Flashlight ON kar di hai." else "Flashlight OFF kar di hai."
        } catch (e: Exception) {
            "Flashlight control nahi ho paya (camera kisi aur app me open ho sakta hai): ${e.message?.take(80)}"
        }
    }

    fun openSettingsPage(context: Context, rawTopic: String): String {
        val t = rawTopic.lowercase(Locale.ROOT)
        val (action, label) = when {
            t.contains("wi-fi") || t.contains("wifi") -> Settings.ACTION_WIFI_SETTINGS to "Wi-Fi Settings"
            t.contains("bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS to "Bluetooth Settings"
            t.contains("data") || t.contains("mobile") || t.contains("network") || t.contains("sim") ->
                Settings.ACTION_WIRELESS_SETTINGS to "Network & Mobile Data Settings"
            t.contains("display") || t.contains("brightness") || t.contains("screen") ->
                Settings.ACTION_DISPLAY_SETTINGS to "Display Settings"
            t.contains("sound") || t.contains("volume") || t.contains("ringtone") ->
                Settings.ACTION_SOUND_SETTINGS to "Sound Settings"
            t.contains("battery") || t.contains("power") ->
                Settings.ACTION_BATTERY_SAVER_SETTINGS to "Battery Settings"
            t.contains("location") || t.contains("gps") ->
                Settings.ACTION_LOCATION_SOURCE_SETTINGS to "Location Settings"
            t.contains("storage") ->
                Settings.ACTION_INTERNAL_STORAGE_SETTINGS to "Storage Settings"
            t.contains("app") ->
                Settings.ACTION_APPLICATION_SETTINGS to "Apps Settings"
            t.contains("notification") ->
                Settings.ACTION_APP_NOTIFICATION_SETTINGS to "Notification Settings"
            else -> Settings.ACTION_SETTINGS to "Phone Settings"
        }

        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (action == Settings.ACTION_APP_NOTIFICATION_SETTINGS) {
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
        return try {
            context.startActivity(intent)
            "$label khol di hain."
        } catch (_: Exception) {
            runCatching { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            "Phone Settings khol di hain."
        }
    }
}
