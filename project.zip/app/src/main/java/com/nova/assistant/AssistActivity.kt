package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Assistant / Bluetooth headset / lock-screen quick voice entry (supports interrupting speech). */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        if (Prefs.privacyPaused(this)) {
            Toast.makeText(this, "Nova Privacy Mode is ON. Open app to Resume.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, ListenService::class.java).setAction(ListenService.ACTION_INTERRUPT_AND_LISTEN)
            )
            Toast.makeText(this, "Nova is listening...", Toast.LENGTH_SHORT).show()
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}
