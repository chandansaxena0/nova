package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * Entry for the phone's "assistant" button: Bluetooth headset voice button,
 * power-button long press (if Nova is chosen), lock-screen shortcut.
 * It shows nothing: it tells the listener "listen now" and closes at once.
 */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, ListenService::class.java).setAction(ListenService.ACTION_LISTEN_NOW)
            )
            Toast.makeText(this, "Boliye...", Toast.LENGTH_SHORT).show()
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}
