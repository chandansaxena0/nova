package com.nova.assistant

import android.content.Context

/** Local on-device preferences. Sensitive API keys are encrypted via Android Keystore (SecureVault). */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun wake(c: Context): Boolean = p(c).getBoolean("wake", false)
    fun setWake(c: Context, value: Boolean) {
        p(c).edit().putBoolean("wake", value).commit()
    }

    /** Master Privacy & Pause Everything switch. */
    fun privacyPaused(c: Context): Boolean = p(c).getBoolean("privacy_paused", false)
    fun setPrivacyPaused(c: Context, paused: Boolean) {
        p(c).edit().putBoolean("privacy_paused", paused).commit()
    }

    /** Wake word detection sensitivity threshold (0.45 = high sensitivity .. 0.85 = strict low false-trigger). */
    fun wakeThreshold(c: Context): Float = p(c).getFloat("wake_threshold", 0.55f).coerceIn(0.45f, 0.85f)
    fun setWakeThreshold(c: Context, value: Float) {
        p(c).edit().putFloat("wake_threshold", value.coerceIn(0.45f, 0.85f)).apply()
    }

    /** Short spoken confirmation after wake word ("Yes, I'm listening." / "Ji, sun raha hoon."). */
    fun wakeVoiceReply(c: Context): Boolean = p(c).getBoolean("wake_voice_reply", true)
    fun setWakeVoiceReply(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("wake_voice_reply", enabled).apply()
    }

    /** Continuous follow-up listening session timeout: 15, 30, or 40 seconds (default 30s). */
    fun sessionDurationSeconds(c: Context): Int = when (p(c).getInt("session_seconds", 30)) {
        15 -> 15
        40 -> 40
        else -> 30
    }

    fun sessionDurationMs(c: Context): Long = sessionDurationSeconds(c) * 1000L

    fun setSessionDurationSeconds(c: Context, seconds: Int) {
        val clean = when {
            seconds <= 15 -> 15
            seconds >= 40 -> 40
            else -> 30
        }
        p(c).edit().putInt("session_seconds", clean).apply()
    }

    /** Hinglish (default), English, or Hindi reply preference. */
    fun replyLanguage(c: Context): String = p(c).getString("reply_lang", "english") ?: "english"
    fun setReplyLanguage(c: Context, lang: String) {
        p(c).edit().putString("reply_lang", lang).apply()
    }

    /** TTS speech rate (0.75f .. 1.5f, default 1.05f). */
    fun ttsSpeed(c: Context): Float = p(c).getFloat("tts_speed", 1.05f).coerceIn(0.75f, 1.5f)
    fun setTtsSpeed(c: Context, speed: Float) {
        p(c).edit().putFloat("tts_speed", speed.coerceIn(0.75f, 1.5f)).apply()
    }

    fun ttsVoice(c: Context): String = p(c).getString("tts_voice", "").orEmpty()
    fun setTtsVoice(c: Context, name: String) {
        p(c).edit().putString("tts_voice", name).apply()
    }

    fun soundFeedback(c: Context): Boolean = p(c).getBoolean("sound_feedback", true)
    fun setSoundFeedback(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("sound_feedback", enabled).apply()
    }

    fun batterySaver(c: Context): Boolean = p(c).getBoolean("battery_saver", false)
    fun setBatterySaver(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("battery_saver", enabled).apply()
    }

    fun lowBatteryAlert(c: Context): Boolean = p(c).getBoolean("low_battery_alert", true)
    fun setLowBatteryAlert(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("low_battery_alert", enabled).apply()
    }

    fun saveHistory(c: Context): Boolean = !privacyPaused(c) && p(c).getBoolean("save_history", true)
    fun saveHistoryRaw(c: Context): Boolean = p(c).getBoolean("save_history", true)
    fun setSaveHistory(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("save_history", enabled).apply()
    }

    /** Persisted diagnostic reason whenever background service stops or encounters an error. */
    fun lastServiceFailure(c: Context): String = p(c).getString("last_service_failure", "").orEmpty()
    fun setLastServiceFailure(c: Context, reason: String) {
        p(c).edit().putString("last_service_failure", reason.trim()).apply()
    }

    fun geminiKey(c: Context): String = SecureVault.decrypt(p(c).getString("gemini_key", ""))

    fun geminiModel(c: Context): String {
        val m = p(c).getString("gemini_model", "")?.trim().orEmpty()
        val deprecated = setOf(
            "", "gemini-2.0-flash", "gemini-2.0-flash-001", "gemini-2.0-flash-lite",
            "gemini-1.5-flash", "gemini-1.5-pro", "gemini-1.5-flash-8b", "gemini-pro", "gemini-1.0-pro"
        )
        return if (m.lowercase() in deprecated) GeminiClient.DEFAULT_MODEL else m
    }

    fun setGemini(c: Context, key: String, model: String) {
        val cleanModel = model.trim().ifEmpty { GeminiClient.DEFAULT_MODEL }
        p(c).edit()
            .putString("gemini_key", SecureVault.encrypt(key.trim()))
            .putString("gemini_model", cleanModel)
            .apply()
    }

    // ---- AI provider choice: Gemini / Grok (xAI) / OpenRouter ----
    fun aiProvider(c: Context): String {
        val v = p(c).getString("ai_provider", OpenAiCompat.GEMINI) ?: OpenAiCompat.GEMINI
        return if (v == OpenAiCompat.GROK || v == OpenAiCompat.OPENROUTER) v else OpenAiCompat.GEMINI
    }

    fun setAiProvider(c: Context, provider: String) {
        p(c).edit().putString("ai_provider", provider).apply()
    }

    fun aiKey(c: Context, provider: String): String = when (provider) {
        OpenAiCompat.GROK -> SecureVault.decrypt(p(c).getString("grok_key", ""))
        OpenAiCompat.OPENROUTER -> SecureVault.decrypt(p(c).getString("openrouter_key", ""))
        else -> geminiKey(c)
    }

    fun aiModel(c: Context, provider: String): String = when (provider) {
        OpenAiCompat.GROK -> p(c).getString("grok_model", "")?.trim().orEmpty().ifEmpty { OpenAiCompat.GROK_DEFAULT_MODEL }
        OpenAiCompat.OPENROUTER -> p(c).getString("openrouter_model", "")?.trim().orEmpty().ifEmpty { OpenAiCompat.OPENROUTER_DEFAULT_MODEL }
        else -> geminiModel(c)
    }

    fun setAiKeyModel(c: Context, provider: String, key: String, model: String) {
        when (provider) {
            OpenAiCompat.GROK -> p(c).edit()
                .putString("grok_key", SecureVault.encrypt(key.trim()))
                .putString("grok_model", model.trim().ifEmpty { OpenAiCompat.GROK_DEFAULT_MODEL })
                .apply()
            OpenAiCompat.OPENROUTER -> p(c).edit()
                .putString("openrouter_key", SecureVault.encrypt(key.trim()))
                .putString("openrouter_model", model.trim().ifEmpty { OpenAiCompat.OPENROUTER_DEFAULT_MODEL })
                .apply()
            else -> setGemini(c, key, model)
        }
    }

    /** Key / model of the provider selected in Settings. */
    fun activeKey(c: Context): String = aiKey(c, aiProvider(c))
    fun activeModel(c: Context): String = aiModel(c, aiProvider(c))
    fun hasAi(c: Context): Boolean = activeKey(c).isNotEmpty()

    fun emergencyName(c: Context): String = p(c).getString("emergency_name", "").orEmpty()
    fun emergencyNumber(c: Context): String = p(c).getString("emergency_number", "").orEmpty()
    fun setEmergencyContact(c: Context, name: String, number: String) {
        p(c).edit()
            .putString("emergency_name", name.trim())
            .putString("emergency_number", number.trim())
            .apply()
    }

    // RailRadar Live Train API settings (encrypted on-device)
    fun railRadarKey(c: Context): String = SecureVault.decrypt(p(c).getString("railradar_key", ""))
    fun railRadarBaseUrl(c: Context): String =
        p(c).getString("railradar_base_url", "")?.trim()?.trimEnd('/').orEmpty()
            .ifEmpty { RailRadarHelper.DEFAULT_BASE_URL }

    fun setRailRadar(c: Context, key: String, baseUrl: String) {
        val cleanUrl = baseUrl.trim().trimEnd('/').ifEmpty { RailRadarHelper.DEFAULT_BASE_URL }
        p(c).edit()
            .putString("railradar_key", SecureVault.encrypt(key.trim()))
            .putString("railradar_base_url", cleanUrl)
            .apply()
    }

    fun preferredMusicPkg(c: Context): String = p(c).getString("pref_music_pkg", "").orEmpty()
    fun setPreferredMusicPkg(c: Context, pkg: String) {
        p(c).edit().putString("pref_music_pkg", pkg.trim()).apply()
    }
}
