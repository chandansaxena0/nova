package com.nova.assistant

import android.content.Context

/** Local on-device preferences. Nothing leaves the phone except explicit user-enabled API calls. */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun wake(c: Context): Boolean = p(c).getBoolean("wake", false)
    fun setWake(c: Context, value: Boolean) {
        p(c).edit().putBoolean("wake", value).apply()
    }

    /** Command listening session timeout: 30 or 40 seconds (default 30s). */
    fun sessionDurationSeconds(c: Context): Int =
        if (p(c).getInt("session_seconds", 30) >= 40) 40 else 30

    fun sessionDurationMs(c: Context): Long = sessionDurationSeconds(c) * 1000L

    fun setSessionDurationSeconds(c: Context, seconds: Int) {
        p(c).edit().putInt("session_seconds", if (seconds >= 40) 40 else 30).apply()
    }

    /** Hinglish (default), English, or Hindi reply preference (recognized/search text stays Hinglish). */
    fun replyLanguage(c: Context): String = p(c).getString("reply_lang", "hinglish") ?: "hinglish"
    fun setReplyLanguage(c: Context, lang: String) {
        p(c).edit().putString("reply_lang", lang).apply()
    }

    /** TTS speech rate (0.75f .. 1.5f, default 1.05f). */
    fun ttsSpeed(c: Context): Float = p(c).getFloat("tts_speed", 1.05f).coerceIn(0.75f, 1.5f)
    fun setTtsSpeed(c: Context, speed: Float) {
        p(c).edit().putFloat("tts_speed", speed.coerceIn(0.75f, 1.5f)).apply()
    }

    /** Preferred TTS voice name (empty = auto best Indian English/Hindi voice). */
    fun ttsVoice(c: Context): String = p(c).getString("tts_voice", "").orEmpty()
    fun setTtsVoice(c: Context, name: String) {
        p(c).edit().putString("tts_voice", name).apply()
    }

    fun soundFeedback(c: Context): Boolean = p(c).getBoolean("sound_feedback", true)
    fun setSoundFeedback(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("sound_feedback", enabled).apply()
    }

    fun batterySaver(c: Context): Boolean = p(c).getBoolean("battery_saver", false)
    fun setBatterySaver(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("battery_saver", enabled).apply()
    }

    fun lowBatteryAlert(c: Context): Boolean = p(c).getBoolean("low_battery_alert", true)
    fun setLowBatteryAlert(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("low_battery_alert", enabled).apply()
    }

    fun saveHistory(c: Context): Boolean = p(c).getBoolean("save_history", true)
    fun setSaveHistory(c: Context, enabled: Boolean) {
        p(c).edit().putBoolean("save_history", enabled).apply()
    }

    fun geminiKey(c: Context): String = p(c).getString("gemini_key", "")?.trim().orEmpty()

    fun geminiModel(c: Context): String {
        val m = p(c).getString("gemini_model", "")?.trim().orEmpty()
        // Auto-migrate broken legacy default model name
        return if (m.isEmpty() || m == "gemini-3.5-flash-lite") GeminiClient.DEFAULT_MODEL else m
    }

    fun setGemini(c: Context, key: String, model: String) {
        val cleanModel = model.trim().ifEmpty { GeminiClient.DEFAULT_MODEL }
        p(c).edit()
            .putString("gemini_key", key.trim())
            .putString("gemini_model", cleanModel)
            .apply()
    }

    fun emergencyName(c: Context): String = p(c).getString("emergency_name", "").orEmpty()
    fun emergencyNumber(c: Context): String = p(c).getString("emergency_number", "").orEmpty()
    fun setEmergencyContact(c: Context, name: String, number: String) {
        p(c).edit()
            .putString("emergency_name", name.trim())
            .putString("emergency_number", number.trim())
            .apply()
    }

    fun preferredMusicPkg(c: Context): String = p(c).getString("pref_music_pkg", "").orEmpty()
    fun setPreferredMusicPkg(c: Context, pkg: String) {
        p(c).edit().putString("pref_music_pkg", pkg.trim()).apply()
    }
}
