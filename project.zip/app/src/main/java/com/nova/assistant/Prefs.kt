package com.nova.assistant

import android.content.Context

/** Small settings stored only on this phone (never uploaded anywhere). */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun wake(c: Context): Boolean = p(c).getBoolean("wake", false)

    fun setWake(c: Context, value: Boolean) {
        p(c).edit().putBoolean("wake", value).apply()
    }

    fun sessionDurationMs(c: Context): Long {
        val seconds = p(c).getInt("session_seconds", 30).coerceIn(30, 40)
        return seconds * 1000L
    }

    fun setSessionDurationSeconds(c: Context, seconds: Int) {
        p(c).edit().putInt("session_seconds", if (seconds >= 40) 40 else 30).apply()
    }

    fun geminiKey(c: Context): String = p(c).getString("gemini_key", "")?.trim().orEmpty()

    fun geminiModel(c: Context): String {
        val m = p(c).getString("gemini_model", "")?.trim().orEmpty()
        return if (m.isEmpty()) GeminiClient.DEFAULT_MODEL else m
    }

    fun setGemini(c: Context, key: String, model: String) {
        p(c).edit()
            .putString("gemini_key", key.trim())
            .putString("gemini_model", model.trim())
            .apply()
    }
}
