package com.nova.assistant

import android.content.Context
import java.util.Locale

/**
 * Interactive Voice Interview & Viva Practice Manager for Nova v11.0:
 *   - Supports Airforce / Defence Interview, B.Sc. Physics / Maths / Chemistry Viva, and HR Interview.
 *   - Conducts 5 progressive cross-questions, evaluates each spoken answer out of 10 with concise tips,
 *     and gives a final scorecard out of 50.
 */
object InterviewVivaManager {

    data class VivaQuestion(val prompt: String, val keyPoints: List<String>)

    @Volatile
    var active: Boolean = false
        private set

    private var topic: String = ""
    private var questions: List<VivaQuestion> = emptyList()
    private var currentIndex: Int = 0
    private var totalScore: Int = 0
    private var appContext: Context? = null

    private val offlineBanks: Map<String, List<VivaQuestion>> = mapOf(
        "airforce" to listOf(
            VivaQuestion("Apna short introduction dijiye aur bataiye aap Indian Air Force kyun join karna chahte hain?", listOf("country", "nation", "discipline", "air force", "serve", "dream", "passion", "desh")),
            VivaQuestion("Agar aapki team ka ek member task ke beech me demotivate ho jaye to aap kya karoge?", listOf("motivate", "help", "support", "team", "listen", "guide", "together")),
            VivaQuestion("Newton ke third law of motion ka koi real-life aviation ya rocket example bataiye.", listOf("action", "reaction", "equal", "opposite", "jet", "rocket", "thrust", "exhaust")),
            VivaQuestion("Aapki sabse badi strength aur ek weakness kya hai, aur weakness par aap kya kaam kar rahe hain?", listOf("strength", "weakness", "improve", "practice", "discipline", "hard work", "focus")),
            VivaQuestion("High pressure situation me aap apna decision kaise lete hain?", listOf("calm", "analyze", "priority", "focus", "fact", "cool", "step"))
        ),
        "physics" to listOf(
            VivaQuestion("Newton ke first law aur inertia ke beech kya relation hai?", listOf("rest", "motion", "external force", "mass", "state", "change")),
            VivaQuestion("Work done zero kab hota hai jabki force aur displacement dono non-zero hon?", listOf("90", "perpendicular", "cos 90", "right angle", "circular")),
            VivaQuestion("Conservative aur non-conservative force me main difference kya hai?", listOf("path", "independent", "gravity", "friction", "closed loop", "energy")),
            VivaQuestion("Simple harmonic motion (SHM) ki essential condition kya hoti hai?", listOf("restoring force", "displacement", "proportional", "opposite", "mean position")),
            VivaQuestion("Differential calculus me derivative ka physical meaning kya hota hai?", listOf("rate of change", "slope", "tangent", "velocity", "instantaneous"))
        ),
        "hr" to listOf(
            VivaQuestion("Tell me about yourself and one project or skill you are most proud of.", listOf("project", "skill", "learn", "build", "student", "experience")),
            VivaQuestion("Jab aapko koi naya mushkil skill seekhna hota hai to aap kaise approach karte hain?", listOf("practice", "research", "break", "step", "daily", "build")),
            VivaQuestion("Aap team work prefer karte hain ya solo work, aur kyun?", listOf("team", "both", "collaborate", "depend", "responsibility")),
            VivaQuestion("Apni koi aisi galti bataiye jisse aapne kuch important seekha ho.", listOf("mistake", "learn", "improve", "check", "plan")),
            VivaQuestion("Agle 2 saal me aap apne aap ko kahan dekhte hain?", listOf("goal", "grow", "skill", "career", "achieve", "better"))
        )
    )

    fun stopSession(): String {
        val wasActive = active
        val asked = currentIndex
        val scoreNow = totalScore
        active = false
        questions = emptyList()
        currentIndex = 0
        totalScore = 0
        return if (wasActive && asked > 0) {
            "Interview practice band kar di hai. $asked sawalon me aapka total score $scoreNow out of ${asked * 10} raha."
        } else {
            "Interview / Viva mode band kar diya hai."
        }
    }

    fun startSession(context: Context, rawRequest: String): String {
        appContext = context.applicationContext
        val cleanTopic = extractTopic(rawRequest)
        val aiBank = generateQuestionsViaAi(context, cleanTopic)
        val bank = aiBank ?: pickOfflineBank(cleanTopic)

        topic = cleanTopic
        questions = bank
        currentIndex = 0
        totalScore = 0
        active = true

        return "$topic viva / interview practice shuru ho rahi hai (${bank.size} sawal). Jawab detail me boliye, ya 'interview band karo' keh sakte hain. Sawal 1: ${bank.first().prompt}"
    }

    private fun generateQuestionsViaAi(context: Context, topicName: String): List<VivaQuestion>? {
        if (!Prefs.hasAi(context) || !PhoneInfoHelper.isOnline(context)) return null
        val prompt = """
Create exactly 5 progressive oral interview / viva questions on "$topicName" in natural Roman Hinglish (NO Devanagari, NO markdown).
Format EVERY line strictly as:
Q: question text | K: keyword1, keyword2, keyword3
Output only those 5 lines.
""".trimIndent()
        return try {
            val raw = GeminiClient.ask(context, prompt, keepContext = false)
            parseQuestions(raw)
        } catch (_: Exception) {
            null
        }
    }

    fun parseQuestions(raw: String): List<VivaQuestion>? {
        val out = ArrayList<VivaQuestion>()
        for (line in raw.lines()) {
            if (!line.contains("|")) continue
            val parts = line.split("|").map { it.trim() }
            val q = parts[0].replace(Regex("^Q\\s*:\\s*", RegexOption.IGNORE_CASE), "").trim()
            val kws = parts.getOrNull(1)
                ?.replace(Regex("^K\\s*:\\s*", RegexOption.IGNORE_CASE), "")
                ?.split(",")
                ?.map { it.trim().lowercase(Locale.ROOT) }
                ?.filter { it.isNotEmpty() }
                .orEmpty()
            if (q.length >= 10) out.add(VivaQuestion(q, kws))
        }
        return out.take(5).takeIf { it.size >= 3 }
    }

    /** Scores a spoken answer offline (0..10) based on relevance keywords + clarity/completeness. */
    fun scoreAnswerOffline(answer: String, q: VivaQuestion): Pair<Int, String> {
        val lower = answer.lowercase(Locale.ROOT).trim()
        val words = lower.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size <= 2 || lower in setOf("skip", "pata nahi", "nahi pata", "pass")) {
            return 2 to "Thoda aur detail aur example ke saath bolne ki koshish karo."
        }
        val hits = q.keyPoints.count { kw -> lower.contains(kw) }
        val lengthBonus = when {
            words.size >= 14 -> 3
            words.size >= 8 -> 2
            else -> 1
        }
        val kwScore = when {
            hits >= 3 -> 7
            hits == 2 -> 6
            hits == 1 -> 4
            else -> 3
        }
        val score = (kwScore + lengthBonus).coerceIn(3, 10)
        val tip = when {
            score >= 8 -> "Bahut solid aur confident jawab!"
            score >= 6 -> "Accha jawab hai, ek real example jod kar aur sharp bana sakte ho."
            else -> "Concept thoda aur clear rakho — key points jaise ${q.keyPoints.take(3).joinToString(", ")} cover karo."
        }
        return score to tip
    }

    fun handleAnswer(context: Context, rawAnswer: String): String {
        if (!active || currentIndex >= questions.size) {
            active = false
            return ""
        }
        val clean = HinglishConverter.toHinglish(rawAnswer).trim()
        val lower = clean.lowercase(Locale.ROOT)
        if ((lower.contains("interview") || lower.contains("viva")) &&
            (lower.contains("band") || lower.contains("stop") || lower.contains("exit") || lower.contains("end"))
        ) {
            return stopSession()
        }

        val q = questions[currentIndex]
        val (score, feedback) = evaluateAnswer(context, q, clean)
        totalScore += score
        currentIndex++

        return if (currentIndex < questions.size) {
            val next = questions[currentIndex]
            "Score: $score/10. $feedback Agla sawal ${currentIndex + 1}: ${next.prompt}"
        } else {
            val maxTotal = questions.size * 10
            val finalScore = totalScore
            val pct = (finalScore * 100) / maxTotal.coerceAtLeast(1)
            active = false
            questions = emptyList()
            appContext?.let { runCatching { StudyProgressStore.recordSession(it, "$topic viva", finalScore, maxTotal) } }
            "Score: $score/10. $feedback Interview complete! Final scorecard: $finalScore out of $maxTotal ($pct%). Keep practicing!"
        }
    }

    private fun evaluateAnswer(context: Context, q: VivaQuestion, answer: String): Pair<Int, String> {
        if (Prefs.hasAi(context) && PhoneInfoHelper.isOnline(context) && answer.length >= 12) {
            val evalPrompt = "Question: ${q.prompt}\nCandidate Answer: $answer\nScore out of 10 and give 1 short Hinglish tip strictly in format: SCORE: 8 | TIP: your 1-sentence tip"
            val raw = runCatching {
                GeminiClient.askWithAgentPrompt(
                    context,
                    "You are a supportive Indian viva/interview examiner. Reply strictly as 'SCORE: <1-10> | TIP: <1 short Hinglish sentence>' (no markdown).",
                    evalPrompt,
                    keepContext = false,
                    maxTokens = 120
                )
            }.getOrDefault("")
            val m = Regex("SCORE\\s*:\\s*(\\d{1,2})\\s*\\|\\s*TIP\\s*:\\s*(.+)", RegexOption.IGNORE_CASE).find(raw)
            if (m != null) {
                val sc = m.groupValues[1].toIntOrNull()?.coerceIn(1, 10) ?: 7
                val tip = m.groupValues[2].trim()
                if (tip.isNotEmpty()) return sc to tip
            }
        }
        return scoreAnswerOffline(answer, q)
    }

    private fun extractTopic(raw: String): String {
        val lower = raw.lowercase(Locale.ROOT)
        return when {
            lower.contains("airforce") || lower.contains("air force") || lower.contains("agniveer") || lower.contains("defence") || lower.contains("ssb") -> "Airforce Defence"
            lower.contains("phys") -> "Physics"
            lower.contains("math") || lower.contains("calc") -> "Maths"
            lower.contains("chem") -> "Chemistry"
            lower.contains("hr") || lower.contains("job") -> "HR"
            else -> raw.replace(Regex("(?i)\\b(nova|viva|interview|roleplay|mock|practice|shuru|start|karo|chalu|mode)\\b"), " ")
                .replace(Regex("\\s+"), " ").trim().ifEmpty { "General Interview" }
        }
    }

    private fun pickOfflineBank(topicName: String): List<VivaQuestion> {
        val l = topicName.lowercase(Locale.ROOT)
        return when {
            l.contains("airforce") || l.contains("defence") -> offlineBanks["airforce"]!!
            l.contains("phys") || l.contains("math") || l.contains("chem") -> offlineBanks["physics"]!!
            else -> offlineBanks["hr"]!!
        }
    }
}
