package com.nova.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/** Fires reminder notifications, announces via Nova voice if active, and reschedules daily repeats. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 100)
        val title = intent.getStringExtra("title")?.ifBlank { "Nova Reminder" } ?: "Nova Reminder"
        val repeatDaily = intent.getBooleanExtra("repeatDaily", false)

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nova_reminders", "Nova Reminders", NotificationManager.IMPORTANCE_HIGH)
        )

        val open = PendingIntent.getActivity(
            context, id,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        nm.notify(
            5000 + (id % 1000),
            NotificationCompat.Builder(context, "nova_reminders")
                .setSmallIcon(R.drawable.ic_mic)
                .setContentTitle("Nova Reminder")
                .setContentText(title)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
        )

        // Voice alert through ListenService if running
        if (ListenService.running) {
            val speakIntent = Intent(context, ListenService::class.java).apply {
                action = ListenService.ACTION_SPEAK_ALERT
                putExtra("message", "Reminder: $title")
            }
            try {
                context.startService(speakIntent)
            } catch (_: Exception) {}
        }

        if (repeatDaily) {
            val next = System.currentTimeMillis() + 86_400_000L
            ReminderStore.update(context, id, title, next, true)
        } else {
            ReminderStore.delete(context, id)
        }
    }
}
