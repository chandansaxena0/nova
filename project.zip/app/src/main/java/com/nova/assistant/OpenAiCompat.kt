package com.nova.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

/**
 * Chat client for OpenAI-compatible providers: Grok (xAI) and OpenRouter.
 * Gemini keeps its own client in [GeminiClient]; this file is only used when the
 * user picks Grok or OpenRouter in Settings.
 */
object OpenAiCompat {
    const val GEMINI = "gemini"
    const val GROK = "grok"
    const val OPENROUTER = "openrouter"
    const val GROK_DEFAULT_MODEL = "grok-4-fast"
    const val OPENROUTER_DEFAULT_MODEL = "openrouter/free"

    fun label(p: String) = when (p) {
        GROK -> "Grok (xAI)"
        OPENROUTER -> "OpenRouter"
        else -> "Gemini"
    }

    fun defaultModel(p: String) = when (p) {
        GROK -> GROK_DEFAULT_MODEL
        OPENROUTER -> OPENROUTER_DEFAULT_MODEL
        else -> GeminiClient.DEFAULT_MODEL
    }

    private fun base(p: String) =
        if (p == GROK) "https://api.x.ai/v1" else "https://openrouter.ai/api/v1"

    private data class Resp(val code: Int, val body: String)

    private fun http(provider: String, key: String, method: String, path: String, payload: ByteArray?): Resp {
        val conn = (URL(base(provider) + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 10000
            readTimeout = 40000
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Accept", "application/json")
            if (provider == OPENROUTER) setRequestProperty("X-Title", "Nova Assistant")
            if (payload != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }
        AiRouter.registerActiveConnection(conn)
        try {
            if (payload != null) conn.outputStream.use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            return Resp(code, stream?.bufferedReader()?.use { it.readText() } ?: "")
        } finally {
            AiRouter.clearActiveConnection(conn)
            conn.disconnect()
        }
    }

    private fun errorText(body: String): String = try {
        val j = JSONObject(body)
        when (val e = j.opt("error")) {
            is JSONObject -> e.optString("message", body)
            is String -> e
            else -> j.optString("message", body)
        }
    } catch (_: Exception) {
        body
    }

    private fun extractContent(body: String): String {
        val msg = JSONObject(body).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            ?: return ""
        val text = when (val c = msg.opt("content")) {
            is String -> c
            is JSONArray -> buildString {
                for (i in 0 until c.length()) append(c.optJSONObject(i)?.optString("text").orEmpty())
            }
            else -> ""
        }
        return text.replace(Regex("(?s)<think>.*?</think>"), "").trim()
    }

    /** turns = list of (role, text), role is "user" or "model"/"assistant". Throws RuntimeException("HTTP code: msg"). */
    fun chat(
        provider: String,
        rawKey: String,
        model: String,
        system: String,
        turns: List<Pair<String, String>>,
        temp: Double,
        maxTokens: Int,
        imageDataUri: String? = null
    ): String {
        val key = rawKey.trim()
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        turns.forEachIndexed { i, (role, text) ->
            val r = if (role == "model") "assistant" else role
            if (i == turns.lastIndex && imageDataUri != null) {
                val parts = JSONArray()
                    .put(JSONObject().put("type", "text").put("text", text))
                    .put(
                        JSONObject().put("type", "image_url")
                            .put("image_url", JSONObject().put("url", imageDataUri))
                    )
                messages.put(JSONObject().put("role", r).put("content", parts))
            } else {
                messages.put(JSONObject().put("role", r).put("content", text))
            }
        }
        val body = JSONObject()
            .put("model", model.trim().ifEmpty { defaultModel(provider) })
            .put("messages", messages)
            .put("temperature", temp)
            // some free/reasoning models spend tokens on thinking, so never go very low
            .put("max_tokens", maxOf(maxTokens, 800))
        val payload = body.toString().toByteArray(Charsets.UTF_8)

        var last: Exception? = null
        for (attempt in 0..2) {
            if (AiRouter.isCancelled()) throw RuntimeException("Request cancelled")
            try {
                val r = http(provider, key, "POST", "/chat/completions", payload)
                if (r.code in 200..299) return extractContent(r.body)
                throw RuntimeException("HTTP ${r.code}: ${errorText(r.body).take(200)}")
            } catch (e: Exception) {
                last = e
                if (AiRouter.isCancelled()) throw e
                val m = e.message.orEmpty()
                val retry = e is SocketTimeoutException || m.contains("HTTP 429") ||
                    m.contains("HTTP 502") || m.contains("HTTP 503")
                if (attempt == 2 || !retry) throw e
                Thread.sleep(AiRouter.backoffDelayMs(attempt))
            }
        }
        throw last ?: RuntimeException("Request failed")
    }

    private fun listModels(provider: String, key: String): List<String> {
        val r = http(provider, key, "GET", "/models", null)
        if (r.code !in 200..299) throw RuntimeException("HTTP ${r.code}: ${errorText(r.body).take(200)}")
        val arr = JSONObject(r.body).optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("id") }
            .filter { it.isNotBlank() }
    }

    /** Used by "Save & Test". Picks a working model automatically when the typed one does not exist. */
    fun test(provider: String, rawKey: String, preferred: String): GeminiClient.TestOutcome {
        val key = rawKey.trim().replace("\"", "").replace("'", "").replace("\\s+".toRegex(), "")
        if (key.isEmpty()) return GeminiClient.TestOutcome(false, preferred, "API key is empty.")
        var model = preferred.trim().ifEmpty { defaultModel(provider) }
        try {
            if (provider == GROK) {
                val ids = listModels(provider, key)
                if (ids.isNotEmpty() && model !in ids) {
                    val bad = listOf("image", "imagine", "vision", "reasoning", "embed")
                    model = ids.firstOrNull { it.contains("grok") && it.contains("fast") && bad.none { b -> it.contains(b) } }
                        ?: ids.firstOrNull { it.startsWith("grok") && bad.none { b -> it.contains(b) } }
                        ?: model
                }
            }
            try {
                chat(provider, key, model, "Reply with OK.", listOf("user" to "Say OK"), 0.0, 20)
            } catch (e: RuntimeException) {
                if (provider == OPENROUTER && e.message?.contains("HTTP 404") == true && model != OPENROUTER_DEFAULT_MODEL) {
                    model = OPENROUTER_DEFAULT_MODEL
                    chat(provider, key, model, "Reply with OK.", listOf("user" to "Say OK"), 0.0, 20)
                } else throw e
            }
            return GeminiClient.TestOutcome(true, model, "Connected! ${label(provider)} ($model) is working.")
        } catch (e: java.net.UnknownHostException) {
            return GeminiClient.TestOutcome(false, preferred, "No internet. Check your network.")
        } catch (e: Exception) {
            return GeminiClient.TestOutcome(false, preferred, friendly(provider, e.message))
        }
    }

    fun friendly(provider: String, raw: String?): String {
        val m = raw.orEmpty()
        val n = label(provider)
        return when {
            m.contains("HTTP 401") -> "$n API key is invalid or expired. Create a fresh key and save it again."
            m.contains("HTTP 402") -> "$n says there are not enough credits (HTTP 402). Add credits or use a free model."
            m.contains("HTTP 403") -> "$n refused the key (HTTP 403). The account may need credits or permission. ${m.take(120)}"
            m.contains("HTTP 404") -> "$n model not found (HTTP 404). Clear the model box and save to use the default."
            m.contains("HTTP 429") -> "$n rate limit reached (HTTP 429). Try again in a moment."
            else -> "$n error: ${m.take(150)}"
        }
    }
}
