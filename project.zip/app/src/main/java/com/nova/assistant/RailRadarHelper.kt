package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.Locale

/**
 * Smart Commute helper powered by RailRadar API:
 * 1) Voice-only Indian Railways Live Train Status & Departure Time (NEVER opens external apps).
 *    Reads user's RailRadar API Key & Base URL from Settings -> RailRadar Live Train API.
 * 2) Persistent Travel / Departure Checklist (manageable by Voice & Hub UI).
 */
object RailRadarHelper {

    const val DEFAULT_BASE_URL = "https://railradar.in/api/v1"
    private const val PREF_CHECKLIST = "nova_travel_checklist"
    private const val KEY_ITEMS = "items_json"

    data class ChecklistItem(val name: String, val checked: Boolean)
    data class TestResult(val ok: Boolean, val message: String)

    private val defaultChecklist = listOf(
        ChecklistItem("Train Ticket / IRCTC PNR", false),
        ChecklistItem("ID Proof", false),
        ChecklistItem("Phone Charger & Power Bank", false),
        ChecklistItem("Water Bottle", false),
        ChecklistItem("Earbuds", false)
    )

    // ------------------------------------------------------------------ Voice-Only Live Train Status (RailRadar)

    @Volatile private var lastTrainNo: String? = null
    @Volatile private var lastTrainAtMs = 0L

    fun rememberTrain(no: String) {
        lastTrainNo = no
        lastTrainAtMs = System.currentTimeMillis()
    }

    /** Train number from the last status question (kept for 20 minutes) so follow-ups can say "woh train". */
    fun recentTrainNo(windowMs: Long = 20 * 60_000L): String? =
        lastTrainNo?.takeIf { System.currentTimeMillis() - lastTrainAtMs <= windowMs }

    private fun isPronounOnly(q: String): Boolean = q.isBlank() || q.lowercase()
        .replace(Regex("\\b(woh|wo|vo|voh|wohi|us|usi|uski|iski|wahi|vahi|same|phir|fir|ab|abhi|kya|ye|yeh|is|isi|train|gaadi|gadi|kahan|kaha)\\b"), " ")
        .isBlank()

    fun extractTrainNumber(raw: String): String? {
        val direct = Regex("\\b(\\d{5})\\b").find(raw)
        if (direct != null) return direct.groupValues[1]
        val digits = raw.replace(Regex("[^0-9]"), "")
        return if (digits.length == 5) digits else null
    }

    fun extractTrainQuery(raw: String): String {
        extractTrainNumber(raw)?.let { return it }
        return HinglishConverter.toHinglish(raw)
            .replace(
                Regex(
                    "\\b(train|gaadi|gadi|number|no|naam|name|kahan|kaha|pahunchi|pahunch|pohchi|gayi|gai|hai|live|status|running|location|depart|departure|time|timing|kitni|kitna|late|batao|check|karo|ki|ka|ke|ye|wo|wali|kaun|si|station|par|pe|abhi)\\b",
                    RegexOption.IGNORE_CASE
                ),
                " "
            )
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /** Tests the user's RailRadar API key in Settings -> RailRadar Live Train API. */
    fun testConnection(rawKey: String, rawBaseUrl: String): TestResult {
        val key = rawKey.trim().replace("\\s+".toRegex(), "")
        if (key.isEmpty()) return TestResult(false, "RailRadar API key khali hai.")
        val base = rawBaseUrl.trim().trimEnd('/').ifEmpty { DEFAULT_BASE_URL }

        val probeUrls = listOf(
            "$base/trains/12951?dataType=live",
            "$base/search/trains?q=12951",
            "$base/trains/12951"
        )
        var lastCode = 0
        var lastBody = ""
        for (u in probeUrls) {
            try {
                val resp = httpGetRailRadar(u, key)
                lastCode = resp.code
                lastBody = resp.body
                if (resp.code in 200..299 && resp.body.trim().startsWith("{")) {
                    return TestResult(true, "Connected! RailRadar API theek kaam kar rahi hai.")
                }
                if (resp.code == 401 || resp.code == 403) {
                    return TestResult(false, "RailRadar API key invalid ya unauthorized hai (HTTP ${resp.code}). Key check karo.")
                }
            } catch (_: UnknownHostException) {
                return TestResult(false, "Internet band hai ya Base URL galat hai. Network aur URL check karo.")
            } catch (_: SocketTimeoutException) {
                return TestResult(false, "RailRadar server respond karne me slow hai (timeout). Dobara try karo.")
            } catch (e: Exception) {
                lastBody = e.message.orEmpty()
            }
        }
        return TestResult(false, "RailRadar test fail (HTTP $lastCode): ${lastBody.take(120)}")
    }

    /**
     * Fetches live train status via RailRadar API and returns a friendly Hinglish voice reply.
     * Strictly voice-only — NEVER opens Chrome, NTES, or any third-party app.
     */
    fun getLiveTrainStatusVoice(context: Context, rawRequest: String): String {
        var trainQuery = extractTrainQuery(rawRequest)
        // Follow-up like "woh train kahan pahunchi?" -> reuse the train asked about just before
        if (extractTrainNumber(trainQuery) == null && isPronounOnly(trainQuery)) {
            recentTrainNo()?.let { trainQuery = it }
        }
        if (trainQuery.isBlank()) {
            return "Kaunsi train ka status check karun? Train number ya naam bolo, jaise: Train 12562 kahan pahunchi."
        }
        if (!PhoneInfoHelper.isOnline(context)) {
            return "Internet band hai. Live train status janne ke liye internet ON karo."
        }

        val apiKey = Prefs.railRadarKey(context)
        if (apiKey.isEmpty()) {
            return "Live train status ke liye Nova ke Settings tab me RailRadar API key save karo."
        }

        val baseUrl = Prefs.railRadarBaseUrl(context)
        val trainNo = extractTrainNumber(trainQuery) ?: searchTrainNumber(baseUrl, apiKey, trainQuery)
            ?: return "'$trainQuery' naam ki train RailRadar par nahi mili. 5-digit train number bolkar try karo."

        rememberTrain(trainNo)
        val endpoints = listOf(
            "$baseUrl/trains/$trainNo?dataType=live",
            "$baseUrl/trains/$trainNo/live",
            "$baseUrl/trains/$trainNo"
        )

        var lastHttpErr = ""
        for (ep in endpoints) {
            try {
                val resp = httpGetRailRadar(ep, apiKey)
                if (resp.code == 401 || resp.code == 403) {
                    return "RailRadar API key invalid ya expire ho gayi hai. Settings me jakar key check karo."
                }
                if (resp.code == 429) {
                    return "RailRadar API ki abhi ki rate limit poori ho gayi hai. Thodi der baad dobara pucho."
                }
                if (resp.code in 200..299 && resp.body.trim().startsWith("{")) {
                    val spoken = parseRailRadarLiveJson(resp.body, trainNo)
                    if (spoken != null) return spoken
                } else {
                    lastHttpErr = "HTTP ${resp.code}"
                }
            } catch (_: UnknownHostException) {
                return "Internet connection nahi mil raha. Network check karo."
            } catch (_: SocketTimeoutException) {
                return "RailRadar server se jawab aane me zyada samay lag gaya. Dobara try karo."
            } catch (e: Exception) {
                lastHttpErr = e.message?.take(80).orEmpty()
            }
        }

        return if (lastHttpErr.isNotEmpty()) {
            "Train $trainNo ka live status abhi RailRadar se nahi mila ($lastHttpErr). Thodi der baad try karo."
        } else {
            "Train $trainNo abhi running nahi lag rahi ya aaj ka live data RailRadar par uplabdh nahi hai."
        }
    }

    private fun searchTrainNumber(baseUrl: String, apiKey: String, nameQuery: String): String? {
        val enc = URLEncoder.encode(nameQuery, "UTF-8")
        val searchUrls = listOf(
            "$baseUrl/search/trains?q=$enc",
            "$baseUrl/trains/search?q=$enc"
        )
        for (u in searchUrls) {
            try {
                val resp = httpGetRailRadar(u, apiKey)
                if (resp.code !in 200..299) continue
                val body = resp.body.trim()
                val arr: JSONArray? = when {
                    body.startsWith("[") -> JSONArray(body)
                    body.startsWith("{") -> {
                        val root = JSONObject(body)
                        root.optJSONArray("data")
                            ?: root.optJSONObject("data")?.optJSONArray("trains")
                            ?: root.optJSONArray("trains")
                            ?: root.optJSONArray("results")
                    }
                    else -> null
                }
                if (arr != null && arr.length() > 0) {
                    val first = arr.getJSONObject(0)
                    val num = firstString(first, "trainNumber", "train_number", "trainNo", "number", "id")
                    val clean = num.filter { it.isDigit() }
                    if (clean.length == 5) return clean
                }
            } catch (_: Exception) {}
        }
        return null
    }

    /**
     * Parses RailRadar API JSON responses cleanly across v1 schema variations
     * and formats a natural friend-like Roman Hinglish spoken sentence.
     */
    fun parseRailRadarLiveJson(jsonText: String, fallbackTrainNo: String): String? {
        return try {
            val root = JSONObject(jsonText)
            if (root.has("success") && !root.optBoolean("success", true)) return null
            val data = root.optJSONObject("data") ?: root
            val trainObj = data.optJSONObject("train") ?: data.optJSONObject("trainInfo") ?: data
            val liveObj = data.optJSONObject("liveData")
                ?: data.optJSONObject("live")
                ?: data.optJSONObject("runningStatus")
                ?: data
            val curLocObj = liveObj.optJSONObject("currentLocation")
                ?: data.optJSONObject("currentLocation")
                ?: liveObj

            val trainNo = firstString(trainObj, "trainNumber", "train_number", "trainNo", "number")
                .ifEmpty { fallbackTrainNo }
            val trainName = firstString(trainObj, "trainName", "train_name", "name")
                .ifEmpty { "Train $trainNo" }

            var currentStation = firstString(
                curLocObj,
                "stationName", "station_name", "currentStationName", "current_station_name",
                "lastStationName", "stationCode", "station"
            ).ifEmpty {
                firstString(liveObj, "currentStationName", "current_station_name", "currentStation", "lastStation")
            }

            val statusSummary = firstString(
                liveObj,
                "statusSummary", "statusMessage", "status_message", "currentLocationInfo",
                "new_message", "message", "status"
            )

            val delayMin = firstInt(
                liveObj,
                "overallDelayMinutes", "delayMinutes", "delay_minutes", "delay", "lateMinutes"
            ) ?: firstInt(curLocObj, "delayMinutes", "delayDeparture", "delayArrival", "delay")

            var departTime = firstString(
                curLocObj,
                "expectedDeparture", "actualDeparture", "scheduledDeparture", "departureTime", "etd", "std"
            ).ifEmpty {
                firstString(liveObj, "expectedDeparture", "departureTime", "etd", "std")
            }

            // Inspect route / upcoming stations if present
            var nextStationName = firstString(liveObj, "nextStationName", "next_station_name", "nextStation")
            var nextStationDep = firstString(liveObj, "nextStationDeparture", "nextDeparture")

            val routeArr = liveObj.optJSONArray("route")
                ?: data.optJSONArray("route")
                ?: liveObj.optJSONArray("upcomingStations")
                ?: liveObj.optJSONArray("upcoming_stations")
                ?: liveObj.optJSONArray("stations")

            if (routeArr != null && routeArr.length() > 0) {
                var lastCrossed: JSONObject? = null
                var firstUpcoming: JSONObject? = null
                for (i in 0 until routeArr.length()) {
                    val st = routeArr.optJSONObject(i) ?: continue
                    val crossed = st.optBoolean("hasDeparted", false) ||
                        st.optBoolean("hasArrived", false) ||
                        st.optBoolean("crossed", false) ||
                        st.optString("status").equals("crossed", true) ||
                        st.optString("status").equals("departed", true)
                    if (crossed) {
                        lastCrossed = st
                    } else if (firstUpcoming == null) {
                        firstUpcoming = st
                    }
                }
                if (currentStation.isBlank() && lastCrossed != null) {
                    currentStation = firstString(lastCrossed, "stationName", "station_name", "name", "stationCode")
                }
                if (departTime.isBlank() && lastCrossed != null) {
                    departTime = firstString(lastCrossed, "actualDeparture", "expectedDeparture", "scheduledDeparture", "etd", "std", "departureTime")
                }
                if (nextStationName.isBlank() && firstUpcoming != null) {
                    nextStationName = firstString(firstUpcoming, "stationName", "station_name", "name", "stationCode")
                    nextStationDep = firstString(firstUpcoming, "expectedDeparture", "scheduledDeparture", "etd", "std", "departureTime")
                }
                if (currentStation.isBlank() && firstUpcoming != null) {
                    // Train hasn't departed origin yet — read origin schedule
                    val origin = routeArr.optJSONObject(0)
                    if (origin != null) {
                        val originName = firstString(origin, "stationName", "station_name", "name", "stationCode")
                        val originDep = firstString(origin, "expectedDeparture", "scheduledDeparture", "departureTime", "std", "etd")
                        if (originName.isNotBlank()) {
                            return if (originDep.isNotBlank()) {
                                "$trainName ($trainNo) abhi start station $originName par hai, iska departure time $originDep hai."
                            } else {
                                "$trainName ($trainNo) abhi start station $originName par hai."
                            }
                        }
                    }
                }
            }

            if (currentStation.isBlank() && statusSummary.isBlank() && nextStationName.isBlank()) {
                return null
            }

            buildString {
                append("$trainName ($trainNo)")
                when {
                    currentStation.isNotBlank() -> append(" abhi $currentStation ke paas pahunchi hai.")
                    statusSummary.isNotBlank() -> append(" ka status: ${statusSummary.take(120)}.")
                }
                if (delayMin != null) {
                    when {
                        delayMin <= 0 -> append(" Train bilkul right time chal rahi hai.")
                        delayMin < 1440 -> append(" Ye lagbhag $delayMin minute late hai.")
                    }
                }
                if (nextStationName.isNotBlank()) {
                    if (nextStationDep.isNotBlank()) {
                        append(" Agla station $nextStationName hai, wahan se departure time $nextStationDep hai.")
                    } else {
                        append(" Agla station $nextStationName hai.")
                    }
                } else if (departTime.isNotBlank()) {
                    append(" Iska departure time $departTime hai.")
                }
            }.trim()
        } catch (_: Exception) {
            null
        }
    }

    private fun firstString(obj: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = obj.optString(k, "").trim()
            if (v.isNotEmpty() && !v.equals("null", true) && v != "--") return v
        }
        return ""
    }

    private fun firstInt(obj: JSONObject, vararg keys: String): Int? {
        for (k in keys) {
            if (obj.has(k) && !obj.isNull(k)) {
                val raw = obj.opt(k)
                when (raw) {
                    is Number -> return raw.toInt()
                    is String -> raw.trim().toIntOrNull()?.let { return it }
                }
            }
        }
        return null
    }

    private data class HttpResp(val code: Int, val body: String)

    private fun httpGetRailRadar(urlStr: String, apiKey: String): HttpResp {
        // Attempt 1: Official RailRadar X-API-Key header
        val r1 = doGet(urlStr) { conn ->
            conn.setRequestProperty("X-API-Key", apiKey)
            conn.setRequestProperty("Accept", "application/json")
        }
        if (r1.code in 200..299 || (r1.code != 401 && r1.code != 403)) return r1

        // Attempt 2: Authorization: Bearer fallback
        val r2 = doGet(urlStr) { conn ->
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.setRequestProperty("Accept", "application/json")
        }
        return r2
    }

    private fun doGet(urlStr: String, configure: (HttpURLConnection) -> Unit): HttpResp {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9000
            readTimeout = 12000
            setRequestProperty("User-Agent", "NovaAssistant/6.3")
            configure(this)
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            HttpResp(code, body)
        } finally {
            conn.disconnect()
        }
    }

    // ------------------------------------------------------------------ Travel Departure Checklist

    private fun p(c: Context) = c.getSharedPreferences(PREF_CHECKLIST, Context.MODE_PRIVATE)

    fun getChecklist(c: Context): List<ChecklistItem> {
        val raw = p(c).getString(KEY_ITEMS, null) ?: return defaultChecklist
        val out = mutableListOf<ChecklistItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(ChecklistItem(o.optString("name"), o.optBoolean("checked", false)))
            }
        } catch (_: Exception) {}
        return if (out.isEmpty()) defaultChecklist else out
    }

    private fun saveChecklist(c: Context, items: List<ChecklistItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("name", it.name).put("checked", it.checked))
        }
        p(c).edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    fun toggleByIndex(c: Context, index: Int) {
        val list = getChecklist(c).toMutableList()
        if (index in list.indices) {
            list[index] = list[index].copy(checked = !list[index].checked)
            saveChecklist(c, list)
        }
    }

    fun addChecklistItem(c: Context, name: String): List<ChecklistItem> {
        val clean = HinglishConverter.toHinglish(name).trim()
        if (clean.isEmpty()) return getChecklist(c)
        val list = getChecklist(c).toMutableList()
        if (list.none { it.name.equals(clean, ignoreCase = true) }) {
            list.add(ChecklistItem(clean, false))
            saveChecklist(c, list)
        }
        return list
    }

    fun resetChecklist(c: Context): List<ChecklistItem> {
        val list = getChecklist(c).map { it.copy(checked = false) }
        saveChecklist(c, list)
        return list
    }

    fun handleChecklistVoice(c: Context, rawRequest: String): String {
        val lower = HinglishConverter.toHinglish(rawRequest).lowercase(Locale.ROOT)
        if (lower.contains("reset") || lower.contains("clear")) {
            resetChecklist(c)
            return "Travel checklist reset kar di hai. Sab items dobara unchecked hain."
        }
        if (lower.contains("add") || lower.contains("jodo") || lower.contains("daalo")) {
            val itemName = HinglishConverter.toHinglish(rawRequest)
                .replace(Regex("\\b(travel|departure|journey|safar|checklist|list|me|mein|add|jodo|daalo|karo|do|ek|item)\\b", RegexOption.IGNORE_CASE), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            if (itemName.isEmpty()) return "Travel checklist me kya add karun? Bolo: checklist me umbrella add karo."
            addChecklistItem(c, itemName)
            return "'$itemName' travel checklist me add ho gaya."
        }
        if (lower.contains("tick") || lower.contains("done") || lower.contains("check ") || lower.contains("rakh liya") || lower.contains("pack")) {
            val list = getChecklist(c).toMutableList()
            val idx = list.indexOfFirst { item ->
                val itemWords = item.name.lowercase(Locale.ROOT).split(Regex("[^a-z0-9]+")).filter { it.length >= 3 }
                itemWords.any { lower.contains(it) }
            }
            if (idx >= 0) {
                list[idx] = list[idx].copy(checked = true)
                saveChecklist(c, list)
                val remaining = list.count { !it.checked }
                return "${list[idx].name} tick kar diya. Ab $remaining items bache hain."
            }
        }
        return spokenChecklistSummary(c)
    }

    fun spokenChecklistSummary(c: Context): String {
        val list = getChecklist(c)
        val pending = list.filter { !it.checked }
        val doneCount = list.size - pending.size
        return if (pending.isEmpty()) {
            "Shabash! Tumhari travel checklist ke saare ${list.size} items ready hain."
        } else {
            val names = pending.joinToString(", ") { it.name }
            "Travel checklist me $doneCount ready hain aur ${pending.size} bache hain: $names."
        }
    }
}
