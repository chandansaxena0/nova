package com.nova.assistant

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts sensitive API keys on-device using Android Keystore (AES-256-GCM).
 * Zero external crypto dependencies; transparently handles legacy plaintext migration.
 */
object SecureVault {
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val KEY_ALIAS = "nova_secure_vault_v7"
    private const val PREFIX = "enc_v1:"

    private fun getOrCreateKey(): SecretKey? {
        return try {
            val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
            (ks.getKey(KEY_ALIAS, null) as? SecretKey) ?: run {
                val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
                val spec = KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                kg.init(spec)
                kg.generateKey()
            }
        } catch (_: Exception) {
            null
        }
    }

    fun encrypt(plain: String): String {
        val clean = plain.trim()
        if (clean.isEmpty()) return ""
        val key = getOrCreateKey() ?: return clean
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val enc = cipher.doFinal(clean.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(iv.size + enc.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(enc, 0, combined, iv.size, enc.size)
            PREFIX + Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (_: Exception) {
            clean
        }
    }

    fun decrypt(stored: String?): String {
        val s = stored?.trim().orEmpty()
        if (s.isEmpty()) return ""
        if (!s.startsWith(PREFIX)) return s // Legacy plaintext support
        val key = getOrCreateKey() ?: return ""
        return try {
            val data = Base64.decode(s.removePrefix(PREFIX), Base64.NO_WRAP)
            if (data.size <= 12) return ""
            val iv = data.copyOfRange(0, 12)
            val enc = data.copyOfRange(12, data.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            String(cipher.doFinal(enc), Charsets.UTF_8).trim()
        } catch (_: Exception) {
            ""
        }
    }
}
