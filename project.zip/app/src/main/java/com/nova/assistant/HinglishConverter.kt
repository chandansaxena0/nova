package com.nova.assistant

/**
 * Guarantees clean Roman Hinglish output for voice searches, WhatsApp messages, and UI display.
 * 1) Converts any Devanagari text into readable Hinglish (never leaves raw Hindi script).
 * 2) Repairs common Indian-accent speech-to-text errors (e.g., "mr beast" -> "MrBeast",
 *    "rob locks" -> "Roblox", "you tube" -> "YouTube", "whats app" -> "WhatsApp").
 */
object HinglishConverter {

    private val consonants = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
        'ष' to "sh", 'स' to "s", 'ह' to "h",
        'क़' to "q", 'ख़' to "kh", 'ग़' to "g", 'ज़' to "z",
        'ड़' to "d", 'ढ़' to "dh", 'फ़' to "f", 'य़' to "y"
    )
    private val nukta = mapOf(
        'ज' to "z", 'फ' to "f", 'क' to "q", 'ख' to "kh", 'ग' to "g", 'ड' to "d", 'ढ' to "dh"
    )
    private val matras = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u",
        'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
        'ॉ' to "o", 'ॅ' to "e"
    )
    private val vowels = mapOf(
        'अ' to "a", 'आ' to "a", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u",
        'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ऋ' to "ri"
    )

    // Common Hindi words -> natural Hinglish spelling
    private val hindiWordMap = mapOf(
        "यूट्यूब" to "YouTube", "यू ट्यूब" to "YouTube",
        "व्हाट्सएप" to "WhatsApp", "व्हाट्सऐप" to "WhatsApp", "वाट्सऐप" to "WhatsApp",
        "वॉट्सऐप" to "WhatsApp", "व्हाट्सअप" to "WhatsApp",
        "इंस्टाग्राम" to "Instagram", "स्पॉटिफाई" to "Spotify", "स्पोटिफाई" to "Spotify",
        "गूगल" to "Google", "क्रोम" to "Chrome", "मैप्स" to "Maps", "मैप" to "Maps",
        "रोब्लॉक्स" to "Roblox", "रॉब्लॉक्स" to "Roblox", "रोब्लोक्स" to "Roblox",
        "मिस्टर बीस्ट" to "MrBeast", "मिस्टरबीस्ट" to "MrBeast", "मिस्टर बिस्ट" to "MrBeast",
        "फ्री फायर" to "Free Fire", "माइनक्राफ्ट" to "Minecraft",
        "पेटीएम" to "Paytm", "फोनपे" to "PhonePe", "अमेज़न" to "Amazon", "फ्लिपकार्ट" to "Flipkart",
        "पेट्रोल पंप" to "petrol pump", "हॉस्पिटल" to "hospital", "अस्पताल" to "hospital",
        "रेलवे स्टेशन" to "railway station", "मेडिकल स्टोर" to "medical store", "रेस्टोरेंट" to "restaurant",
        "खोलो" to "kholo", "चलाओ" to "chalao", "बजाओ" to "bajao", "सर्च" to "search",
        "ढूंढो" to "dhundo", "ढूँढो" to "dhundo", "बंद" to "band", "करो" to "karo",
        "भेजो" to "bhejo", "मैसेज" to "message", "कॉल" to "call", "रिप्लाई" to "reply",
        "मैं" to "main", "मेरा" to "mera", "मेरे" to "mere", "मेरी" to "meri",
        "क्या" to "kya", "है" to "hai", "हैं" to "hain", "हूँ" to "hoon", "हूं" to "hoon",
        "को" to "ko", "पर" to "par", "में" to "mein", "से" to "se", "का" to "ka", "की" to "ki", "के" to "ke",
        "नहीं" to "nahi", "हां" to "haan", "हाँ" to "haan", "और" to "aur", "पास" to "paas",
        "सबसे" to "sabse", "कौन" to "kaun", "सा" to "sa", "बताओ" to "batao",
        "मौसम" to "mausam", "तारीख" to "tarikh", "समय" to "samay", "बैटरी" to "battery",
        "रिमाइंडर" to "reminder", "अलार्म" to "alarm", "लगाओ" to "lagao",
        "नोवा" to "Nova", "नवा" to "Nova", "स्टॉप" to "stop", "बस" to "bas"
    )

    // Phrase-level voice recognition normalizations (case-insensitive word boundaries)
    private val phraseFixes: List<Pair<Regex, String>> = listOf(
        Regex("\\b(mr\\.?\\s*beast|mister\\s+beast|mister\\s+bist|mr\\s+bist|mr\\s+best|mister\\s+best)\\b", RegexOption.IGNORE_CASE) to "MrBeast",
        Regex("\\b(you\\s+tube\\s+music)\\b", RegexOption.IGNORE_CASE) to "YouTube Music",
        Regex("\\b(you\\s+tube|u\\s+tube)\\b", RegexOption.IGNORE_CASE) to "YouTube",
        Regex("\\b(whats\\s+app|what's\\s+app|what\\s+app|watsapp)\\b", RegexOption.IGNORE_CASE) to "WhatsApp",
        Regex("\\b(rob\\s*locks|road\\s*blocks|row\\s*blocks|rob\\s*lox|ro\\s+blocks)\\b", RegexOption.IGNORE_CASE) to "Roblox",
        Regex("\\b(free\\s*fire\\s*max)\\b", RegexOption.IGNORE_CASE) to "Free Fire MAX",
        Regex("\\b(free\\s*fire)\\b", RegexOption.IGNORE_CASE) to "Free Fire",
        Regex("\\b(mine\\s*craft)\\b", RegexOption.IGNORE_CASE) to "Minecraft",
        Regex("\\b(insta\\s+gram)\\b", RegexOption.IGNORE_CASE) to "Instagram",
        Regex("\\b(tele\\s+gram)\\b", RegexOption.IGNORE_CASE) to "Telegram",
        Regex("\\b(face\\s+book)\\b", RegexOption.IGNORE_CASE) to "Facebook",
        Regex("\\b(phone\\s+pe|phone\\s+pay)\\b", RegexOption.IGNORE_CASE) to "PhonePe",
        Regex("\\b(pay\\s+tm)\\b", RegexOption.IGNORE_CASE) to "Paytm",
        Regex("\\b(google\\s+pay|g\\s+pay)\\b", RegexOption.IGNORE_CASE) to "Google Pay",
        Regex("\\b(google\\s+maps?)\\b", RegexOption.IGNORE_CASE) to "Google Maps",
        Regex("\\b(jio\\s+saavn|jio\\s+savan|jio\\s+seven)\\b", RegexOption.IGNORE_CASE) to "JioSaavn",
        Regex("\\b(jio\\s+hotstar)\\b", RegexOption.IGNORE_CASE) to "JioHotstar",
        Regex("\\b(play\\s+store)\\b", RegexOption.IGNORE_CASE) to "Play Store",
        Regex("\\b(petrol\\s+pam|petrol\\s+pamp)\\b", RegexOption.IGNORE_CASE) to "petrol pump",
        Regex("\\b(spot\\s*ify|spot\\s+if\\s+i)\\b", RegexOption.IGNORE_CASE) to "Spotify",
        Regex("\\b(clip\\s+board)\\b", RegexOption.IGNORE_CASE) to "clipboard",
        Regex("\\b(blue\\s+tooth)\\b", RegexOption.IGNORE_CASE) to "bluetooth",
        Regex("\\b(wi\\s*fi|why\\s+fi)\\b", RegexOption.IGNORE_CASE) to "Wi-Fi",
        Regex("\\b(screen\\s+time)\\b", RegexOption.IGNORE_CASE) to "screen time"
    )

    fun hasDevanagari(s: String): Boolean = s.any { it in '\u0900'..'\u097F' }

    /** Converts any raw voice transcript (English, Hindi, or mixed) into clean Roman Hinglish. */
    fun toHinglish(raw: String): String {
        if (raw.isBlank()) return ""
        var text = raw.trim()

        // Step 1: Replace multi-word Devanagari phrases first
        if (hasDevanagari(text)) {
            for ((hi, en) in hindiWordMap.entries.sortedByDescending { it.key.length }) {
                if (text.contains(hi)) {
                    text = text.replace(hi, en)
                }
            }
            // Step 2: Transliterate any remaining Devanagari words
            text = text.split(Regex("\\s+")).joinToString(" ") { token ->
                if (hasDevanagari(token)) transliterate(token) else token
            }
        }

        // Step 3: Repair common Indian speech recognition phrasing/brand splits
        for ((pattern, replacement) in phraseFixes) {
            text = pattern.replace(text, replacement)
        }

        return text.replace(Regex("\\s+"), " ").trim()
    }

    /** Character-level Devanagari -> Roman Latin transliteration. */
    fun transliterate(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val cons = consonants[c]
            when {
                cons != null -> {
                    var b: String = cons
                    var j = i + 1
                    if (j < s.length && s[j] == '़') {
                        b = nukta[c] ?: b
                        j++
                    }
                    val mat = if (j < s.length) matras[s[j]] else null
                    when {
                        mat != null -> {
                            sb.append(b).append(mat)
                            i = j + 1
                        }
                        j < s.length && s[j] == '्' -> {
                            sb.append(b)
                            i = j + 1
                        }
                        else -> {
                            sb.append(b)
                            if (j < s.length && s[j] in '\u0900'..'\u097F') sb.append('a')
                            i = j
                        }
                    }
                }
                vowels[c] != null -> {
                    sb.append(vowels[c])
                    i++
                }
                c == 'ं' || c == 'ँ' -> {
                    sb.append('n')
                    i++
                }
                c == 'ः' -> {
                    sb.append('h')
                    i++
                }
                c in '\u0900'..'\u097F' -> i++
                else -> {
                    sb.append(c)
                    i++
                }
            }
        }
        return sb.toString()
    }
}
