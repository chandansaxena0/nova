package com.nova.assistant

import android.content.Context
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.File
import java.math.BigInteger
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import javax.crypto.Cipher

/**
 * Pure-Kotlin Android TV / Google TV Voice Controller (Zero PC, Works on Wi-Fi & Mobile Hotspot!).
 *
 * Implements standard ADB-over-TCP (port 5555) with persistent RSA-2048 key authentication:
 *   - First connection pops up "Allow USB debugging?" on the TV screen once -> tap "Always allow".
 *   - Every future voice command connects and executes in ~100ms:
 *       Power/Sleep/Wake, Volume Up/Down/Mute, Play/Pause/Next/Prev, Home/Back/D-Pad/OK/Menu,
 *       HDMI Input, Channel Up/Down, Launch YouTube/Netflix/Prime/Hotstar/SonyLIV/Zee5/Spotify/Settings,
 *       Play/Search directly on TV YouTube, Type text on TV, and Auto-Scan local Wi-Fi/Hotspot for TV IP!
 */
object SmartTvController {

    private const val A_CNXN = 0x4e584e43 // "CNXN"
    private const val A_AUTH = 0x48545541 // "AUTH"
    private const val A_OPEN = 0x4e45504f // "OPEN"
    private const val A_OKAY = 0x59414b4f // "OKAY"
    private const val A_CLSE = 0x45534c43 // "CLSE"
    private const val A_WRTE = 0x45545257 // "WRTE"

    private const val AUTH_TOKEN = 1
    private const val AUTH_SIGNATURE = 2
    private const val AUTH_RSAPUBLICKEY = 3

    private const val ADB_VERSION = 0x01000000
    private const val ADB_MAXDATA = 256 * 1024

    // ASN.1 DigestInfo prefix for SHA-1 (used by ADB RSA token signing)
    private val SHA1_ASN1_PREFIX = byteArrayOf(
        0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e,
        0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    )

    private val tvApps = mapOf(
        "youtube" to "com.google.android.youtube.tv",
        "netflix" to "com.netflix.ninja",
        "prime" to "com.amazon.amazonvideo.livingroom",
        "hotstar" to "in.startv.hotstar",
        "jiocinema" to "com.jio.media.ondemand",
        "sonyliv" to "com.sonyliv",
        "zee5" to "com.graymatrix.did",
        "spotify" to "com.spotify.tv.android",
        "playstore" to "com.android.vending",
        "settings" to "com.android.tv.settings"
    )

    data class AdbPacket(val cmd: Int, val arg0: Int, val arg1: Int, val data: ByteArray)

    fun handleVoiceCommand(context: Context, op: String, arg: String): String {
        if (op == "scan") {
            val found = scanLocalTvs()
            return if (found.isNotEmpty()) {
                val ip = found.first()
                Prefs.setTvIp(context, ip)
                "Smart TV mil gaya: $ip. IP save kar diya hai! Ab 'TV connect karo' bolo ya Hub me Pair dabao."
            } else {
                "Wi-Fi ya Hotspot par koi Smart TV (port 5555) nahi mila. TV me Developer Options > USB/Network Debugging ON karke phir scan karo."
            }
        }

        val ip = Prefs.tvIp(context)
        val port = Prefs.tvPort(context)
        if (ip.isEmpty()) {
            // Try a quick automatic scan first!
            val autoFound = scanLocalTvs()
            if (autoFound.isNotEmpty()) {
                Prefs.setTvIp(context, autoFound.first())
            } else {
                return "Smart TV ka IP set nahi hai. Hub tab me Smart TV section par jakar 'Scan TV' dabao ya TV ka IP enter karo."
            }
        }
        val targetIp = Prefs.tvIp(context)

        if (op == "pair" || op == "connect") {
            return testAndPair(context, targetIp, port)
        }

        val shellCmd = buildShellCommand(op, arg) ?: return "TV command samajh nahi aaya."
        return runShellOnTv(context, targetIp, port, shellCmd, readTimeoutMs = 5500)
            .fold(
                onSuccess = { friendlyConfirmation(op, arg) },
                onFailure = { err -> "Smart TV ($targetIp) se connect nahi ho paya: ${err.message}" }
            )
    }

    fun testAndPair(context: Context, ip: String, port: Int = 5555): String {
        val cleanIp = ip.trim()
        if (cleanIp.isEmpty()) return "Pehle Smart TV ka IP enter karo ya Scan dabao."
        Prefs.setTvIp(context, cleanIp)
        Prefs.setTvPort(context, port)
        return runShellOnTv(context, cleanIp, port, "getprop ro.product.model", readTimeoutMs = 20000)
            .fold(
                onSuccess = { out ->
                    val model = out.trim().ifEmpty { "Android TV" }
                    "Smart TV connected! Model: $model ($cleanIp). Ab aap voice se TV control kar sakte ho."
                },
                onFailure = { err ->
                    "TV ($cleanIp:$port) pair nahi ho paya: ${err.message}. TV par USB/Network Debugging ON karo aur 'Allow' popup accept karo."
                }
            )
    }

    private fun buildShellCommand(op: String, arg: String): String? = when (op) {
        "power_toggle" -> "input keyevent 26"
        "power_on" -> "input keyevent 224" // KEYCODE_WAKEUP
        "power_off" -> "input keyevent 223" // KEYCODE_SLEEP
        "vol_up" -> repeatKey(24, arg.toIntOrNull()?.coerceIn(1, 15) ?: 3)
        "vol_down" -> repeatKey(25, arg.toIntOrNull()?.coerceIn(1, 15) ?: 3)
        "mute" -> "input keyevent 164"
        "play_pause" -> "input keyevent 85"
        "play" -> "input keyevent 126"
        "pause" -> "input keyevent 127"
        "next" -> "input keyevent 87"
        "previous" -> "input keyevent 88"
        "home" -> "input keyevent 3"
        "back" -> "input keyevent 4"
        "up" -> "input keyevent 19"
        "down" -> "input keyevent 20"
        "left" -> "input keyevent 21"
        "right" -> "input keyevent 22"
        "ok" -> "input keyevent 23"
        "menu" -> "input keyevent 82"
        "input" -> "input keyevent 178"
        "ch_up" -> "input keyevent 166"
        "ch_down" -> "input keyevent 167"
        "open_app" -> {
            val pkg = tvApps[arg.lowercase(Locale.ROOT)] ?: return null
            if (pkg == "com.android.tv.settings") {
                "am start -a android.settings.SETTINGS"
            } else {
                "monkey -p $pkg -c android.intent.category.LEANBACK_LAUNCHER 1 || monkey -p $pkg -c android.intent.category.LAUNCHER 1"
            }
        }
        "youtube_play" -> {
            val enc = URLEncoder.encode(arg.trim(), "UTF-8")
            "am start -a android.intent.action.VIEW -d \"https://www.youtube.com/results?search_query=$enc\""
        }
        "type_text" -> {
            val safe = arg.trim().replace(" ", "%s").replace(Regex("[\"'`$&|;<>\\\\]"), "")
            if (safe.isEmpty()) null else "input text \"$safe\""
        }
        else -> null
    }

    private fun repeatKey(keyCode: Int, count: Int): String =
        (1..count).joinToString("; ") { "input keyevent $keyCode" }

    private fun friendlyConfirmation(op: String, arg: String): String = when (op) {
        "power_on" -> "Smart TV on kar diya hai."
        "power_off" -> "Smart TV band kar diya hai."
        "power_toggle" -> "Smart TV power toggle kar diya hai."
        "vol_up" -> "TV volume badha diya hai."
        "vol_down" -> "TV volume kam kar diya hai."
        "mute" -> "TV mute/unmute kar diya hai."
        "play_pause" -> "TV play/pause kar diya hai."
        "play" -> "TV play kar diya hai."
        "pause" -> "TV pause kar diya hai."
        "next" -> "TV par next chalaya hai."
        "previous" -> "TV par previous chalaya hai."
        "home" -> "TV home screen par aa gaya."
        "back" -> "TV back chala gaya."
        "up" -> "TV upar move kiya."
        "down" -> "TV neeche move kiya."
        "left" -> "TV left move kiya."
        "right" -> "TV right move kiya."
        "ok" -> "TV par OK select kiya."
        "menu" -> "TV menu khol diya."
        "input" -> "TV HDMI input menu khol diya."
        "ch_up" -> "TV next channel kar diya."
        "ch_down" -> "TV previous channel kar diya."
        "open_app" -> "Smart TV par ${arg.replaceFirstChar { it.uppercase() }} khol diya hai."
        "youtube_play" -> "Smart TV YouTube par '$arg' search kar diya hai."
        "type_text" -> "Smart TV par '$arg' type kar diya hai."
        else -> "Smart TV command complete."
    }

    /** Fast parallel subnet scanner (works over both home Wi-Fi AND phone Mobile Hotspot!). */
    fun scanLocalTvs(port: Int = 5555): List<String> {
        val prefixes = LinkedHashSet<String>()
        val localIps = HashSet<String>()
        runCatching {
            val ifaces = NetworkInterface.getNetworkInterfaces()
            while (ifaces.hasMoreElements()) {
                val nif = ifaces.nextElement()
                if (!nif.isUp || nif.isLoopback) continue
                val addrs = nif.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        val host = a.hostAddress ?: continue
                        if (host.startsWith("192.168.") || host.startsWith("10.") || host.startsWith("172.")) {
                            localIps.add(host)
                            val parts = host.split(".")
                            if (parts.size == 4) prefixes.add("${parts[0]}.${parts[1]}.${parts[2]}")
                        }
                    }
                }
            }
        }
        if (prefixes.isEmpty()) return emptyList()

        val pool = Executors.newFixedThreadPool(32)
        val tasks = ArrayList<Callable<String?>>()
        for (prefix in prefixes.take(2)) {
            for (last in 1..254) {
                val candidate = "$prefix.$last"
                if (candidate in localIps) continue
                tasks.add(Callable {
                    try {
                        Socket().use { s ->
                            s.connect(InetSocketAddress(candidate, port), 200)
                            candidate
                        }
                    } catch (_: Exception) {
                        null
                    }
                })
            }
        }
        return try {
            pool.invokeAll(tasks).mapNotNull { runCatching { it.get() }.getOrNull() }
        } finally {
            pool.shutdownNow()
        }
    }

    // ---- Pure-Kotlin ADB Wire Protocol Engine ----

    private fun runShellOnTv(context: Context, ip: String, port: Int, shellCmd: String, readTimeoutMs: Int): Result<String> {
        return try {
            val keyPair = getOrCreateKeyPair(context)
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), 3500)
                socket.soTimeout = readTimeoutMs
                val out = socket.getOutputStream()
                val inp = DataInputStream(socket.getInputStream())

                // 1) Send CNXN banner
                sendPacket(out, A_CNXN, ADB_VERSION, ADB_MAXDATA, "host::nova-assistant\u0000".toByteArray(Charsets.UTF_8))

                // 2) Authenticate (RSA signature -> fallback RSA pubkey for first-time pairing)
                var sentSignature = false
                var connected = false
                for (attempt in 0 until 6) {
                    val pkt = readPacket(inp)
                    when (pkt.cmd) {
                        A_CNXN -> {
                            connected = true
                            break
                        }
                        A_AUTH -> {
                            if (pkt.arg0 == AUTH_TOKEN) {
                                if (!sentSignature) {
                                    sentSignature = true
                                    val sig = signAdbToken(pkt.data, keyPair)
                                    sendPacket(out, A_AUTH, AUTH_SIGNATURE, 0, sig)
                                } else {
                                    val pubBytes = encodeAdbPublicKey(keyPair.public as RSAPublicKey, "nova@android")
                                    sendPacket(out, A_AUTH, AUTH_RSAPUBLICKEY, 0, pubBytes)
                                }
                            }
                        }
                        else -> throw IllegalStateException("Unexpected ADB packet: 0x${pkt.cmd.toString(16)}")
                    }
                }
                if (!connected) throw IllegalStateException("TV ne authorization accept nahi kiya (TV screen par Allow dabao)")

                // 3) Open shell stream
                val localId = 1
                val dest = "shell:$shellCmd\u0000".toByteArray(Charsets.UTF_8)
                sendPacket(out, A_OPEN, localId, 0, dest)

                val stdout = ByteArrayOutputStream()
                var remoteId = 0
                socket.soTimeout = 3500
                for (step in 0 until 32) {
                    val pkt = try {
                        readPacket(inp)
                    } catch (_: Exception) {
                        break
                    }
                    when (pkt.cmd) {
                        A_OKAY -> remoteId = pkt.arg0
                        A_WRTE -> {
                            remoteId = pkt.arg0
                            stdout.write(pkt.data)
                            sendPacket(out, A_OKAY, localId, remoteId, ByteArray(0))
                        }
                        A_CLSE -> {
                            if (remoteId != 0) runCatching { sendPacket(out, A_CLSE, localId, remoteId, ByteArray(0)) }
                            break
                        }
                    }
                }
                Result.success(stdout.toString(Charsets.UTF_8.name()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun buildPacketBytes(cmd: Int, arg0: Int, arg1: Int, payload: ByteArray): ByteArray {
        val checksum = payloadChecksum(payload)
        val header = ByteBuffer.allocate(24 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
        header.putInt(cmd)
        header.putInt(arg0)
        header.putInt(arg1)
        header.putInt(payload.size)
        header.putInt(checksum)
        header.putInt(cmd xor -1)
        header.put(payload)
        return header.array()
    }

    fun payloadChecksum(payload: ByteArray): Int {
        var sum = 0
        for (b in payload) sum += (b.toInt() and 0xFF)
        return sum
    }

    private fun sendPacket(out: java.io.OutputStream, cmd: Int, arg0: Int, arg1: Int, payload: ByteArray) {
        out.write(buildPacketBytes(cmd, arg0, arg1, payload))
        out.flush()
    }

    private fun readPacket(inp: DataInputStream): AdbPacket {
        val hdr = ByteArray(24)
        inp.readFully(hdr)
        val bb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.int
        val arg0 = bb.int
        val arg1 = bb.int
        val len = bb.int
        @Suppress("UNUSED_VARIABLE") val crc = bb.int
        @Suppress("UNUSED_VARIABLE") val magic = bb.int
        if (len < 0 || len > ADB_MAXDATA) throw IllegalStateException("Invalid ADB payload size: $len")
        val data = ByteArray(len)
        if (len > 0) inp.readFully(data)
        return AdbPacket(cmd, arg0, arg1, data)
    }

    fun signAdbToken(token: ByteArray, kp: KeyPair): ByteArray {
        val cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        cipher.init(Cipher.ENCRYPT_MODE, kp.private)
        val block = ByteArray(SHA1_ASN1_PREFIX.size + token.size)
        System.arraycopy(SHA1_ASN1_PREFIX, 0, block, 0, SHA1_ASN1_PREFIX.size)
        System.arraycopy(token, 0, block, SHA1_ASN1_PREFIX.size, token.size)
        return cipher.doFinal(block)
    }

    /** Builds the exact 524-byte AOSP RSAPublicKey binary struct (len, n0inv, n[64], rr[64], exp). */
    fun buildAdbPublicKeyBinary(pub: RSAPublicKey): ByteArray {
        val keySizeWords = 64 // 2048 bits / 32 bits
        val r32 = BigInteger.ONE.shiftLeft(32)
        val n = pub.modulus
        val n0inv = r32.subtract(n.modInverse(r32)).toLong() and 0xFFFFFFFFL
        val r = BigInteger.ONE.shiftLeft(2048)
        val rr = r.multiply(r).mod(n)

        val buf = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(keySizeWords)
        buf.putInt(n0inv.toInt())

        var tmpN = n
        for (i in 0 until keySizeWords) {
            val limb = tmpN.and(r32.subtract(BigInteger.ONE)).toLong().toInt()
            buf.putInt(limb)
            tmpN = tmpN.shiftRight(32)
        }
        var tmpRR = rr
        for (i in 0 until keySizeWords) {
            val limb = tmpRR.and(r32.subtract(BigInteger.ONE)).toLong().toInt()
            buf.putInt(limb)
            tmpRR = tmpRR.shiftRight(32)
        }
        buf.putInt(pub.publicExponent.toInt())
        return buf.array()
    }

    private fun encodeAdbPublicKey(pub: RSAPublicKey, userTag: String): ByteArray {
        val b64 = Base64.encodeToString(buildAdbPublicKeyBinary(pub), Base64.NO_WRAP)
        return "$b64 $userTag\u0000".toByteArray(Charsets.UTF_8)
    }

    private fun getOrCreateKeyPair(context: Context): KeyPair {
        val privFile = File(context.filesDir, "nova_tv_adb_priv.der")
        val pubFile = File(context.filesDir, "nova_tv_adb_pub.der")
        if (privFile.exists() && pubFile.exists()) {
            runCatching {
                val kf = KeyFactory.getInstance("RSA")
                val priv = kf.generatePrivate(PKCS8EncodedKeySpec(privFile.readBytes()))
                val pub = kf.generatePublic(X509EncodedKeySpec(pubFile.readBytes()))
                return KeyPair(pub, priv)
            }
        }
        val kpg = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val kp = kpg.generateKeyPair()
        privFile.writeBytes(kp.private.encoded)
        pubFile.writeBytes(kp.public.encoded)
        return kp
    }

    fun setupInstructions(): String =
        "Smart TV (Google TV / Android TV) Voice Control Setup (1-Time, No PC Needed):\n\n" +
        "1. Connect phone and Smart TV to the SAME Wi-Fi (or turn ON your phone Hotspot and connect TV to it).\n" +
        "2. On TV: Settings > System > About > tap 'Android TV OS Build' 7 times to enable Developer Options.\n" +
        "3. On TV: Settings > System > Developer Options > enable 'USB Debugging' / 'Network Debugging'.\n" +
        "4. In Nova Hub > Smart TV card: tap 'Scan TV' (or enter TV IP shown in TV Network Settings) and tap 'Pair / Test'.\n" +
        "5. On TV screen: check 'Always allow from this computer' and press OK.\n\n" +
        "Done! Ab bolo: 'TV on karo', 'TV volume badhao', 'TV par YouTube kholo', 'TV par Arijit Singh chalao', 'TV mute karo', 'TV off karo'!"
}
