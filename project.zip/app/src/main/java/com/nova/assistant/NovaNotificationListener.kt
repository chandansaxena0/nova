package com.nova.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Remembers incoming chat notifications that have a "Reply" box (WhatsApp, Telegram, SMS ...),
 * so Nova can answer them by voice without opening the app.
 */
class NovaNotificationListener : NotificationListenerService() {

    class ReplyTarget(val sender: String, val action: Notification.Action, val time: Long)

    companion object {
        @Volatile
        var connected = false

        private val replies = LinkedHashMap<String, ReplyTarget>()

        /** Sends [text] as a reply to the newest chat from [whoKey] (or the newest chat if blank). */
        fun replyTo(context: Context, whoKey: String, whoName: String, text: String): String {
            val all = synchronized(replies) { replies.values.toList() }
            if (all.isEmpty()) return "Abhi koi message notification nahi hai jisko reply kar sakun."

            val target = if (whoKey.isBlank()) {
                all.maxByOrNull { it.time }
            } else {
                all.filter { Normalizer.similarity(whoKey, Normalizer.key(it.sender)) >= 0.7 }
                    .maxByOrNull { it.time }
            }
            if (target == null) return "\"$whoName\" ka koi naya message notification nahi mila."

            return try {
                val inputs = target.action.remoteInputs
                val ri = inputs.first { it.allowFreeFormInput }
                val intent = Intent()
                val bundle = Bundle()
                bundle.putCharSequence(ri.resultKey, text)
                RemoteInput.addResultsToIntent(inputs, intent, bundle)
                target.action.actionIntent.send(context, 0, intent)
                "${target.sender} ko reply bhej diya: \"$text\""
            } catch (e: Exception) {
                "Reply nahi ja paya: ${e.message}"
            }
        }
    }

    override fun onListenerConnected() {
        connected = true
        try {
            activeNotifications?.forEach { capture(it) }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        capture(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(replies) { replies.remove(sbn.key) }
    }

    private fun capture(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val act = n.actions?.firstOrNull { a ->
            a.remoteInputs?.any { it.allowFreeFormInput } == true
        } ?: return
        val title = n.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        if (title.isEmpty()) return
        synchronized(replies) {
            replies[sbn.key] = ReplyTarget(title, act, sbn.postTime)
        }
    }
}
