package com.nova.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Tracks incoming WhatsApp / chat notifications with inline RemoteInput reply actions.
 * Enables:
 * - Announcing sender name & reading message aloud
 * - Replying via supported Android inline RemoteInput ONLY after user confirmation
 */
class NovaNotificationListener : NotificationListenerService() {

    data class ChatMessage(
        val key: String,
        val pkg: String,
        val sender: String,
        val messageText: String,
        val action: Notification.Action,
        val time: Long
    )

    companion object {
        @Volatile
        var connected = false

        private val messages = LinkedHashMap<String, ChatMessage>()

        fun latestMessages(onlyWhatsApp: Boolean = false): List<ChatMessage> = synchronized(messages) {
            messages.values
                .filter { !onlyWhatsApp || it.pkg.startsWith("com.whatsapp") }
                .sortedByDescending { it.time }
        }

        fun findTarget(whoKey: String): ChatMessage? {
            val all = latestMessages(onlyWhatsApp = false)
            if (all.isEmpty()) return null
            if (whoKey.isBlank()) return all.first()
            return all.filter {
                Normalizer.similarity(whoKey, Normalizer.key(HinglishConverter.toHinglish(it.sender))) >= 0.68
            }.maxByOrNull { it.time }
        }

        fun readLatestSummary(): String {
            if (!connected) {
                return "WhatsApp messages padhne ke liye Nova me Notification Access ON karo."
            }
            val wa = latestMessages(onlyWhatsApp = true)
            val list = if (wa.isNotEmpty()) wa else latestMessages(onlyWhatsApp = false)
            if (list.isEmpty()) return "Abhi koi naya WhatsApp ya chat notification nahi hai."
            val latest = list.first()
            val body = HinglishConverter.toHinglish(latest.messageText)
            return "${latest.sender} ka message aaya hai: $body. Reply bhejne ke liye bolo: reply karo aur apna message."
        }

        fun sendInlineReply(context: Context, target: ChatMessage, replyText: String): String {
            val cleanReply = HinglishConverter.toHinglish(replyText)
            return try {
                val inputs = target.action.remoteInputs ?: return "Is notification me inline reply support nahi hai."
                val ri = inputs.first { it.allowFreeFormInput }
                val intent = Intent()
                val bundle = Bundle()
                bundle.putCharSequence(ri.resultKey, cleanReply)
                RemoteInput.addResultsToIntent(inputs, intent, bundle)
                target.action.actionIntent.send(context, 0, intent)
                "${target.sender} ko reply bhej diya: \"$cleanReply\""
            } catch (e: Exception) {
                "Reply nahi ja paya: ${e.message}"
            }
        }
    }

    override fun onListenerConnected() {
        connected = true
        try {
            activeNotifications?.forEach { capture(it) }
        } catch (_: Exception) {}
    }

    override fun onListenerDisconnected() {
        connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        capture(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(messages) { messages.remove(sbn.key) }
    }

    private fun capture(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val act = n.actions?.firstOrNull { a ->
            a.remoteInputs?.any { it.allowFreeFormInput } == true
        } ?: return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        if (title.isEmpty()) return
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
            ?: ""
        synchronized(messages) {
            messages[sbn.key] = ChatMessage(
                key = sbn.key,
                pkg = sbn.packageName ?: "",
                sender = title,
                messageText = text,
                action = act,
                time = sbn.postTime
            )
            // Keep memory bounded
            while (messages.size > 30) {
                val oldestKey = messages.keys.firstOrNull() ?: break
                messages.remove(oldestKey)
            }
        }
    }
}
