package com.nova.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

/**
 * Notification Intelligence Engine:
 * - Captures active non-ongoing notifications across apps (grouped by app, classified by importance).
 * - Masks sensitive OTP digits automatically when summarizing aloud.
 * - Supports confirmed inline RemoteInput replies for WhatsApp / chat notifications.
 */
class NovaNotificationListener : NotificationListenerService() {

    data class ChatMessage(
        val key: String,
        val pkg: String,
        val sender: String,
        val messageText: String,
        val action: Notification.Action,
        val time: Long
    )

    data class NotifItem(
        val key: String,
        val pkg: String,
        val appLabel: String,
        val title: String,
        val text: String,
        val important: Boolean,
        val time: Long
    )

    companion object {
        @Volatile
        var connected = false

        private val messages = LinkedHashMap<String, ChatMessage>()
        private val allNotifs = LinkedHashMap<String, NotifItem>()

        fun latestMessages(onlyWhatsApp: Boolean = false): List<ChatMessage> = synchronized(messages) {
            messages.values
                .filter { !onlyWhatsApp || it.pkg.startsWith("com.whatsapp") }
                .sortedByDescending { it.time }
        }

        fun findTarget(whoKey: String): ChatMessage? {
            val all = latestMessages(onlyWhatsApp = false)
            if (all.isEmpty()) return null
            if (whoKey.isBlank()) return all.first()
            return all.filter {
                Normalizer.similarity(whoKey, Normalizer.key(HinglishConverter.toHinglish(it.sender))) >= 0.68
            }.maxByOrNull { it.time }
        }

        fun readLatestSummary(): String {
            if (!connected) {
                return "Messages padhne ke liye Nova ke Settings tab me Notification Access ON karo."
            }
            val wa = latestMessages(onlyWhatsApp = true)
            val list = if (wa.isNotEmpty()) wa else latestMessages(onlyWhatsApp = false)
            if (list.isEmpty()) return "Abhi koi naya WhatsApp ya chat notification nahi hai."
            val latest = list.first()
            val body = maskOtp(HinglishConverter.toHinglish(latest.messageText))
            return "${latest.sender} ka message aaya hai: $body. Reply bhejne ke liye bolo: reply karo aur apna message."
        }

        /** Groups notifications by app, highlights important alerts, and summarizes cleanly. */
        fun summarizeAllNotifications(context: Context): String {
            if (!connected) {
                return "Notifications summarize karne ke liye Settings tab me Notification Access ON karo."
            }
            val list = synchronized(allNotifs) { allNotifs.values.sortedByDescending { it.time } }
            if (list.isEmpty()) {
                return "Abhi koi unread notification nahi hai."
            }

            val important = list.filter { it.important }
            val grouped = list.groupBy { it.appLabel }

            val summaryLines = buildString {
                append("Total ${list.size} notifications hain (${grouped.size} apps se). ")
                if (important.isNotEmpty()) {
                    append("Important (${important.size}): ")
                    important.take(3).forEach { n ->
                        append("${n.appLabel} - ${n.title}: ${maskOtp(HinglishConverter.toHinglish(n.text)).take(70)}; ")
                    }
                }
                val counts = grouped.entries
                    .sortedByDescending { it.value.size }
                    .take(5)
                    .joinToString(", ") { "${it.key} (${it.value.size})" }
                append("Grouped by app: $counts.")
            }

            // If online + Gemini configured and many notifications exist, polish into a crisp spoken brief
            if (list.size >= 4 && PhoneInfoHelper.isOnline(context) && Prefs.hasAi(context)) {
                val rawDigest = list.take(15).joinToString("\n") {
                    "[${if (it.important) "IMPORTANT" else "NORMAL"}] ${it.appLabel} | ${it.title}: ${maskOtp(it.text).take(90)}"
                }
                val sys = "You are Nova's Notification Intelligence. Group similar notifications, highlight important ones first, and give a crisp 2 to 4 sentence spoken summary in Roman Hinglish/English (no markdown, never reveal OTPs)."
                val ai = GeminiClient.askWithAgentPrompt(context, sys, rawDigest, keepContext = false, maxTokens = 300)
                if (!ai.startsWith("Gemini error") && !ai.startsWith("Internet")) return ai
            }
            return summaryLines.trim()
        }

        fun sendInlineReply(context: Context, target: ChatMessage, replyText: String): String {
            val cleanReply = HinglishConverter.toHinglish(replyText)
            return try {
                val inputs = target.action.remoteInputs ?: return "Is notification me inline reply support nahi hai."
                val ri = inputs.first { it.allowFreeFormInput }
                val intent = Intent()
                val bundle = Bundle()
                bundle.putCharSequence(ri.resultKey, cleanReply)
                RemoteInput.addResultsToIntent(inputs, intent, bundle)
                target.action.actionIntent.send(context, 0, intent)
                "${target.sender} ko reply bhej diya: \"$cleanReply\""
            } catch (e: Exception) {
                "Reply nahi ja paya: ${e.message}"
            }
        }

        private fun maskOtp(text: String): String =
            if (text.lowercase(Locale.ROOT).let { it.contains("otp") || it.contains("verification code") || it.contains("pin") }) {
                text.replace(Regex("\\b\\d{4,8}\\b"), "[hidden code]")
            } else text
    }

    override fun onListenerConnected() {
        connected = true
        try {
            activeNotifications?.forEach { capture(it) }
        } catch (_: Exception) {}
    }

    override fun onListenerDisconnected() {
        connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        capture(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(messages) { messages.remove(sbn.key) }
        synchronized(allNotifs) { allNotifs.remove(sbn.key) }
    }

    private fun capture(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
            ?: ""
        if (title.isEmpty() && text.isEmpty()) return

        // Track general non-ongoing notifications for Notification Intelligence
        if (!sbn.isOngoing) {
            val appLabel = resolveAppLabel(pkg)
            val combined = "$title $text".lowercase(Locale.ROOT)
            val important = pkg.startsWith("com.whatsapp") ||
                pkg.contains("dialer") || pkg.contains("messaging") || pkg.contains("calendar") ||
                pkg.contains("gm") || pkg.contains("bank") ||
                combined.contains("missed call") || combined.contains("urgent") ||
                combined.contains("delivered") || combined.contains("alarm") ||
                combined.contains("reminder") || combined.contains("train")

            synchronized(allNotifs) {
                allNotifs[sbn.key] = NotifItem(
                    key = sbn.key,
                    pkg = pkg,
                    appLabel = appLabel,
                    title = title.ifEmpty { appLabel },
                    text = text,
                    important = important,
                    time = sbn.postTime
                )
                while (allNotifs.size > 40) {
                    val oldest = allNotifs.keys.firstOrNull() ?: break
                    allNotifs.remove(oldest)
                }
            }
        }

        // Track inline-replyable chat notifications
        val act = n.actions?.firstOrNull { a ->
            a.remoteInputs?.any { it.allowFreeFormInput } == true
        } ?: return
        if (title.isEmpty()) return
        synchronized(messages) {
            messages[sbn.key] = ChatMessage(
                key = sbn.key,
                pkg = pkg,
                sender = title,
                messageText = text,
                action = act,
                time = sbn.postTime
            )
            while (messages.size > 30) {
                val oldestKey = messages.keys.firstOrNull() ?: break
                messages.remove(oldestKey)
            }
        }
    }

    private fun resolveAppLabel(pkg: String): String = try {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString()
    } catch (_: Exception) {
        pkg.substringAfterLast('.')
    }
}
