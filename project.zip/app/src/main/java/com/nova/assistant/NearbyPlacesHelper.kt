package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * On-demand Location helper (ZERO background location polling -> ZERO background battery drain).
 * Powers:
 * 1) Nearest Petrol Pump, Hospital, ATM, Railway Station, Medical Store, Restaurant
 *    with actual distance calculation (OpenStreetMap Overpass API) + Google Maps Route.
 * 2) Current Weather & Temperature (free Open-Meteo API, no API key needed).
 * 3) One-shot Emergency Location link.
 */
object NearbyPlacesHelper {

    data class PlaceType(val label: String, val osmTag: String, val mapsQuery: String)
    private data class PlaceHit(val name: String, val lat: Double, val lon: Double, val meters: Float)

    fun hasLocationPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun detectPlaceType(text: String): PlaceType? {
        val s = text.lowercase(Locale.ROOT)
        return when {
            s.contains("petrol") || s.contains("fuel") || s.contains("diesel") || s.contains("cng") ->
                PlaceType("Petrol Pump", "\"amenity\"=\"fuel\"", "petrol pump near me")
            s.contains("hospital") || s.contains("aspatal") || s.contains("clinic") ->
                PlaceType("Hospital", "\"amenity\"=\"hospital\"", "hospital near me")
            s.contains("atm") ->
                PlaceType("ATM", "\"amenity\"=\"atm\"", "ATM near me")
            s.contains("railway") || s.contains("train station") || s.contains("station") ->
                PlaceType("Railway Station", "\"railway\"=\"station\"", "railway station near me")
            s.contains("medical") || s.contains("pharmacy") || s.contains("chemist") || s.contains("dawai") ->
                PlaceType("Medical Store", "\"amenity\"=\"pharmacy\"", "medical store near me")
            s.contains("restaurant") || s.contains("hotel") || s.contains("dhaba") || s.contains("cafe") ->
                PlaceType("Restaurant", "\"amenity\"=\"restaurant\"", "restaurant near me")
            else -> null
        }
    }

    /** Must be called on a background thread. */
    fun findNearestAndOpenMaps(context: Context, place: PlaceType): String {
        if (!hasLocationPermission(context)) {
            return "Nearest ${place.label} aur actual distance batane ke liye Location permission chahiye. Nova ke Settings tab se Location allow karo."
        }

        val loc = getOneShotLocation(context)
        if (loc == null) {
            openMapsSearch(context, place.mapsQuery)
            return "Abhi exact GPS fix nahi mila, isliye Google Maps par nearest ${place.label} khol raha hoon."
        }

        if (!PhoneInfoHelper.isOnline(context)) {
            openMapsSearch(context, place.mapsQuery)
            return "Internet band hai, isliye actual distance nahi nikal paya. Google Maps khol raha hoon."
        }

        val nearest = queryOverpass(loc.latitude, loc.longitude, place.osmTag)
        return if (nearest != null) {
            val distText = formatDistance(nearest.meters)
            openMapsRoute(context, nearest.lat, nearest.lon, nearest.name)
            "Aapke sabse paas ${nearest.name} hai, lagbhag $distText door. Google Maps me route khol raha hoon."
        } else {
            openMapsSearch(context, place.mapsQuery)
            "Nearby ${place.label} ka exact record nahi mila, isliye Google Maps par nearest ${place.label} dikha raha hoon."
        }
    }

    /** Free Open-Meteo current weather using on-demand location (runs on background thread). */
    fun fetchWeather(context: Context): String {
        if (!PhoneInfoHelper.isOnline(context)) {
            return "Weather check karne ke liye internet chalu karo."
        }
        if (!hasLocationPermission(context)) {
            return "Weather aur temperature batane ke liye Nova me Location permission allow karo."
        }
        val loc = getOneShotLocation(context)
            ?: return "Abhi GPS location nahi mili. Phone ki Location ON karke dobara bolo."

        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}" +
                    "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "NovaAssistant/6.0")
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val current = JSONObject(body).getJSONObject("current")
            val temp = current.optDouble("temperature_2m", Double.NaN)
            val humidity = current.optInt("relative_humidity_2m", -1)
            val wind = current.optDouble("wind_speed_10m", 0.0)
            val code = current.optInt("weather_code", 0)
            val desc = weatherCodeDesc(code)
            if (temp.isNaN()) "Weather data nahi mila."
            else String.format(
                Locale.US,
                "Abhi temperature %.1f°C hai, mausam %s hai. Humidity %d%% aur hawa %.0f km/h chal rahi hai.",
                temp, desc, humidity, wind
            )
        } catch (_: Exception) {
            "Weather server se connect nahi ho paya. Thodi der baad try karo."
        }
    }

    fun dailyBriefing(context: Context, index: AppIndex): String {
        val dateStr = SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val bat = PhoneInfoHelper.battery(context)
        val reminders = ReminderStore.upcoming(context)
        val remSummary = if (reminders.isEmpty()) {
            "Aaj koi pending reminder nahi hai."
        } else {
            val top = reminders.take(3).joinToString("; ") { "${it.title} (${ReminderStore.formatTime(it.triggerAtMs)})" }
            "Aapke ${reminders.size} reminders hain: $top."
        }
        val weather = if (hasLocationPermission(context) && PhoneInfoHelper.isOnline(context)) {
            fetchWeather(context)
        } else {
            "Weather ke liye Location aur Internet ON rakho."
        }
        return "Aaj $dateStr hai. Phone battery ${bat.percent}% hai. $weather $remSummary"
    }

    fun getLocationShareLink(context: Context): String? {
        if (!hasLocationPermission(context)) return null
        val loc = getOneShotLocation(context) ?: return null
        return "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
    }

    @Suppress("MissingPermission")
    fun getOneShotLocation(context: Context): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (Build.VERSION.SDK_INT >= 30) {
            val provider = when {
                runCatching { lm.isProviderEnabled(LocationManager.FUSED_PROVIDER) }.getOrDefault(false) ->
                    LocationManager.FUSED_PROVIDER
                runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false) ->
                    LocationManager.GPS_PROVIDER
                runCatching { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false) ->
                    LocationManager.NETWORK_PROVIDER
                else -> null
            }
            if (provider != null) {
                var result: Location? = null
                val latch = CountDownLatch(1)
                try {
                    lm.getCurrentLocation(provider, null, context.mainExecutor) { l ->
                        result = l
                        latch.countDown()
                    }
                    latch.await(6, TimeUnit.SECONDS)
                    if (result != null) return result
                } catch (_: Exception) {}
            }
        }
        return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
    }

    private fun queryOverpass(lat: Double, lon: Double, osmTag: String): PlaceHit? {
        val radii = listOf(5000, 15000)
        for (radius in radii) {
            val hit = queryOverpassRadius(lat, lon, osmTag, radius)
            if (hit != null) return hit
        }
        return null
    }

    private fun queryOverpassRadius(lat: Double, lon: Double, osmTag: String, radiusMeters: Int): PlaceHit? {
        return try {
            val q = "[out:json][timeout:8];(node[$osmTag](around:$radiusMeters,$lat,$lon);way[$osmTag](around:$radiusMeters,$lat,$lon););out center 20;"
            val url = URL("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8"))
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 7000
                readTimeout = 9000
                setRequestProperty("User-Agent", "NovaAssistant/6.0")
            }
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val els = JSONObject(body).optJSONArray("elements") ?: return null
            var best: PlaceHit? = null
            val res = FloatArray(1)
            for (i in 0 until els.length()) {
                val el = els.getJSONObject(i)
                val cLat = if (el.has("lat")) el.getDouble("lat")
                else el.optJSONObject("center")?.optDouble("lat") ?: continue
                val cLon = if (el.has("lon")) el.getDouble("lon")
                else el.optJSONObject("center")?.optDouble("lon") ?: continue
                val tags = el.optJSONObject("tags")
                val name = tags?.optString("name")?.trim().orEmpty()
                    .ifEmpty { tags?.optString("brand")?.trim().orEmpty() }
                    .ifEmpty { tags?.optString("operator")?.trim().orEmpty() }
                    .ifEmpty { "Nearby spot" }
                Location.distanceBetween(lat, lon, cLat, cLon, res)
                if (best == null || res[0] < best.meters) {
                    best = PlaceHit(name, cLat, cLon, res[0])
                }
            }
            best
        } catch (_: Exception) {
            null
        }
    }

    private fun formatDistance(meters: Float): String =
        if (meters < 1000f) "${meters.toInt()} meter"
        else String.format(Locale.US, "%.1f kilometer", meters / 1000f)

    private fun openMapsRoute(context: Context, lat: Double, lon: Double, label: String) {
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$lat,$lon"))
            .setPackage("com.google.android.apps.maps")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val geo = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(label)})"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(nav) }.onFailure { runCatching { context.startActivity(geo) } }
    }

    private fun openMapsSearch(context: Context, query: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(query)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(i) }
    }

    private fun weatherCodeDesc(code: Int): String = when (code) {
        0 -> "saaf (clear sky)"
        1, 2, 3 -> "halke badal (partly cloudy)"
        45, 48 -> "kohra (fog)"
        51, 53, 55, 61, 63, 65 -> "baarish (rain)"
        71, 73, 75 -> "barf (snow)"
        80, 81, 82 -> "tez baarish (showers)"
        95, 96, 99 -> "aandhi-toofan (thunderstorm)"
        else -> "normal"
    }
}
