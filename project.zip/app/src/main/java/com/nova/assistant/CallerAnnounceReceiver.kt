package com.nova.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

object CallControlHelper {

    @SuppressLint("MissingPermission")
    fun answerIncomingCall(context: Context): String {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            return "Call uthane ke liye Settings tab me 'Phone / Call Control' permission allow karo."
        }
        return try {
            val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            @Suppress("DEPRECATION")
            tm.acceptRingingCall()
            "Incoming call receive kar liya hai."
        } catch (e: Exception) {
            "Call receive nahi ho paya: ${e.message?.take(60)}"
        }
    }

    @SuppressLint("MissingPermission")
    fun rejectOrEndCall(context: Context): String {
        if (Build.VERSION.SDK_INT < 28) {
            return "Voice se call cut karna Android 9+ par supported hai."
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            return "Call cut karne ke liye Settings tab me 'Phone / Call Control' permission allow karo."
        }
        return try {
            val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            @Suppress("DEPRECATION")
            val ok = tm.endCall()
            if (ok) "Call disconnect kar diya hai." else "Abhi koi active ya ringing call nahi hai."
        } catch (e: Exception) {
            "Call disconnect nahi ho paya: ${e.message?.take(60)}"
        }
    }
}

/**
 * Announces incoming caller name aloud when phone rings (configurable: Off / Earbuds Only / Always).
 */
class CallerAnnounceReceiver : BroadcastReceiver() {

    companion object {
        @Volatile
        private var lastAnnouncedAtMs: Long = 0L
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (Prefs.privacyPaused(context)) return

        val mode = Prefs.callerAnnounceMode(context)
        if (mode == "off") return
        if (mode == "headset" && !HeadsetAutoReceiver.isAudioHeadsetConnected(context)) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        val now = System.currentTimeMillis()
        if (now - lastAnnouncedAtMs < 6000L) return
        lastAnnouncedAtMs = now

        @Suppress("DEPRECATION")
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER).orEmpty().trim()
        val callerName = if (number.isNotEmpty()) {
            Contacts.findNameByNumber(context, number) ?: "Unknown number"
        } else {
            "Kisi"
        }

        val announcement = "$callerName ka call aa raha hai. Uthaun ya cut karun?"
        if (ListenService.running) {
            runCatching {
                context.startService(
                    Intent(context, ListenService::class.java)
                        .setAction(ListenService.ACTION_SPEAK_ALERT)
                        .putExtra("message", announcement)
                )
            }
        }
    }
}
