package com.nova.assistant

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Research Agent engine:
 * - Uses Gemini + Google Search Grounding (returning verified source links) as primary engine.
 * - Falls back to public Wikipedia REST Summary + DuckDuckGo Instant Answer API with links
 *   when grounding isn't available, clearly distinguishing verified facts vs uncertain details.
 */
object WebResearchHelper {

    fun research(context: Context, rawQuery: String): String {
        val cleanQuery = HinglishConverter.toHinglish(rawQuery)
            .replace(Regex("\\b(research|web search|search online|internet par|latest news|fact check|batao|karo)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ").trim()
            .ifEmpty { rawQuery.trim() }

        if (!PhoneInfoHelper.isOnline(context)) {
            return "Internet band hai. Web research aur current news ke liye internet ON karo."
        }

        val today = SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH).format(Date())
        val sys = """
You are Nova's Research Agent. Today is $today.
Use Google Search to verify information across reliable sources.
Summarize clearly in 3 to 5 concise sentences (Roman Hinglish or English, NO markdown stars/hashtags).
Explicitly distinguish confirmed/verified facts from uncertain or unconfirmed claims.
""".trimIndent()

        val grounded = GeminiClient.askWithSearchGrounding(context, sys, "Research and summarize with verified facts: $cleanQuery")
        if (grounded != null && grounded.text.isNotBlank()) {
            return if (grounded.sources.isNotEmpty()) {
                val links = grounded.sources.joinToString("\n") { (title, url) -> "- $title ($url)" }
                "${grounded.text}\n\nSources:\n$links"
            } else {
                grounded.text
            }
        }

        // Secondary free open-source lookup: Wikipedia + DuckDuckGo Instant Answer
        val wiki = fetchWikipediaSummary(cleanQuery)
        val ddg = fetchDuckDuckGoSummary(cleanQuery)

        val parts = mutableListOf<String>()
        val sources = mutableListOf<String>()
        if (wiki != null) {
            parts.add(wiki.first)
            sources.add("- Wikipedia (${wiki.second})")
        }
        if (ddg != null) {
            parts.add(ddg.first)
            if (ddg.second.isNotEmpty()) sources.add("- Source (${ddg.second})")
        }

        if (parts.isNotEmpty()) {
            val combined = parts.joinToString(" ")
            val refined = if (Prefs.hasAi(context)) {
                GeminiClient.askWithAgentPrompt(
                    context,
                    "Summarize these verified web snippets cleanly in 2 to 4 short sentences (no markdown). Do not invent facts outside the text.",
                    "Topic: $cleanQuery\nWeb snippets:\n$combined",
                    keepContext = true,
                    maxTokens = 400
                )
            } else combined.take(450)
            return if (sources.isNotEmpty()) "$refined\n\nSources:\n${sources.joinToString("\n")}" else refined
        }

        // Fallback to Gemini with honest uncertainty note
        return if (Prefs.hasAi(context)) {
            GeminiClient.askWithAgentPrompt(
                context,
                "You are Nova's Research Agent. Answer clearly in 2 to 4 sentences (no markdown). If live real-time web verification is unavailable, honestly note that live details may have changed.",
                cleanQuery,
                keepContext = true,
                maxTokens = 450
            )
        } else {
            "Web sources se '$cleanQuery' par instant summary nahi mila. Better AI research ke liye Settings me Gemini API key save karo."
        }
    }

    private fun fetchWikipediaSummary(query: String): Pair<String, String>? {
        return try {
            val slug = URLEncoder.encode(query.replace(" ", "_"), "UTF-8")
            val url = URL("https://en.wikipedia.org/api/rest_v1/page/summary/$slug")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 7000
                setRequestProperty("User-Agent", "NovaAssistant/7.0")
            }
            try {
                if (conn.responseCode !in 200..299) return null
                val obj = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val extract = obj.optString("extract", "").trim()
                val pageUrl = obj.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page")
                    ?: "https://en.wikipedia.org/wiki/$slug"
                if (extract.length > 40) extract.take(600) to pageUrl else null
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun fetchDuckDuckGoSummary(query: String): Pair<String, String>? {
        return try {
            val q = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://api.duckduckgo.com/?q=$q&format=json&no_html=1&skip_disambig=1")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 7000
                setRequestProperty("User-Agent", "NovaAssistant/7.0")
            }
            try {
                if (conn.responseCode !in 200..299) return null
                val obj = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val abs = obj.optString("AbstractText", "").trim()
                val srcUrl = obj.optString("AbstractURL", "").trim()
                if (abs.length > 30) abs.take(500) to srcUrl else null
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) {
            null
        }
    }
}
