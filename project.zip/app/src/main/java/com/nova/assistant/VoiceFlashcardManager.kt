package com.nova.assistant

import android.content.Context
import java.util.Locale

/**
 * Interactive Voice Flashcards & Quick Revision Session Manager.
 * - Uses existing GeminiClient.ask(context, ..., keepContext = false) to generate dynamic topic decks
 *   when online, with built-in offline decks (Maths/Calculus, Physics, GK) as instant fallback.
 * - Conducts hands-free spoken Q&A: asks 1 question at a time, evaluates spoken answer,
 *   gives friendly Hinglish feedback, tracks score, and announces final result.
 */
object VoiceFlashcardManager {

    data class Flashcard(val question: String, val answer: String, val keywords: List<String>)

    @Volatile var active: Boolean = false
        private set

    private var topic: String = ""
    private var cards: List<Flashcard> = emptyList()
    private var currentIndex: Int = 0
    private var score: Int = 0

    private val offlineDecks: Map<String, List<Flashcard>> = mapOf(
        "maths" to listOf(
            Flashcard("sin x ka derivative kya hota hai?", "cos x", listOf("cos", "cosx")),
            Flashcard("log x (natural log) ka derivative kya hota hai?", "1 by x", listOf("1/x", "1 by x", "one by x", "x inverse")),
            Flashcard("cos 60 degree ki value kitni hoti hai?", "1 by 2 ya 0.5", listOf("1/2", "half", "0.5", "one by two", "aadha")),
            Flashcard("Pythagoras theorem ka formula kya hai?", "hypotenuse square equals base square plus perpendicular square", listOf("square", "hypotenuse", "base", "perpendicular", "a2", "b2", "c2")),
            Flashcard("e power x ka integration kya hota hai?", "e power x plus C", listOf("e power x", "e to the power x", "ex"))
        ),
        "physics" to listOf(
            Flashcard("Newton ka second law formula kya hai?", "Force equals mass into acceleration (F = m a)", listOf("ma", "mass", "acceleration", "f=ma")),
            Flashcard("Ohm's Law ka formula kya hota hai?", "V equals I into R", listOf("ir", "v=ir", "current", "resistance")),
            Flashcard("Force ki SI unit kya hoti hai?", "Newton", listOf("newton")),
            Flashcard("Vacuum me light ki speed kitni hoti hai?", "3 into 10 power 8 meter per second", listOf("3", "10", "8", "3 lakh", "300000")),
            Flashcard("Work done ka formula kya hota hai?", "Force into displacement (W = F into d cos theta)", listOf("force", "displacement", "distance", "fd"))
        ),
        "gk" to listOf(
            Flashcard("India ki sabse lambi nadi kaunsi hai?", "Ganga", listOf("ganga", "ganges")),
            Flashcard("Indian Air Force Day har saal kis date ko manaya jata hai?", "8 October", listOf("8 october", "october 8", "aath october")),
            Flashcard("Rajasthan ki capital kya hai?", "Jaipur", listOf("jaipur")),
            Flashcard("Solar system ka sabse bada planet kaunsa hai?", "Jupiter", listOf("jupiter", "brihaspati")),
            Flashcard("India ke Constitution ka father kise kaha jata hai?", "Dr. B. R. Ambedkar", listOf("ambedkar", "bhimrao"))
        )
    )

    fun stopSession(): String {
        val wasActive = active
        val finalScore = score
        val asked = currentIndex
        active = false
        cards = emptyList()
        currentIndex = 0
        score = 0
        return if (wasActive && asked > 0) {
            "Flashcards band kar diye. Ab tak tumhara score $finalScore out of $asked raha."
        } else {
            "Voice flashcards band kar diye."
        }
    }

    /** Starts a new flashcard session (runs on background thread). */
    fun startSession(context: Context, rawRequest: String): String {
        val cleanedTopic = extractTopic(rawRequest)
        val aiCards = generateCardsViaGemini(context, cleanedTopic)
        val chosen = aiCards ?: pickOfflineDeck(cleanedTopic)

        topic = cleanedTopic
        cards = chosen
        currentIndex = 0
        score = 0
        active = true

        val first = cards.first()
        return "$topic ke ${cards.size} voice flashcards shuru kar rahe hain. Jawab bolo, ya 'skip' ya 'flashcards band karo' keh sakte ho. Pehla sawal: ${first.question}"
    }

    /** Calls the untouched GeminiClient.ask() to generate 5 spoken flashcards on any custom topic. */
    private fun generateCardsViaGemini(context: Context, topicName: String): List<Flashcard>? {
        if (!Prefs.hasAi(context) || !PhoneInfoHelper.isOnline(context)) return null
        val prompt = """
Create exactly 5 short voice flashcards on "$topicName" in clean Roman Hinglish (NO Devanagari, NO numbering, NO markdown).
Format EVERY line strictly like this:
Q: short question | A: short answer | K: keyword1, keyword2
Output only those 5 lines.
""".trimIndent()

        return try {
            val raw = GeminiClient.ask(context, prompt, keepContext = false)
            parseFlashcardLines(raw)
        } catch (_: Exception) {
            null
        }
    }

    fun parseFlashcardLines(raw: String): List<Flashcard>? {
        val out = mutableListOf<Flashcard>()
        for (line in raw.lines()) {
            if (!line.contains("|")) continue
            val parts = line.split("|").map { it.trim() }
            if (parts.size < 2) continue
            val q = parts[0].replace(Regex("^Q\\s*:\\s*", RegexOption.IGNORE_CASE), "").trim()
            val a = parts[1].replace(Regex("^A\\s*:\\s*", RegexOption.IGNORE_CASE), "").trim()
            val kws = if (parts.size >= 3) {
                parts[2].replace(Regex("^K\\s*:\\s*", RegexOption.IGNORE_CASE), "")
                    .split(",")
                    .map { it.trim().lowercase(Locale.ROOT) }
                    .filter { it.isNotEmpty() }
            } else emptyList()
            if (q.length >= 6 && a.isNotEmpty()) {
                out.add(Flashcard(q, a, kws))
            }
        }
        return out.take(5).takeIf { it.size >= 3 }
    }

    fun handleAnswer(rawAnswer: String): String {
        if (!active || currentIndex >= cards.size) {
            active = false
            return ""
        }
        val clean = HinglishConverter.toHinglish(rawAnswer).trim()
        val lower = clean.lowercase(Locale.ROOT)

        if (lower.contains("flashcard") && (lower.contains("band") || lower.contains("stop") || lower.contains("exit") || lower.contains("khatam")) ||
            lower in setOf("exit flashcards", "quit flashcards", "stop quiz", "quiz band karo", "end flashcards")
        ) {
            return stopSession()
        }

        val card = cards[currentIndex]
        val isSkip = lower in setOf("skip", "next", "pata nahi", "nahi pata", "pass", "chhodo", "answer batao", "jawab batao") ||
            lower.contains("pata nahi") || lower.contains("nahi pata") || lower.contains("skip")

        val feedback = if (isSkip) {
            "Koi baat nahi, sahi jawab hai: ${card.answer}."
        } else if (matchesAnswer(lower, card)) {
            score++
            "Bilkul sahi! Jawab hai: ${card.answer}."
        } else {
            "Thoda miss ho gaya. Sahi jawab hai: ${card.answer}."
        }

        currentIndex++
        return if (currentIndex < cards.size) {
            val next = cards[currentIndex]
            "$feedback Agla sawal number ${currentIndex + 1}: ${next.question}"
        } else {
            val total = cards.size
            val finalScore = score
            active = false
            cards = emptyList()
            val remark = when {
                finalScore == total -> "Kamaal kar diya, full marks!"
                finalScore >= (total * 2) / 3 -> "Bahut badhiya revision hua!"
                else -> "Acchi koshish thi, thodi practice se aur strong ho jayega!"
            }
            "$feedback Flashcards complete! Tumhara final score $finalScore out of $total raha. $remark"
        }
    }

    fun matchesAnswer(userLower: String, card: Flashcard): Boolean {
        val ansLower = card.answer.lowercase(Locale.ROOT)
        if (Normalizer.similarity(Normalizer.key(userLower), Normalizer.key(ansLower)) >= 0.72) return true
        if (card.keywords.any { kw -> kw.isNotEmpty() && userLower.contains(kw.lowercase(Locale.ROOT)) }) return true
        val ansTokens = ansLower.split(Regex("[^a-z0-9]+")).filter { it.length >= 3 }
        if (ansTokens.isEmpty()) return false
        val hits = ansTokens.count { userLower.contains(it) }
        return hits.toDouble() / ansTokens.size >= 0.5
    }

    private fun extractTopic(raw: String): String {
        val clean = HinglishConverter.toHinglish(raw)
            .replace(
                Regex(
                    "\\b(voice|flashcards?|flash\\s+cards?|quiz|revision|practice|shuru|start|karo|chalu|khelo|ke|ka|ki|on|for|about|mujhe|mere|ek|banao)\\b",
                    RegexOption.IGNORE_CASE
                ),
                " "
            )
            .replace(Regex("\\s+"), " ")
            .trim()
        return clean.ifEmpty { "Physics & Maths" }
    }

    private fun pickOfflineDeck(topic: String): List<Flashcard> {
        val lower = topic.lowercase(Locale.ROOT)
        return when {
            lower.contains("math") || lower.contains("calc") || lower.contains("trigo") || lower.contains("algebra") ->
                offlineDecks["maths"]!!
            lower.contains("phys") || lower.contains("science") || lower.contains("newton") || lower.contains("optic") ->
                offlineDecks["physics"]!!
            else -> offlineDecks["gk"]!!
        }
    }
}
