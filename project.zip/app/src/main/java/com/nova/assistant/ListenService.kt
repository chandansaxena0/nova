package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import kotlin.concurrent.thread

/**
 * Always-on listener. Runs as a foreground service (notification stays visible),
 * so it keeps working when the screen is locked or the app is closed.
 * Everything runs on the phone: no internet, no cost.
 */
class ListenService : Service(), RecognitionListener {

    companion object {
        const val ACTION_LISTEN_NOW = "com.nova.assistant.LISTEN_NOW"
        const val ACTION_STOP = "com.nova.assistant.STOP"
        const val ACTION_STOP_AGENT = "com.nova.assistant.STOP_AGENT"
        const val CH_LISTEN = "nova_listen"
        const val CH_RESULT = "nova_result"
        const val NOTIF_ID = 1
        const val RESULT_ID = 2
        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var foregroundStarted = false
    @Volatile private var resumeAfterSpeech = false
    @Volatile private var activeSpeechId: String? = null
    private var armedUntil = 0L
    private var sessionTimeout: Runnable? = null
    private var tts: TextToSpeech? = null
    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        index = AppIndex(this)
        parser = CommandParser(index)
        index.refresh()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Voice replies remain Hindi-friendly, but recognition text is Romanized.
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) {
                        if (id == activeSpeechId) finishSpeechAndResume()
                    }
                    override fun onDone(id: String?) {
                        if (id == activeSpeechId) finishSpeechAndResume()
                    }
                })
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("nova", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_STOP_AGENT) {
            NovaAccessibility.instance?.stopAgent()
            return START_STICKY
        }

        if (!foregroundStarted) {
            try {
                ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification("Taiyaar ho raha hoon..."),
                    if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                )
                foregroundStarted = true
            } catch (e: Exception) {
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:listen").apply { acquire() }
            loadModelAndListen()
        }

        if (intent?.action == ACTION_LISTEN_NOW) arm()
        return START_STICKY
    }

    private fun loadModelAndListen() {
        thread {
            try {
                val dir = ModelFiles.ensure(this)
                val m = Model(dir.absolutePath)
                main.post {
                    if (!running) {
                        m.close()
                        return@post
                    }
                    model = m
                    startRecognizer()
                }
            } catch (e: Exception) {
                main.post { fail("Voice model load nahi hua: ${e.message}") }
            }
        }
    }

    private fun startRecognizer() {
        if (speech != null || model == null || !running) return
        try {
            val rec = Recognizer(model, 16000.0f)
            val s = SpeechService(rec, 16000.0f)
            s.startListening(this)
            speech = s
            updateNotification("Sun raha hoon. Bolo: \"Hey Nova\"")
        } catch (e: Exception) {
            fail("Mic shuru nahi hua: ${e.message}")
        }
    }

    // ---- RecognitionListener ----
    override fun onResult(hypothesis: String?) {
        val text = try {
            JSONObject(hypothesis ?: return).optString("text", "").trim()
        } catch (e: Exception) {
            ""
        }
        if (text.isNotEmpty()) {
            // Vosk Hindi model emits Devanagari; convert it to Roman Hinglish
            // before parsing, displaying, or forwarding the recognized command.
            val romanText = if (text.any { it in '\\u0900'..'\\u097F' }) parser.transliterate(text) else text
            handleText(romanText)
        }
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) {
        fail("Sunne me error: ${exception?.message}")
    }

    override fun onTimeout() {}

    private fun handleText(text: String) {
        if (!running) return
        // Stop phrases are intercepted before the resolver/Gemini and have highest priority.
        if (isStopCommand(text)) {
            pauseRecognizer()
            getSharedPreferences("nova", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
            stopSelf()
            return
        }

        val armed = SystemClock.elapsedRealtime() < armedUntil
        val afterWake = parser.stripWake(text)
        when {
            afterWake != null && afterWake.isBlank() -> arm()
            afterWake != null -> {
                arm()
                if (afterWake.isNotBlank()) runCommand(afterWake)
            }
            armed -> runCommand(text)
            else -> { /* normal talking, ignore */ }
        }
    }

    private fun isStopCommand(raw: String): Boolean {
        val s = raw.lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
        val normalized = s.replace(" ", "")
        val latin = parser.transliterate(s).lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "")
        val stopForms = setOf(
            "stop", "stoplistening", "novastop", "novabandhojao",
            "bandkaro", "bandhojao", "listeningbandkaro", "basnova",
            "नवाबंदकरो", "सुननाबंदकरो"
        )
        return normalized in stopForms || latin in stopForms
    }

    /** Wake word heard: beep, acknowledge and open a 30-second command session. */
    private fun arm() {
        pauseRecognizer()
        beep()
        speak("Ji, main sun raha hoon.", resumeAfter = true)
        updateNotification("Boliye, sun raha hoon...")
        refreshSession()
    }

    private fun refreshSession() {
        val duration = Prefs.sessionDurationMs(this)
        armedUntil = SystemClock.elapsedRealtime() + duration
        sessionTimeout?.let { main.removeCallbacks(it) }
        val timeout = Runnable {
            if (armedUntil != 0L && SystemClock.elapsedRealtime() >= armedUntil) {
                armedUntil = 0L
                speak("Command session khatam. Hey Nova boliye.")
                updateNotification("Sun raha hoon. Bolo: \"Hey Nova\"")
            }
        }
        sessionTimeout = timeout
        main.postDelayed(timeout, duration + 250)
    }

    private fun runCommand(text: String) {
        // Stop microphone capture before Nova speaks or executes anything.
        pauseRecognizer()
        // Keep command mode alive; each accepted command refreshes the session timeout.
        refreshSession()
        index.refresh()
        speak("Ji, kar raha hoon.")
        Resolver.resolve(this, index, parser, text) { cmd ->
            withOverlay {
                val msg = ActionExecutor.run(this, index, cmd)
                refreshSession() // successful/processed command refreshes the listening window
                speak(msg, resumeAfter = true)
                updateNotification("Suna: \"${cmd.heard}\"")
                showResult(cmd, msg)
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun pauseRecognizer() {
        resumeAfterSpeech = false
        try {
            speech?.stop()
            speech?.shutdown()
        } catch (_: Exception) { }
        speech = null
    }

    private fun speak(message: String, resumeAfter: Boolean = false) {
        resumeAfterSpeech = resumeAfter
        val utteranceId = "nova-${SystemClock.elapsedRealtime()}"
        activeSpeechId = utteranceId
        try {
            val result = tts?.speak(
                message,
                TextToSpeech.QUEUE_FLUSH,
                null,
                utteranceId
            )
            if (result == TextToSpeech.ERROR && resumeAfter) finishSpeechAndResume()
        } catch (_: Exception) {
            if (resumeAfter) finishSpeechAndResume()
        }
    }

    private fun finishSpeechAndResume() {
        main.post {
            if (resumeAfterSpeech && running && Prefs.wake(this)) {
                resumeAfterSpeech = false
                main.postDelayed({ if (running && Prefs.wake(this)) startRecognizer() }, 450L)
            }
        }
    }

    /**
     * Android blocks apps from opening other apps while in the background.
     * A tiny invisible window ("Display over other apps") lets this app do it.
     */
    private fun withOverlay(block: () -> Unit) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var view: View? = null
        if (Settings.canDrawOverlays(this)) {
            try {
                val v = View(this)
                val lp = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                wm.addView(v, lp)
                view = v
            } catch (e: Exception) {
                view = null
            }
        }
        main.postDelayed({
            block()
            view?.let { v ->
                main.postDelayed({
                    try {
                        wm.removeView(v)
                    } catch (e: Exception) {
                    }
                }, 2500)
            }
        }, if (view != null) 150L else 0L)
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ tg.release() }, 400)
        } catch (e: Exception) {
        }
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private fun fail(message: String) {
        updateNotification(message)
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    // ---- notifications ----
    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Nova sun raha hai", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RESULT, "Nova natija", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
            }
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listenNow = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_LISTEN_NOW),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAgent = PendingIntent.getService(
            this, 4, Intent(this, ListenService::class.java).setAction(ACTION_STOP_AGENT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Nova")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "Abhi suno", listenNow)
            .addAction(0, "Rok do", stopAgent)
            .addAction(0, "Band karo", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!foregroundStarted) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    /** If Android still blocks the launch, this notification opens the app with one tap. */
    private fun showResult(cmd: Command, msg: String) {
        val pkg = cmd.app?.pkg
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        val b = NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(msg)
            .setContentText(if (launch != null) "Nahi khula? Yahan tap karo." else "")
            .setAutoCancel(true)
            .setTimeoutAfter(15000)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (launch != null) {
            b.setContentIntent(
                PendingIntent.getActivity(
                    this, 3, launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        getSystemService(NotificationManager::class.java).notify(RESULT_ID, b.build())
    }

    override fun onDestroy() {
        running = false
        sessionTimeout?.let { main.removeCallbacks(it) }
        tts?.stop()
        tts?.shutdown()
        tts = null
        speech?.stop()
        speech?.shutdown()
        speech = null
        model?.close()
        model = null
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
