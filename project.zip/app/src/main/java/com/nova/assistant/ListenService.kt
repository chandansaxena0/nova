package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.RecognitionListener as AndroidRecListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener as VoskListener
import org.vosk.android.SpeechService
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Nova v6.2 Siri-Style Neural Voice Service:
 *
 * Stage 1 (Neural Wake Mode):
 *   Primary: openWakeWord ONNX Runtime (`hey_nova.onnx` — 80 ms neural frames, instant trigger).
 *   Fallback: Vosk Indian-English if neural backbone cannot initialize.
 *
 * Stage 2 (Command Mode — 30s or 40s configurable session):
 *   - Instant 120 ms chime (no "Ji, boliye" delay) + Auto Audio Ducking + Siri-style Floating Glow Pill.
 *   - Android SpeechRecognizer (en-IN) for clean Roman Hinglish + automatic offline Vosk fallback.
 *   - Priority #0 Stop interception returns cleanly to Wake Mode.
 *   - Strict Mic-Mute during TTS replies + 500 ms echo cooldown after TTS finishes.
 */
class ListenService : Service(), VoskListener {

    companion object {
        const val ACTION_LISTEN_NOW = "com.nova.assistant.LISTEN_NOW"
        const val ACTION_STOP_SERVICE = "com.nova.assistant.STOP"
        const val ACTION_STOP_AGENT = "com.nova.assistant.STOP_AGENT"
        const val ACTION_SPEAK_ALERT = "com.nova.assistant.SPEAK_ALERT"
        const val ACTION_APPLY_SETTINGS = "com.nova.assistant.APPLY_SETTINGS"

        const val CH_LISTEN = "nova_listen"
        const val CH_RESULT = "nova_result"
        const val NOTIF_ID = 1
        const val RESULT_ID = 2

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var owwEngine: OpenWakeWordEngine? = null
    private var useNeuralWake = false
    private var voskModel: Model? = null
    private var voskService: SpeechService? = null
    private var voskInCommandMode = false
    private var androidSr: SpeechRecognizer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var foregroundStarted = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // Audio ducking focus request
    private var focusRequest: AudioFocusRequest? = null

    // Siri-style floating glow pill overlay
    private var pillView: View? = null
    private var pillText: TextView? = null

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    @Volatile private var inCommandSession = false
    @Volatile private var userSpeaking = false
    @Volatile private var isProcessingCommand = false
    @Volatile private var isSpeakingReply = false
    @Volatile private var activeSpeechId: String? = null
    @Volatile private var afterSpeechAction: (() -> Unit)? = null

    private var sessionEndAt = 0L
    private var lastWakeTriggerAt = 0L
    @Volatile private var wakeArmedAt = 0L
    private var voskErrorCount = 0
    private var lowBatteryAlerted = false

    private val sessionTickRunnable = object : Runnable {
        override fun run() {
            if (!running || !inCommandSession) return
            val leftMs = sessionEndAt - SystemClock.elapsedRealtime()
            if (leftMs <= 0L) {
                if (userSpeaking || isProcessingCommand || isSpeakingReply) {
                    main.postDelayed(this, 600L)
                    return
                }
                endCommandSession(announce = false)
                return
            }
            val sec = ((leftMs + 999L) / 1000L).toInt()
            NovaState.update(remainingSec = sec)
            updateNotification("Command mode (${sec}s) — Boliye ya 'Stop' kahein")
            main.postDelayed(this, 1000L)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!Prefs.lowBatteryAlert(context)) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
            if (charging || pct > 20) {
                lowBatteryAlerted = false
            } else if (running && Prefs.wake(context) && !Prefs.privacyPaused(context) && pct <= 15 && !lowBatteryAlerted && !inCommandSession && !isProcessingCommand && !isSpeakingReply) {
                lowBatteryAlerted = true
                speakAndThen("Battery low alert: phone battery sirf $pct percent bachi hai.") {
                    if (running) enterWakeMode()
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        index = AppIndex(this)
        parser = CommandParser(index)
        index.refresh(force = true)

        initTts()
        try {
            registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Exception) {}
    }

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                applyTtsSettings()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) {
                        if (id == activeSpeechId) onTtsFinished()
                    }
                    override fun onDone(id: String?) {
                        if (id == activeSpeechId) onTtsFinished()
                    }
                })
            }
        }
    }

    private fun applyTtsSettings() {
        val engine = tts ?: return
        val langPref = Prefs.replyLanguage(this)
        engine.language = if (langPref == "english") Locale("en", "IN") else Locale("hi", "IN")
        engine.setSpeechRate(Prefs.ttsSpeed(this))
        val savedVoice = Prefs.ttsVoice(this)
        if (savedVoice.isNotEmpty()) {
            val match = engine.voices?.firstOrNull { it.name == savedVoice }
            if (match != null) engine.voice = match
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        // 1) Immediate full shutdown when user taps "Band karo" or toggles Wake OFF
        if (action == ACTION_STOP_SERVICE) {
            Prefs.setWake(this, false)
            shutdownImmediately()
            return START_NOT_STICKY
        }

        // 2) Never allow Android (null intent) or stale actions to resurrect the service when Wake is OFF or Privacy Mode is ON
        if (Prefs.privacyPaused(this) || (!Prefs.wake(this) && action != ACTION_LISTEN_NOW)) {
            shutdownImmediately()
            return START_NOT_STICKY
        }

        when (action) {
            ACTION_STOP_AGENT -> {
                NovaAccessibility.instance?.stopAgent()
                if (inCommandSession) endCommandSession(announce = false)
                return START_NOT_STICKY
            }
            ACTION_APPLY_SETTINGS -> {
                applyTtsSettings()
                return START_NOT_STICKY
            }
            ACTION_SPEAK_ALERT -> {
                val msg = intent.getStringExtra("message").orEmpty()
                if (msg.isNotBlank() && running && Prefs.wake(this)) {
                    stopAllRecognizers()
                    speakAndThen(msg) {
                        if (running && Prefs.wake(this) && !Prefs.privacyPaused(this)) {
                            if (inCommandSession) startCommandRecognizer() else enterWakeMode()
                        }
                    }
                }
                return START_NOT_STICKY
            }
        }

        if (!foregroundStarted) {
            try {
                ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification("Nova v6.3 neural engine load ho raha hai..."),
                    if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                )
                foregroundStarted = true
            } catch (_: Exception) {
                shutdownImmediately()
                return START_NOT_STICKY
            }
            running = true
            acquireWakeLock()
            loadEnginesAndStart()
        }

        if (action == ACTION_LISTEN_NOW) {
            main.post { activateCommandSession(initialCommand = null) }
        }
        // START_NOT_STICKY prevents Android from automatically restarting Nova in the background after it is closed/stopped
        return START_NOT_STICKY
    }

    private fun shutdownImmediately() {
        running = false
        inCommandSession = false
        isProcessingCommand = false
        isSpeakingReply = false
        afterSpeechAction = null
        activeSpeechId = null
        main.removeCallbacksAndMessages(null)
        releaseAudioDucking()
        hideOverlayPill()
        stopAllRecognizers()
        runCatching { tts?.stop() }
        runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
        foregroundStarted = false
        runCatching { getSystemService(NotificationManager::class.java).cancel(NOTIF_ID) }
        NovaState.update(mode = ListenMode.STOPPED, status = "Band hai", micActive = false, remainingSec = 0)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!Prefs.wake(this) || Prefs.privacyPaused(this)) {
            shutdownImmediately()
        }
        super.onTaskRemoved(rootIntent)
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:listen").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun loadEnginesAndStart() {
        NovaState.update(mode = ListenMode.LOADING_MODEL, status = "Neural 'Hey Nova' model load ho raha hai...", micActive = false)
        thread {
            // 1) Primary: Initialize openWakeWord neural engine (hey_nova.onnx)
            val engine = OpenWakeWordEngine(
                context = this,
                threshold = 0.65f,
                onWakeDetected = { _ ->
                    main.post {
                        if (running && !inCommandSession && !isSpeakingReply && !isProcessingCommand &&
                            SystemClock.elapsedRealtime() - wakeArmedAt > 1500L) {
                            activateCommandSession(initialCommand = null)
                        }
                    }
                },
                onError = { err ->
                    main.post {
                        if (running && !inCommandSession) {
                            scheduleWakeRecovery(err)
                        }
                    }
                }
            )
            val neuralOk = engine.init()
            if (!running || !Prefs.wake(this) || Prefs.privacyPaused(this)) {
                runCatching { engine.release() }
                return@thread
            }
            if (neuralOk) {
                owwEngine = engine
                useNeuralWake = true
                main.post {
                    if (running && Prefs.wake(this) && !Prefs.privacyPaused(this)) enterWakeMode()
                    else shutdownImmediately()
                }
                // Warm up Vosk in background ONLY if already downloaded (for offline command fallback)
                if (ModelFiles.isReady(this)) {
                    runCatching {
                        val dir = ModelFiles.ensure(this)
                        voskModel = Model(dir.absolutePath)
                    }
                }
                return@thread
            }

            // 2) Fallback: Vosk Indian-English model if neural backbone unavailable
            useNeuralWake = false
            try {
                val dir = ModelFiles.ensure(this) { pct ->
                    NovaState.update(
                        mode = ListenMode.LOADING_MODEL,
                        status = "Fallback voice model download ($pct%)...",
                        modelProgress = pct
                    )
                    updateNotification("Voice model download ($pct%)...")
                }
                val m = Model(dir.absolutePath)
                main.post {
                    if (!running || !Prefs.wake(this) || Prefs.privacyPaused(this)) {
                        m.close()
                        return@post
                    }
                    voskModel = m
                    NovaState.update(modelProgress = -1)
                    enterWakeMode()
                }
            } catch (e: Exception) {
                main.post {
                    NovaState.update(
                        mode = ListenMode.ERROR_RECOVERING,
                        status = "Model load error: ${e.message}",
                        micActive = false,
                        modelProgress = -1
                    )
                    updateNotification("Model error: ${e.message}")
                }
            }
        }
    }

    // ------------------------------------------------------------------ Stage 1: Wake Word Mode

    private fun enterWakeMode() {
        if (!running || !Prefs.wake(this) || Prefs.privacyPaused(this)) {
            shutdownImmediately()
            return
        }
        stopAllRecognizers()
        releaseAudioDucking()
        hideOverlayPill()
        inCommandSession = false
        userSpeaking = false
        isProcessingCommand = false
        isSpeakingReply = false
        sessionEndAt = 0L
        main.removeCallbacks(sessionTickRunnable)
        ActionExecutor.clearPending()

        wakeArmedAt = SystemClock.elapsedRealtime()
        if (useNeuralWake && owwEngine != null) {
            owwEngine?.start()
            voskErrorCount = 0
            NovaState.update(
                mode = ListenMode.WAKE_LISTENING,
                status = "Neural Wake ON — Bolo: \"Hey Nova\"",
                micActive = true,
                remainingSec = 0
            )
            updateNotification("Neural Wake ON — Bolo: \"Hey Nova\"")
            return
        }

        val m = voskModel
        if (m == null) {
            NovaState.update(mode = ListenMode.LOADING_MODEL, status = "Model taiyaar ho raha hai...", micActive = false, remainingSec = 0)
            return
        }

        try {
            voskInCommandMode = false
            val rec = Recognizer(m, 16000.0f)
            val svc = SpeechService(rec, 16000.0f)
            svc.startListening(this)
            voskService = svc
            voskErrorCount = 0
            NovaState.update(
                mode = ListenMode.WAKE_LISTENING,
                status = "Wake mode ON — Bolo: \"Hey Nova\"",
                micActive = true,
                remainingSec = 0
            )
            updateNotification("Sun raha hoon — Bolo: \"Hey Nova\"")
        } catch (e: Exception) {
            scheduleWakeRecovery("Mic start error: ${e.message}")
        }
    }

    // ---- Vosk RecognitionListener (Fallback Wake Mode & Offline Command Fallback) ----

    override fun onPartialResult(hypothesis: String?) {
        if (!running || isProcessingCommand || isSpeakingReply) return
        val partial = extractVoskText(hypothesis, "partial")
        if (partial.isEmpty()) return

        if (voskInCommandMode) {
            if (WakeStopDetector.isStopCommand(partial)) handlePriorityStop()
            return
        }

        val now = SystemClock.elapsedRealtime()
        if (now - lastWakeTriggerAt < 1800L) return
        val afterWake = WakeStopDetector.stripWake(partial, isPartial = true)
        if (afterWake != null) {
            lastWakeTriggerAt = now
            main.post { activateCommandSession(initialCommand = null) }
        }
    }

    override fun onResult(hypothesis: String?) {
        if (!running || isProcessingCommand || isSpeakingReply) return
        val text = extractVoskText(hypothesis, "text")
        if (text.isEmpty()) return

        if (voskInCommandMode) {
            main.post { handleCommandTranscript(text) }
            return
        }

        val now = SystemClock.elapsedRealtime()
        if (now - lastWakeTriggerAt < 1800L) return
        val afterWake = WakeStopDetector.stripWake(text, isPartial = false)
        if (afterWake != null) {
            lastWakeTriggerAt = now
            main.post { activateCommandSession(initialCommand = afterWake.takeIf { it.isNotBlank() }) }
        }
    }

    override fun onFinalResult(hypothesis: String?) = onResult(hypothesis)

    override fun onError(exception: Exception?) {
        scheduleWakeRecovery("Voice engine error: ${exception?.message}")
    }

    override fun onTimeout() {
        if (running && !inCommandSession) main.post { enterWakeMode() }
    }

    private fun scheduleWakeRecovery(reason: String) {
        if (!running || !Prefs.wake(this) || Prefs.privacyPaused(this)) {
            shutdownImmediately()
            return
        }
        stopAllRecognizers()
        voskErrorCount++
        val delayMs = (1200L * voskErrorCount).coerceAtMost(8000L)
        NovaState.update(mode = ListenMode.ERROR_RECOVERING, status = "$reason (auto-recovering...)", micActive = false)
        updateNotification("Mic recover ho raha hai...")
        main.postDelayed({
            if (running) {
                if (inCommandSession) startCommandRecognizer() else enterWakeMode()
            }
        }, delayMs)
    }

    // ------------------------------------------------------------------ Stage 2: Siri-Style Instant Command Mode

    private fun activateCommandSession(initialCommand: String?) {
        if (!running) return
        stopAllRecognizers()
        inCommandSession = true
        isProcessingCommand = false
        isSpeakingReply = false
        requestAudioDucking()
        resetSessionTimer()
        playFeedbackBeep(high = true)
        showOverlayPill("Nova sun raha hai...")

        if (!initialCommand.isNullOrBlank()) {
            handleCommandTranscript(initialCommand)
            return
        }

        // Instant Siri-style activation: 140 ms after chime, open command mic immediately (no "Ji, boliye" delay!)
        main.postDelayed({
            if (running && inCommandSession && !isProcessingCommand && !isSpeakingReply) {
                startCommandRecognizer()
            }
        }, 140L)
    }

    private fun resetSessionTimer() {
        val dur = Prefs.sessionDurationMs(this)
        sessionEndAt = SystemClock.elapsedRealtime() + dur
        main.removeCallbacks(sessionTickRunnable)
        NovaState.update(remainingSec = (dur / 1000L).toInt())
        main.post(sessionTickRunnable)
    }

    private fun endCommandSession(announce: Boolean, reason: String = "Listening band.") {
        inCommandSession = false
        userSpeaking = false
        isProcessingCommand = false
        sessionEndAt = 0L
        main.removeCallbacks(sessionTickRunnable)
        ActionExecutor.clearPending()
        stopAllRecognizers()
        playFeedbackBeep(high = false)

        if (announce) {
            updateOverlayPill(reason)
            speakAndThen(reason) {
                if (running) enterWakeMode()
            }
        } else {
            enterWakeMode()
        }
    }

    private fun handlePriorityStop() {
        NovaAccessibility.instance?.stopAgent()
        VoiceFlashcardManager.stopSession()
        tts?.stop()
        isSpeakingReply = false
        afterSpeechAction = null
        activeSpeechId = null
        NovaState.update(heard = "Stop", reply = "Listening band. Wake mode active.")
        endCommandSession(announce = true, reason = "Theek hai, sunna band.")
    }

    private fun startCommandRecognizer() {
        if (!running || !inCommandSession || isProcessingCommand || isSpeakingReply) return
        stopAllRecognizers()

        val canUseAndroidSr = SpeechRecognizer.isRecognitionAvailable(this) &&
            (PhoneInfoHelper.isOnline(this) || Build.VERSION.SDK_INT >= 31)

        if (canUseAndroidSr) {
            startAndroidSpeechRecognizer()
        } else {
            startOfflineVoskCommandFallback()
        }
    }

    private fun startAndroidSpeechRecognizer() {
        try {
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            androidSr = sr
            sr.setRecognitionListener(object : AndroidRecListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    userSpeaking = false
                    updateOverlayPill("Nova sun raha hai...")
                    NovaState.update(
                        mode = ListenMode.COMMAND_LISTENING,
                        status = "Command sun raha hoon (Hinglish)...",
                        micActive = true
                    )
                }

                override fun onBeginningOfSpeech() {
                    userSpeaking = true
                }

                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    userSpeaking = false
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    if (isSpeakingReply || isProcessingCommand) return
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) {
                        val h = HinglishConverter.toHinglish(partial)
                        updateOverlayPill(h)
                        if (WakeStopDetector.isStopCommand(h)) {
                            handlePriorityStop()
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    userSpeaking = false
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    destroyAndroidSr()
                    if (isSpeakingReply || isProcessingCommand) return
                    if (spoken.isBlank()) {
                        continueSessionOrSleep()
                    } else {
                        handleCommandTranscript(spoken)
                    }
                }

                override fun onError(error: Int) {
                    userSpeaking = false
                    destroyAndroidSr()
                    if (!running || !inCommandSession || isSpeakingReply) return
                    when (error) {
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER,
                        SpeechRecognizer.ERROR_CLIENT,
                        SpeechRecognizer.ERROR_AUDIO,
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                            startOfflineVoskCommandFallback()
                        }
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                            continueSessionOrSleep()
                        }
                        else -> {
                            main.postDelayed({ continueSessionOrSleep() }, 400L)
                        }
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2200L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000L)
            }
            sr.startListening(intent)
        } catch (_: Exception) {
            destroyAndroidSr()
            startOfflineVoskCommandFallback()
        }
    }

    private fun startOfflineVoskCommandFallback() {
        val m = voskModel ?: run {
            updateOverlayPill("Internet band hai — offline model nahi mila.")
            endCommandSession(announce = false)
            return
        }
        try {
            voskInCommandMode = true
            val rec = Recognizer(m, 16000.0f)
            val svc = SpeechService(rec, 16000.0f)
            svc.startListening(this)
            voskService = svc
            updateOverlayPill("Offline sun raha hoon...")
            NovaState.update(
                mode = ListenMode.COMMAND_LISTENING,
                status = "Offline command mode sun raha hoon...",
                micActive = true
            )
        } catch (e: Exception) {
            scheduleWakeRecovery("Offline mic error: ${e.message}")
        }
    }

    private fun continueSessionOrSleep() {
        if (!running || !inCommandSession || isSpeakingReply || isProcessingCommand) return
        if (SystemClock.elapsedRealtime() >= sessionEndAt) {
            endCommandSession(announce = false)
        } else {
            main.postDelayed({
                if (running && inCommandSession && !isProcessingCommand && !isSpeakingReply) {
                    startCommandRecognizer()
                }
            }, 250L)
        }
    }

    // ------------------------------------------------------------------ Command Handling

    private fun handleCommandTranscript(rawTranscript: String) {
        if (!running || isSpeakingReply) return
        val hinglish = HinglishConverter.toHinglish(rawTranscript)
        if (hinglish.isBlank()) {
            continueSessionOrSleep()
            return
        }

        if (WakeStopDetector.isStopCommand(hinglish)) {
            handlePriorityStop()
            return
        }

        val stripped = WakeStopDetector.stripWake(hinglish, isPartial = false)
        val effectiveText = when {
            stripped != null && stripped.isBlank() -> {
                resetSessionTimer()
                continueSessionOrSleep()
                return
            }
            stripped != null -> stripped
            else -> hinglish
        }

        stopAllRecognizers()
        isProcessingCommand = true
        updateOverlayPill("Soch raha hoon: $effectiveText")
        NovaState.update(mode = ListenMode.PROCESSING, status = "Samajh raha hoon: $effectiveText", heard = effectiveText, micActive = false)

        if (ActionExecutor.hasActivePending()) {
            ActionExecutor.handleConfirmationInput(effectiveText) { confirmReply ->
                if (confirmReply.isNotEmpty()) {
                    finishCommandReply(effectiveText, confirmReply, appPkg = null)
                } else {
                    ActionExecutor.clearPending()
                    dispatchToResolver(effectiveText)
                }
            }
            return
        }

        // Active Voice Flashcards revision session?
        if (VoiceFlashcardManager.active) {
            val fcReply = VoiceFlashcardManager.handleAnswer(effectiveText)
            if (fcReply.isNotEmpty()) {
                finishCommandReply(effectiveText, fcReply, appPkg = null)
                return
            }
        }

        dispatchToResolver(effectiveText)
    }

    private fun dispatchToResolver(text: String) {
        index.refresh()
        Resolver.resolve(this, index, parser, text) { cmd ->
            ActionExecutor.runAsync(this, index, cmd) { reply ->
                finishCommandReply(cmd.heard.ifEmpty { text }, reply, appPkg = cmd.app?.pkg)
            }
        }
    }

    private fun finishCommandReply(heard: String, reply: String, appPkg: String?) {
        isProcessingCommand = false
        if (inCommandSession) resetSessionTimer()

        updateOverlayPill(reply.take(120))
        NovaState.update(
            mode = ListenMode.SPEAKING,
            status = reply,
            heard = heard,
            reply = reply,
            micActive = false
        )
        showResultNotification(heard, reply, appPkg)

        // Strict Mic-Mute Reply: mic stays 100% OFF until TTS finishes + 500 ms echo cooldown
        speakAndThen(reply) {
            if (!running) return@speakAndThen
            if (inCommandSession) {
                continueSessionOrSleep()
            } else {
                enterWakeMode()
            }
        }
    }

    // ------------------------------------------------------------------ Audio Ducking, Strict Mic-Mute TTS & Overlay Pill

    private fun requestAudioDucking() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .build()
            focusRequest = req
            am.requestAudioFocus(req)
        } catch (_: Exception) {}
    }

    private fun releaseAudioDucking() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
            focusRequest = null
        } catch (_: Exception) {}
    }

    private fun showOverlayPill(text: String) {
        if (!Settings.canDrawOverlays(this)) return
        main.post {
            if (pillView != null) {
                pillText?.text = text
                return@post
            }
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val container = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(42, 24, 42, 24)
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#E60F172A"))
                        cornerRadius = 64f
                        setStroke(3, Color.parseColor("#38BDF8"))
                    }
                }
                val dot = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(22, 22).apply { marginEnd = 20 }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.parseColor("#38BDF8"))
                    }
                }
                val tv = TextView(this).apply {
                    this.text = text
                    setTextColor(Color.WHITE)
                    textSize = 14f
                    maxLines = 2
                }
                container.addView(dot)
                container.addView(tv)

                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = 90
                }
                wm.addView(container, lp)
                pillView = container
                pillText = tv
            } catch (_: Exception) {
                pillView = null
                pillText = null
            }
        }
    }

    private fun updateOverlayPill(text: String) {
        main.post {
            if (pillView != null) {
                pillText?.text = text
            }
        }
    }

    private fun hideOverlayPill() {
        main.post {
            val v = pillView ?: return@post
            pillView = null
            pillText = null
            runCatching {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
            }
        }
    }

    private fun stopAllRecognizers() {
        owwEngine?.stop()
        destroyAndroidSr()
        try {
            voskService?.stop()
            voskService?.shutdown()
        } catch (_: Exception) {}
        voskService = null
        userSpeaking = false
    }

    private fun destroyAndroidSr() {
        try {
            androidSr?.stopListening()
            androidSr?.cancel()
            androidSr?.destroy()
        } catch (_: Exception) {}
        androidSr = null
    }

    private fun speakAndThen(message: String, onDone: () -> Unit) {
        // Hard-lock mic OFF before speaking
        isSpeakingReply = true
        stopAllRecognizers()

        val engine = tts
        if (!ttsReady || engine == null || message.isBlank()) {
            isSpeakingReply = false
            main.postDelayed(onDone, 300L)
            return
        }
        val id = "nova-${SystemClock.elapsedRealtime()}"
        activeSpeechId = id
        afterSpeechAction = onDone
        NovaState.update(mode = ListenMode.SPEAKING, micActive = false)

        val estimatedMs = (message.length * 95L).coerceIn(3500L, 25000L)
        main.postDelayed({
            if (activeSpeechId == id) onTtsFinished()
        }, estimatedMs)

        try {
            val res = engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, id)
            if (res == TextToSpeech.ERROR) onTtsFinished()
        } catch (_: Exception) {
            onTtsFinished()
        }
    }

    private fun onTtsFinished() {
        main.post {
            val next = afterSpeechAction
            afterSpeechAction = null
            activeSpeechId = null
            // 500 ms acoustic cooldown guarantees Nova NEVER hears its own speaker echo
            main.postDelayed({
                isSpeakingReply = false
                next?.invoke()
            }, 500L)
        }
    }

    private fun playFeedbackBeep(high: Boolean) {
        if (!Prefs.soundFeedback(this)) return
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
            tg.startTone(if (high) ToneGenerator.TONE_PROP_BEEP else ToneGenerator.TONE_PROP_NACK, 120)
            main.postDelayed({ runCatching { tg.release() } }, 320L)
        } catch (_: Exception) {}
        try {
            @Suppress("DEPRECATION")
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(if (high) 50 else 30, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun extractVoskText(json: String?, key: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            val raw = JSONObject(json).optString(key, "").trim()
            if (raw == "[unk]") "" else raw.replace("[unk]", "").trim()
        } catch (_: Exception) {
            ""
        }
    }

    // ------------------------------------------------------------------ Notifications

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Nova Active Listener", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RESULT, "Nova Results", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
            }
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listenNow = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_LISTEN_NOW),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopSvc = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP_SERVICE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAgent = PendingIntent.getService(
            this, 4, Intent(this, ListenService::class.java).setAction(ACTION_STOP_AGENT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Nova v6.3")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "Abhi suno", listenNow)
            .addAction(0, "Rok do", stopAgent)
            .addAction(0, "Band karo", stopSvc)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!foregroundStarted) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun showResultNotification(heard: String, reply: String, pkg: String?) {
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        val b = NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Nova: $heard")
            .setContentText(reply)
            .setStyle(NotificationCompat.BigTextStyle().bigText(reply))
            .setAutoCancel(true)
            .setTimeoutAfter(15000)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (launch != null) {
            b.setContentIntent(
                PendingIntent.getActivity(
                    this, 3, launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        getSystemService(NotificationManager::class.java).notify(RESULT_ID, b.build())
    }

    override fun onDestroy() {
        running = false
        inCommandSession = false
        isSpeakingReply = false
        main.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(batteryReceiver) }
        releaseAudioDucking()
        hideOverlayPill()
        stopAllRecognizers()
        runCatching { owwEngine?.release() }
        owwEngine = null
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
        runCatching { voskModel?.close() }
        voskModel = null
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
        foregroundStarted = false
        runCatching { getSystemService(NotificationManager::class.java).cancel(NOTIF_ID) }
        NovaState.update(mode = ListenMode.STOPPED, status = "Band hai", micActive = false, remainingSec = 0)
        super.onDestroy()
    }
}
