package com.nova.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.bluetooth.BluetoothDevice
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.media.ToneGenerator
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.RecognitionListener as AndroidRecListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener as VoskListener
import org.vosk.android.SpeechService
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Nova v7.0 Reliable Background Microphone Foreground Service:
 *
 * - Multi-Phrase Wake Detection:
 *     Single AudioRecord running ONNX (`hey_nova.onnx`) + VAD-gated constrained Vosk
 *     for genuine "Hey Nova", "Hi Nova", and "Okay Nova" detection.
 * - Safe Lifecycle Strategy:
 *     Uses START_STICKY ONLY when Wake is enabled and Privacy Mode is OFF (so OS recreation restores listening),
 *     and START_NOT_STICKY + immediate teardown when Wake is OFF or Privacy Mode is ON.
 * - Microphone Conflict & Permission Protection:
 *     Detects mic permission revocation and external mic conflicts (AudioRecordingCallback), pausing cleanly
 *     and recovering automatically when the mic becomes available again.
 * - Conversational Flow:
 *     Wake phrase -> chime + short voice response ("Yes, I'm listening." / "Ji, sun raha hoon.") ->
 *     automatic speech recognition -> Multi-Agent execution -> strict mic-mute TTS reply ->
 *     follow-up session (15s/30s/40s) -> automatic return to wake listening.
 * - Interruptible TTS:
 *     ACTION_INTERRUPT_AND_LISTEN immediately stops current speech and starts listening.
 */
class ListenService : Service(), VoskListener {

    companion object {
        const val ACTION_LISTEN_NOW = "com.nova.assistant.LISTEN_NOW"
        const val ACTION_INTERRUPT_AND_LISTEN = "com.nova.assistant.INTERRUPT_AND_LISTEN"
        const val ACTION_STOP_SERVICE = "com.nova.assistant.STOP"
        const val ACTION_STOP_AGENT = "com.nova.assistant.STOP_AGENT"
        const val ACTION_SPEAK_ALERT = "com.nova.assistant.SPEAK_ALERT"
        const val ACTION_APPLY_SETTINGS = "com.nova.assistant.APPLY_SETTINGS"

        const val CH_LISTEN = "nova_listen"
        const val CH_RESULT = "nova_result"
        const val NOTIF_ID = 1
        const val RESULT_ID = 2

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var wakeEngine: OpenWakeWordEngine? = null
    private var voskModel: Model? = null
    private var voskCommandService: SpeechService? = null
    private var bargeInService: SpeechService? = null
    private var headsetReceiver: HeadsetAutoReceiver? = null
    private var androidSr: SpeechRecognizer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var foregroundStarted = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var focusRequest: AudioFocusRequest? = null
    private var pillView: View? = null
    private var pillText: TextView? = null

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    @Volatile private var inCommandSession = false
    @Volatile private var userSpeaking = false
    @Volatile private var isProcessingCommand = false
    @Volatile private var isSpeakingReply = false
    @Volatile private var micConflictPaused = false
    @Volatile private var activeSpeechId: String? = null
    @Volatile private var afterSpeechAction: (() -> Unit)? = null

    private var sessionEndAt = 0L
    private var lastWakeTriggerAt = 0L
    @Volatile private var wakeArmedAt = 0L
    private var errorRetryCount = 0
    private var lowBatteryAlerted = false

    private val sessionTickRunnable = object : Runnable {
        override fun run() {
            if (!running || !inCommandSession) return
            val leftMs = sessionEndAt - SystemClock.elapsedRealtime()
            if (leftMs <= 0L) {
                if (userSpeaking || isProcessingCommand || isSpeakingReply) {
                    main.postDelayed(this, 600L)
                    return
                }
                endCommandSession(announce = false)
                return
            }
            val sec = ((leftMs + 999L) / 1000L).toInt()
            NovaState.update(remainingSec = sec)
            updateNotification("Listening (${sec}s) — Speak or say 'Stop'")
            main.postDelayed(this, 1000L)
        }
    }

    // Background Wake Health Watchdog: guarantees wake mic auto-recovers if OS silently stalls or pauses it
    private val wakeWatchdogRunnable = object : Runnable {
        override fun run() {
            if (!running || !Prefs.wake(this@ListenService) || Prefs.privacyPaused(this@ListenService)) return
            if (!inCommandSession && !isProcessingCommand && !isSpeakingReply) {
                acquireWakeLock()
                val eng = wakeEngine
                if (eng != null && (eng.isNeuralReady() || eng.isMultiPhraseReady())) {
                    if (micConflictPaused || !eng.isActivelyRecording()) {
                        micConflictPaused = false
                        enterWakeMode()
                    }
                }
            }
            main.postDelayed(this, 15_000L)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!Prefs.lowBatteryAlert(context)) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
            if (charging || pct > 20) {
                lowBatteryAlerted = false
            } else if (running && Prefs.wake(context) && !Prefs.privacyPaused(context) &&
                pct <= 15 && !lowBatteryAlerted && !inCommandSession && !isProcessingCommand && !isSpeakingReply
            ) {
                lowBatteryAlerted = true
                speakAndThen("Battery low alert: phone battery sirf $pct percent bachi hai.") {
                    if (running) enterWakeMode()
                }
            }
        }
    }

    // Detects external microphone usage (calls, camera, voice notes) to avoid mic conflict crash-loops
    private val recordingCallback = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
            if (!running || configs == null) return
            val myUid = android.os.Process.myUid()
            val externalActive = if (Build.VERSION.SDK_INT >= 29) {
                configs.any { cfg -> cfg.isClientSilenced }
            } else false

            if (externalActive && !micConflictPaused && !inCommandSession) {
                micConflictPaused = true
                wakeEngine?.stop()
                recordFailure("Microphone busy by another app (paused safely)")
                NovaState.update(
                    mode = ListenMode.MIC_CONFLICT,
                    status = "Mic busy by another app — will auto-resume when free",
                    micActive = false
                )
                updateNotification("Mic busy — auto-checking to resume")
                // Safety probe in case OEM OS does not emit a follow-up AudioRecordingCallback
                main.postDelayed({
                    if (running && micConflictPaused && Prefs.wake(this@ListenService) &&
                        !Prefs.privacyPaused(this@ListenService) && !inCommandSession
                    ) {
                        micConflictPaused = false
                        enterWakeMode()
                    }
                }, 4500L)
            } else if (!externalActive && micConflictPaused) {
                micConflictPaused = false
                main.postDelayed({
                    if (running && Prefs.wake(this@ListenService) && !Prefs.privacyPaused(this@ListenService) && !inCommandSession) {
                        enterWakeMode()
                    }
                }, 1200L)
            }
            @Suppress("UNUSED_VARIABLE")
            val ignored = myUid
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        index = AppIndex(this)
        parser = CommandParser(index)
        index.refresh(force = true)

        initTts()
        runCatching { registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }
        NovaState.headsetConnected = HeadsetAutoReceiver.isAudioHeadsetConnected(this)
        headsetReceiver = HeadsetAutoReceiver().also { hr ->
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_HEADSET_PLUG)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            }
            runCatching { registerReceiver(hr, f) }
        }
        runCatching {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.registerAudioRecordingCallback(recordingCallback, main)
        }
    }

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                applyTtsSettings()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) {
                        if (id == activeSpeechId) onTtsFinished()
                    }
                    override fun onDone(id: String?) {
                        if (id == activeSpeechId) onTtsFinished()
                    }
                })
            }
        }
    }

    private fun applyTtsSettings() {
        val engine = tts ?: return
        val langPref = Prefs.replyLanguage(this)
        engine.language = if (langPref == "english") Locale("en", "IN") else Locale("hi", "IN")
        engine.setSpeechRate(Prefs.ttsSpeed(this))
        val savedVoice = Prefs.ttsVoice(this)
        if (savedVoice.isNotEmpty()) {
            val match = engine.voices?.firstOrNull { it.name == savedVoice }
            if (match != null) engine.voice = match
        }
        wakeEngine?.setThreshold(Prefs.wakeThreshold(this))
        wakeEngine?.setPowerMode(Prefs.powerMode(this))
        wakeEngine?.setStrictVerify(Prefs.strictWakeVerify(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        // 1) Explicit user stop
        if (action == ACTION_STOP_SERVICE) {
            Prefs.setWake(this, false)
            recordFailure("Stopped by user")
            shutdownImmediately()
            return START_NOT_STICKY
        }

        // 2) Never run if Privacy Mode is ON, or Wake is OFF (except explicit one-shot manual listen)
        val allowManual = action == ACTION_LISTEN_NOW || action == ACTION_INTERRUPT_AND_LISTEN
        if (Prefs.privacyPaused(this) || (!Prefs.wake(this) && !allowManual)) {
            shutdownImmediately()
            return START_NOT_STICKY
        }

        // 3) Verify microphone permission hasn't been revoked
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Prefs.setWake(this, false)
            recordFailure("Microphone permission revoked — allow Mic in App Settings")
            shutdownImmediately()
            return START_NOT_STICKY
        }

        when (action) {
            ACTION_STOP_AGENT -> {
                AiRouter.cancelActiveRequest()
                MacroStore.cancelActiveWorkflow()
                NovaOrchestrator.clearActiveTask()
                NovaAccessibility.instance?.stopAgent()
                tts?.stop()
                isSpeakingReply = false
                if (inCommandSession) endCommandSession(announce = false)
                return stickyMode()
            }
            ACTION_APPLY_SETTINGS -> {
                applyTtsSettings()
                return stickyMode()
            }
            ACTION_SPEAK_ALERT -> {
                val msg = intent.getStringExtra("message").orEmpty()
                if (msg.isNotBlank() && running) {
                    stopAllRecognizers()
                    speakAndThen(msg) {
                        if (running && Prefs.wake(this) && !Prefs.privacyPaused(this)) {
                            if (inCommandSession) startCommandRecognizer() else enterWakeMode()
                        }
                    }
                }
                return stickyMode()
            }
        }

        if (!foregroundStarted) {
            try {
                ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification("Nova v11.0 initializing wake engines..."),
                    if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                )
                foregroundStarted = true
            } catch (e: Exception) {
                recordFailure("Foreground mic service blocked by Android: ${e.message}")
                shutdownImmediately()
                return START_NOT_STICKY
            }
            running = true
            NovaState.serviceStartedAtMs = System.currentTimeMillis()
            NovaState.batteryAtStartPct = PhoneInfoHelper.battery(this).percent
            Prefs.setLastServiceFailure(this, "")
            NovaState.lastErrorReason = ""
            acquireWakeLock()
            loadEnginesAndStart()
        }

        if (action == ACTION_INTERRUPT_AND_LISTEN) {
            main.post { interruptAndListenNow() }
        } else if (action == ACTION_LISTEN_NOW) {
            main.post { activateCommandSession(initialCommand = null, spokenAck = false) }
        }

        return stickyMode()
    }

    /** START_STICKY ONLY when the user wants background wake active; START_NOT_STICKY otherwise. */
    private fun stickyMode(): Int =
        if (Prefs.wake(this) && !Prefs.privacyPaused(this)) START_STICKY else START_NOT_STICKY

    private fun recordFailure(reason: String) {
        NovaState.lastErrorReason = reason
        Prefs.setLastServiceFailure(this, reason)
    }

    private fun shutdownImmediately() {
        running = false
        inCommandSession = false
        isProcessingCommand = false
        isSpeakingReply = false
        micConflictPaused = false
        afterSpeechAction = null
        activeSpeechId = null
        main.removeCallbacksAndMessages(null)
        releaseAudioDucking()
        hideOverlayPill()
        stopAllRecognizers()
        runCatching { tts?.stop() }
        runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
        foregroundStarted = false
        runCatching { getSystemService(NotificationManager::class.java).cancel(NOTIF_ID) }
        NovaState.update(mode = ListenMode.STOPPED, status = "Stopped", micActive = false, remainingSec = 0)
        stopSelf()
    }

    private fun interruptAndListenNow() {
        tts?.stop()
        isSpeakingReply = false
        afterSpeechAction = null
        activeSpeechId = null
        activateCommandSession(initialCommand = null, spokenAck = false)
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:listen").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun loadEnginesAndStart() {
        NovaState.update(mode = ListenMode.LOADING_MODEL, status = "Loading Hey / Hi / Hello / Okay Nova engines...", micActive = false)
        thread {
            val engine = OpenWakeWordEngine(
                context = this,
                initialThreshold = Prefs.wakeThreshold(this),
                onWakeDetected = { phrase, _ ->
                    main.post {
                        if (running && !inCommandSession && !isSpeakingReply && !isProcessingCommand &&
                            SystemClock.elapsedRealtime() - wakeArmedAt > 1200L
                        ) {
                            NovaState.lastWakePhrase = phrase
                            NovaState.wakeTriggerCount++
                            activateCommandSession(initialCommand = null, spokenAck = Prefs.wakeVoiceReply(this))
                        }
                    }
                },
                onError = { err ->
                    main.post {
                        if (running && !inCommandSession) {
                            scheduleWakeRecovery(err)
                        }
                    }
                }
            )
            engine.setPowerMode(Prefs.powerMode(this))
            engine.setStrictVerify(Prefs.strictWakeVerify(this))

            // 1) Initialize Neural ONNX ("Hey Nova")
            val neuralOk = engine.initNeural()
            if (!running || (!Prefs.wake(this) && !inCommandSession) || Prefs.privacyPaused(this)) {
                runCatching { engine.release() }
                return@thread
            }

            wakeEngine = engine

            // 2) If Vosk Indian-English model is already cached locally, attach immediately for Hey/Hi/Okay Nova
            if (ModelFiles.isReady(this)) {
                runCatching {
                    val dir = ModelFiles.ensure(this)
                    val m = Model(dir.absolutePath)
                    voskModel = m
                    engine.attachVoskModel(m)
                }
            }

            if (neuralOk || voskModel != null) {
                main.post {
                    if (running && (Prefs.wake(this) || inCommandSession) && !Prefs.privacyPaused(this)) {
                        if (!inCommandSession) enterWakeMode()
                    } else {
                        shutdownImmediately()
                    }
                }
            }

            // 3) Ensure multi-phrase Vosk model is downloaded once in background so Hi Nova & Okay Nova always work too
            if (voskModel == null && PhoneInfoHelper.isOnline(this)) {
                try {
                    val dir = ModelFiles.ensure(this) { pct ->
                        if (!neuralOk) {
                            NovaState.update(
                                mode = ListenMode.LOADING_MODEL,
                                status = "Downloading multi-phrase voice model ($pct%)...",
                                modelProgress = pct
                            )
                            updateNotification("Downloading voice model ($pct%)...")
                        }
                    }
                    if (!running) return@thread
                    val m = Model(dir.absolutePath)
                    voskModel = m
                    engine.attachVoskModel(m)
                    NovaState.update(modelProgress = -1)
                    if (!neuralOk) {
                        main.post {
                            if (running && !inCommandSession && Prefs.wake(this) && !Prefs.privacyPaused(this)) {
                                enterWakeMode()
                            }
                        }
                    } else {
                        main.post {
                            if (running && !inCommandSession) {
                                NovaState.update(status = "Wake Ready — Say \"Hey Nova\", \"Hi Nova\", \"Hello Nova\" or \"Okay Nova\"")
                                updateNotification("Listening — Hey / Hi / Hello / Okay Nova")
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (!neuralOk) {
                        recordFailure("Voice model download failed: ${e.message}")
                        main.post {
                            NovaState.update(
                                mode = ListenMode.ERROR_RECOVERING,
                                status = "Model error: ${e.message}",
                                micActive = false,
                                modelProgress = -1
                            )
                        }
                    }
                }
            } else if (!neuralOk && voskModel == null) {
                recordFailure("Offline and voice models not cached yet — connect internet once")
                main.post {
                    NovaState.update(
                        mode = ListenMode.STOPPED,
                        status = "Connect internet once to finish downloading wake model",
                        micActive = false
                    )
                }
            }
        }
    }

    // ------------------------------------------------------------------ Stage 1: Wake Word Mode

    private fun enterWakeMode() {
        if (!running || !Prefs.wake(this) || Prefs.privacyPaused(this)) {
            shutdownImmediately()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Prefs.setWake(this, false)
            recordFailure("Microphone permission revoked")
            shutdownImmediately()
            return
        }

        stopAllRecognizers()
        releaseAudioDucking()
        hideOverlayPill()
        inCommandSession = false
        userSpeaking = false
        isProcessingCommand = false
        isSpeakingReply = false
        micConflictPaused = false
        sessionEndAt = 0L
        main.removeCallbacks(sessionTickRunnable)
        ActionExecutor.clearPending()

        acquireWakeLock()
        main.removeCallbacks(wakeWatchdogRunnable)
        main.postDelayed(wakeWatchdogRunnable, 15_000L)
        wakeArmedAt = SystemClock.elapsedRealtime()
        val eng = wakeEngine
        if (eng != null && (eng.isNeuralReady() || eng.isMultiPhraseReady())) {
            val started = eng.start()
            if (started) {
                errorRetryCount = 0
                val phrases = if (eng.isMultiPhraseReady()) "\"Hey Nova\", \"Hi Nova\", \"Hello Nova\" or \"Okay Nova\"" else "\"Hey Nova\""
                NovaState.update(
                    mode = ListenMode.WAKE_LISTENING,
                    status = "Wake Ready — Say $phrases",
                    micActive = true,
                    remainingSec = 0
                )
                updateNotification("Wake Ready — Say $phrases")
            } else {
                scheduleWakeRecovery("Microphone start failed")
            }
        } else {
            NovaState.update(mode = ListenMode.LOADING_MODEL, status = "Preparing wake engines...", micActive = false)
        }
    }

    // ---- Vosk Listener (Offline Command Fallback) ----

    override fun onPartialResult(hypothesis: String?) {
        if (!running || isProcessingCommand || isSpeakingReply) return
        val partial = extractVoskText(hypothesis, "partial")
        if (partial.isNotEmpty() && WakeStopDetector.isStopCommand(partial)) {
            handlePriorityStop()
        }
    }

    override fun onResult(hypothesis: String?) {
        if (!running || isProcessingCommand || isSpeakingReply) return
        val text = extractVoskText(hypothesis, "text")
        if (text.isNotEmpty()) {
            main.post { handleCommandTranscript(text) }
        }
    }

    override fun onFinalResult(hypothesis: String?) = onResult(hypothesis)

    override fun onError(exception: Exception?) {
        scheduleWakeRecovery("Offline voice error: ${exception?.message}")
    }

    override fun onTimeout() {
        if (running && !inCommandSession) main.post { enterWakeMode() }
    }

    private fun scheduleWakeRecovery(reason: String) {
        if (!running || !Prefs.wake(this) || Prefs.privacyPaused(this)) {
            shutdownImmediately()
            return
        }
        stopAllRecognizers()
        errorRetryCount++
        recordFailure(reason)
        val delayMs = (1500L * errorRetryCount).coerceAtMost(12_000L)
        NovaState.update(
            mode = ListenMode.ERROR_RECOVERING,
            status = "$reason (auto-recovering in ${delayMs / 1000}s...)",
            micActive = false,
            lastErrorReason = reason
        )
        updateNotification("Recovering mic...")
        main.postDelayed({
            if (running && Prefs.wake(this) && !Prefs.privacyPaused(this)) {
                if (inCommandSession) startCommandRecognizer() else enterWakeMode()
            }
        }, delayMs)
    }

    // ------------------------------------------------------------------ Stage 2: Command Mode

    private fun activateCommandSession(initialCommand: String?, spokenAck: Boolean = false) {
        if (!running) return
        stopAllRecognizers()
        inCommandSession = true
        isProcessingCommand = false
        isSpeakingReply = false
        requestAudioDucking()
        resetSessionTimer()
        playFeedbackBeep(high = true)
        showOverlayPill("Nova is listening...")

        if (!initialCommand.isNullOrBlank()) {
            handleCommandTranscript(initialCommand)
            return
        }

        if (spokenAck && ttsReady) {
            val ack = if (Prefs.replyLanguage(this) == "english") "Yes, I'm listening." else "Ji, sun raha hoon."
            updateOverlayPill(ack)
            speakAndThen(ack, cooldownMs = 260L) {
                if (running && inCommandSession && !isProcessingCommand && !isSpeakingReply) {
                    startCommandRecognizer()
                }
            }
        } else {
            main.postDelayed({
                if (running && inCommandSession && !isProcessingCommand && !isSpeakingReply) {
                    startCommandRecognizer()
                }
            }, 140L)
        }
    }

    private fun resetSessionTimer() {
        val dur = Prefs.sessionDurationMs(this)
        sessionEndAt = SystemClock.elapsedRealtime() + dur
        main.removeCallbacks(sessionTickRunnable)
        NovaState.update(remainingSec = (dur / 1000L).toInt())
        main.post(sessionTickRunnable)
    }

    private fun endCommandSession(announce: Boolean, reason: String = "Listening band.") {
        inCommandSession = false
        userSpeaking = false
        isProcessingCommand = false
        sessionEndAt = 0L
        main.removeCallbacks(sessionTickRunnable)
        ActionExecutor.clearPending()
        stopAllRecognizers()
        playFeedbackBeep(high = false)

        if (announce) {
            updateOverlayPill(reason)
            speakAndThen(reason) {
                if (running && Prefs.wake(this) && !Prefs.privacyPaused(this)) enterWakeMode()
                else shutdownImmediately()
            }
        } else {
            if (Prefs.wake(this) && !Prefs.privacyPaused(this)) enterWakeMode()
            else shutdownImmediately()
        }
    }

    private fun handlePriorityStop() {
        AiRouter.cancelActiveRequest()
        MacroStore.cancelActiveWorkflow()
        NovaOrchestrator.clearActiveTask()
        NovaAccessibility.instance?.stopAgent()
        VoiceFlashcardManager.stopSession()
        InterviewVivaManager.stopSession()
        tts?.stop()
        isSpeakingReply = false
        afterSpeechAction = null
        activeSpeechId = null
        NovaState.update(heard = "Stop", reply = "Listening stopped. Wake mode active.")
        endCommandSession(announce = true, reason = "Theek hai, sunna band.")
    }

    private fun startCommandRecognizer() {
        if (!running || !inCommandSession || isProcessingCommand || isSpeakingReply) return
        stopAllRecognizers()

        val canUseAndroidSr = SpeechRecognizer.isRecognitionAvailable(this) &&
            (PhoneInfoHelper.isOnline(this) || Build.VERSION.SDK_INT >= 31)

        if (canUseAndroidSr) {
            startAndroidSpeechRecognizer()
        } else {
            startOfflineVoskCommandFallback()
        }
    }

    private fun startAndroidSpeechRecognizer() {
        try {
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            androidSr = sr
            sr.setRecognitionListener(object : AndroidRecListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    userSpeaking = false
                    updateOverlayPill("Listening...")
                    NovaState.update(
                        mode = ListenMode.COMMAND_LISTENING,
                        status = "Listening for your command...",
                        micActive = true
                    )
                }

                override fun onBeginningOfSpeech() { userSpeaking = true }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { userSpeaking = false }

                override fun onPartialResults(partialResults: Bundle?) {
                    if (isSpeakingReply || isProcessingCommand) return
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) {
                        val h = HinglishConverter.toHinglish(partial)
                        updateOverlayPill(h)
                        if (WakeStopDetector.isStopCommand(h)) handlePriorityStop()
                    }
                }

                override fun onResults(results: Bundle?) {
                    userSpeaking = false
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    destroyAndroidSr()
                    if (isSpeakingReply || isProcessingCommand) return
                    if (spoken.isBlank()) continueSessionOrSleep()
                    else handleCommandTranscript(spoken)
                }

                override fun onError(error: Int) {
                    userSpeaking = false
                    destroyAndroidSr()
                    if (!running || !inCommandSession || isSpeakingReply) return
                    when (error) {
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER,
                        SpeechRecognizer.ERROR_CLIENT,
                        SpeechRecognizer.ERROR_AUDIO,
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> startOfflineVoskCommandFallback()
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> continueSessionOrSleep()
                        else -> main.postDelayed({ continueSessionOrSleep() }, 400L)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2200L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000L)
            }
            sr.startListening(intent)
        } catch (_: Exception) {
            destroyAndroidSr()
            startOfflineVoskCommandFallback()
        }
    }

    private fun startOfflineVoskCommandFallback() {
        val m = voskModel ?: run {
            updateOverlayPill("Offline — voice model not installed yet.")
            endCommandSession(announce = false)
            return
        }
        try {
            val rec = Recognizer(m, 16000.0f)
            val svc = SpeechService(rec, 16000.0f)
            svc.startListening(this)
            voskCommandService = svc
            updateOverlayPill("Listening offline...")
            NovaState.update(
                mode = ListenMode.COMMAND_LISTENING,
                status = "Listening (Offline Mode)...",
                micActive = true
            )
        } catch (e: Exception) {
            scheduleWakeRecovery("Offline mic error: ${e.message}")
        }
    }

    private fun continueSessionOrSleep() {
        if (!running || !inCommandSession || isSpeakingReply || isProcessingCommand) return
        if (SystemClock.elapsedRealtime() >= sessionEndAt) {
            endCommandSession(announce = false)
        } else {
            main.postDelayed({
                if (running && inCommandSession && !isProcessingCommand && !isSpeakingReply) {
                    startCommandRecognizer()
                }
            }, 250L)
        }
    }

    // ------------------------------------------------------------------ Command Dispatch

    private fun handleCommandTranscript(rawTranscript: String) {
        if (!running || isSpeakingReply) return
        val hinglish = HinglishConverter.toHinglish(rawTranscript)
        if (hinglish.isBlank()) {
            continueSessionOrSleep()
            return
        }

        if (WakeStopDetector.isStopCommand(hinglish)) {
            handlePriorityStop()
            return
        }

        val stripped = WakeStopDetector.stripWake(hinglish, isPartial = false)
        val effectiveText = when {
            stripped != null && stripped.isBlank() -> {
                resetSessionTimer()
                continueSessionOrSleep()
                return
            }
            stripped != null -> stripped
            else -> hinglish
        }

        stopAllRecognizers()
        isProcessingCommand = true
        updateOverlayPill("Thinking: $effectiveText")
        NovaState.update(mode = ListenMode.PROCESSING, status = "Processing: $effectiveText", heard = effectiveText, micActive = false)

        if (ActionExecutor.hasActivePending()) {
            ActionExecutor.handleConfirmationInput(effectiveText) { confirmReply ->
                if (confirmReply.isNotEmpty()) {
                    finishCommandReply(effectiveText, confirmReply, appPkg = null)
                } else {
                    ActionExecutor.clearPending()
                    dispatchToResolver(effectiveText)
                }
            }
            return
        }

        if (VoiceFlashcardManager.active) {
            val fcReply = VoiceFlashcardManager.handleAnswer(effectiveText)
            if (fcReply.isNotEmpty()) {
                finishCommandReply(effectiveText, fcReply, appPkg = null)
                return
            }
        }

        if (InterviewVivaManager.active) {
            thread {
                val vivaReply = InterviewVivaManager.handleAnswer(this, effectiveText)
                main.post {
                    if (vivaReply.isNotEmpty()) finishCommandReply(effectiveText, vivaReply, appPkg = null)
                    else dispatchToResolver(effectiveText)
                }
            }
            return
        }

        if (NovaOrchestrator.hasActiveTask()) {
            thread {
                val taskReply = NovaOrchestrator.tryContinueActiveTask(this, effectiveText)
                main.post {
                    if (taskReply != null) finishCommandReply(effectiveText, taskReply, appPkg = null)
                    else dispatchToResolver(effectiveText)
                }
            }
            return
        }

        dispatchToResolver(effectiveText)
    }

    private fun dispatchToResolver(text: String) {
        index.refresh()
        val matchedMacro = MacroStore.findMatch(this, text)
        if (matchedMacro != null) {
            ActionExecutor.runWorkflowAsync(this, index, parser, matchedMacro.trigger, matchedMacro.actions, text) { reply ->
                finishCommandReply(text, reply, appPkg = null)
            }
            return
        }
        val chained = UltimatePowerHelper.splitChainedCommands(text)
        if (chained.size >= 2) {
            ActionExecutor.runChainedAsync(this, index, parser, chained, text) { reply ->
                finishCommandReply(text, reply, appPkg = null)
            }
            return
        }
        Resolver.resolve(this, index, parser, text) { cmd ->
            // Handle voice-initiated privacy pause cleanly: speak confirmation BEFORE shutting down
            if (cmd.kind == Kind.PRIVACY_PAUSE && cmd.query != "off") {
                isProcessingCommand = false
                val msg = "Privacy mode ON. Wake word, mic aur history sab pause kar diye hain."
                NovaState.update(mode = ListenMode.SPEAKING, status = msg, heard = text, reply = msg, micActive = false)
                speakAndThen(msg) {
                    ActionExecutor.pauseEverything(this)
                }
                return@resolve
            }

            ActionExecutor.runAsync(this, index, cmd) { reply ->
                finishCommandReply(cmd.heard.ifEmpty { text }, reply, appPkg = cmd.app?.pkg)
            }
        }
    }

    private fun finishCommandReply(heard: String, reply: String, appPkg: String?) {
        isProcessingCommand = false
        if (inCommandSession) resetSessionTimer()

        updateOverlayPill(reply.take(120))
        NovaState.update(
            mode = ListenMode.SPEAKING,
            status = reply,
            heard = heard,
            reply = reply,
            micActive = false
        )
        showResultNotification(heard, reply, appPkg)
        NovaAppWidgetProvider.requestUpdate(this)

        // Strict Mic-Mute Reply + 500 ms acoustic cooldown before reopening mic
        speakAndThen(reply) {
            if (!running) return@speakAndThen
            if (inCommandSession) continueSessionOrSleep()
            else if (Prefs.wake(this) && !Prefs.privacyPaused(this)) enterWakeMode()
            else shutdownImmediately()
        }
    }

    // ------------------------------------------------------------------ Audio Ducking, Overlay & Strict Mic-Mute TTS

    private fun requestAudioDucking() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .build()
            focusRequest = req
            am.requestAudioFocus(req)
        } catch (_: Exception) {}
    }

    private fun releaseAudioDucking() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
            focusRequest = null
        } catch (_: Exception) {}
    }

    private fun showOverlayPill(text: String) {
        if (!Settings.canDrawOverlays(this)) return
        main.post {
            if (pillView != null) {
                pillText?.text = text
                return@post
            }
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val container = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(42, 22, 42, 22)
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#EB0A0A0E"))
                        cornerRadius = 64f
                        setStroke(2, Color.parseColor("#C8F63A"))
                    }
                }
                val dot = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(20, 20).apply { marginEnd = 18 }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.parseColor("#C8F63A"))
                    }
                }
                val tv = TextView(this).apply {
                    this.text = text
                    setTextColor(Color.WHITE)
                    textSize = 14f
                    maxLines = 2
                }
                container.addView(dot)
                container.addView(tv)

                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = 88
                }
                wm.addView(container, lp)
                pillView = container
                pillText = tv
            } catch (_: Exception) {
                pillView = null
                pillText = null
            }
        }
    }

    private fun updateOverlayPill(text: String) {
        main.post { if (pillView != null) pillText?.text = text }
    }

    private fun hideOverlayPill() {
        main.post {
            val v = pillView ?: return@post
            pillView = null
            pillText = null
            runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) }
        }
    }

    private fun stopAllRecognizers() {
        wakeEngine?.stop()
        destroyAndroidSr()
        try {
            voskCommandService?.stop()
            voskCommandService?.shutdown()
        } catch (_: Exception) {}
        voskCommandService = null
        stopBargeInListener()
        userSpeaking = false
    }

    private fun destroyAndroidSr() {
        try {
            androidSr?.stopListening()
            androidSr?.cancel()
            androidSr?.destroy()
        } catch (_: Exception) {}
        androidSr = null
    }

    private var currentCooldownMs = 500L

    private fun speakAndThen(message: String, cooldownMs: Long = 500L, onDone: () -> Unit) {
        isSpeakingReply = true
        currentCooldownMs = cooldownMs
        stopAllRecognizers()

        val engine = tts
        if (!ttsReady || engine == null || message.isBlank()) {
            isSpeakingReply = false
            main.postDelayed(onDone, 250L)
            return
        }
        val id = "nova-${SystemClock.elapsedRealtime()}"
        activeSpeechId = id
        afterSpeechAction = onDone
        NovaState.update(mode = ListenMode.SPEAKING, micActive = false)

        val estimatedMs = (message.length * 95L).coerceIn(3000L, 60_000L)
        main.postDelayed({ if (activeSpeechId == id) onTtsFinished() }, estimatedMs)

        try {
            val res = engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, id)
            if (res == TextToSpeech.ERROR) {
                onTtsFinished()
            } else if (message.length >= 65 && Prefs.bargeInEnabled(this) && HeadsetAutoReceiver.isAudioHeadsetConnected(this)) {
                // Echo-safe Hands-Free Barge-In: only while earbuds/headset are connected!
                startBargeInListener()
            }
        } catch (_: Exception) {
            onTtsFinished()
        }
    }

    private fun startBargeInListener() {
        val m = voskModel ?: return
        stopBargeInListener()
        try {
            val grammar = "[\"stop\", \"ruko\", \"skip\", \"bas\", \"chup\", \"cancel\", \"nova\", \"[unk]\"]"
            val rec = Recognizer(m, 16000.0f, grammar)
            val svc = SpeechService(rec, 16000.0f)
            svc.startListening(object : VoskListener {
                override fun onPartialResult(hypothesis: String?) = checkBargeIn(extractVoskText(hypothesis, "partial"))
                override fun onResult(hypothesis: String?) = checkBargeIn(extractVoskText(hypothesis, "text"))
                override fun onFinalResult(hypothesis: String?) = checkBargeIn(extractVoskText(hypothesis, "text"))
                override fun onError(exception: Exception?) {}
                override fun onTimeout() {}
            })
            bargeInService = svc
        } catch (_: Exception) {
            stopBargeInListener()
        }
    }

    private fun checkBargeIn(spoken: String) {
        if (!isSpeakingReply || spoken.isBlank()) return
        val w = spoken.lowercase(Locale.ROOT)
        if (w.contains("stop") || w.contains("ruko") || w.contains("skip") || w.contains("bas") || w.contains("chup")) {
            main.post {
                if (isSpeakingReply) {
                    stopBargeInListener()
                    interruptAndListenNow()
                }
            }
        }
    }

    private fun stopBargeInListener() {
        try {
            bargeInService?.stop()
            bargeInService?.shutdown()
        } catch (_: Exception) {}
        bargeInService = null
    }

    private fun onTtsFinished() {
        main.post {
            stopBargeInListener()
            val next = afterSpeechAction
            afterSpeechAction = null
            activeSpeechId = null
            main.postDelayed({
                isSpeakingReply = false
                next?.invoke()
            }, currentCooldownMs)
        }
    }

    private fun playFeedbackBeep(high: Boolean) {
        if (!Prefs.soundFeedback(this)) return
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            tg.startTone(if (high) ToneGenerator.TONE_PROP_BEEP else ToneGenerator.TONE_PROP_NACK, 110)
            main.postDelayed({ runCatching { tg.release() } }, 300L)
        } catch (_: Exception) {}
        try {
            @Suppress("DEPRECATION")
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(if (high) 45 else 25, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun extractVoskText(json: String?, key: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            val raw = JSONObject(json).optString(key, "").trim()
            if (raw == "[unk]") "" else raw.replace("[unk]", "").trim()
        } catch (_: Exception) { "" }
    }

    // ------------------------------------------------------------------ Notifications

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Nova Active Listener", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RESULT, "Nova Results", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
            }
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listenNow = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_INTERRUPT_AND_LISTEN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopSvc = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP_SERVICE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAgent = PendingIntent.getService(
            this, 4, Intent(this, ListenService::class.java).setAction(ACTION_STOP_AGENT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Nova v11.0 Pro")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "Listen Now", listenNow)
            .addAction(0, "Stop Speech", stopAgent)
            .addAction(0, "Turn Off", stopSvc)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!foregroundStarted) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun showResultNotification(heard: String, reply: String, pkg: String?) {
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        val b = NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Nova: $heard")
            .setContentText(reply)
            .setStyle(NotificationCompat.BigTextStyle().bigText(reply))
            .setAutoCancel(true)
            .setTimeoutAfter(15000)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (launch != null) {
            b.setContentIntent(
                PendingIntent.getActivity(
                    this, 3, launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        getSystemService(NotificationManager::class.java).notify(RESULT_ID, b.build())
    }

    override fun onDestroy() {
        running = false
        inCommandSession = false
        isSpeakingReply = false
        micConflictPaused = false
        main.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(batteryReceiver) }
        headsetReceiver?.let { runCatching { unregisterReceiver(it) } }
        headsetReceiver = null
        runCatching {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .unregisterAudioRecordingCallback(recordingCallback)
        }
        releaseAudioDucking()
        hideOverlayPill()
        stopAllRecognizers()
        runCatching { wakeEngine?.release() }
        wakeEngine = null
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
        runCatching { voskModel?.close() }
        voskModel = null
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
        foregroundStarted = false
        runCatching { getSystemService(NotificationManager::class.java).cancel(NOTIF_ID) }
        NovaState.update(mode = ListenMode.STOPPED, status = "Stopped", micActive = false, remainingSec = 0)
        super.onDestroy()
    }
}
