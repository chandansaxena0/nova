package com.nova.assistant

import android.content.Context
import java.util.Locale

enum class ActionStatus {
    COMPLETED,
    FAILED,
    NEEDS_PERMISSION,
    NEEDS_CONFIRMATION,
    UNSUPPORTED
}

data class ActionResult(
    val status: ActionStatus,
    val message: String,
    val agent: AgentType = AgentType.MAIN_ASSISTANT
)

data class ActiveTaskState(
    val kind: String,
    val description: String,
    val awaitingSlot: String = "",
    val createdAtMs: Long = System.currentTimeMillis()
)

object NovaOrchestrator {

    @Volatile
    var activeTask: ActiveTaskState? = null
        private set

    fun clearActiveTask() {
        activeTask = null
    }

    fun hasActiveTask(): Boolean {
        val t = activeTask ?: return false
        if (System.currentTimeMillis() - t.createdAtMs > 180_000L) {
            activeTask = null
            return false
        }
        return true
    }

    fun classifyOutcome(reply: String): ActionStatus {
        val l = reply.lowercase(Locale.ROOT)
        return when {
            l.contains("haan ya nahi") || l.contains("say yes or no") || l.contains("confirm") -> ActionStatus.NEEDS_CONFIRMATION
            l.contains("permission") || l.contains("accessibility") || l.contains("allow ") || l.contains("dnd access") -> ActionStatus.NEEDS_PERMISSION
            l.contains("unsupported") || l.contains("available nahi") || l.contains("hardware nahi mila") -> ActionStatus.UNSUPPORTED
            l.contains("error") || l.contains("failed") || l.contains("nahi ho paya") || l.contains("could not") -> ActionStatus.FAILED
            else -> ActionStatus.COMPLETED
        }
    }

    fun extractTravelDestination(raw: String): String {
        val clean = HinglishConverter.toHinglish(raw).trim()
        val m1 = Regex("(?:travel plan|trip plan|trip|safar|yatra)\\s+(?:for|to|ke liye|ka|ki)\\s+([a-zA-Z][a-zA-Z\\s]{1,30})", RegexOption.IGNORE_CASE).find(clean)
        val m2 = Regex("([a-zA-Z][a-zA-Z\\s]{1,28})\\s+(?:ka|ki|ke liye)\\s+(?:travel plan|trip plan|trip|yatra)", RegexOption.IGNORE_CASE).find(clean)
        val rawDest = (m1?.groupValues?.get(1) ?: m2?.groupValues?.get(1)).orEmpty()
        return rawDest
            .replace(Regex("\\b(banao|prepare|karo|please|mera|my|nova|plan|ready)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun tryContinueActiveTask(context: Context, userInput: String): String? {
        if (!hasActiveTask()) return null
        val t = activeTask ?: return null
        val lower = userInput.lowercase(Locale.ROOT).trim()
        if (lower in setOf("cancel", "chhodo", "rehne do", "stop", "nahi")) {
            clearActiveTask()
            return "Active task cancel kar diya hai."
        }
        if (t.kind == "travel_plan" && t.awaitingSlot == "destination") {
            val dest = userInput.replace(Regex("^(?:for|to|main|hum)?\\s*", RegexOption.IGNORE_CASE), "").trim()
            if (dest.length >= 2) {
                clearActiveTask()
                return executeTravelPlanWorkflow(context, dest, userInput)
            }
        }
        return null
    }

    fun executeTravelPlanWorkflow(context: Context, destinationHint: String, rawRequest: String): String {
        val dest = destinationHint.ifBlank { extractTravelDestination(rawRequest) }
        if (dest.isBlank()) {
            activeTask = ActiveTaskState(
                kind = "travel_plan",
                description = "Prepare travel plan",
                awaitingSlot = "destination"
            )
            return "Zaroor! Aap kis jagah (destination) ka travel plan banana chahte ho? Shehar ya station ka naam bolo."
        }

        NovaState.update(activeAgent = "Orchestrator (Travel + Planner)")
        val sections = ArrayList<String>()
        sections.add("Travel Plan ready for $dest:")

        val checklist = RailRadarHelper.getChecklist(context)
        val pendingItems = checklist.filter { !it.checked }.map { it.name }
        sections.add(
            if (pendingItems.isEmpty()) "1. Packing Checklist: Sabhi items packed hain."
            else "1. Packing Checklist (${pendingItems.size} pending): ${pendingItems.take(5).joinToString(", ")}."
        )

        val trainNo = RailRadarHelper.extractTrainNumber(rawRequest) ?: RailRadarHelper.recentTrainNo()
        if (!trainNo.isNullOrBlank()) {
            val trainNote = if (PhoneInfoHelper.isOnline(context) && Prefs.railRadarKey(context).isNotEmpty()) {
                RailRadarHelper.getLiveTrainStatusVoice(context, "train $trainNo status")
            } else {
                "Remembered Train $trainNo — live status dekhne ke liye bolo 'Train $trainNo status'."
            }
            sections.add("2. Train Info: $trainNote")
        } else {
            sections.add("2. Transport: Train status dekhne ke liye train number bolo, ya '$dest ka rasta dikhao' bolo.")
        }

        val weather = if (PhoneInfoHelper.isOnline(context)) NearbyPlacesHelper.fetchWeather(context)
        else "Offline mode — internet ON hone par live weather check kar sakte ho."
        sections.add("3. Weather: $weather")

        DailyPlannerStore.addTask(context, "Travel prep for $dest (ID, ticket, charger, powerbank)")
        sections.add("4. Planner: '$dest travel prep' task Daily Planner me add kar diya hai.")

        if (PhoneInfoHelper.isOnline(context) && Prefs.hasAi(context)) {
            val tips = GeminiClient.askWithAgentPrompt(
                context,
                "You are Nova's Travel Planner. Give 2 short practical travel tips for visiting $dest in India (no markdown).",
                "Give 2 quick preparation tips for traveling to $dest.",
                keepContext = false,
                maxTokens = 220
            )
            if (tips.isNotBlank() && !tips.contains("error", ignoreCase = true)) {
                sections.add("5. Smart Tips: $tips")
            }
        }

        clearActiveTask()
        return sections.joinToString("\n")
    }
}
