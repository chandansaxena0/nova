package com.nova.assistant

/** Tracks the timestamp of the latest AI conversation turn so short follow-up questions route seamlessly. */
object FollowUpTracker {
    @Volatile
    private var lastChatAtMs: Long = 0L

    fun markActive() {
        lastChatAtMs = System.currentTimeMillis()
    }

    fun reset() {
        lastChatAtMs = 0L
    }

    fun isRecent(windowMs: Long = 5 * 60_000L): Boolean {
        val t = lastChatAtMs
        return t > 0L && (System.currentTimeMillis() - t) <= windowMs
    }
}
