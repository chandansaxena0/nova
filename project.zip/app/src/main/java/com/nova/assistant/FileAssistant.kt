package com.nova.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.Inflater
import java.util.zip.ZipInputStream

object FileAssistant {

    data class DocChunk(val label: String, val text: String)

    data class LoadedDoc(
        val name: String,
        val kind: String,
        val sourceUri: Uri? = null,
        val textContent: String = "",
        val chunks: List<DocChunk> = emptyList(),
        val imageBase64: String = "",
        val imageMime: String = "image/jpeg",
        val pageCount: Int = 1,
        val isScannedPdf: Boolean = false
    )

    @Volatile
    var activeDoc: LoadedDoc? = null
        private set

    fun clearActiveDoc() {
        activeDoc = null
    }

    fun activeDocSummaryLabel(): String {
        val d = activeDoc ?: return "No file loaded. Pick PDF, TXT, MD, DOCX, CSV, XLSX, PPTX, or Image."
        val modeTag = if (d.isScannedPdf) "scanned PDF" else d.kind.uppercase(Locale.ROOT)
        return "Loaded: ${d.name} ($modeTag, ${d.pageCount} page/sheet/slide)"
    }

    fun selectRelevantChunks(chunks: List<DocChunk>, query: String, maxChars: Int = 11_000): String {
        if (chunks.isEmpty()) return ""
        val qWords = query.lowercase(Locale.ROOT)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 3 }
            .toSet()

        val pageReq = Regex("\\b(?:page|slide|sheet)\\s*(\\d{1,3})\\b", RegexOption.IGNORE_CASE).find(query)
            ?.groupValues?.get(1)?.toIntOrNull()

        val ordered = if (pageReq != null) {
            val exact = chunks.filter { it.label.contains(" $pageReq") || it.label.endsWith("$pageReq") }
            (exact + chunks.take(3)).distinctBy { it.label }
        } else if (qWords.isEmpty()) {
            chunks
        } else {
            val scored = chunks.mapIndexed { idx, ch ->
                val lower = ch.text.lowercase(Locale.ROOT)
                val hits = qWords.count { lower.contains(it) }
                Triple(ch, hits, idx)
            }.sortedWith(compareByDescending<Triple<DocChunk, Int, Int>> { it.second }.thenBy { it.third })
            val top = scored.filter { it.second > 0 }.map { it.first }
            (top + chunks.take(2) + chunks.takeLast(1)).distinctBy { it.label }
        }

        val sb = StringBuilder()
        for (ch in ordered) {
            val block = "[${ch.label}]\n${ch.text.trim()}\n\n"
            if (sb.length + block.length > maxChars && sb.isNotEmpty()) break
            sb.append(block)
        }
        return sb.toString().trim()
    }

    fun chunkText(fullText: String, chunkSize: Int = 2200, labelPrefix: String = "Section"): List<DocChunk> {
        val clean = fullText.trim()
        if (clean.isEmpty()) return emptyList()
        if (clean.length <= chunkSize) return listOf(DocChunk("$labelPrefix 1", clean))
        val out = ArrayList<DocChunk>()
        var pos = 0
        var idx = 1
        while (pos < clean.length && idx <= 40) {
            val end = minOf(clean.length, pos + chunkSize)
            out.add(DocChunk("$labelPrefix $idx", clean.substring(pos, end)))
            pos = end
            idx++
        }
        return out
    }

    fun loadAndSummarize(context: Context, uri: Uri): String {
        val name = resolveFileName(context, uri)
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase(Locale.ROOT)
        val lower = name.lowercase(Locale.ROOT)

        val doc: LoadedDoc = try {
            when {
                mime.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") -> {
                    val b64 = readScaledImageBase64(context, uri) ?: return "Image read nahi ho payi."
                    LoadedDoc(name = name, kind = "image", sourceUri = uri, imageBase64 = b64, imageMime = "image/jpeg")
                }
                mime == "application/pdf" || lower.endsWith(".pdf") -> {
                    loadMultiPagePdf(context, uri, name)
                }
                lower.endsWith(".docx") || mime.contains("wordprocessingml") -> {
                    val text = extractDocxText(context, uri)
                    if (text.isBlank()) return "DOCX file me readable text nahi mila (empty ya password-protected ho sakti hai)."
                    val chunks = chunkText(text, 2400, "Part")
                    LoadedDoc(name = name, kind = "docx", sourceUri = uri, textContent = text.take(45_000), chunks = chunks, pageCount = chunks.size)
                }
                lower.endsWith(".xlsx") || mime.contains("spreadsheetml") -> {
                    val sheets = extractXlsxSheets(context, uri)
                    if (sheets.isEmpty()) return "XLSX spreadsheet me readable cells nahi mile."
                    val joined = sheets.joinToString("\n\n") { "[${it.label}]\n${it.text}" }
                    LoadedDoc(name = name, kind = "xlsx", sourceUri = uri, textContent = joined.take(45_000), chunks = sheets, pageCount = sheets.size)
                }
                lower.endsWith(".pptx") || mime.contains("presentationml") -> {
                    val slides = extractPptxSlides(context, uri)
                    if (slides.isEmpty()) return "PPTX presentation me readable slide text nahi mila."
                    val joined = slides.joinToString("\n\n") { "[${it.label}]\n${it.text}" }
                    LoadedDoc(name = name, kind = "pptx", sourceUri = uri, textContent = joined.take(45_000), chunks = slides, pageCount = slides.size)
                }
                lower.endsWith(".csv") || mime.contains("csv") -> {
                    val raw = readPlainTextSafe(context, uri)
                    if (raw.isBlank()) return "CSV file khali hai."
                    val rows = raw.lines().filter { it.isNotBlank() }
                    val summaryHeader = "CSV Table (${rows.size} rows):\n" + raw.take(40_000)
                    val chunks = chunkText(summaryHeader, 2400, "Rows Block")
                    LoadedDoc(name = name, kind = "csv", sourceUri = uri, textContent = summaryHeader, chunks = chunks, pageCount = rows.size)
                }
                lower.endsWith(".md") || lower.endsWith(".markdown") || lower.endsWith(".txt") || mime.startsWith("text/") -> {
                    val text = readPlainTextSafe(context, uri)
                    if (text.isBlank()) return "Text file khali hai ya unreadable hai."
                    val kind = if (lower.endsWith(".md") || lower.endsWith(".markdown")) "md" else "txt"
                    val chunks = chunkText(text, 2400, "Section")
                    LoadedDoc(name = name, kind = kind, sourceUri = uri, textContent = text.take(45_000), chunks = chunks, pageCount = chunks.size)
                }
                else -> {
                    return "Unsupported file format ($name). Supported: PDF, TXT, MD, DOCX, CSV, XLSX, PPTX, JPEG, PNG, WebP."
                }
            }
        } catch (e: SecurityException) {
            return "File encrypted/password-protected ya permission-blocked hai: ${e.message?.take(90)}"
        } catch (e: Exception) {
            return "File read karne me error aaya: ${e.message?.take(110)}"
        }

        activeDoc = doc
        return answerQuestion(context, "Summarize this complete file clearly, extract key points/tables, and mention page/slide references where available.")
    }

    fun answerQuestion(context: Context, userQuestion: String): String {
        val doc = activeDoc
            ?: return "Abhi koi file load nahi hai. Hub tab me 'Pick File' dabakar PDF, DOCX, XLSX, PPTX, CSV, TXT ya Image select karo."

        val requestedPage = Regex("\\bpage\\s*(\\d{1,3})\\b", RegexOption.IGNORE_CASE)
            .find(userQuestion)?.groupValues?.get(1)?.toIntOrNull()

        if (doc.kind == "pdf" && doc.isScannedPdf && requestedPage != null && doc.sourceUri != null) {
            val pageIdx = (requestedPage - 1).coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0))
            val b64 = renderPdfPageBase64(context, doc.sourceUri, pageIdx)
            if (b64 != null && PhoneInfoHelper.isOnline(context) && Prefs.hasAi(context)) {
                val prompt = "Scanned PDF: ${doc.name}, Page ${pageIdx + 1} of ${doc.pageCount}. User request: $userQuestion. Reply clearly citing Page ${pageIdx + 1} (no markdown)."
                return GeminiClient.askWithImageBase64(context, "image/jpeg", b64, prompt)
            }
        }

        if (doc.imageBase64.isNotEmpty() && doc.textContent.isBlank()) {
            if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
                return "${doc.name} load ho gayi hai (${doc.pageCount} page/image). Visual OCR/explanation ke liye internet aur AI API key chahiye."
            }
            val scanNote = if (doc.isScannedPdf && doc.pageCount > 1) {
                " Note: This PDF appears scanned (${doc.pageCount} pages); showing Page 1 preview — say 'page 2 explain karo' to inspect other pages."
            } else ""
            val prompt = "File: ${doc.name} (${doc.kind}, ${doc.pageCount} pages).$scanNote User request: $userQuestion. Extract readable text, diagrams, or tables accurately without markdown symbols."
            return GeminiClient.askWithImageBase64(context, doc.imageMime, doc.imageBase64, prompt)
        }

        val relevant = if (doc.chunks.isNotEmpty()) selectRelevantChunks(doc.chunks, userQuestion) else doc.textContent.take(12_000)

        if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
            val preview = relevant.replace(Regex("\\s+"), " ").trim().take(420)
            return "Offline local extract (${doc.name}, ${doc.pageCount} pages/sections): $preview"
        }

        val sys = "You are Nova's File Agent. Answer strictly using the provided document evidence. Cite page/slide/sheet numbers when available, extract tables cleanly, and honestly say if information is not in the file. Do NOT use markdown stars or hashtags."
        val prompt = "Document: ${doc.name} (${doc.kind.uppercase(Locale.ROOT)}, ${doc.pageCount} pages/items)\nExtracted Evidence:\n$relevant\n\nUser request: $userQuestion"
        return GeminiClient.askWithAgentPrompt(context, sys, prompt, keepContext = true, maxTokens = 850)
    }

    private fun loadMultiPagePdf(context: Context, uri: Uri, name: String): LoadedDoc {
        val rawBytes = context.contentResolver.openInputStream(uri)?.use { stream ->
            val baos = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            var total = 0
            while (true) {
                val n = stream.read(buf)
                if (n <= 0) break
                total += n
                if (total > 12_000_000) break
                baos.write(buf, 0, n)
            }
            baos.toByteArray()
        } ?: throw IllegalStateException("PDF file read nahi ho payi.")

        val headerSample = String(rawBytes, 0, minOf(rawBytes.size, 8192), Charsets.ISO_8859_1)
        if (headerSample.contains("/Encrypt")) {
            throw SecurityException("Password-protected / encrypted PDF support nahi hai.")
        }

        var pageCount = 1
        var firstPageB64 = ""
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
        pfd?.use { fd ->
            PdfRenderer(fd).use { renderer ->
                pageCount = renderer.pageCount.coerceAtLeast(1)
                firstPageB64 = renderPageToBase64(renderer, 0)
            }
        }

        val extractedPages = extractPdfTextHeuristic(rawBytes, pageCount)
        val combinedText = extractedPages.joinToString("\n\n") { "[${it.label}]\n${it.text}" }.trim()

        if (combinedText.length >= 120) {
            return LoadedDoc(
                name = name,
                kind = "pdf",
                sourceUri = uri,
                textContent = combinedText.take(60_000),
                chunks = extractedPages,
                imageBase64 = firstPageB64,
                pageCount = pageCount,
                isScannedPdf = false
            )
        }

        if (firstPageB64.isEmpty()) throw IllegalStateException("PDF ka content unreadable ya corrupt hai.")
        return LoadedDoc(
            name = name,
            kind = "pdf",
            sourceUri = uri,
            textContent = "",
            chunks = emptyList(),
            imageBase64 = firstPageB64,
            imageMime = "image/jpeg",
            pageCount = pageCount,
            isScannedPdf = true
        )
    }

    private fun renderPdfPageBase64(context: Context, uri: Uri, pageIndex: Int): String? = try {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { fd ->
            PdfRenderer(fd).use { renderer ->
                if (pageIndex in 0 until renderer.pageCount) renderPageToBase64(renderer, pageIndex) else null
            }
        }
    } catch (_: Exception) {
        null
    }

    private fun renderPageToBase64(renderer: PdfRenderer, pageIndex: Int): String {
        renderer.openPage(pageIndex).use { page ->
            val maxDim = 1150f
            val scale = minOf(maxDim / page.width.coerceAtLeast(1), maxDim / page.height.coerceAtLeast(1), 2.0f)
            val w = (page.width * scale).toInt().coerceAtLeast(200)
            val h = (page.height * scale).toInt().coerceAtLeast(200)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            return try {
                val canvas = Canvas(bmp)
                canvas.drawColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bitmapToBase64Jpeg(bmp, 78)
            } finally {
                bmp.recycle()
            }
        }
    }

    fun extractPdfTextHeuristic(pdfBytes: ByteArray, knownPageCount: Int): List<DocChunk> {
        val latin = String(pdfBytes, Charsets.ISO_8859_1)
        val extractedBlocks = ArrayList<String>()
        var searchFrom = 0
        var streamCount = 0

        while (streamCount < 80) {
            val sIdx = latin.indexOf("stream", searchFrom)
            if (sIdx < 0) break
            var dataStart = sIdx + 6
            if (dataStart < pdfBytes.size && pdfBytes[dataStart] == '\r'.code.toByte()) dataStart++
            if (dataStart < pdfBytes.size && pdfBytes[dataStart] == '\n'.code.toByte()) dataStart++
            val eIdx = latin.indexOf("endstream", dataStart)
            if (eIdx < 0) break
            searchFrom = eIdx + 9
            streamCount++

            val sliceLen = (eIdx - dataStart).coerceIn(0, 512_000)
            if (sliceLen < 8) continue
            val rawSlice = pdfBytes.copyOfRange(dataStart, dataStart + sliceLen)
            val decompressed = tryInflate(rawSlice) ?: rawSlice
            val content = String(decompressed, Charsets.ISO_8859_1)
            if (content.contains("BT") && content.contains("ET")) {
                val txt = extractTextFromPdfOperators(content)
                if (txt.length >= 15) extractedBlocks.add(txt)
            }
        }

        if (extractedBlocks.isEmpty()) return emptyList()
        val pages = ArrayList<DocChunk>()
        if (extractedBlocks.size == knownPageCount) {
            extractedBlocks.forEachIndexed { idx, txt ->
                pages.add(DocChunk("Page ${idx + 1}", txt.take(3000)))
            }
        } else {
            val merged = extractedBlocks.joinToString("\n\n")
            val perPage = (merged.length / knownPageCount.coerceAtLeast(1)).coerceIn(800, 2600)
            var pos = 0
            var pageNum = 1
            while (pos < merged.length && pageNum <= 40) {
                val end = minOf(merged.length, pos + perPage)
                pages.add(DocChunk("Page $pageNum", merged.substring(pos, end)))
                pos = end
                pageNum++
            }
        }
        return pages
    }

    private fun tryInflate(data: ByteArray): ByteArray? = try {
        val inflater = Inflater()
        inflater.setInput(data)
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        while (!inflater.finished() && out.size() < 512_000) {
            val n = inflater.inflate(buf)
            if (n <= 0) break
            out.write(buf, 0, n)
        }
        inflater.end()
        if (out.size() > 0) out.toByteArray() else null
    } catch (_: Exception) {
        null
    }

    private fun extractTextFromPdfOperators(stream: String): String {
        val sb = StringBuilder()
        var i = 0
        val n = stream.length
        while (i < n) {
            val c = stream[i]
            if (c == '(') {
                i++
                var depth = 1
                val word = StringBuilder()
                while (i < n && depth > 0) {
                    val ch = stream[i]
                    if (ch == '\\' && i + 1 < n) {
                        val nx = stream[i + 1]
                        when (nx) {
                            'n' -> word.append('\n')
                            'r' -> word.append(' ')
                            't' -> word.append(' ')
                            '(', ')', '\\' -> word.append(nx)
                            else -> {}
                        }
                        i += 2
                    } else if (ch == '(') {
                        depth++; word.append(ch); i++
                    } else if (ch == ')') {
                        depth--; if (depth > 0) word.append(ch); i++
                    } else {
                        if (ch.code in 32..126) word.append(ch)
                        i++
                    }
                }
                if (word.isNotEmpty()) sb.append(word).append(' ')
            } else {
                i++
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun extractDocxText(context: Context, uri: Uri): String {
        val sb = StringBuilder()
        context.contentResolver.openInputStream(uri)?.use { stream ->
            ZipInputStream(stream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        parseXmlText(zip, sb, setOf("p", "br", "tr"), setOf("tab", "tc"))
                        break
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        return sb.toString().replace(Regex("\n{3,}"), "\n\n").trim()
    }

    private fun extractXlsxSheets(context: Context, uri: Uri): List<DocChunk> {
        val sharedStrings = ArrayList<String>()
        val rawSheets = LinkedHashMap<String, ByteArray>()

        context.contentResolver.openInputStream(uri)?.use { stream ->
            ZipInputStream(stream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (name == "xl/sharedStrings.xml") {
                        val parser = XmlPullParserFactory.newInstance().newPullParser()
                        parser.setInput(zip, "UTF-8")
                        var inSi = false
                        val cur = StringBuilder()
                        var ev = parser.eventType
                        while (ev != XmlPullParser.END_DOCUMENT) {
                            when (ev) {
                                XmlPullParser.START_TAG -> if (parser.name == "si") { inSi = true; cur.clear() }
                                XmlPullParser.TEXT -> if (inSi) cur.append(parser.text.orEmpty())
                                XmlPullParser.END_TAG -> if (parser.name == "si") { sharedStrings.add(cur.toString()); inSi = false }
                            }
                            ev = parser.next()
                        }
                    } else if (name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml")) {
                        rawSheets[name] = zip.readBytes()
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }

        val out = ArrayList<DocChunk>()
        rawSheets.entries.sortedBy { it.key }.forEachIndexed { idx, (_, bytes) ->
            val sb = StringBuilder()
            val parser = XmlPullParserFactory.newInstance().newPullParser()
            parser.setInput(bytes.inputStream(), "UTF-8")
            var cellType = ""
            var inVal = false
            var ev = parser.eventType
            var rowCount = 0
            while (ev != XmlPullParser.END_DOCUMENT && sb.length < 15_000) {
                when (ev) {
                    XmlPullParser.START_TAG -> {
                        if (parser.name == "c") cellType = parser.getAttributeValue(null, "t").orEmpty()
                        else if (parser.name == "v" || parser.name == "t") inVal = true
                    }
                    XmlPullParser.TEXT -> if (inVal) {
                        val raw = parser.text.orEmpty().trim()
                        val resolved = if (cellType == "s") {
                            raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) } ?: raw
                        } else raw
                        if (resolved.isNotEmpty()) sb.append(resolved).append(" | ")
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name == "v" || parser.name == "t") inVal = false
                        else if (parser.name == "row") { sb.append('\n'); rowCount++ }
                    }
                }
                ev = parser.next()
            }
            val txt = sb.toString().trim()
            if (txt.isNotEmpty()) out.add(DocChunk("Sheet ${idx + 1} ($rowCount rows)", txt))
        }
        return out
    }

    private fun extractPptxSlides(context: Context, uri: Uri): List<DocChunk> {
        val slides = ArrayList<Pair<Int, String>>()
        context.contentResolver.openInputStream(uri)?.use { stream ->
            ZipInputStream(stream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val m = Regex("ppt/slides/slide(\\d+)\\.xml").matchEntire(entry.name)
                    if (m != null) {
                        val num = m.groupValues[1].toIntOrNull() ?: 0
                        val sb = StringBuilder()
                        parseXmlText(zip, sb, setOf("p", "br"), setOf("tab"))
                        val txt = sb.toString().replace(Regex("\n{2,}"), "\n").trim()
                        if (txt.isNotEmpty()) slides.add(num to txt)
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        return slides.sortedBy { it.first }.map { (num, txt) -> DocChunk("Slide $num", txt) }
    }

    private fun parseXmlText(stream: java.io.InputStream, sb: StringBuilder, newLineTags: Set<String>, spaceTags: Set<String>) {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(stream, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT && sb.length < 48_000) {
            when (event) {
                XmlPullParser.TEXT -> {
                    val t = parser.text
                    if (!t.isNullOrEmpty()) sb.append(t)
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name in newLineTags) sb.append('\n')
                    else if (parser.name in spaceTags) sb.append(" | ")
                }
            }
            event = parser.next()
        }
    }

    private fun readPlainTextSafe(context: Context, uri: Uri): String =
        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
            val buf = CharArray(45_000)
            val n = reader.read(buf)
            if (n > 0) String(buf, 0, n).trim() else ""
        }.orEmpty()

    private fun readScaledImageBase64(context: Context, uri: Uri): String? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        val maxDim = maxOf(opts.outWidth, opts.outHeight)
        var sample = 1
        while (maxDim / sample > 1024) sample *= 2

        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decodeOpts) }
            ?: return null
        return try {
            bitmapToBase64Jpeg(bmp, 80)
        } finally {
            bmp.recycle()
        }
    }

    fun bitmapToBase64Jpeg(bmp: Bitmap, quality: Int = 80): String {
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    private fun resolveFileName(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Document" } ?: "Document"
    }
}
