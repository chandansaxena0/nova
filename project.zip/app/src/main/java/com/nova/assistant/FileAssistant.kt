package com.nova.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.ZipInputStream

/**
 * Local-first File Assistant supporting PDF, TXT, DOCX, and Images.
 * - TXT/MD/CSV: read locally directly from ContentResolver.
 * - DOCX: parsed locally via ZipInputStream + XmlPullParser (`word/document.xml`).
 * - PDF: rendered via native Android PdfRenderer (+ local text heuristic) and summarized/queried via Gemini.
 * - Images: downscaled locally to <= 1024px JPEG and explained via Gemini Vision.
 */
object FileAssistant {

    data class LoadedDoc(
        val name: String,
        val kind: String, // txt, docx, pdf, image
        val textContent: String = "",
        val imageBase64: String = "",
        val imageMime: String = "image/jpeg",
        val pageCount: Int = 1
    )

    @Volatile
    var activeDoc: LoadedDoc? = null
        private set

    fun clearActiveDoc() {
        activeDoc = null
    }

    fun activeDocSummaryLabel(): String {
        val d = activeDoc ?: return "No file loaded. Pick a PDF, TXT, DOCX, or Image to summarize or ask questions."
        return "Loaded: ${d.name} (${d.kind.uppercase(Locale.ROOT)}, ${d.pageCount} page/item)"
    }

    /** Loads and parses a file URI off the UI thread. Returns user-friendly status + summary. */
    fun loadAndSummarize(context: Context, uri: Uri): String {
        val name = resolveFileName(context, uri)
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase(Locale.ROOT)
        val lower = name.lowercase(Locale.ROOT)

        val doc: LoadedDoc = try {
            when {
                mime.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") -> {
                    val b64 = readScaledImageBase64(context, uri)
                        ?: return "Image read nahi ho payi."
                    LoadedDoc(name = name, kind = "image", imageBase64 = b64, imageMime = "image/jpeg")
                }
                mime == "application/pdf" || lower.endsWith(".pdf") -> {
                    loadPdf(context, uri, name)
                }
                lower.endsWith(".docx") || mime.contains("wordprocessingml") -> {
                    val text = extractDocxText(context, uri)
                    if (text.isBlank()) return "DOCX file me readable text nahi mila."
                    LoadedDoc(name = name, kind = "docx", textContent = text.take(18_000))
                }
                else -> {
                    val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty().trim()
                    if (text.isBlank()) return "File khali hai ya supported format (PDF, TXT, DOCX, Image) nahi hai."
                    LoadedDoc(name = name, kind = "txt", textContent = text.take(18_000))
                }
            }
        } catch (e: Exception) {
            return "File read karne me error aaya: ${e.message?.take(100)}"
        }

        activeDoc = doc
        return answerQuestion(context, "Summarize this file clearly and extract key points.")
    }

    /** Answers a follow-up question or summary request about the currently loaded file. */
    fun answerQuestion(context: Context, userQuestion: String): String {
        val doc = activeDoc
            ?: return "Abhi koi file load nahi hai. Hub tab me 'Pick File (PDF/TXT/DOCX/Image)' dabakar file select karo."

        // Image or PDF page rendered as image -> Gemini Vision
        if (doc.imageBase64.isNotEmpty() && doc.textContent.isBlank()) {
            if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
                return "${doc.name} load ho gayi hai (${doc.pageCount} page/image). Visual explanation ke liye internet aur Gemini API key chahiye."
            }
            val prompt = "File name: ${doc.name} (${doc.kind}, ${doc.pageCount} pages). User request: $userQuestion. Reply clearly in Roman Hinglish or English (no markdown symbols)."
            return GeminiClient.askWithImageBase64(context, doc.imageMime, doc.imageBase64, prompt)
        }

        // Text-based document (TXT, DOCX, or text-extracted PDF)
        if (!PhoneInfoHelper.isOnline(context) || !Prefs.hasAi(context)) {
            // Local offline summary (first few clean sentences)
            val preview = doc.textContent.replace(Regex("\\s+"), " ").trim().take(360)
            return "Offline local preview (${doc.name}): $preview"
        }

        val sys = "You are Nova's File Agent. Answer strictly using the provided document text. Be accurate, concise, and clear (no markdown stars/hashtags)."
        val prompt = "Document: ${doc.name}\nContent:\n${doc.textContent.take(12_000)}\n\nUser request: $userQuestion"
        return GeminiClient.askWithAgentPrompt(context, sys, prompt, keepContext = true, maxTokens = 750)
    }

    private fun loadPdf(context: Context, uri: Uri, name: String): LoadedDoc {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("PDF open nahi hua")
        pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
                val count = renderer.pageCount
                if (count <= 0) throw IllegalStateException("PDF me koi page nahi hai")
                // Render first page cleanly to a compact JPEG bitmap for visual/OCR reading
                renderer.openPage(0).use { page ->
                    val maxDim = 1200f
                    val scale = minOf(maxDim / page.width.coerceAtLeast(1), maxDim / page.height.coerceAtLeast(1), 2.0f)
                    val w = (page.width * scale).toInt().coerceAtLeast(200)
                    val h = (page.height * scale).toInt().coerceAtLeast(200)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bmp)
                    canvas.drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val b64 = bitmapToBase64Jpeg(bmp, 80)
                    bmp.recycle()
                    return LoadedDoc(name = name, kind = "pdf", imageBase64 = b64, imageMime = "image/jpeg", pageCount = count)
                }
            }
        }
    }

    private fun extractDocxText(context: Context, uri: Uri): String {
        val sb = StringBuilder()
        context.contentResolver.openInputStream(uri)?.use { stream ->
            ZipInputStream(stream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val factory = XmlPullParserFactory.newInstance()
                        val parser = factory.newPullParser()
                        parser.setInput(zip, "UTF-8")
                        var event = parser.eventType
                        while (event != XmlPullParser.END_DOCUMENT) {
                            when (event) {
                                XmlPullParser.TEXT -> {
                                    val t = parser.text
                                    if (!t.isNullOrEmpty()) sb.append(t)
                                }
                                XmlPullParser.END_TAG -> {
                                    if (parser.name == "p" || parser.name == "br") sb.append('\n')
                                    else if (parser.name == "tab") sb.append(' ')
                                }
                            }
                            event = parser.next()
                        }
                        break
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        return sb.toString().replace(Regex("\n{3,}"), "\n\n").trim()
    }

    private fun readScaledImageBase64(context: Context, uri: Uri): String? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        val maxDim = maxOf(opts.outWidth, opts.outHeight)
        var sample = 1
        while (maxDim / sample > 1024) sample *= 2

        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decodeOpts) }
            ?: return null
        val b64 = bitmapToBase64Jpeg(bmp, 80)
        bmp.recycle()
        return b64
    }

    fun bitmapToBase64Jpeg(bmp: Bitmap, quality: Int = 80): String {
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    private fun resolveFileName(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Document" } ?: "Document"
    }
}
