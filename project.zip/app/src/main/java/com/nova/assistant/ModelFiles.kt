package com.nova.assistant

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Provisioner for the official Vosk Small Indian-English model (vosk-model-small-en-in-0.4).
 * Recognizes "Hey Nova", "Hi Nova", "Hello Nova", "Okay Nova", "Nova", and Stop phrases
 * accurately in Indian accents without Devanagari corruption.
 */
object ModelFiles {
    private const val VERSION = "en-in-0.4-v6"
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip"

    fun isReady(context: Context): Boolean {
        val target = File(context.filesDir, "model-$VERSION")
        if (File(target, ".done").exists()) return true
        // Model bundled inside the APK by the build workflow: no internet needed
        return try { context.assets.list("model").orEmpty().isNotEmpty() } catch (_: Exception) { false }
    }

    fun ensure(context: Context, onProgress: (Int) -> Unit = {}): File {
        val target = File(context.filesDir, "model-$VERSION")
        val done = File(target, ".done")
        if (done.exists()) return target

        val archive = File(context.cacheDir, "vosk-en-in-model.zip")
        val staging = File(context.filesDir, "model-staging-$VERSION")
        target.deleteRecursively()
        staging.deleteRecursively()
        archive.delete()

        val bundled = context.assets.list("model").orEmpty()
        if (bundled.isNotEmpty()) {
            onProgress(50)
            copyAssetDir(context, "model", target)
            done.writeText("ok")
            onProgress(100)
            return target
        }

        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 120000
            instanceFollowRedirects = true
        }
        try {
            val total = conn.contentLengthLong
            var downloaded = 0L
            var lastPct = -1
            conn.inputStream.use { input ->
                archive.outputStream().buffered().use { output ->
                    val buf = ByteArray(16384)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        output.write(buf, 0, n)
                        downloaded += n
                        if (total > 0) {
                            val pct = ((downloaded * 90) / total).toInt().coerceIn(0, 90)
                            if (pct != lastPct) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
            }
        } finally {
            conn.disconnect()
        }

        if (!archive.exists() || archive.length() < 1_000_000L) {
            archive.delete()
            throw IllegalStateException("Voice model download adhura raha. Internet check karo.")
        }

        onProgress(92)
        staging.mkdirs()
        ZipInputStream(BufferedInputStream(archive.inputStream())).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val rawName = entry.name.replace('\\', '/')
                val parts = rawName.split('/').filter { it.isNotBlank() && it != "." }
                if (parts.any { it == ".." }) throw SecurityException("Invalid model archive path")
                val relative = if (parts.size > 1) parts.drop(1) else emptyList()
                if (relative.isNotEmpty()) {
                    val out = File(staging, relative.joinToString("/")).canonicalFile
                    if (!out.path.startsWith(staging.canonicalPath + File.separator)) {
                        throw SecurityException("Invalid model archive path")
                    }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().buffered().use { zip.copyTo(it) }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        archive.delete()

        if (!staging.exists() || staging.list()?.isEmpty() == true) {
            staging.deleteRecursively()
            throw IllegalStateException("Voice model extract nahi hua.")
        }
        if (!staging.renameTo(target)) {
            staging.copyRecursively(target, overwrite = true)
            staging.deleteRecursively()
        }
        done.writeText("ok")
        onProgress(100)
        return target
    }

    private fun copyAssetDir(context: Context, assetPath: String, dest: File) {
        val names = context.assets.list(assetPath) ?: return
        dest.mkdirs()
        for (name in names) {
            val child = "$assetPath/$name"
            val sub = context.assets.list(child)
            if (sub != null && sub.isNotEmpty()) {
                copyAssetDir(context, child, File(dest, name))
            } else {
                context.assets.open(child).use { input ->
                    File(dest, name).outputStream().buffered().use { input.copyTo(it) }
                }
            }
        }
    }
}
