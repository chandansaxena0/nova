package com.nova.assistant

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Installs the official Vosk small Hindi model on first run.
 * The model is downloaded only when the user enables wake-word listening.
 */
object ModelFiles {
    private const val VERSION = "hi-0.22-v2"
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"

    fun ensure(context: Context): File {
        val target = File(context.filesDir, "model-$VERSION")
        val done = File(target, ".done")
        if (done.exists()) return target

        val archive = File(context.cacheDir, "vosk-hi-model.zip")
        val staging = File(context.filesDir, "model-staging")
        target.deleteRecursively()
        staging.deleteRecursively()
        archive.delete()

        // GitHub Actions may package the model into assets/model. Prefer that copy
        // to avoid downloading the same large archive again on first launch.
        val bundled = context.assets.list("model").orEmpty()
        if (bundled.isNotEmpty()) {
            copyAssetDir(context, "model", target)
            done.writeText("ok")
            return target
        }

        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 120000
            instanceFollowRedirects = true
        }
        try {
            conn.inputStream.use { input ->
                archive.outputStream().buffered().use { output -> input.copyTo(output) }
            }
        } finally {
            conn.disconnect()
        }
        if (!archive.exists() || archive.length() < 1_000_000L) {
            archive.delete()
            throw IllegalStateException("Hindi voice model download adhura raha.")
        }

        staging.mkdirs()
        ZipInputStream(BufferedInputStream(archive.inputStream())).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val rawName = entry.name.replace('\\', '/')
                val parts = rawName.split('/').filter { it.isNotBlank() && it != "." }
                if (parts.any { it == ".." }) throw SecurityException("Invalid model archive path")
                // ZIP contains one top-level model directory; remove that prefix.
                val relative = if (parts.size > 1) parts.drop(1) else emptyList()
                if (relative.isNotEmpty()) {
                    val out = File(staging, relative.joinToString("/")).canonicalFile
                    if (!out.path.startsWith(staging.canonicalPath + File.separator)) {
                        throw SecurityException("Invalid model archive path")
                    }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().buffered().use { zip.copyTo(it) }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        archive.delete()
        if (!staging.exists() || staging.list()?.isEmpty() == true) {
            staging.deleteRecursively()
            throw IllegalStateException("Hindi voice model extract nahi hua.")
        }
        if (!staging.renameTo(target)) {
            staging.copyRecursively(target, overwrite = true)
            staging.deleteRecursively()
        }
        // Marker is written only after extraction completed.
        done.writeText("ok")
        return target
    }

    private fun copyAssetDir(context: Context, assetPath: String, dest: File) {
        val names = context.assets.list(assetPath) ?: return
        dest.mkdirs()
        for (name in names) {
            val child = "$assetPath/$name"
            val sub = context.assets.list(child)
            if (sub != null && sub.isNotEmpty()) {
                copyAssetDir(context, child, File(dest, name))
            } else {
                context.assets.open(child).use { input ->
                    File(dest, name).outputStream().buffered().use { input.copyTo(it) }
                }
            }
        }
    }
}
