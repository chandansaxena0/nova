package com.nova.assistant

import android.content.Context
import java.net.HttpURLConnection
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

enum class AiTaskType {
    LOCAL_ONLY,
    GENERAL_CHAT,
    RESEARCH,
    VISION,
    REASONING
}

data class ProviderHealth(
    val provider: String,
    val successCount: Int = 0,
    val errorCount: Int = 0,
    val lastLatencyMs: Long = 0L,
    val lastError: String = "",
    val lastCheckedMs: Long = 0L
)

object AiRouter {

    private const val PREF_USAGE = "nova_ai_usage"
    private val healthMap = ConcurrentHashMap<String, ProviderHealth>()
    private val activeConnRef = AtomicReference<HttpURLConnection?>(null)
    private val cancelRequested = AtomicBoolean(false)

    private fun estimatedUsdPerMillionTokens(provider: String, model: String): Double {
        val m = model.lowercase(Locale.ROOT)
        return when {
            m.contains(":free") || m == "openrouter/free" -> 0.0
            provider == OpenAiCompat.GEMINI && m.contains("flash-lite") -> 0.15
            provider == OpenAiCompat.GEMINI && m.contains("flash") -> 0.35
            provider == OpenAiCompat.GEMINI && m.contains("pro") -> 2.50
            provider == OpenAiCompat.GROK && m.contains("fast") -> 0.40
            provider == OpenAiCompat.GROK -> 3.00
            else -> 0.50
        }
    }

    fun registerActiveConnection(conn: HttpURLConnection?) {
        cancelRequested.set(false)
        activeConnRef.set(conn)
    }

    fun clearActiveConnection(conn: HttpURLConnection?) {
        activeConnRef.compareAndSet(conn, null)
    }

    fun cancelActiveRequest() {
        cancelRequested.set(true)
        runCatching { activeConnRef.getAndSet(null)?.disconnect() }
    }

    fun isCancelled(): Boolean = cancelRequested.get()

    fun backoffDelayMs(attempt: Int): Long = (1200L * (1L shl attempt.coerceIn(0, 3))).coerceAtMost(8000L)

    fun selectProviders(primary: String, secondary: String, hasPrimaryKey: Boolean, hasSecondaryKey: Boolean): List<String> {
        val list = ArrayList<String>(2)
        if (hasPrimaryKey) list.add(primary)
        if (secondary.isNotEmpty() && secondary != "none" && secondary != primary && hasSecondaryKey) {
            list.add(secondary)
        }
        return list
    }

    fun resolveProviderChain(context: Context, task: AiTaskType): List<String> {
        if (task == AiTaskType.LOCAL_ONLY) return emptyList()
        val primary = Prefs.aiProvider(context)
        val secondary = Prefs.secondaryAiProvider(context)
        return selectProviders(
            primary = primary,
            secondary = secondary,
            hasPrimaryKey = Prefs.aiKey(context, primary).isNotEmpty(),
            hasSecondaryKey = secondary != "none" && Prefs.aiKey(context, secondary).isNotEmpty()
        )
    }

    fun canMakeRequest(context: Context): Pair<Boolean, String> {
        val limit = Prefs.dailyAiLimit(context)
        if (limit <= 0) return true to ""
        val used = todayRequestCount(context)
        return if (used >= limit) {
            false to "Daily AI request limit ($limit) poora ho gaya hai. Settings me limit badhao ya kal try karo."
        } else {
            true to ""
        }
    }

    fun recordSuccess(context: Context, provider: String, model: String, latencyMs: Long, inputChars: Int, outputChars: Int) {
        val prev = healthMap[provider] ?: ProviderHealth(provider)
        healthMap[provider] = prev.copy(
            successCount = prev.successCount + 1,
            lastLatencyMs = latencyMs,
            lastError = "",
            lastCheckedMs = System.currentTimeMillis()
        )
        val estTokens = ((inputChars + outputChars) / 4).coerceAtLeast(1)
        val estUsd = (estTokens / 1_000_000.0) * estimatedUsdPerMillionTokens(provider, model)
        addDailyUsage(context, estTokens, estUsd)
    }

    fun recordError(provider: String, message: String) {
        val prev = healthMap[provider] ?: ProviderHealth(provider)
        healthMap[provider] = prev.copy(
            errorCount = prev.errorCount + 1,
            lastError = message.take(120),
            lastCheckedMs = System.currentTimeMillis()
        )
    }

    fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun addDailyUsage(context: Context, tokens: Int, usd: Double) {
        val p = context.getSharedPreferences(PREF_USAGE, Context.MODE_PRIVATE)
        val day = todayKey()
        val storedDay = p.getString("day", "")
        val reqs = if (storedDay == day) p.getInt("reqs", 0) + 1 else 1
        val toks = if (storedDay == day) p.getInt("tokens", 0) + tokens else tokens
        val cost = if (storedDay == day) p.getFloat("usd", 0f) + usd.toFloat() else usd.toFloat()
        p.edit()
            .putString("day", day)
            .putInt("reqs", reqs)
            .putInt("tokens", toks)
            .putFloat("usd", cost)
            .apply()
    }

    fun todayRequestCount(context: Context): Int {
        val p = context.getSharedPreferences(PREF_USAGE, Context.MODE_PRIVATE)
        return if (p.getString("day", "") == todayKey()) p.getInt("reqs", 0) else 0
    }

    fun usageAndHealthSummary(context: Context): String {
        val p = context.getSharedPreferences(PREF_USAGE, Context.MODE_PRIVATE)
        val sameDay = p.getString("day", "") == todayKey()
        val reqs = if (sameDay) p.getInt("reqs", 0) else 0
        val toks = if (sameDay) p.getInt("tokens", 0) else 0
        val usd = if (sameDay) p.getFloat("usd", 0f) else 0f
        val limit = Prefs.dailyAiLimit(context)
        val primary = Prefs.aiProvider(context)
        val secondary = Prefs.secondaryAiProvider(context)
        val h = healthMap[primary]
        val healthStr = if (h == null) "Ready"
        else if (h.lastError.isEmpty()) "Healthy (${h.lastLatencyMs}ms, ${h.successCount} ok)"
        else "Degraded (${h.errorCount} errs: ${h.lastError.take(55)})"

        return buildString {
            append("Primary: ").append(OpenAiCompat.label(primary)).append(" (").append(Prefs.activeModel(context)).append(")")
            if (secondary != "none" && secondary != primary) {
                append(" | Fallback: ").append(OpenAiCompat.label(secondary))
            }
            append('\n')
            append("AI Health: ").append(healthStr).append('\n')
            append("Today Usage: ").append(reqs).append(if (limit > 0) "/$limit" else "").append(" calls • ~").append(toks).append(" tokens")
            append(String.format(Locale.US, " • Est. $%.4f", usd))
        }
    }
}
