package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser
    private var localTts: TextToSpeech? = null
    private var availableVoices: List<String> = emptyList()

    // Tabs
    private lateinit var tabHome: ScrollView
    private lateinit var tabTools: ScrollView
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView

    // Dashboard views
    private lateinit var timerBadge: TextView
    private lateinit var dashWakeSwitch: MaterialSwitch
    private lateinit var dashTelemetryText: TextView
    private lateinit var btnPrivacyPause: MaterialButton
    private lateinit var heardText: TextView
    private lateinit var statusText: TextView
    private lateinit var confirmBar: LinearLayout
    private lateinit var commandInput: TextInputEditText
    private lateinit var recentHistoryText: TextView
    private lateinit var appCountText: TextView

    // Hub views
    private lateinit var trainQueryInput: TextInputEditText
    private lateinit var checklistContainer: LinearLayout
    private lateinit var checklistAddInput: TextInputEditText
    private lateinit var reminderTitleInput: TextInputEditText
    private lateinit var reminderMinInput: TextInputEditText
    private lateinit var reminderRepeatCheck: CheckBox
    private lateinit var reminderListContainer: LinearLayout
    private lateinit var memoryInput: TextInputEditText
    private lateinit var memoryListContainer: LinearLayout
    private lateinit var emergNameInput: TextInputEditText
    private lateinit var emergNumberInput: TextInputEditText
    private lateinit var phoneInfoText: TextView

    // Settings views
    private lateinit var wakeSwitch: MaterialSwitch
    private lateinit var wakeStatus: TextView
    private lateinit var durationToggleGroup: MaterialButtonToggleGroup
    private lateinit var langToggleGroup: MaterialButtonToggleGroup
    private lateinit var ttsSpeedLabel: TextView
    private lateinit var ttsSpeedSlider: Slider
    private lateinit var btnPickVoice: MaterialButton
    private lateinit var soundFeedbackSwitch: MaterialSwitch
    private lateinit var batterySaverSwitch: MaterialSwitch
    private lateinit var lowBatteryAlertSwitch: MaterialSwitch
    private lateinit var saveHistorySwitch: MaterialSwitch
    private lateinit var geminiKeyInput: TextInputEditText
    private lateinit var geminiModelInput: TextInputEditText
    private lateinit var geminiStatus: TextView
    private lateinit var railRadarKeyInput: TextInputEditText
    private lateinit var railRadarUrlInput: TextInputEditText
    private lateinit var railRadarStatus: TextView
    private lateinit var permStatus: TextView

    private var askedPermissions = false
    private var askedOverlay = false
    private var askedBattery = false
    private var updatingSwitchUi = false

    private val stateListener: () -> Unit = { refreshDashboardTelemetry() }

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                val spoken = r.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    val hinglish = HinglishConverter.toHinglish(spoken)
                    commandInput.setText(hinglish)
                    executeCommand(hinglish)
                }
            }
        }

    private val wakePermsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            continueWakeSetup()
        }

    private val extraPermsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshPerms()
            refreshPhoneDiagnostics()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        index = AppIndex(this)
        parser = CommandParser(index)
        initLocalTts()

        bindViews()
        setupBottomNav()
        setupDashboardControls()
        setupHubControls()
        setupSettingsControls()

        if (intent.getBooleanExtra("autostart", false)) {
            Prefs.setWake(this, true)
        }
    }

    private fun initLocalTts() {
        localTts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                localTts?.language = Locale("hi", "IN")
                localTts?.setSpeechRate(Prefs.ttsSpeed(this))
                availableVoices = localTts?.voices
                    ?.filter { it.locale.language in setOf("en", "hi") && !it.isNetworkConnectionRequired }
                    ?.map { it.name }
                    ?.sorted()
                    .orEmpty()
            }
        }
    }

    private fun bindViews() {
        tabHome = findViewById(R.id.tabHome)
        tabTools = findViewById(R.id.tabTools)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)

        timerBadge = findViewById(R.id.timerBadge)
        dashWakeSwitch = findViewById(R.id.dashWakeSwitch)
        dashTelemetryText = findViewById(R.id.dashTelemetryText)
        btnPrivacyPause = findViewById(R.id.btnPrivacyPause)
        heardText = findViewById(R.id.heardText)
        statusText = findViewById(R.id.statusText)
        confirmBar = findViewById(R.id.confirmBar)
        commandInput = findViewById(R.id.commandInput)
        recentHistoryText = findViewById(R.id.recentHistoryText)
        appCountText = findViewById(R.id.appCountText)

        trainQueryInput = findViewById(R.id.trainQueryInput)
        checklistContainer = findViewById(R.id.checklistContainer)
        checklistAddInput = findViewById(R.id.checklistAddInput)
        reminderTitleInput = findViewById(R.id.reminderTitleInput)
        reminderMinInput = findViewById(R.id.reminderMinInput)
        reminderRepeatCheck = findViewById(R.id.reminderRepeatCheck)
        reminderListContainer = findViewById(R.id.reminderListContainer)
        memoryInput = findViewById(R.id.memoryInput)
        memoryListContainer = findViewById(R.id.memoryListContainer)
        emergNameInput = findViewById(R.id.emergNameInput)
        emergNumberInput = findViewById(R.id.emergNumberInput)
        phoneInfoText = findViewById(R.id.phoneInfoText)

        wakeSwitch = findViewById(R.id.wakeSwitch)
        wakeStatus = findViewById(R.id.wakeStatus)
        durationToggleGroup = findViewById(R.id.durationToggleGroup)
        langToggleGroup = findViewById(R.id.langToggleGroup)
        ttsSpeedLabel = findViewById(R.id.ttsSpeedLabel)
        ttsSpeedSlider = findViewById(R.id.ttsSpeedSlider)
        btnPickVoice = findViewById(R.id.btnPickVoice)
        soundFeedbackSwitch = findViewById(R.id.soundFeedbackSwitch)
        batterySaverSwitch = findViewById(R.id.batterySaverSwitch)
        lowBatteryAlertSwitch = findViewById(R.id.lowBatteryAlertSwitch)
        saveHistorySwitch = findViewById(R.id.saveHistorySwitch)
        geminiKeyInput = findViewById(R.id.geminiKeyInput)
        geminiModelInput = findViewById(R.id.geminiModelInput)
        geminiStatus = findViewById(R.id.geminiStatus)
        railRadarKeyInput = findViewById(R.id.railRadarKeyInput)
        railRadarUrlInput = findViewById(R.id.railRadarUrlInput)
        railRadarStatus = findViewById(R.id.railRadarStatus)
        permStatus = findViewById(R.id.permStatus)
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            tabHome.visibility = if (item.itemId == R.id.nav_home) View.VISIBLE else View.GONE
            tabTools.visibility = if (item.itemId == R.id.nav_tools) View.VISIBLE else View.GONE
            tabSettings.visibility = if (item.itemId == R.id.nav_settings) View.VISIBLE else View.GONE
            if (item.itemId == R.id.nav_tools) {
                refreshChecklistUi()
                refreshRemindersUi()
                refreshMemoriesUi()
                refreshPhoneDiagnostics()
            }
            if (item.itemId == R.id.nav_settings) {
                refreshPerms()
            }
            true
        }
    }

    private fun setupDashboardControls() {
        val wakeToggleHandler: (Boolean) -> Unit = { checked ->
            if (!updatingSwitchUi) {
                if (checked && Prefs.privacyPaused(this)) {
                    Prefs.setPrivacyPaused(this, false)
                }
                Prefs.setWake(this, checked)
                syncWakeSwitches(checked)
                if (checked) {
                    askedPermissions = false
                    askedOverlay = false
                    askedBattery = false
                    continueWakeSetup()
                } else {
                    stopService(Intent(this, ListenService::class.java))
                    refreshDashboardTelemetry()
                }
            }
        }
        dashWakeSwitch.setOnCheckedChangeListener { _, checked -> wakeToggleHandler(checked) }
        wakeSwitch.setOnCheckedChangeListener { _, checked -> wakeToggleHandler(checked) }

        findViewById<FloatingActionButton>(R.id.micButton).setOnClickListener { startVoicePrompt() }
        findViewById<MaterialButton>(R.id.goButton).setOnClickListener { submitTypedCommand() }
        findViewById<MaterialButton>(R.id.stopNowButton).setOnClickListener {
            ActionExecutor.clearPending()
            VoiceFlashcardManager.stopSession()
            confirmBar.visibility = View.GONE
            localTts?.stop()
            NovaAccessibility.instance?.stopAgent()
            if (ListenService.running) {
                startService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_STOP_AGENT))
            }
            statusText.text = "Stopped. Wake mode active."
        }

        btnPrivacyPause.setOnClickListener {
            localTts?.stop()
            if (Prefs.privacyPaused(this)) {
                val msg = ActionExecutor.resumeFromPrivacyPause(this)
                statusText.text = msg
                Toast.makeText(this, "Nova Resumed!", Toast.LENGTH_SHORT).show()
            } else {
                val msg = ActionExecutor.pauseEverything(this)
                confirmBar.visibility = View.GONE
                statusText.text = msg
                Toast.makeText(this, "Privacy Mode ON — Sab Pause ho gaya", Toast.LENGTH_SHORT).show()
            }
            refreshDashboardTelemetry()
        }

        findViewById<MaterialButton>(R.id.btnConfirmYes).setOnClickListener {
            executeCommand("Haan")
        }
        findViewById<MaterialButton>(R.id.btnConfirmNo).setOnClickListener {
            executeCommand("Nahi")
        }

        commandInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitTypedCommand()
                true
            } else false
        }

        val chips = findViewById<ChipGroup>(R.id.chipGroup)
        listOf(
            "YouTube par MrBeast search karo",
            "Mere sabse paas petrol pump",
            "Daily briefing",
            "Battery status batao",
            "Roblox me Brookhaven chalao",
            "Train 12562 kahan pahunchi",
            "Maths voice flashcards shuru karo",
            "Travel checklist dikhao"
        ).forEach { sample ->
            val chip = Chip(this).apply {
                text = sample
                setOnClickListener {
                    commandInput.setText(sample)
                    executeCommand(sample)
                }
            }
            chips.addView(chip)
        }
    }

    private fun setupHubControls() {
        findViewById<MaterialButton>(R.id.btnAskTrain).setOnClickListener {
            val q = trainQueryInput.text?.toString()?.trim().orEmpty()
            if (q.isEmpty()) {
                Toast.makeText(this, "Train number ya naam likho (e.g. 12562).", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Train $q kahan pahunchi aur depart time kya hai")
        }

        findViewById<MaterialButton>(R.id.btnAddChecklistItem).setOnClickListener {
            val item = checklistAddInput.text?.toString()?.trim().orEmpty()
            if (item.isEmpty()) return@setOnClickListener
            RailRadarHelper.addChecklistItem(this, item)
            checklistAddInput.setText("")
            refreshChecklistUi()
        }

        findViewById<MaterialButton>(R.id.btnResetChecklist).setOnClickListener {
            RailRadarHelper.resetChecklist(this)
            refreshChecklistUi()
            Toast.makeText(this, "Travel checklist reset ho gayi.", Toast.LENGTH_SHORT).show()
        }

        val fcGroup = findViewById<ChipGroup>(R.id.flashcardChipGroup)
        listOf(
            "Maths Flashcards" to "Maths ke voice flashcards shuru karo",
            "Physics Flashcards" to "Physics ke voice flashcards shuru karo",
            "GK Flashcards" to "GK ke voice flashcards shuru karo",
            "Calculus Revision" to "Calculus ke voice flashcards shuru karo"
        ).forEach { (label, cmd) ->
            fcGroup.addView(Chip(this).apply {
                text = label
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand(cmd)
                }
            })
        }

        findViewById<MaterialButton>(R.id.btnBriefing).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Daily briefing")
        }
        findViewById<MaterialButton>(R.id.btnWeather).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Aaj ka weather batao")
        }

        val nearbyGroup = findViewById<ChipGroup>(R.id.nearbyChipGroup)
        listOf("Petrol Pump", "Hospital", "ATM", "Railway Station", "Medical Store", "Restaurant").forEach { place ->
            nearbyGroup.addView(Chip(this).apply {
                text = place
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand("Mere sabse paas $place")
                }
            })
        }

        findViewById<MaterialButton>(R.id.btnAddReminder).setOnClickListener {
            val title = reminderTitleInput.text?.toString()?.trim().orEmpty()
            val mins = reminderMinInput.text?.toString()?.toIntOrNull()?.coerceAtLeast(1) ?: 10
            if (title.isEmpty()) {
                Toast.makeText(this, "Reminder title likho.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val triggerAt = System.currentTimeMillis() + mins * 60_000L
            ReminderStore.add(this, title, triggerAt, reminderRepeatCheck.isChecked)
            reminderTitleInput.setText("")
            refreshRemindersUi()
            Toast.makeText(this, "Reminder set ho gaya!", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.btnAddMemory).setOnClickListener {
            val txt = memoryInput.text?.toString()?.trim().orEmpty()
            if (txt.isEmpty()) return@setOnClickListener
            SmartMemory.addMemory(this, txt)
            memoryInput.setText("")
            refreshMemoriesUi()
            Toast.makeText(this, "Memory save ho gayi.", Toast.LENGTH_SHORT).show()
        }

        val clipGroup = findViewById<ChipGroup>(R.id.clipboardChipGroup)
        listOf(
            "Read" to "Clipboard padho",
            "Summarize" to "Clipboard summarize karo",
            "Translate" to "Clipboard translate karo",
            "Fix Grammar" to "Clipboard grammar correct karo",
            "Draft Reply" to "Clipboard reply banao"
        ).forEach { (label, cmd) ->
            clipGroup.addView(Chip(this).apply {
                text = label
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand(cmd)
                }
            })
        }

        emergNameInput.setText(Prefs.emergencyName(this))
        emergNumberInput.setText(Prefs.emergencyNumber(this))
        findViewById<MaterialButton>(R.id.btnSaveEmergency).setOnClickListener {
            Prefs.setEmergencyContact(
                this,
                emergNameInput.text?.toString().orEmpty(),
                emergNumberInput.text?.toString().orEmpty()
            )
            Toast.makeText(this, "Emergency contact saved.", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnDial112).setOnClickListener {
            executeCommand("Emergency 112")
        }
        findViewById<MaterialButton>(R.id.btnShareEmergLoc).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Emergency location share karo")
        }

        findViewById<MaterialButton>(R.id.btnRefreshPhoneInfo).setOnClickListener {
            refreshPhoneDiagnostics()
        }
    }

    private fun setupSettingsControls() {
        // 30s / 40s session limit
        durationToggleGroup.check(if (Prefs.sessionDurationSeconds(this) == 40) R.id.btnDur40 else R.id.btnDur30)
        durationToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val sec = if (checkedId == R.id.btnDur40) 40 else 30
            Prefs.setSessionDurationSeconds(this, sec)
            Toast.makeText(this, "Command session limit: ${sec}s", Toast.LENGTH_SHORT).show()
        }

        // Reply language preference
        langToggleGroup.check(if (Prefs.replyLanguage(this) == "english") R.id.btnLangEnglish else R.id.btnLangHinglish)
        langToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            Prefs.setReplyLanguage(this, if (checkedId == R.id.btnLangEnglish) "english" else "hinglish")
            notifyServiceSettingsChanged()
        }

        // TTS speed
        val curSpeed = Prefs.ttsSpeed(this)
        ttsSpeedSlider.value = curSpeed
        ttsSpeedLabel.text = String.format(Locale.US, "TTS Speed: %.2fx", curSpeed)
        ttsSpeedSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                Prefs.setTtsSpeed(this, value)
                ttsSpeedLabel.text = String.format(Locale.US, "TTS Speed: %.2fx", value)
                localTts?.setSpeechRate(value)
                notifyServiceSettingsChanged()
            }
        }

        updateVoiceButtonLabel()
        btnPickVoice.setOnClickListener { showVoicePickerDialog() }

        soundFeedbackSwitch.isChecked = Prefs.soundFeedback(this)
        soundFeedbackSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setSoundFeedback(this, checked) }

        batterySaverSwitch.isChecked = Prefs.batterySaver(this)
        batterySaverSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setBatterySaver(this, checked) }

        lowBatteryAlertSwitch.isChecked = Prefs.lowBatteryAlert(this)
        lowBatteryAlertSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setLowBatteryAlert(this, checked) }

        saveHistorySwitch.isChecked = Prefs.saveHistoryRaw(this)
        saveHistorySwitch.setOnCheckedChangeListener { _, checked -> Prefs.setSaveHistory(this, checked) }

        findViewById<MaterialButton>(R.id.btnClearHistory).setOnClickListener {
            SmartMemory.clearHistory(this)
            refreshHistoryUi()
            Toast.makeText(this, "Command history clear ho gayi.", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnClearMemory).setOnClickListener {
            SmartMemory.clearMemories(this)
            refreshMemoriesUi()
            Toast.makeText(this, "Smart memory clear ho gayi.", Toast.LENGTH_SHORT).show()
        }

        // Gemini config
        geminiKeyInput.setText(Prefs.geminiKey(this))
        geminiModelInput.setText(Prefs.geminiModel(this))
        updateGeminiStatusText()
        findViewById<MaterialButton>(R.id.geminiSaveButton).setOnClickListener { saveAndTestGemini() }
        findViewById<MaterialButton>(R.id.btnResetChat).setOnClickListener {
            GeminiClient.clearChatHistory()
            Toast.makeText(this, "Gemini conversation context reset ho gaya.", Toast.LENGTH_SHORT).show()
        }

        // RailRadar Live Train API config (separate from Gemini)
        railRadarKeyInput.setText(Prefs.railRadarKey(this))
        railRadarUrlInput.setText(Prefs.railRadarBaseUrl(this))
        updateRailRadarStatusText()
        findViewById<MaterialButton>(R.id.railRadarSaveButton).setOnClickListener { saveAndTestRailRadar() }

        // Permissions buttons
        findViewById<MaterialButton>(R.id.btnContacts).setOnClickListener {
            extraPermsLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.SEND_SMS
                )
            )
        }
        findViewById<MaterialButton>(R.id.btnLocationPerm).setOnClickListener {
            val perms = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 31) perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            extraPermsLauncher.launch(perms.toTypedArray())
        }
        findViewById<MaterialButton>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<MaterialButton>(R.id.btnNotif).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<MaterialButton>(R.id.btnUsageAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
    }

    override fun onStart() {
        super.onStart()
        NovaState.addListener(stateListener)
    }

    override fun onStop() {
        super.onStop()
        NovaState.removeListener(stateListener)
    }

    override fun onResume() {
        super.onResume()
        index.refresh()
        appCountText.text = "${index.apps.size} installed apps indexed • Nova v6.3"
        continueWakeSetup()
        refreshDashboardTelemetry()
        refreshHistoryUi()
        refreshPerms()
        refreshPhoneDiagnostics()
    }

    override fun onDestroy() {
        runCatching { localTts?.stop(); localTts?.shutdown() }
        super.onDestroy()
    }

    private fun syncWakeSwitches(checked: Boolean) {
        updatingSwitchUi = true
        dashWakeSwitch.isChecked = checked
        wakeSwitch.isChecked = checked
        updatingSwitchUi = false
    }

    private fun continueWakeSetup() {
        val wakeEnabled = Prefs.wake(this)
        syncWakeSwitches(wakeEnabled)
        if (!wakeEnabled) {
            refreshDashboardTelemetry()
            return
        }

        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty() && !askedPermissions) {
            askedPermissions = true
            wakePermsLauncher.launch(need.toTypedArray())
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            Prefs.setWake(this, false)
            syncWakeSwitches(false)
            Toast.makeText(this, "Mic permission chahiye. Settings > Apps > Nova me allow karo.", Toast.LENGTH_LONG).show()
            return
        }

        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            Toast.makeText(this, "Background se apps kholne ke liye 'Display over other apps' allow karo.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !askedBattery) {
            askedBattery = true
            runCatching {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                return
            }
        }

        if (!ListenService.running) {
            ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
        }
        refreshDashboardTelemetry()
    }

    private fun refreshDashboardTelemetry() {
        val wakeOn = Prefs.wake(this)
        syncWakeSwitches(wakeOn)
        val bat = PhoneInfoHelper.battery(this)
        val net = if (PhoneInfoHelper.isOnline(this)) "Online" else "Offline"
        val gemini = if (Prefs.geminiKey(this).isNotEmpty()) "Configured" else "Off"
        val micState = if (NovaState.micActive) "Active" else "Idle"
        val modeStr = when (NovaState.mode) {
            ListenMode.STOPPED -> "OFF"
            ListenMode.LOADING_MODEL -> if (NovaState.modelProgress >= 0) "Downloading ${NovaState.modelProgress}%" else "Loading..."
            ListenMode.WAKE_LISTENING -> "Wake Ready"
            ListenMode.COMMAND_LISTENING -> "Listening (${NovaState.sessionRemainingSec}s)"
            ListenMode.PROCESSING -> "Processing..."
            ListenMode.SPEAKING -> "Speaking"
            ListenMode.ERROR_RECOVERING -> "Recovering..."
        }
        timerBadge.text = if (NovaState.sessionRemainingSec > 0) "${NovaState.sessionRemainingSec}s" else modeStr.uppercase(Locale.ROOT)
        val paused = Prefs.privacyPaused(this)
        btnPrivacyPause.text = if (paused) "Resume Nova (Privacy Mode Active)" else "Pause Everything (Privacy Mode)"
        dashTelemetryText.text = if (paused) {
            "PRIVACY MODE ON • Wake: PAUSED • Mic: OFF\nHistory: PAUSED • AI Context: CLEARED • Battery: ${bat.percent}%"
        } else {
            "Wake: ${if (wakeOn) "ON" else "OFF"} • Mic: $micState • Mode: $modeStr\n" +
            "Limit: ${Prefs.sessionDurationSeconds(this)}s • Gemini: $gemini • Net: $net • Battery: ${bat.percent}%"
        }

        wakeStatus.text = if (wakeOn) NovaState.statusMessage
        else "Band hai. ON karoge to Hey Nova / Hi Nova / Hello Nova / Okay Nova / Nova background me sunega."

        if (NovaState.lastHeard.isNotBlank()) {
            heardText.text = "Suna: ${NovaState.lastHeard}"
        }
        if (NovaState.lastReply.isNotBlank() && ListenService.running) {
            statusText.text = NovaState.lastReply
        }
        confirmBar.visibility = if (ActionExecutor.hasActivePending()) View.VISIBLE else View.GONE
        refreshHistoryUi()
    }

    private fun refreshHistoryUi() {
        val list = SmartMemory.getHistory(this).take(8)
        recentHistoryText.text = if (list.isEmpty()) {
            "Abhi koi recent command nahi hai."
        } else {
            list.joinToString("\n\n") { "• ${it.heard}\n   → ${it.reply.take(90)}" }
        }
    }

    private fun refreshChecklistUi() {
        checklistContainer.removeAllViews()
        val items = RailRadarHelper.getChecklist(this)
        items.forEachIndexed { idx, item ->
            val cb = CheckBox(this).apply {
                text = item.name
                isChecked = item.checked
                textSize = 13f
                setOnCheckedChangeListener { _, _ ->
                    RailRadarHelper.toggleByIndex(this@MainActivity, idx)
                }
            }
            checklistContainer.addView(cb)
        }
    }

    private fun saveAndTestRailRadar() {
        val key = railRadarKeyInput.text?.toString()?.trim()?.replace("\\s+".toRegex(), "").orEmpty()
        val url = railRadarUrlInput.text?.toString()?.trim().orEmpty().ifEmpty { RailRadarHelper.DEFAULT_BASE_URL }
        Prefs.setRailRadar(this, key, url)
        railRadarKeyInput.setText(key)
        railRadarUrlInput.setText(Prefs.railRadarBaseUrl(this))
        updateRailRadarStatusText()
        if (key.isEmpty()) return
        railRadarStatus.text = "Testing RailRadar API key..."
        val usedUrl = Prefs.railRadarBaseUrl(this)
        thread {
            val res = RailRadarHelper.testConnection(key, usedUrl)
            runOnUiThread {
                railRadarStatus.text = res.message
            }
        }
    }

    private fun updateRailRadarStatusText() {
        railRadarStatus.text = if (Prefs.railRadarKey(this).isEmpty()) {
            "RailRadar API key save nahi hai. Live train status ke liye apni RailRadar key yahan save karo."
        } else {
            "RailRadar key saved (${Prefs.railRadarBaseUrl(this)})."
        }
    }

    private fun refreshRemindersUi() {
        reminderListContainer.removeAllViews()
        val items = ReminderStore.all(this)
        if (items.isEmpty()) {
            reminderListContainer.addView(TextView(this).apply {
                text = "Koi active reminder nahi hai."
                alpha = 0.7f
            })
            return
        }
        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 8, 0, 8)
            }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                val rep = if (item.repeatDaily) " (Daily)" else ""
                text = "${item.title}$rep\n${ReminderStore.formatTime(item.triggerAtMs)}"
                textSize = 13f
            }
            val del = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Delete"
                setOnClickListener {
                    ReminderStore.delete(this@MainActivity, item.id)
                    refreshRemindersUi()
                }
            }
            row.addView(tv)
            row.addView(del)
            reminderListContainer.addView(row)
        }
    }

    private fun refreshMemoriesUi() {
        memoryListContainer.removeAllViews()
        val items = SmartMemory.getMemories(this)
        if (items.isEmpty()) {
            memoryListContainer.addView(TextView(this).apply {
                text = "Koi saved memory nahi hai. Bolkar bhi save kar sakte ho: 'Yaad rakho mera favourite app Spotify hai'."
                alpha = 0.7f
            })
            return
        }
        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 6, 0, 6)
            }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = "• ${item.text}"
                textSize = 13f
            }
            val del = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Delete"
                setOnClickListener {
                    SmartMemory.deleteMemory(this@MainActivity, item.id)
                    refreshMemoriesUi()
                }
            }
            row.addView(tv)
            row.addView(del)
            memoryListContainer.addView(row)
        }
    }

    private fun refreshPhoneDiagnostics() {
        phoneInfoText.text = PhoneInfoHelper.fullSummary(this, index)
    }

    private fun refreshPerms() {
        fun tick(ok: Boolean) = if (ok) "✔" else "✘"
        permStatus.text =
            "Mic: ${tick(granted(Manifest.permission.RECORD_AUDIO))}   " +
            "Location: ${tick(NearbyPlacesHelper.hasLocationPermission(this))}\n" +
            "Contacts: ${tick(granted(Manifest.permission.READ_CONTACTS))}   " +
            "Call: ${tick(granted(Manifest.permission.CALL_PHONE))}   " +
            "SMS: ${tick(granted(Manifest.permission.SEND_SMS))}\n" +
            "Accessibility: ${tick(NovaAccessibility.instance != null)}   " +
            "Notifications: ${tick(NovaNotificationListener.connected)}\n" +
            "Usage Access (Screen Time): ${tick(PhoneInfoHelper.hasUsageAccess(this))}"
    }

    private fun saveAndTestGemini() {
        val key = geminiKeyInput.text?.toString()?.trim()?.replace("\\s+".toRegex(), "").orEmpty()
        val model = geminiModelInput.text?.toString()?.trim().orEmpty().ifEmpty { GeminiClient.DEFAULT_MODEL }
        Prefs.setGemini(this, key, model)
        geminiKeyInput.setText(key)
        geminiModelInput.setText(Prefs.geminiModel(this))
        updateGeminiStatusText()
        if (key.isEmpty()) return
        geminiStatus.text = "Testing Gemini API key..."
        val usedModel = Prefs.geminiModel(this)
        thread {
            val outcome = GeminiClient.testAndResolveModel(key, usedModel)
            runOnUiThread {
                if (outcome.ok && outcome.workingModel != usedModel) {
                    Prefs.setGemini(this, key, outcome.workingModel)
                    geminiModelInput.setText(outcome.workingModel)
                }
                geminiStatus.text = outcome.message
                refreshDashboardTelemetry()
            }
        }
    }

    private fun updateGeminiStatusText() {
        geminiStatus.text = if (Prefs.geminiKey(this).isEmpty()) {
            "API key save nahi hai. Offline commands bina key ke bhi chalte hain."
        } else {
            "Key saved (Model: ${Prefs.geminiModel(this)})."
        }
    }

    private fun showVoicePickerDialog() {
        if (availableVoices.isEmpty()) {
            Toast.makeText(this, "Device par extra offline voices nahi mile. Auto Indian voice active hai.", Toast.LENGTH_SHORT).show()
            return
        }
        val items = (listOf("Auto (Best Indian Voice)") + availableVoices).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("TTS Voice Chuno")
            .setItems(items) { _, which ->
                val chosen = if (which == 0) "" else availableVoices[which - 1]
                Prefs.setTtsVoice(this, chosen)
                updateVoiceButtonLabel()
                notifyServiceSettingsChanged()
            }
            .show()
    }

    private fun updateVoiceButtonLabel() {
        val v = Prefs.ttsVoice(this)
        btnPickVoice.text = if (v.isEmpty()) "Voice Selection: Auto Indian Voice" else "Voice: ${v.take(24)}"
    }

    private fun notifyServiceSettingsChanged() {
        if (ListenService.running) {
            startService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_APPLY_SETTINGS))
        }
    }

    private fun startVoicePrompt() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Hinglish me bolo...")
        }
        try {
            speechLauncher.launch(i)
        } catch (_: Exception) {
            statusText.text = "Voice prompt available nahi hai. Neeche type karke chalao."
        }
    }

    private fun submitTypedCommand() {
        val text = commandInput.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) executeCommand(text)
    }

    private fun executeCommand(rawText: String) {
        val hinglish = HinglishConverter.toHinglish(rawText)
        heardText.text = "Suna: $hinglish"

        // Priority #0 Stop check even in foreground UI
        if (WakeStopDetector.isStopCommand(hinglish)) {
            ActionExecutor.clearPending()
            VoiceFlashcardManager.stopSession()
            confirmBar.visibility = View.GONE
            localTts?.stop()
            NovaAccessibility.instance?.stopAgent()
            statusText.text = "Listening band kar di."
            return
        }

        // Active Voice Flashcards answer?
        if (VoiceFlashcardManager.active) {
            val fcReply = VoiceFlashcardManager.handleAnswer(hinglish)
            if (fcReply.isNotEmpty()) {
                showAndSpeakLocalReply(fcReply)
                return
            }
        }

        // Confirmation answer?
        if (ActionExecutor.hasActivePending()) {
            statusText.text = "Confirming..."
            ActionExecutor.handleConfirmationInput(hinglish) { reply ->
                if (reply.isNotEmpty()) {
                    showAndSpeakLocalReply(reply)
                } else {
                    ActionExecutor.clearPending()
                    runResolverAndExecute(hinglish)
                }
            }
            return
        }

        runResolverAndExecute(hinglish)
    }

    private fun runResolverAndExecute(hinglish: String) {
        statusText.text = "Soch raha hoon..."
        Resolver.resolve(this, index, parser, hinglish) { cmd ->
            ActionExecutor.runAsync(this, index, cmd) { reply ->
                showAndSpeakLocalReply(reply)
            }
        }
    }

    private fun showAndSpeakLocalReply(reply: String) {
        statusText.text = reply
        confirmBar.visibility = if (ActionExecutor.hasActivePending()) View.VISIBLE else View.GONE
        refreshDashboardTelemetry()
        refreshChecklistUi()
        refreshRemindersUi()
        refreshMemoriesUi()
        if (!ListenService.running) {
            localTts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "ui-${System.currentTimeMillis()}")
        }
    }

    private fun granted(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
}
