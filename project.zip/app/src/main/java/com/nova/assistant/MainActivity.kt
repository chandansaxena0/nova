package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser
    private var localTts: TextToSpeech? = null
    private var availableVoices: List<String> = emptyList()

    // Tabs
    private lateinit var tabHome: ScrollView
    private lateinit var tabTools: ScrollView
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView

    // Dashboard views
    private lateinit var timerBadge: TextView
    private lateinit var dashWakeSwitch: MaterialSwitch
    private lateinit var activeAgentBadge: TextView
    private lateinit var dashTelemetryText: TextView
    private lateinit var btnPrivacyPause: MaterialButton
    private lateinit var heardText: TextView
    private lateinit var statusText: TextView
    private lateinit var confirmBar: LinearLayout
    private lateinit var commandInput: TextInputEditText
    private lateinit var recentHistoryText: TextView
    private lateinit var historyPillContainer: LinearLayout
    private lateinit var appCountText: TextView

    // Hub views
    private lateinit var tvIpInput: TextInputEditText
    private lateinit var tvStatusText: TextView
    private lateinit var macroTriggerInput: TextInputEditText
    private lateinit var macroActionsInput: TextInputEditText
    private lateinit var macroListContainer: LinearLayout
    private lateinit var expenseSummaryText: TextView
    private lateinit var fileStatusText: TextView
    private lateinit var vaultQueryInput: TextInputEditText
    private lateinit var vaultListContainer: LinearLayout
    private lateinit var fileQuestionInput: TextInputEditText
    private lateinit var btnToggleFlashlight: MaterialButton
    private lateinit var timerMinInput: TextInputEditText
    private lateinit var timerListText: TextView
    private lateinit var taskInput: TextInputEditText
    private lateinit var taskListContainer: LinearLayout
    private lateinit var trainQueryInput: TextInputEditText
    private lateinit var checklistContainer: LinearLayout
    private lateinit var checklistAddInput: TextInputEditText
    private lateinit var reminderTitleInput: TextInputEditText
    private lateinit var reminderMinInput: TextInputEditText
    private lateinit var reminderRepeatCheck: CheckBox
    private lateinit var reminderListContainer: LinearLayout
    private lateinit var memoryInput: TextInputEditText
    private lateinit var memoryListContainer: LinearLayout
    private lateinit var emergNameInput: TextInputEditText
    private lateinit var emergNumberInput: TextInputEditText
    private lateinit var phoneInfoText: TextView

    // Settings views
    private lateinit var wakeSwitch: MaterialSwitch
    private lateinit var wakeStatus: TextView
    private lateinit var wakeSensLabel: TextView
    private lateinit var wakeSensSlider: Slider
    private lateinit var strictWakeVerifySwitch: MaterialSwitch
    private lateinit var powerModeGroup: MaterialButtonToggleGroup
    private lateinit var fallbackProviderGroup: MaterialButtonToggleGroup
    private lateinit var dailyAiLimitInput: TextInputEditText
    private lateinit var settingsSearchInput: TextInputEditText
    private lateinit var settingsCardsContainer: LinearLayout
    private lateinit var headsetAutoMusicSwitch: MaterialSwitch
    private lateinit var headsetReadNotifsSwitch: MaterialSwitch
    private lateinit var bargeInSwitch: MaterialSwitch
    private lateinit var volumeTriggerSwitch: MaterialSwitch
    private lateinit var callerAnnounceGroup: MaterialButtonToggleGroup
    private lateinit var wakeVoiceReplySwitch: MaterialSwitch
    private lateinit var durationToggleGroup: MaterialButtonToggleGroup
    private lateinit var diagnosticsText: TextView
    private lateinit var langToggleGroup: MaterialButtonToggleGroup
    private lateinit var ttsSpeedLabel: TextView
    private lateinit var ttsSpeedSlider: Slider
    private lateinit var btnPickVoice: MaterialButton
    private lateinit var soundFeedbackSwitch: MaterialSwitch
    private lateinit var batterySaverSwitch: MaterialSwitch
    private lateinit var lowBatteryAlertSwitch: MaterialSwitch
    private lateinit var saveHistorySwitch: MaterialSwitch
    private lateinit var geminiKeyInput: TextInputEditText
    private lateinit var geminiModelInput: TextInputEditText
    private lateinit var geminiStatus: TextView
    private lateinit var railRadarKeyInput: TextInputEditText
    private lateinit var railRadarUrlInput: TextInputEditText
    private lateinit var railRadarStatus: TextView
    private lateinit var permStatus: TextView

    private var askedPermissions = false
    private var askedOverlay = false
    private var askedBattery = false
    private var updatingSwitchUi = false

    private val stateListener: () -> Unit = { refreshDashboardTelemetry() }

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                val spoken = r.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    val hinglish = HinglishConverter.toHinglish(spoken)
                    commandInput.setText(hinglish)
                    executeCommand(hinglish)
                }
            }
        }

    private val filePickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) handlePickedFile(uri)
        }

    private val screenshotPickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) handlePickedFile(uri, isScreenshot = true)
        }

    private val wakePermsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            continueWakeSetup()
        }

    private val extraPermsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshPerms()
            refreshPhoneDiagnostics()
            refreshDiagnosticsUi()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        index = AppIndex(this)
        parser = CommandParser(index)
        initLocalTts()

        bindViews()
        setupBottomNav()
        setupDashboardControls()
        setupHubControls()
        setupSettingsControls()

        if (intent.getBooleanExtra("autostart", false)) {
            intent.removeExtra("autostart")
            if (!Prefs.privacyPaused(this)) {
                Prefs.setWake(this, true)
            }
        }
    }

    private fun initLocalTts() {
        localTts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                localTts?.language = if (Prefs.replyLanguage(this) == "english") Locale("en", "IN") else Locale("hi", "IN")
                localTts?.setSpeechRate(Prefs.ttsSpeed(this))
                availableVoices = localTts?.voices
                    ?.filter { it.locale.language in setOf("en", "hi") && !it.isNetworkConnectionRequired }
                    ?.map { it.name }
                    ?.sorted()
                    .orEmpty()
            }
        }
    }

    private fun bindViews() {
        tabHome = findViewById(R.id.tabHome)
        tabTools = findViewById(R.id.tabTools)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)

        timerBadge = findViewById(R.id.timerBadge)
        dashWakeSwitch = findViewById(R.id.dashWakeSwitch)
        activeAgentBadge = findViewById(R.id.activeAgentBadge)
        dashTelemetryText = findViewById(R.id.dashTelemetryText)
        btnPrivacyPause = findViewById(R.id.btnPrivacyPause)
        heardText = findViewById(R.id.heardText)
        statusText = findViewById(R.id.statusText)
        confirmBar = findViewById(R.id.confirmBar)
        commandInput = findViewById(R.id.commandInput)
        recentHistoryText = findViewById(R.id.recentHistoryText)
        historyPillContainer = findViewById(R.id.historyPillContainer)
        appCountText = findViewById(R.id.appCountText)

        tvIpInput = findViewById(R.id.tvIpInput)
        tvStatusText = findViewById(R.id.tvStatusText)
        macroTriggerInput = findViewById(R.id.macroTriggerInput)
        macroActionsInput = findViewById(R.id.macroActionsInput)
        macroListContainer = findViewById(R.id.macroListContainer)
        expenseSummaryText = findViewById(R.id.expenseSummaryText)
        fileStatusText = findViewById(R.id.fileStatusText)
        vaultQueryInput = findViewById(R.id.vaultQueryInput)
        vaultListContainer = findViewById(R.id.vaultListContainer)
        fileQuestionInput = findViewById(R.id.fileQuestionInput)
        btnToggleFlashlight = findViewById(R.id.btnToggleFlashlight)
        timerMinInput = findViewById(R.id.timerMinInput)
        timerListText = findViewById(R.id.timerListText)
        taskInput = findViewById(R.id.taskInput)
        taskListContainer = findViewById(R.id.taskListContainer)
        trainQueryInput = findViewById(R.id.trainQueryInput)
        checklistContainer = findViewById(R.id.checklistContainer)
        checklistAddInput = findViewById(R.id.checklistAddInput)
        reminderTitleInput = findViewById(R.id.reminderTitleInput)
        reminderMinInput = findViewById(R.id.reminderMinInput)
        reminderRepeatCheck = findViewById(R.id.reminderRepeatCheck)
        reminderListContainer = findViewById(R.id.reminderListContainer)
        memoryInput = findViewById(R.id.memoryInput)
        memoryListContainer = findViewById(R.id.memoryListContainer)
        emergNameInput = findViewById(R.id.emergNameInput)
        emergNumberInput = findViewById(R.id.emergNumberInput)
        phoneInfoText = findViewById(R.id.phoneInfoText)

        wakeSwitch = findViewById(R.id.wakeSwitch)
        wakeStatus = findViewById(R.id.wakeStatus)
        wakeSensLabel = findViewById(R.id.wakeSensLabel)
        wakeSensSlider = findViewById(R.id.wakeSensSlider)
        strictWakeVerifySwitch = findViewById(R.id.strictWakeVerifySwitch)
        powerModeGroup = findViewById(R.id.powerModeGroup)
        fallbackProviderGroup = findViewById(R.id.fallbackProviderGroup)
        dailyAiLimitInput = findViewById(R.id.dailyAiLimitInput)
        settingsSearchInput = findViewById(R.id.settingsSearchInput)
        settingsCardsContainer = findViewById(R.id.settingsCardsContainer)
        headsetAutoMusicSwitch = findViewById(R.id.headsetAutoMusicSwitch)
        headsetReadNotifsSwitch = findViewById(R.id.headsetReadNotifsSwitch)
        bargeInSwitch = findViewById(R.id.bargeInSwitch)
        volumeTriggerSwitch = findViewById(R.id.volumeTriggerSwitch)
        callerAnnounceGroup = findViewById(R.id.callerAnnounceGroup)
        wakeVoiceReplySwitch = findViewById(R.id.wakeVoiceReplySwitch)
        durationToggleGroup = findViewById(R.id.durationToggleGroup)
        diagnosticsText = findViewById(R.id.diagnosticsText)
        langToggleGroup = findViewById(R.id.langToggleGroup)
        ttsSpeedLabel = findViewById(R.id.ttsSpeedLabel)
        ttsSpeedSlider = findViewById(R.id.ttsSpeedSlider)
        btnPickVoice = findViewById(R.id.btnPickVoice)
        soundFeedbackSwitch = findViewById(R.id.soundFeedbackSwitch)
        batterySaverSwitch = findViewById(R.id.batterySaverSwitch)
        lowBatteryAlertSwitch = findViewById(R.id.lowBatteryAlertSwitch)
        saveHistorySwitch = findViewById(R.id.saveHistorySwitch)
        geminiKeyInput = findViewById(R.id.geminiKeyInput)
        geminiModelInput = findViewById(R.id.geminiModelInput)
        geminiStatus = findViewById(R.id.geminiStatus)
        railRadarKeyInput = findViewById(R.id.railRadarKeyInput)
        railRadarUrlInput = findViewById(R.id.railRadarUrlInput)
        railRadarStatus = findViewById(R.id.railRadarStatus)
        permStatus = findViewById(R.id.permStatus)
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            tabHome.visibility = if (item.itemId == R.id.nav_home) View.VISIBLE else View.GONE
            tabTools.visibility = if (item.itemId == R.id.nav_tools) View.VISIBLE else View.GONE
            tabSettings.visibility = if (item.itemId == R.id.nav_settings) View.VISIBLE else View.GONE
            if (item.itemId == R.id.nav_tools) {
                refreshHubAll()
            }
            if (item.itemId == R.id.nav_settings) {
                refreshPerms()
                refreshDiagnosticsUi()
            }
            true
        }
    }

    private fun setupDashboardControls() {
        val wakeToggleHandler: (Boolean) -> Unit = { checked ->
            if (!updatingSwitchUi) {
                if (checked && Prefs.privacyPaused(this)) {
                    Prefs.setPrivacyPaused(this, false)
                }
                Prefs.setWake(this, checked)
                syncWakeSwitches(checked)
                if (checked) {
                    askedPermissions = false
                    askedOverlay = false
                    askedBattery = false
                    continueWakeSetup()
                } else {
                    stopListenServiceCleanly()
                    refreshDashboardTelemetry()
                }
            }
        }
        dashWakeSwitch.setOnCheckedChangeListener { _, checked -> wakeToggleHandler(checked) }
        wakeSwitch.setOnCheckedChangeListener { _, checked -> wakeToggleHandler(checked) }

        // Manual Mic button also interrupts Nova cleanly while speaking
        findViewById<FloatingActionButton>(R.id.micButton).setOnClickListener {
            localTts?.stop()
            if (ListenService.running) {
                startService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_INTERRUPT_AND_LISTEN))
                Toast.makeText(this, "Nova is listening...", Toast.LENGTH_SHORT).show()
            } else {
                startVoicePrompt()
            }
        }

        findViewById<View>(R.id.btnTopMenu)?.setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_settings
            tabSettings.post { tabSettings.scrollTo(0, 0) }
        }
        findViewById<View>(R.id.cardTalkNova)?.setOnClickListener {
            findViewById<FloatingActionButton>(R.id.micButton).performClick()
        }
        findViewById<View>(R.id.cardChatNova)?.setOnClickListener {
            commandInput.requestFocus()
        }
        findViewById<View>(R.id.cardSearchImage)?.setOnClickListener {
            screenshotPickerLauncher.launch(arrayOf("image/*"))
        }
        findViewById<View>(R.id.btnSeeAllHistory)?.setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_tools
        }
        findViewById<MaterialButton>(R.id.goButton).setOnClickListener { submitTypedCommand() }
        findViewById<MaterialButton>(R.id.stopNowButton).setOnClickListener {
            AiRouter.cancelActiveRequest()
            MacroStore.cancelActiveWorkflow()
            NovaOrchestrator.clearActiveTask()
            ActionExecutor.clearPending()
            VoiceFlashcardManager.stopSession()
            InterviewVivaManager.stopSession()
            confirmBar.visibility = View.GONE
            localTts?.stop()
            NovaAccessibility.instance?.stopAgent()
            if (ListenService.running) {
                startService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_STOP_AGENT))
            }
            statusText.text = "Speech stopped."
        }

        btnPrivacyPause.setOnClickListener {
            localTts?.stop()
            if (Prefs.privacyPaused(this)) {
                val msg = ActionExecutor.resumeFromPrivacyPause(this)
                statusText.text = msg
                Toast.makeText(this, "Nova Resumed!", Toast.LENGTH_SHORT).show()
            } else {
                val msg = ActionExecutor.pauseEverything(this)
                confirmBar.visibility = View.GONE
                statusText.text = msg
                Toast.makeText(this, "Privacy Mode ON — Everything Paused", Toast.LENGTH_SHORT).show()
            }
            refreshDashboardTelemetry()
        }

        findViewById<MaterialButton>(R.id.btnConfirmYes).setOnClickListener { executeCommand("Haan") }
        findViewById<MaterialButton>(R.id.btnConfirmNo).setOnClickListener { executeCommand("Nahi") }

        commandInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitTypedCommand()
                true
            } else false
        }

        val chips = findViewById<ChipGroup>(R.id.chipGroup)
        listOf(
            "Wi-Fi off karo",
            "Hotspot on karo",
            "Bluetooth on karo",
            "TV par YouTube kholo",
            "TV volume badhao",
            "Flashlight on karo aur volume 70 percent karo",
            "5000 par 18 percent GST kitna hoga",
            "Screenshot lo",
            "Train 12562 kahan pahunchi",
            "10 minute ka timer lagao"
        ).forEach { sample ->
            chips.addView(Chip(this).apply {
                text = sample
                setOnClickListener {
                    commandInput.setText(sample)
                    executeCommand(sample)
                }
            })
        }
    }

    private fun setupHubControls() {
        // Smart TV Voice Control & Built-in Remote
        tvIpInput.setText(Prefs.tvIp(this))
        findViewById<MaterialButton>(R.id.btnScanTv).setOnClickListener {
            tvStatusText.text = "Scanning Wi-Fi / Hotspot for Smart TV (port 5555)..."
            thread {
                val found = SmartTvController.scanLocalTvs()
                runOnUiThread {
                    if (found.isNotEmpty()) {
                        val ip = found.first()
                        Prefs.setTvIp(this, ip)
                        tvIpInput.setText(ip)
                        tvStatusText.text = "Found Smart TV at $ip! Tap 'Pair / Test' and accept Allow on TV."
                    } else {
                        tvStatusText.text = "No Smart TV found on port 5555. Enable USB/Network Debugging on TV or enter TV IP manually."
                    }
                }
            }
        }
        findViewById<MaterialButton>(R.id.btnPairTv).setOnClickListener {
            val ip = tvIpInput.text?.toString()?.trim().orEmpty()
            tvStatusText.text = "Connecting to $ip... Check TV screen for 'Allow USB debugging' popup!"
            thread {
                val msg = SmartTvController.testAndPair(this, ip)
                runOnUiThread { tvStatusText.text = msg }
            }
        }
        findViewById<MaterialButton>(R.id.btnTvGuide).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Smart TV Voice Control Setup")
                .setMessage(SmartTvController.setupInstructions())
                .setPositiveButton("Got it", null)
                .show()
        }
        fun runTvTap(op: String, arg: String = "") {
            val ip = tvIpInput.text?.toString()?.trim().orEmpty()
            if (ip.isNotEmpty()) Prefs.setTvIp(this, ip)
            thread {
                val msg = SmartTvController.handleVoiceCommand(this, op, arg)
                runOnUiThread {
                    tvStatusText.text = msg
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }
        findViewById<MaterialButton>(R.id.btnTvPower).setOnClickListener { runTvTap("power_toggle") }
        findViewById<MaterialButton>(R.id.btnTvVolDown).setOnClickListener { runTvTap("vol_down", "2") }
        findViewById<MaterialButton>(R.id.btnTvVolUp).setOnClickListener { runTvTap("vol_up", "2") }
        findViewById<MaterialButton>(R.id.btnTvMute).setOnClickListener { runTvTap("mute") }
        findViewById<MaterialButton>(R.id.btnTvBack).setOnClickListener { runTvTap("back") }
        findViewById<MaterialButton>(R.id.btnTvHome).setOnClickListener { runTvTap("home") }
        findViewById<MaterialButton>(R.id.btnTvPlayPause).setOnClickListener { runTvTap("play_pause") }
        findViewById<MaterialButton>(R.id.btnTvYouTube).setOnClickListener { runTvTap("open_app", "youtube") }

        // Connectivity Quick Toggles
        findViewById<MaterialButton>(R.id.btnToggleWifi).setOnClickListener { executeCommand("Wi-Fi toggle karo") }
        findViewById<MaterialButton>(R.id.btnToggleBt).setOnClickListener { executeCommand("Bluetooth toggle karo") }
        findViewById<MaterialButton>(R.id.btnToggleData).setOnClickListener { executeCommand("Mobile data toggle karo") }
        findViewById<MaterialButton>(R.id.btnToggleHotspot).setOnClickListener { executeCommand("Hotspot toggle karo") }

        // Custom Voice Shortcuts (Macros)
        findViewById<MaterialButton>(R.id.btnAddMacro).setOnClickListener {
            val trig = macroTriggerInput.text?.toString()?.trim().orEmpty()
            val acts = macroActionsInput.text?.toString()?.trim().orEmpty()
            if (MacroStore.save(this, trig, acts)) {
                macroTriggerInput.setText("")
                macroActionsInput.setText("")
                refreshMacrosUi()
                Toast.makeText(this, "Voice shortcut saved!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enter both trigger phrase and actions.", Toast.LENGTH_SHORT).show()
            }
        }

        // Expense Ledger Quick Buttons
        findViewById<MaterialButton>(R.id.btnExpenseToday).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Aaj kitna kharch hua")
        }
        findViewById<MaterialButton>(R.id.btnExpenseMonth).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Is mahine ka kharcha batao")
        }
        findViewById<MaterialButton>(R.id.btnExpenseClear).setOnClickListener {
            ExpenseTrackerStore.handleVoice(this, "clear", "")
            refreshExpenseUi()
        refreshVaultUi()
            Toast.makeText(this, "Expense records cleared.", Toast.LENGTH_SHORT).show()
        }

        // File Assistant
        findViewById<MaterialButton>(R.id.btnPickFile).setOnClickListener {
            filePickerLauncher.launch(
                arrayOf(
                    "application/pdf",
                    "text/plain",
                    "text/markdown",
                    "text/csv",
                    "text/*",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    "image/*"
                )
            )
        }
        findViewById<MaterialButton>(R.id.btnClearFile).setOnClickListener {
            FileAssistant.clearActiveDoc()
            fileStatusText.text = FileAssistant.activeDocSummaryLabel()
            Toast.makeText(this, "Loaded document cleared.", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnSaveToVault).setOnClickListener {
            val msg = KnowledgeBaseStore.saveCurrentLoadedDoc(this)
            refreshVaultUi()
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
        findViewById<MaterialButton>(R.id.btnCameraLens).setOnClickListener {
            startActivity(Intent(this, CameraLensActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnAskVault).setOnClickListener {
            val q = vaultQueryInput.text?.toString()?.trim().orEmpty()
            if (q.isEmpty()) return@setOnClickListener
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Vault me se $q")
            vaultQueryInput.setText("")
        }
        findViewById<MaterialButton>(R.id.btnAskFile).setOnClickListener {
            val q = fileQuestionInput.text?.toString()?.trim().orEmpty()
            if (q.isEmpty()) return@setOnClickListener
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("File question: $q")
            fileQuestionInput.setText("")
        }

        // Screen Understanding & Notification Intelligence
        findViewById<MaterialButton>(R.id.btnAnalyzeScreen).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Screen samjhao")
        }
        findViewById<MaterialButton>(R.id.btnAnalyzeScreenshot).setOnClickListener {
            screenshotPickerLauncher.launch(arrayOf("image/*"))
        }
        findViewById<MaterialButton>(R.id.btnSummarizeNotifs).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Mere notifications summarize karo")
        }

        // Phone Quick Controls
        btnToggleFlashlight.setOnClickListener {
            val next = !PhoneControlHelper.torchOn
            val msg = PhoneControlHelper.setFlashlight(this, next)
            btnToggleFlashlight.text = if (PhoneControlHelper.torchOn) "Flashlight: ON" else "Flashlight: OFF"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnWifiSettings).setOnClickListener {
            PhoneControlHelper.openSettingsPage(this, "wifi")
        }
        findViewById<MaterialButton>(R.id.btnBluetoothSettings).setOnClickListener {
            PhoneControlHelper.openSettingsPage(this, "bluetooth")
        }

        // Timers, Routines & Tasks
        findViewById<MaterialButton>(R.id.btnStartTimer).setOnClickListener {
            val mins = timerMinInput.text?.toString()?.toLongOrNull()?.coerceAtLeast(1L) ?: 10L
            TimerManager.startTimer(this, mins * 60L, "Timer (${mins}m)")
            refreshTimersUi()
            Toast.makeText(this, "$mins minute timer started!", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnCancelTimers).setOnClickListener {
            TimerManager.cancelAll(this)
            refreshTimersUi()
            Toast.makeText(this, "Active timers cleared.", Toast.LENGTH_SHORT).show()
        }

        val routineGroup = findViewById<ChipGroup>(R.id.routineChipGroup)
        listOf(
            "Morning Routine" to "Morning routine chalu karo",
            "Study Mode (25m)" to "Study routine chalu karo",
            "Travel Prep" to "Travel routine chalu karo",
            "Work Sprint (45m)" to "Work routine chalu karo",
            "Sleep Mode" to "Sleep routine chalu karo"
        ).forEach { (label, cmd) ->
            routineGroup.addView(Chip(this).apply {
                text = label
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand(cmd)
                }
            })
        }

        findViewById<MaterialButton>(R.id.btnAddTask).setOnClickListener {
            val title = taskInput.text?.toString()?.trim().orEmpty()
            if (title.isEmpty()) return@setOnClickListener
            DailyPlannerStore.addTask(this, title)
            taskInput.setText("")
            refreshTasksUi()
        }

        // Travel Agent: RailRadar & Checklist
        findViewById<MaterialButton>(R.id.btnAskTrain).setOnClickListener {
            val q = trainQueryInput.text?.toString()?.trim().orEmpty()
            if (q.isEmpty()) {
                Toast.makeText(this, "Enter train number or name (e.g. 12562).", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Train $q kahan pahunchi aur depart time kya hai")
        }
        findViewById<MaterialButton>(R.id.btnAddChecklistItem).setOnClickListener {
            val item = checklistAddInput.text?.toString()?.trim().orEmpty()
            if (item.isEmpty()) return@setOnClickListener
            RailRadarHelper.addChecklistItem(this, item)
            checklistAddInput.setText("")
            refreshChecklistUi()
        }
        findViewById<MaterialButton>(R.id.btnResetChecklist).setOnClickListener {
            RailRadarHelper.resetChecklist(this)
            refreshChecklistUi()
            Toast.makeText(this, "Travel checklist reset.", Toast.LENGTH_SHORT).show()
        }

        // Study Agent: Voice Flashcards
        val fcGroup = findViewById<ChipGroup>(R.id.flashcardChipGroup)
        listOf(
            "Maths Flashcards" to "Maths ke voice flashcards shuru karo",
            "Physics Flashcards" to "Physics ke voice flashcards shuru karo",
            "Chemistry Flashcards" to "Chemistry ke voice flashcards shuru karo",
            "Biology Flashcards" to "Biology ke voice flashcards shuru karo",
            "English Grammar" to "English grammar ke voice flashcards shuru karo",
            "GK Flashcards" to "GK ke voice flashcards shuru karo"
        ).forEach { (label, cmd) ->
            fcGroup.addView(Chip(this).apply {
                text = label
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand(cmd)
                }
            })
        }

        findViewById<MaterialButton>(R.id.btnStudyProgress).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Study progress batao")
        }
        findViewById<MaterialButton>(R.id.btnStartAirforceViva).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Airforce interview practice shuru karo")
        }
        findViewById<MaterialButton>(R.id.btnStartPhysicsViva).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Physics viva shuru karo")
        }

        // Briefing, Weather & Nearby
        findViewById<MaterialButton>(R.id.btnBriefing).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Daily briefing")
        }
        findViewById<MaterialButton>(R.id.btnWeather).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Aaj ka weather batao")
        }
        val nearbyGroup = findViewById<ChipGroup>(R.id.nearbyChipGroup)
        listOf("Petrol Pump", "Hospital", "ATM", "Railway Station", "Medical Store", "Restaurant").forEach { place ->
            nearbyGroup.addView(Chip(this).apply {
                text = place
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand("Mere sabse paas $place")
                }
            })
        }

        // Reminders
        findViewById<MaterialButton>(R.id.btnAddReminder).setOnClickListener {
            val title = reminderTitleInput.text?.toString()?.trim().orEmpty()
            val mins = reminderMinInput.text?.toString()?.toIntOrNull()?.coerceAtLeast(1) ?: 10
            if (title.isEmpty()) {
                Toast.makeText(this, "Enter reminder title.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            ReminderStore.add(this, title, System.currentTimeMillis() + mins * 60_000L, reminderRepeatCheck.isChecked)
            reminderTitleInput.setText("")
            refreshRemindersUi()
            Toast.makeText(this, "Reminder scheduled!", Toast.LENGTH_SHORT).show()
        }

        // Smart Memory (with sensitive data guard)
        findViewById<MaterialButton>(R.id.btnAddMemory).setOnClickListener {
            val txt = memoryInput.text?.toString()?.trim().orEmpty()
            if (txt.isEmpty()) return@setOnClickListener
            if (SmartMemory.isSensitive(txt)) {
                Toast.makeText(this, "Sensitive info (passwords/OTP/PIN/ID) is blocked from memory for safety.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            SmartMemory.addMemory(this, txt)
            memoryInput.setText("")
            refreshMemoriesUi()
            Toast.makeText(this, "Preference saved.", Toast.LENGTH_SHORT).show()
        }

        // Clipboard
        val clipGroup = findViewById<ChipGroup>(R.id.clipboardChipGroup)
        listOf(
            "Read" to "Clipboard padho",
            "Summarize" to "Clipboard summarize karo",
            "Translate" to "Clipboard translate karo",
            "Fix Grammar" to "Clipboard grammar correct karo",
            "Draft Reply" to "Clipboard reply banao"
        ).forEach { (label, cmd) ->
            clipGroup.addView(Chip(this).apply {
                text = label
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand(cmd)
                }
            })
        }

        // Emergency
        emergNameInput.setText(Prefs.emergencyName(this))
        emergNumberInput.setText(Prefs.emergencyNumber(this))
        findViewById<MaterialButton>(R.id.btnSaveEmergency).setOnClickListener {
            Prefs.setEmergencyContact(this, emergNameInput.text?.toString().orEmpty(), emergNumberInput.text?.toString().orEmpty())
            Toast.makeText(this, "Emergency contact saved.", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnDial112).setOnClickListener { executeCommand("Emergency 112") }
        findViewById<MaterialButton>(R.id.btnShareEmergLoc).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_home
            executeCommand("Emergency location share karo")
        }

        findViewById<MaterialButton>(R.id.btnRefreshPhoneInfo).setOnClickListener { refreshPhoneDiagnostics() }
    }

    private fun setupSettingsControls() {
        // Wake sensitivity slider (0.45..0.85, default 0.60f, snapped safely to 0.05 step)
        val curThresh = Prefs.wakeThreshold(this)
        setSliderSafely(wakeSensSlider, curThresh, 0.60f)
        wakeSensLabel.text = String.format(Locale.US, "Wake Threshold: %.2f (Higher = stricter, Lower = easier trigger)", curThresh)
        wakeSensSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                val clean = Prefs.snapStep05(value, 0.45f, 0.85f)
                Prefs.setWakeThreshold(this, clean)
                wakeSensLabel.text = String.format(Locale.US, "Wake Threshold: %.2f (Higher = stricter, Lower = easier trigger)", clean)
                notifyServiceSettingsChanged()
            }
        }

        strictWakeVerifySwitch.isChecked = Prefs.strictWakeVerify(this)
        strictWakeVerifySwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setStrictWakeVerify(this, checked)
            notifyServiceSettingsChanged()
        }

        // 3 Power Modes (Battery Saver / Balanced / High Responsiveness)
        powerModeGroup.check(
            when (Prefs.powerMode(this)) {
                Prefs.POWER_BATTERY_SAVER -> R.id.btnPowerSaver
                Prefs.POWER_HIGH -> R.id.btnPowerHigh
                else -> R.id.btnPowerBalanced
            }
        )
        powerModeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val mode = when (checkedId) {
                R.id.btnPowerSaver -> Prefs.POWER_BATTERY_SAVER
                R.id.btnPowerHigh -> Prefs.POWER_HIGH
                else -> Prefs.POWER_BALANCED
            }
            Prefs.setPowerMode(this, mode)
            batterySaverSwitch.isChecked = (mode == Prefs.POWER_BATTERY_SAVER)
            notifyServiceSettingsChanged()
            Toast.makeText(this, "Power Mode: $mode", Toast.LENGTH_SHORT).show()
        }

        // Searchable Settings live filter
        settingsSearchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterSettingsCards(s?.toString().orEmpty())
            }
        })

        // Export Sanitized Diagnostics & Export Memories JSON
        findViewById<MaterialButton>(R.id.btnExportDiag).setOnClickListener {
            val report = NovaDiagnostics.buildSanitizedExportReport(this)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Nova v10.0 Diagnostic Report")
                putExtra(Intent.EXTRA_TEXT, report)
            }
            startActivity(Intent.createChooser(share, "Share Diagnostic Report"))
        }
        findViewById<MaterialButton>(R.id.btnExportMemories).setOnClickListener {
            val json = SmartMemory.exportMemoriesJson(this)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Nova Memories Backup")
                putExtra(Intent.EXTRA_TEXT, json)
            }
            startActivity(Intent.createChooser(share, "Export Nova Memories"))
        }

        wakeVoiceReplySwitch.isChecked = Prefs.wakeVoiceReply(this)
        wakeVoiceReplySwitch.setOnCheckedChangeListener { _, checked -> Prefs.setWakeVoiceReply(this, checked) }

        // 15s / 30s / 40s follow-up timeout
        val durId = when (Prefs.sessionDurationSeconds(this)) {
            15 -> R.id.btnDur15
            40 -> R.id.btnDur40
            else -> R.id.btnDur30
        }
        durationToggleGroup.check(durId)
        durationToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val sec = when (checkedId) {
                R.id.btnDur15 -> 15
                R.id.btnDur40 -> 40
                else -> 30
            }
            Prefs.setSessionDurationSeconds(this, sec)
            Toast.makeText(this, "Follow-up timeout: ${sec}s", Toast.LENGTH_SHORT).show()
        }

        // Vivo / iQOO Setup Guide
        findViewById<MaterialButton>(R.id.btnVivoGuide).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Vivo / iQOO Background Reliability")
                .setMessage(NovaDiagnostics.vivoSetupInstructions())
                .setPositiveButton("Open Settings Now") { _, _ ->
                    val msg = NovaDiagnostics.openOemBackgroundSettings(this)
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
                .setNegativeButton("Close", null)
                .show()
        }

        findViewById<MaterialButton>(R.id.btnRefreshDiag).setOnClickListener { refreshDiagnosticsUi() }

        // Language & TTS
        langToggleGroup.check(if (Prefs.replyLanguage(this) == "english") R.id.btnLangEnglish else R.id.btnLangHinglish)
        langToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            Prefs.setReplyLanguage(this, if (checkedId == R.id.btnLangEnglish) "english" else "hinglish")
            localTts?.language = if (checkedId == R.id.btnLangEnglish) Locale("en", "IN") else Locale("hi", "IN")
            notifyServiceSettingsChanged()
        }

        val curSpeed = Prefs.ttsSpeed(this)
        setSliderSafely(ttsSpeedSlider, curSpeed, 1.05f)
        ttsSpeedLabel.text = String.format(Locale.US, "TTS Speed: %.2fx", curSpeed)
        ttsSpeedSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                val clean = Prefs.snapStep05(value, 0.75f, 1.50f)
                Prefs.setTtsSpeed(this, clean)
                ttsSpeedLabel.text = String.format(Locale.US, "TTS Speed: %.2fx", clean)
                localTts?.setSpeechRate(clean)
                notifyServiceSettingsChanged()
            }
        }

        updateVoiceButtonLabel()
        btnPickVoice.setOnClickListener { showVoicePickerDialog() }

        soundFeedbackSwitch.isChecked = Prefs.soundFeedback(this)
        soundFeedbackSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setSoundFeedback(this, checked) }

        batterySaverSwitch.isChecked = Prefs.batterySaver(this)
        batterySaverSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setBatterySaver(this, checked)
            notifyServiceSettingsChanged()
        }

        lowBatteryAlertSwitch.isChecked = Prefs.lowBatteryAlert(this)
        lowBatteryAlertSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setLowBatteryAlert(this, checked) }

        saveHistorySwitch.isChecked = Prefs.saveHistoryRaw(this)
        saveHistorySwitch.setOnCheckedChangeListener { _, checked -> Prefs.setSaveHistory(this, checked) }

        findViewById<MaterialButton>(R.id.btnClearHistory).setOnClickListener {
            SmartMemory.clearHistory(this)
            refreshHistoryUi()
            Toast.makeText(this, "History cleared.", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnClearMemory).setOnClickListener {
            SmartMemory.clearMemories(this)
            refreshMemoriesUi()
            Toast.makeText(this, "All memories reset.", Toast.LENGTH_SHORT).show()
        }

        // Gemini config (working auth preserved)
        val aiGroup = findViewById<MaterialButtonToggleGroup>(R.id.aiProviderGroup)
        aiGroup.check(
            when (Prefs.aiProvider(this)) {
                OpenAiCompat.GROK -> R.id.btnAiGrok
                OpenAiCompat.OPENROUTER -> R.id.btnAiOpenRouter
                else -> R.id.btnAiGemini
            }
        )
        aiGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            Prefs.setAiProvider(
                this,
                when (checkedId) {
                    R.id.btnAiGrok -> OpenAiCompat.GROK
                    R.id.btnAiOpenRouter -> OpenAiCompat.OPENROUTER
                    else -> OpenAiCompat.GEMINI
                }
            )
            loadAiFields()
        }
        loadAiFields()
        findViewById<MaterialButton>(R.id.geminiSaveButton).setOnClickListener { saveAndTestGemini() }
        findViewById<MaterialButton>(R.id.btnClearAiKey).setOnClickListener {
            val prov = Prefs.aiProvider(this)
            Prefs.clearAiKey(this, prov)
            loadAiFields()
            refreshDashboardTelemetry()
            Toast.makeText(this, "${OpenAiCompat.label(prov)} API key removed.", Toast.LENGTH_SHORT).show()
        }
        fallbackProviderGroup.check(
            when (Prefs.secondaryAiProvider(this)) {
                OpenAiCompat.GEMINI -> R.id.btnFallbackGemini
                OpenAiCompat.GROK -> R.id.btnFallbackGrok
                OpenAiCompat.OPENROUTER -> R.id.btnFallbackOpenRouter
                else -> R.id.btnFallbackNone
            }
        )
        fallbackProviderGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val sec = when (checkedId) {
                R.id.btnFallbackGemini -> OpenAiCompat.GEMINI
                R.id.btnFallbackGrok -> OpenAiCompat.GROK
                R.id.btnFallbackOpenRouter -> OpenAiCompat.OPENROUTER
                else -> "none"
            }
            Prefs.setSecondaryAiProvider(this, sec)
            refreshDiagnosticsUi()
        }
        dailyAiLimitInput.setText(Prefs.dailyAiLimit(this).toString())
        findViewById<MaterialButton>(R.id.btnSaveAiLimit).setOnClickListener {
            val lim = dailyAiLimitInput.text?.toString()?.trim()?.toIntOrNull() ?: 0
            Prefs.setDailyAiLimit(this, lim)
            dailyAiLimitInput.setText(Prefs.dailyAiLimit(this).toString())
            refreshDiagnosticsUi()
            Toast.makeText(this, if (lim == 0) "Daily AI limit: Unlimited" else "Daily AI limit set to $lim calls", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnResetChat).setOnClickListener {
            GeminiClient.clearChatHistory()
            FollowUpTracker.reset()
            Toast.makeText(this, "Conversation context reset.", Toast.LENGTH_SHORT).show()
        }

        // RailRadar Live Train API config
        railRadarKeyInput.setText(Prefs.railRadarKey(this))
        railRadarUrlInput.setText(Prefs.railRadarBaseUrl(this))
        updateRailRadarStatusText()
        findViewById<MaterialButton>(R.id.railRadarSaveButton).setOnClickListener { saveAndTestRailRadar() }

        // Earbuds, Barge-In, Caller Announce & Volume Trigger
        headsetAutoMusicSwitch.isChecked = Prefs.headsetAutoMusic(this)
        headsetAutoMusicSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setHeadsetAutoMusic(this, checked) }

        headsetReadNotifsSwitch.isChecked = Prefs.headsetReadNotifs(this)
        headsetReadNotifsSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setHeadsetReadNotifs(this, checked) }

        bargeInSwitch.isChecked = Prefs.bargeInEnabled(this)
        bargeInSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setBargeInEnabled(this, checked) }

        volumeTriggerSwitch.isChecked = Prefs.volumeTriggerEnabled(this)
        volumeTriggerSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setVolumeTriggerEnabled(this, checked)
            if (checked && NovaAccessibility.instance == null) {
                Toast.makeText(this, "Enable Nova Accessibility below to activate Volume-Down long-press trigger.", Toast.LENGTH_LONG).show()
            }
        }

        callerAnnounceGroup.check(
            when (Prefs.callerAnnounceMode(this)) {
                "off" -> R.id.btnCallerOff
                "always" -> R.id.btnCallerAlways
                else -> R.id.btnCallerHeadset
            }
        )
        callerAnnounceGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            Prefs.setCallerAnnounceMode(
                this,
                when (checkedId) {
                    R.id.btnCallerOff -> "off"
                    R.id.btnCallerAlways -> "always"
                    else -> "headset"
                }
            )
        }
        findViewById<MaterialButton>(R.id.btnCallStatePerm).setOnClickListener {
            val perms = mutableListOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 26) perms.add(Manifest.permission.ANSWER_PHONE_CALLS)
            extraPermsLauncher.launch(perms.toTypedArray())
        }

        // Permissions
        findViewById<MaterialButton>(R.id.btnContacts).setOnClickListener {
            extraPermsLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS))
        }
        findViewById<MaterialButton>(R.id.btnLocationPerm).setOnClickListener {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 31) perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            extraPermsLauncher.launch(perms.toTypedArray())
        }
        findViewById<MaterialButton>(R.id.btnCalendarPerm).setOnClickListener {
            extraPermsLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR))
        }
        findViewById<MaterialButton>(R.id.btnAccess).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<MaterialButton>(R.id.btnNotif).setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        findViewById<MaterialButton>(R.id.btnUsageAccess).setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
    }

    private fun handlePickedFile(uri: Uri, isScreenshot: Boolean = false) {
        bottomNav.selectedItemId = R.id.nav_home
        heardText.text = if (isScreenshot) "Analyzing selected image..." else "Loading selected file..."
        statusText.text = "Reading document locally..."
        NovaState.update(activeAgent = AgentType.FILE.displayName)
        thread {
            val reply = FileAssistant.loadAndSummarize(this, uri)
            runOnUiThread {
                fileStatusText.text = FileAssistant.activeDocSummaryLabel()
                showAndSpeakLocalReply(reply)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        NovaState.addListener(stateListener)
    }

    override fun onStop() {
        super.onStop()
        NovaState.removeListener(stateListener)
    }

    override fun onResume() {
        super.onResume()
        index.refresh()
        appCountText.text = "${index.apps.size} installed apps indexed • Nova v11.0 Pro"
        continueWakeSetup()
        refreshDashboardTelemetry()
        refreshHubAll()
        refreshPerms()
        refreshDiagnosticsUi()
    }

    override fun onDestroy() {
        runCatching { localTts?.stop(); localTts?.shutdown() }
        super.onDestroy()
    }

    private fun syncWakeSwitches(checked: Boolean) {
        updatingSwitchUi = true
        dashWakeSwitch.isChecked = checked
        wakeSwitch.isChecked = checked
        updatingSwitchUi = false
    }

    private fun stopListenServiceCleanly() {
        ListenService.running = false
        stopService(Intent(this, ListenService::class.java))
    }

    private fun continueWakeSetup() {
        val wakeEnabled = Prefs.wake(this) && !Prefs.privacyPaused(this)
        syncWakeSwitches(wakeEnabled)
        if (!wakeEnabled) {
            if (ListenService.running) stopListenServiceCleanly()
            refreshDashboardTelemetry()
            return
        }

        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty() && !askedPermissions) {
            askedPermissions = true
            wakePermsLauncher.launch(need.toTypedArray())
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            Prefs.setWake(this, false)
            Prefs.setLastServiceFailure(this, "Microphone permission denied")
            syncWakeSwitches(false)
            Toast.makeText(this, "Microphone permission required for wake word detection.", Toast.LENGTH_LONG).show()
            return
        }

        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            Toast.makeText(this, "Allow 'Display over other apps' for floating indicator & background app launch.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !askedBattery) {
            askedBattery = true
            runCatching {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                return
            }
        }

        if (!ListenService.running) {
            ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
        }
        refreshDashboardTelemetry()
    }

    private fun refreshDashboardTelemetry() {
        val wakePref = Prefs.wake(this)
        val paused = Prefs.privacyPaused(this)
        val trulyRunning = NovaDiagnostics.isServiceTrulyActive()
        syncWakeSwitches(wakePref && !paused)

        val bat = PhoneInfoHelper.battery(this)
        val net = if (PhoneInfoHelper.isOnline(this)) "Online" else "Offline"
        val gemini = if (Prefs.hasAi(this)) "Ready" else "No Key"
        val micState = if (trulyRunning && NovaState.micActive) "Active" else "Idle"
        val modeStr = if (!trulyRunning) "STOPPED" else when (NovaState.mode) {
            ListenMode.STOPPED -> "STOPPED"
            ListenMode.LOADING_MODEL -> if (NovaState.modelProgress >= 0) "Downloading ${NovaState.modelProgress}%" else "Loading..."
            ListenMode.WAKE_LISTENING -> "Wake Ready"
            ListenMode.COMMAND_LISTENING -> "Listening (${NovaState.sessionRemainingSec}s)"
            ListenMode.PROCESSING -> "Processing"
            ListenMode.SPEAKING -> "Speaking"
            ListenMode.MIC_CONFLICT -> "Mic Busy"
            ListenMode.ERROR_RECOVERING -> "Recovering"
        }

        timerBadge.text = if (NovaState.sessionRemainingSec > 0) "${NovaState.sessionRemainingSec}s" else modeStr.uppercase(Locale.ROOT)
        activeAgentBadge.text = if (trulyRunning) "● Online • ${NovaState.activeAgent}" else "● Standby • ${NovaState.activeAgent}"
        btnPrivacyPause.text = if (paused) "Resume Nova (Privacy Mode Active)" else "Pause Everything (Privacy Mode)"

        dashTelemetryText.text = when {
            paused -> "PRIVACY MODE ON • Service: PAUSED • Mic: OFF\nHistory: PAUSED • AI Context: CLEARED • Battery: ${bat.percent}%"
            wakePref && !trulyRunning -> "WARNING: Service NOT running (${NovaState.lastErrorReason.ifEmpty { "Stopped by OS" }})\nNet: $net • Gemini: $gemini • Battery: ${bat.percent}%"
            else -> "Service: $modeStr • Mic: $micState • Net: $net\nTimeout: ${Prefs.sessionDurationSeconds(this)}s • Gemini: $gemini • Battery: ${bat.percent}%"
        }

        wakeStatus.text = if (trulyRunning) NovaState.statusMessage
        else if (wakePref) "Service stopped: ${NovaState.lastErrorReason.ifEmpty { "Check Diagnostics & Vivo Battery Guide below" }}"
        else "Off. Enable to listen for Hey Nova, Hi Nova, Hello Nova, and Okay Nova in the background."

        if (NovaState.lastHeard.isNotBlank()) heardText.text = "Heard: ${NovaState.lastHeard}"
        if (NovaState.lastReply.isNotBlank() && trulyRunning) statusText.text = NovaState.lastReply
        confirmBar.visibility = if (ActionExecutor.hasActivePending()) View.VISIBLE else View.GONE
        refreshHistoryUi()
        refreshDiagnosticsUi()
    }

    private fun refreshHubAll() {
        refreshMacrosUi()
        refreshExpenseUi()
        fileStatusText.text = FileAssistant.activeDocSummaryLabel()
        btnToggleFlashlight.text = if (PhoneControlHelper.torchOn) "Flashlight: ON" else "Flashlight: OFF"
        refreshTimersUi()
        refreshTasksUi()
        refreshChecklistUi()
        refreshRemindersUi()
        refreshMemoriesUi()
        refreshPhoneDiagnostics()
    }

    private fun refreshTimersUi() {
        val timers = TimerManager.activeTimers(this)
        timerListText.text = if (timers.isEmpty()) "No active timers."
        else timers.joinToString(" | ") { "${it.label}: ${TimerManager.formatRemaining(it.endAtMs)} left" }
    }

    private fun refreshMacrosUi() {
        macroListContainer.removeAllViews()
        val list = MacroStore.all(this)
        if (list.isEmpty()) {
            macroListContainer.addView(TextView(this).apply {
                text = "No custom shortcuts yet. Example: Trigger 'movie time' -> 'silent mode aur TV par YouTube kholo'."
                alpha = 0.7f
                textSize = 12f
            })
            return
        }
        list.forEach { m ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = "\"${m.trigger}\" → ${m.actions}"
                textSize = 12.5f
            }
            val run = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Run"
                setOnClickListener {
                    bottomNav.selectedItemId = R.id.nav_home
                    executeCommand(m.trigger)
                }
            }
            val del = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Del"
                setOnClickListener { MacroStore.delete(this@MainActivity, m.trigger); refreshMacrosUi() }
            }
            row.addView(tv); row.addView(run); row.addView(del)
            macroListContainer.addView(row)
        }
    }

    private fun refreshTasksUi() {
        taskListContainer.removeAllViews()
        val tasks = DailyPlannerStore.getTasks(this)
        if (tasks.isEmpty()) {
            taskListContainer.addView(TextView(this).apply {
                text = "No tasks yet."
                alpha = 0.7f
            })
            return
        }
        tasks.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 4, 0, 4)
            }
            val cb = CheckBox(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = item.title
                isChecked = item.done
                textSize = 13f
                setOnCheckedChangeListener { _, _ -> DailyPlannerStore.toggleTask(this@MainActivity, item.id) }
            }
            val del = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Del"
                setOnClickListener {
                    DailyPlannerStore.deleteTask(this@MainActivity, item.id)
                    refreshTasksUi()
                }
            }
            row.addView(cb)
            row.addView(del)
            taskListContainer.addView(row)
        }
    }

    private fun refreshHistoryUi() {
        val list = SmartMemory.getHistory(this).take(6)
        recentHistoryText.text = if (list.isEmpty()) "No recent commands yet."
        else list.joinToString("\n\n") { "• ${it.heard}\n   → ${it.reply.take(100)}" }

        historyPillContainer.removeAllViews()
        if (list.isEmpty()) {
            historyPillContainer.addView(TextView(this).apply {
                text = "Say 'Hello Nova' or tap Talk with Nova to start."
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.nova_text_secondary))
                textSize = 13f
                setPadding(16, 16, 16, 16)
                setBackgroundResource(R.drawable.bg_history_row)
            })
            return
        }
        val dotBgs = intArrayOf(R.drawable.bg_circle_lime, R.drawable.bg_circle_lavender, R.drawable.bg_circle_pink)
        val density = resources.displayMetrics.density
        list.forEachIndexed { idx, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_history_row)
                val p = (12 * density).toInt()
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (8 * density).toInt() }
                setOnClickListener {
                    commandInput.setText(item.heard)
                    executeCommand(item.heard)
                }
            }
            val dot = View(this).apply {
                val sz = (28 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (12 * density).toInt() }
                setBackgroundResource(dotBgs[idx % dotBgs.size])
            }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = item.heard
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.nova_text_primary))
                textSize = 13.5f
            }
            row.addView(dot)
            row.addView(tv)
            historyPillContainer.addView(row)
        }
    }

    private fun refreshChecklistUi() {
        checklistContainer.removeAllViews()
        val items = RailRadarHelper.getChecklist(this)
        items.forEachIndexed { idx, item ->
            checklistContainer.addView(CheckBox(this).apply {
                text = item.name
                isChecked = item.checked
                textSize = 13f
                setOnCheckedChangeListener { _, _ -> RailRadarHelper.toggleByIndex(this@MainActivity, idx) }
            })
        }
    }

    private fun refreshRemindersUi() {
        reminderListContainer.removeAllViews()
        val items = ReminderStore.all(this)
        if (items.isEmpty()) {
            reminderListContainer.addView(TextView(this).apply { text = "No active reminders."; alpha = 0.7f })
            return
        }
        items.forEach { item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                val rep = if (item.repeatDaily) " (Daily)" else ""
                text = "${item.title}$rep\n${ReminderStore.formatTime(item.triggerAtMs)}"
                textSize = 13f
            }
            val del = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Delete"
                setOnClickListener { ReminderStore.delete(this@MainActivity, item.id); refreshRemindersUi() }
            }
            row.addView(tv); row.addView(del)
            reminderListContainer.addView(row)
        }
    }

    private fun refreshMemoriesUi() {
        memoryListContainer.removeAllViews()
        val items = SmartMemory.getMemories(this)
        if (items.isEmpty()) {
            memoryListContainer.addView(TextView(this).apply {
                text = "No saved memories. Say 'Yaad rakho mera favourite app Spotify hai'."
                alpha = 0.7f
            })
            return
        }
        items.forEach { item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = "• ${item.text}"
                textSize = 13f
            }
            val edit = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Edit"
                setOnClickListener { showEditMemoryDialog(item) }
            }
            val del = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Del"
                setOnClickListener { SmartMemory.deleteMemory(this@MainActivity, item.id); refreshMemoriesUi() }
            }
            row.addView(tv); row.addView(edit); row.addView(del)
            memoryListContainer.addView(row)
        }
    }

    private fun showEditMemoryDialog(item: MemoryItem) {
        val input = EditText(this).apply { setText(item.text); setPadding(40, 28, 40, 28) }
        AlertDialog.Builder(this)
            .setTitle("Edit Memory")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val updated = input.text?.toString()?.trim().orEmpty()
                if (!SmartMemory.updateMemory(this, item.id, updated)) {
                    Toast.makeText(this, "Empty or sensitive text cannot be saved.", Toast.LENGTH_SHORT).show()
                } else {
                    refreshMemoriesUi()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshPhoneDiagnostics() {
        phoneInfoText.text = PhoneInfoHelper.fullSummary(this, index)
    }

    private fun setSliderSafely(slider: Slider, desired: Float, fallback: Float) {
        val snapped = Prefs.snapStep05(desired, slider.valueFrom, slider.valueTo)
        runCatching { slider.value = snapped }.onFailure {
            runCatching { slider.value = fallback }
        }
    }

    private fun refreshVaultUi() {
        vaultListContainer.removeAllViews()
        val docs = KnowledgeBaseStore.listDocs(this)
        if (docs.isEmpty()) {
            vaultListContainer.addView(TextView(this).apply {
                text = "Vault khali hai. Upar koi PDF/DOCX/TXT pick karke 'Save to Vault' dabao."
                alpha = 0.7f
                textSize = 12f
            })
            return
        }
        docs.forEach { d ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = "• ${d.name} (${d.kind.uppercase(Locale.ROOT)}, ${d.chunkCount} sections)"
                textSize = 12.5f
            }
            val del = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Del"
                setOnClickListener { KnowledgeBaseStore.deleteDoc(this@MainActivity, d.id); refreshVaultUi() }
            }
            row.addView(tv); row.addView(del)
            vaultListContainer.addView(row)
        }
    }

    private fun refreshExpenseUi() {
        runCatching { expenseSummaryText.text = ExpenseTrackerStore.quickDashboardSummary(this) }
    }

    private fun filterSettingsCards(rawQuery: String) {
        val q = rawQuery.trim().lowercase(Locale.ROOT)
        for (i in 1 until settingsCardsContainer.childCount) {
            val child = settingsCardsContainer.getChildAt(i)
            if (q.isEmpty()) {
                child.visibility = View.VISIBLE
            } else {
                val allText = collectViewText(child).lowercase(Locale.ROOT)
                child.visibility = if (allText.contains(q)) View.VISIBLE else View.GONE
            }
        }
    }

    private fun collectViewText(v: View): String {
        if (v is TextView) return v.text?.toString().orEmpty()
        if (v is android.view.ViewGroup) {
            val sb = StringBuilder()
            for (i in 0 until v.childCount) sb.append(collectViewText(v.getChildAt(i))).append(' ')
            return sb.toString()
        }
        return ""
    }

    private fun refreshDiagnosticsUi() {
        runCatching {
            diagnosticsText.text = NovaDiagnostics.buildDiagnosticsReport(this)
        }
    }

    private fun refreshPerms() {
        fun tick(ok: Boolean) = if (ok) "✔" else "✘"
        permStatus.text =
            "Mic: ${tick(granted(Manifest.permission.RECORD_AUDIO))}   " +
            "Location: ${tick(NearbyPlacesHelper.hasLocationPermission(this))}   " +
            "Calendar: ${tick(granted(Manifest.permission.READ_CALENDAR))}\n" +
            "Contacts: ${tick(granted(Manifest.permission.READ_CONTACTS))}   " +
            "Call: ${tick(granted(Manifest.permission.CALL_PHONE))}   " +
            "SMS: ${tick(granted(Manifest.permission.SEND_SMS))}\n" +
            "Accessibility: ${tick(NovaAccessibility.instance != null)}   " +
            "Notifications: ${tick(NovaNotificationListener.connected)}\n" +
            "Usage Access: ${tick(PhoneInfoHelper.hasUsageAccess(this))}   " +
            "Battery Unrestricted: ${tick(NovaDiagnostics.isBatteryUnrestricted(this))}"
    }

    private fun loadAiFields() {
        val provider = Prefs.aiProvider(this)
        geminiKeyInput.setText(Prefs.aiKey(this, provider))
        geminiModelInput.setText(Prefs.aiModel(this, provider))
        findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.aiKeyLayout).hint =
            "${OpenAiCompat.label(provider)} API Key"
        findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.aiModelLayout).hint =
            "Model (default: ${OpenAiCompat.defaultModel(provider)})"
        updateGeminiStatusText()
    }

    private fun saveAndTestGemini() {
        val provider = Prefs.aiProvider(this)
        val name = OpenAiCompat.label(provider)
        val key = geminiKeyInput.text?.toString()?.trim()?.replace("\\s+".toRegex(), "").orEmpty()
        val model = geminiModelInput.text?.toString()?.trim().orEmpty().ifEmpty { OpenAiCompat.defaultModel(provider) }
        Prefs.setAiKeyModel(this, provider, key, model)
        geminiKeyInput.setText(key)
        geminiModelInput.setText(Prefs.aiModel(this, provider))
        updateGeminiStatusText()
        if (key.isEmpty()) return
        geminiStatus.text = "Testing $name API key..."
        val usedModel = Prefs.aiModel(this, provider)
        thread {
            val outcome = if (provider == OpenAiCompat.GEMINI) GeminiClient.testAndResolveModel(key, usedModel)
            else OpenAiCompat.test(provider, key, usedModel)
            runOnUiThread {
                if (outcome.ok && outcome.workingModel != usedModel) {
                    Prefs.setAiKeyModel(this, provider, key, outcome.workingModel)
                    geminiModelInput.setText(outcome.workingModel)
                }
                geminiStatus.text = outcome.message
                refreshDashboardTelemetry()
            }
        }
    }

    private fun updateGeminiStatusText() {
        val provider = Prefs.aiProvider(this)
        val name = OpenAiCompat.label(provider)
        geminiStatus.text = if (Prefs.aiKey(this, provider).isEmpty()) {
            "No $name API key saved. Offline commands still work without a key."
        } else {
            "Key encrypted & saved (Model: ${Prefs.aiModel(this, provider)}). Active provider: $name."
        }
    }

    private fun saveAndTestRailRadar() {
        val key = railRadarKeyInput.text?.toString()?.trim()?.replace("\\s+".toRegex(), "").orEmpty()
        val url = railRadarUrlInput.text?.toString()?.trim().orEmpty().ifEmpty { RailRadarHelper.DEFAULT_BASE_URL }
        Prefs.setRailRadar(this, key, url)
        railRadarKeyInput.setText(key)
        railRadarUrlInput.setText(Prefs.railRadarBaseUrl(this))
        updateRailRadarStatusText()
        if (key.isEmpty()) return
        railRadarStatus.text = "Testing RailRadar API key..."
        val usedUrl = Prefs.railRadarBaseUrl(this)
        thread {
            val res = RailRadarHelper.testConnection(key, usedUrl)
            runOnUiThread { railRadarStatus.text = res.message }
        }
    }

    private fun updateRailRadarStatusText() {
        railRadarStatus.text = if (Prefs.railRadarKey(this).isEmpty()) {
            "No RailRadar key saved."
        } else {
            "RailRadar key encrypted & saved (${Prefs.railRadarBaseUrl(this)})."
        }
    }

    private fun showVoicePickerDialog() {
        if (availableVoices.isEmpty()) {
            Toast.makeText(this, "No extra offline TTS voices found. Using Auto Indian voice.", Toast.LENGTH_SHORT).show()
            return
        }
        val items = (listOf("Auto (Best Indian Voice)") + availableVoices).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select TTS Voice")
            .setItems(items) { _, which ->
                val chosen = if (which == 0) "" else availableVoices[which - 1]
                Prefs.setTtsVoice(this, chosen)
                updateVoiceButtonLabel()
                notifyServiceSettingsChanged()
            }
            .show()
    }

    private fun updateVoiceButtonLabel() {
        val v = Prefs.ttsVoice(this)
        btnPickVoice.text = if (v.isEmpty()) "Voice Selection: Auto Indian Voice" else "Voice: ${v.take(24)}"
    }

    private fun notifyServiceSettingsChanged() {
        if (ListenService.running) {
            startService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_APPLY_SETTINGS))
        }
    }

    private fun startVoicePrompt() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in Hindi, Hinglish, or English...")
        }
        try {
            speechLauncher.launch(i)
        } catch (_: Exception) {
            statusText.text = "Voice recognizer unavailable. Type your command below."
        }
    }

    private fun submitTypedCommand() {
        val text = commandInput.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) executeCommand(text)
    }

    private fun executeCommand(rawText: String) {
        val hinglish = HinglishConverter.toHinglish(rawText)
        heardText.text = "Heard: $hinglish"

        if (WakeStopDetector.isStopCommand(hinglish)) {
            ActionExecutor.clearPending()
            VoiceFlashcardManager.stopSession()
            confirmBar.visibility = View.GONE
            localTts?.stop()
            NovaAccessibility.instance?.stopAgent()
            statusText.text = "Stopped listening."
            return
        }

        if (VoiceFlashcardManager.active) {
            val fcReply = VoiceFlashcardManager.handleAnswer(hinglish)
            if (fcReply.isNotEmpty()) {
                showAndSpeakLocalReply(fcReply)
                return
            }
        }

        if (InterviewVivaManager.active) {
            statusText.text = "Evaluating your answer..."
            thread {
                val vivaReply = InterviewVivaManager.handleAnswer(this, hinglish)
                runOnUiThread {
                    if (vivaReply.isNotEmpty()) showAndSpeakLocalReply(vivaReply)
                    else runResolverAndExecute(hinglish)
                }
            }
            return
        }

        if (NovaOrchestrator.hasActiveTask()) {
            statusText.text = "Completing active task..."
            thread {
                val taskReply = NovaOrchestrator.tryContinueActiveTask(this, hinglish)
                runOnUiThread {
                    if (taskReply != null) showAndSpeakLocalReply(taskReply)
                    else runResolverAndExecute(hinglish)
                }
            }
            return
        }

        if (ActionExecutor.hasActivePending()) {
            statusText.text = "Confirming..."
            ActionExecutor.handleConfirmationInput(hinglish) { reply ->
                if (reply.isNotEmpty()) {
                    showAndSpeakLocalReply(reply)
                } else {
                    ActionExecutor.clearPending()
                    runResolverAndExecute(hinglish)
                }
            }
            return
        }

        runResolverAndExecute(hinglish)
    }

    private fun runResolverAndExecute(hinglish: String) {
        statusText.text = "Thinking..."
        val matchedMacro = MacroStore.findMatch(this, hinglish)
        if (matchedMacro != null) {
            ActionExecutor.runWorkflowAsync(this, index, parser, matchedMacro.trigger, matchedMacro.actions, hinglish) { reply ->
                showAndSpeakLocalReply(reply)
            }
            return
        }
        val chained = UltimatePowerHelper.splitChainedCommands(hinglish)
        if (chained.size >= 2) {
            ActionExecutor.runChainedAsync(this, index, parser, chained, hinglish) { reply ->
                showAndSpeakLocalReply(reply)
            }
            return
        }
        Resolver.resolve(this, index, parser, hinglish) { cmd ->
            ActionExecutor.runAsync(this, index, cmd) { reply ->
                showAndSpeakLocalReply(reply)
            }
        }
    }

    private fun showAndSpeakLocalReply(reply: String) {
        statusText.text = reply
        confirmBar.visibility = if (ActionExecutor.hasActivePending()) View.VISIBLE else View.GONE
        refreshDashboardTelemetry()
        refreshHubAll()
        NovaAppWidgetProvider.requestUpdate(this)
        if (!ListenService.running) {
            localTts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "ui-${System.currentTimeMillis()}")
        }
    }

    private fun granted(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
}
