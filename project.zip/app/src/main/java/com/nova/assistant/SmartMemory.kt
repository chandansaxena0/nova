package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MemoryItem(
    val id: Long,
    val text: String,
    val time: Long,
    val category: String = "general",
    val expiresAt: Long = 0L
)

data class HistoryItem(val heard: String, val reply: String, val time: Long)

object SmartMemory {

    private val sensitivePattern = Regex(
        "\\b(password|passcode|otp|cvv|upi\\s*pin|atm\\s*pin|bank\\s*pin|credit\\s*card|debit\\s*card|aadhaar|aadhar|pan\\s*number|secret\\s*key|api\\s*key|private\\s*key)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isSensitive(text: String): Boolean = sensitivePattern.containsMatchIn(text)

    fun inferCategory(text: String): String {
        val l = text.lowercase(Locale.ROOT)
        return when {
            l.contains("favourite") || l.contains("favorite") || l.contains("pasand") || l.contains("prefer") || l.contains("like") -> "preference"
            l.contains("exam") || l.contains("physics") || l.contains("maths") || l.contains("chemistry") || l.contains("biology") || l.contains("study") || l.contains("college") -> "study"
            l.contains("train") || l.contains("jaipur") || l.contains("delhi") || l.contains("station") || l.contains("trip") || l.contains("travel") -> "travel"
            l.contains("mummy") || l.contains("papa") || l.contains("brother") || l.contains("friend") || l.contains("birthday") -> "contact"
            l.contains("routine") || l.contains("gym") || l.contains("wake") || l.contains("sleep") -> "routine"
            else -> "general"
        }
    }

    fun parseExpiryMs(text: String, nowMs: Long = System.currentTimeMillis()): Long {
        val l = text.lowercase(Locale.ROOT)
        Regex("(?:for\\s+)?(\\d{1,3})\\s*(?:days?|din)\\b").find(l)?.let { m ->
            val days = m.groupValues[1].toLongOrNull()?.coerceIn(1L, 365L) ?: return 0L
            return nowMs + days * 24L * 3600_000L
        }
        Regex("(?:for\\s+)?(\\d{1,3})\\s*(?:hours?|ghante|ghanta)\\b").find(l)?.let { m ->
            val hrs = m.groupValues[1].toLongOrNull()?.coerceIn(1L, 720L) ?: return 0L
            return nowMs + hrs * 3600_000L
        }
        return 0L
    }

    fun isDuplicateText(candidate: String, existing: List<String>): Boolean {
        val normCand = normalizeTokens(candidate)
        if (normCand.isEmpty()) return false
        val cleanCand = candidate.trim().lowercase(Locale.ROOT)
        for (ex in existing) {
            if (ex.trim().lowercase(Locale.ROOT) == cleanCand) return true
            val normEx = normalizeTokens(ex)
            if (normEx.isEmpty()) continue
            val inter = normCand.intersect(normEx).size
            val union = normCand.union(normEx).size
            if (union > 0 && inter.toDouble() / union.toDouble() >= 0.80) return true
        }
        return false
    }

    fun rankRelevant(items: List<MemoryItem>, queryHint: String, limit: Int = 8): List<MemoryItem> {
        if (items.isEmpty()) return emptyList()
        val qTokens = normalizeTokens(queryHint)
        if (qTokens.isEmpty()) return items.take(limit)
        val qCat = inferCategory(queryHint)

        val scored = items.map { item ->
            val iTokens = normalizeTokens(item.text)
            val overlap = qTokens.count { qt -> iTokens.any { it.contains(qt) || qt.contains(it) } }
            val catBonus = if (item.category == qCat && qCat != "general") 1 else 0
            item to (overlap * 3 + catBonus)
        }.sortedByDescending { it.second }

        val matched = scored.filter { it.second > 0 }.map { it.first }.take(limit)
        return (matched + items.take(4)).distinctBy { it.id }.take(limit)
    }

    private fun normalizeTokens(s: String): Set<String> =
        s.lowercase(Locale.ROOT)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 3 }
            .toSet()

    fun getMemories(c: Context): List<MemoryItem> =
        NovaMemoryDb.get(c).getActiveMemories().map {
            MemoryItem(it.id, it.text, it.createdAt, it.category, it.expiresAt)
        }

    fun addMemory(
        c: Context,
        text: String,
        allowSensitive: Boolean = false,
        category: String? = null,
        expiresAt: Long? = null
    ): MemoryItem? {
        val clean = text.trim()
        if (clean.isEmpty()) return null
        if (!allowSensitive && isSensitive(clean)) return null
        val existing = getMemories(c)
        if (isDuplicateText(clean, existing.map { it.text })) {
            return existing.firstOrNull { isDuplicateText(clean, listOf(it.text)) }
        }
        val now = System.currentTimeMillis()
        val cat = category?.ifBlank { null } ?: inferCategory(clean)
        val exp = expiresAt ?: parseExpiryMs(clean, now)
        val id = NovaMemoryDb.get(c).insertMemory(clean, cat, now, exp)
        return if (id > 0) MemoryItem(id, clean, now, cat, exp) else null
    }

    fun updateMemory(c: Context, id: Long, newText: String): Boolean {
        val clean = newText.trim()
        if (clean.isEmpty() || isSensitive(clean)) return false
        return NovaMemoryDb.get(c).updateMemory(id, clean, inferCategory(clean))
    }

    fun deleteMemory(c: Context, id: Long) {
        NovaMemoryDb.get(c).deleteMemory(id)
    }

    fun clearMemories(c: Context) {
        NovaMemoryDb.get(c).clearMemories()
    }

    fun searchMemories(c: Context, query: String): List<MemoryItem> {
        val all = getMemories(c)
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return all
        val direct = all.filter { it.text.lowercase(Locale.ROOT).contains(q) || it.category.lowercase(Locale.ROOT).contains(q) }
        return if (direct.isNotEmpty()) direct else rankRelevant(all, q, limit = 6)
    }

    fun exportMemoriesJson(c: Context): String {
        val arr = JSONArray()
        getMemories(c).forEach { m ->
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("category", m.category)
                    .put("text", m.text)
                    .put("createdAt", formatTime(m.time))
                    .put("expiresAt", if (m.expiresAt > 0L) formatTime(m.expiresAt) else "never")
            )
        }
        return JSONObject()
            .put("exportedAt", formatTime(System.currentTimeMillis()))
            .put("count", arr.length())
            .put("memories", arr)
            .toString(2)
    }

    fun relevantMemorySummary(c: Context, queryHint: String = ""): String {
        val ranked = rankRelevant(getMemories(c), queryHint, limit = 10)
        if (ranked.isEmpty()) return ""
        return "User saved preferences/memories:\n" + ranked.joinToString("\n") { "- [${it.category}] ${it.text}" }
    }

    fun memorySummaryForPrompt(c: Context): String = relevantMemorySummary(c, "")

    fun getHistory(c: Context): List<HistoryItem> = NovaMemoryDb.get(c).getHistory(40)

    fun recordCommand(c: Context, heard: String, reply: String) {
        if (!Prefs.saveHistory(c) || heard.isBlank()) return
        val db = NovaMemoryDb.get(c)
        db.insertHistory(heard.trim(), reply.trim())
        db.incrementFrequency(heard.trim())
    }

    fun topCommands(c: Context, limit: Int = 5): List<Pair<String, Int>> =
        NovaMemoryDb.get(c).topFrequentCommands(limit)

    fun clearHistory(c: Context) {
        NovaMemoryDb.get(c).clearHistory()
    }

    fun formatTime(ts: Long): String =
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ts))
}
