package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MemoryItem(val id: Long, val text: String, val time: Long)
data class HistoryItem(val heard: String, val reply: String, val time: Long)

/**
 * Local Smart Memory & Command History store.
 * - Saves user memories ONLY when explicitly requested ("Yaad rakho...").
 * - Tracks frequent command counts for fast insights.
 * - Allows full viewing and deletion from Settings/Hub.
 */
object SmartMemory {
    private const val PREF = "nova_memory"
    private const val KEY_MEMORIES = "memories_json"
    private const val KEY_HISTORY = "history_json"
    private const val KEY_FREQ = "freq_json"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    // ---- Explicit User Memories ----
    fun getMemories(c: Context): List<MemoryItem> {
        val raw = p(c).getString(KEY_MEMORIES, "[]") ?: "[]"
        val out = mutableListOf<MemoryItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(MemoryItem(o.optLong("id"), o.optString("text"), o.optLong("time")))
            }
        } catch (_: Exception) {}
        return out.sortedByDescending { it.time }
    }

    fun addMemory(c: Context, text: String): MemoryItem {
        val clean = text.trim()
        val list = getMemories(c).toMutableList()
        val item = MemoryItem(System.currentTimeMillis(), clean, System.currentTimeMillis())
        list.add(0, item)
        saveMemories(c, list.take(50))
        return item
    }

    fun deleteMemory(c: Context, id: Long) {
        saveMemories(c, getMemories(c).filterNot { it.id == id })
    }

    fun clearMemories(c: Context) {
        p(c).edit().remove(KEY_MEMORIES).apply()
    }

    fun memorySummaryForPrompt(c: Context): String {
        val items = getMemories(c).take(12)
        if (items.isEmpty()) return ""
        return "User saved preferences/memories:\n" + items.joinToString("\n") { "- ${it.text}" }
    }

    private fun saveMemories(c: Context, list: List<MemoryItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time))
        }
        p(c).edit().putString(KEY_MEMORIES, arr.toString()).apply()
    }

    // ---- Command History ----
    fun getHistory(c: Context): List<HistoryItem> {
        val raw = p(c).getString(KEY_HISTORY, "[]") ?: "[]"
        val out = mutableListOf<HistoryItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(HistoryItem(o.optString("heard"), o.optString("reply"), o.optLong("time")))
            }
        } catch (_: Exception) {}
        return out
    }

    fun recordCommand(c: Context, heard: String, reply: String) {
        if (!Prefs.saveHistory(c) || heard.isBlank()) return
        val list = getHistory(c).toMutableList()
        list.add(0, HistoryItem(heard.trim(), reply.trim(), System.currentTimeMillis()))
        val arr = JSONArray()
        list.take(40).forEach {
            arr.put(JSONObject().put("heard", it.heard).put("reply", it.reply).put("time", it.time))
        }
        p(c).edit().putString(KEY_HISTORY, arr.toString()).apply()
        recordFrequency(c, heard.trim().lowercase(Locale.ROOT))
    }

    fun clearHistory(c: Context) {
        p(c).edit().remove(KEY_HISTORY).remove(KEY_FREQ).apply()
    }

    private fun recordFrequency(c: Context, cmd: String) {
        try {
            val obj = JSONObject(p(c).getString(KEY_FREQ, "{}") ?: "{}")
            obj.put(cmd, obj.optInt(cmd, 0) + 1)
            p(c).edit().putString(KEY_FREQ, obj.toString()).apply()
        } catch (_: Exception) {}
    }

    fun topFrequentCommands(c: Context, limit: Int = 5): List<String> {
        return try {
            val obj = JSONObject(p(c).getString(KEY_FREQ, "{}") ?: "{}")
            val pairs = mutableListOf<Pair<String, Int>>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                pairs.add(k to obj.optInt(k, 0))
            }
            pairs.sortedByDescending { it.second }.take(limit).map { it.first }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun formatTime(ts: Long): String =
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ts))
}
