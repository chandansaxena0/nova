package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MemoryItem(val id: Long, val text: String, val time: Long)
data class HistoryItem(val heard: String, val reply: String, val time: Long)

/**
 * Local Smart Memory & Command History store:
 * - Saves user-approved preferences/facts only.
 * - Blocks accidental storage of sensitive data (passwords, OTP, CVV, UPI PIN, Aadhaar/bank PINs).
 * - Supports view, edit, delete, complete reset, and relevance-ranked retrieval for AI prompts.
 */
object SmartMemory {
    private const val PREF = "nova_memory"
    private const val KEY_MEMORIES = "memories_json"
    private const val KEY_HISTORY = "history_json"
    private const val KEY_FREQ = "freq_json"

    private val sensitivePattern = Regex(
        "\\b(password|passcode|otp|cvv|upi\\s*pin|atm\\s*pin|bank\\s*pin|credit\\s*card|debit\\s*card|aadhaar|aadhar|secret\\s*key|api\\s*key)\\b",
        RegexOption.IGNORE_CASE
    )

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun isSensitive(text: String): Boolean = sensitivePattern.containsMatchIn(text)

    // ---- Explicit User Memories ----
    fun getMemories(c: Context): List<MemoryItem> {
        val raw = p(c).getString(KEY_MEMORIES, "[]") ?: "[]"
        val out = mutableListOf<MemoryItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(MemoryItem(o.optLong("id"), o.optString("text"), o.optLong("time")))
            }
        } catch (_: Exception) {}
        return out.sortedByDescending { it.time }
    }

    fun addMemory(c: Context, text: String, allowSensitive: Boolean = false): MemoryItem? {
        val clean = text.trim()
        if (clean.isEmpty()) return null
        if (!allowSensitive && isSensitive(clean)) return null
        val list = getMemories(c).toMutableList()
        val item = MemoryItem(System.currentTimeMillis(), clean, System.currentTimeMillis())
        list.add(0, item)
        saveMemories(c, list.take(60))
        return item
    }

    fun updateMemory(c: Context, id: Long, newText: String): Boolean {
        val clean = newText.trim()
        if (clean.isEmpty() || isSensitive(clean)) return false
        val updated = getMemories(c).map {
            if (it.id == id) it.copy(text = clean, time = System.currentTimeMillis()) else it
        }
        saveMemories(c, updated)
        return true
    }

    fun deleteMemory(c: Context, id: Long) {
        saveMemories(c, getMemories(c).filterNot { it.id == id })
    }

    fun clearMemories(c: Context) {
        p(c).edit().remove(KEY_MEMORIES).apply()
    }

    /** Retrieves the most relevant saved memories for the current query + latest preferences. */
    fun relevantMemorySummary(c: Context, queryHint: String = ""): String {
        val all = getMemories(c)
        if (all.isEmpty()) return ""
        val qWords = queryHint.lowercase(Locale.ROOT)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 3 }
            .toSet()

        val ranked = if (qWords.isEmpty()) {
            all.take(10)
        } else {
            val scored = all.map { item ->
                val lower = item.text.lowercase(Locale.ROOT)
                val hits = qWords.count { lower.contains(it) }
                item to hits
            }.sortedByDescending { it.second }
            val matched = scored.filter { it.second > 0 }.map { it.first }.take(6)
            (matched + all.take(6)).distinctBy { it.id }.take(10)
        }
        return "User saved preferences/memories:\n" + ranked.joinToString("\n") { "- ${it.text}" }
    }

    fun memorySummaryForPrompt(c: Context): String = relevantMemorySummary(c, "")

    private fun saveMemories(c: Context, list: List<MemoryItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time))
        }
        p(c).edit().putString(KEY_MEMORIES, arr.toString()).apply()
    }

    // ---- Command History ----
    fun getHistory(c: Context): List<HistoryItem> {
        val raw = p(c).getString(KEY_HISTORY, "[]") ?: "[]"
        val out = mutableListOf<HistoryItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(HistoryItem(o.optString("heard"), o.optString("reply"), o.optLong("time")))
            }
        } catch (_: Exception) {}
        return out
    }

    fun recordCommand(c: Context, heard: String, reply: String) {
        if (!Prefs.saveHistory(c) || heard.isBlank()) return
        val list = getHistory(c).toMutableList()
        list.add(0, HistoryItem(heard.trim(), reply.trim(), System.currentTimeMillis()))
        val arr = JSONArray()
        list.take(40).forEach {
            arr.put(JSONObject().put("heard", it.heard).put("reply", it.reply).put("time", it.time))
        }
        p(c).edit().putString(KEY_HISTORY, arr.toString()).apply()
        recordFrequency(c, heard.trim().lowercase(Locale.ROOT))
    }

    fun clearHistory(c: Context) {
        p(c).edit().remove(KEY_HISTORY).remove(KEY_FREQ).apply()
    }

    private fun recordFrequency(c: Context, cmd: String) {
        try {
            val obj = JSONObject(p(c).getString(KEY_FREQ, "{}") ?: "{}")
            obj.put(cmd, obj.optInt(cmd, 0) + 1)
            p(c).edit().putString(KEY_FREQ, obj.toString()).apply()
        } catch (_: Exception) {}
    }

    fun formatTime(ts: Long): String =
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ts))
}
