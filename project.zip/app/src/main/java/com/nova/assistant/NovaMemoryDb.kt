package com.nova.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import java.util.Locale

data class MemoryRecord(
    val id: Long,
    val text: String,
    val category: String,
    val createdAt: Long,
    val expiresAt: Long
)

data class StudyTopicStat(
    val topic: String,
    val correct: Int,
    val total: Int,
    val lastPracticedMs: Long
) {
    val accuracyPct: Int get() = if (total <= 0) 0 else ((correct * 100) / total)
    val isWeak: Boolean get() = total >= 2 && accuracyPct < 70
}

data class WorkflowRunRecord(
    val id: Long,
    val name: String,
    val status: String,
    val summary: String,
    val runAt: Long
)

data class ExpenseRecord(
    val id: Long,
    val amount: Double,
    val category: String,
    val note: String,
    val createdAt: Long
)

/**
 * Structured Encrypted SQLite Database for Nova v10.0 Ultimate:
 *   - memories (AES-256-GCM encrypted via SecureVault, categorized, optional expiry)
 *   - command_history & command_frequency
 *   - study_progress (per-topic accuracy & spaced revision)
 *   - workflow_runs (macro/workflow audit log)
 *   - expenses (offline Indian INR voice expense ledger)
 */
class NovaMemoryDb private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "nova_memory_v10.db"
        private const val DB_VERSION = 1

        @Volatile
        private var instance: NovaMemoryDb? = null

        fun get(context: Context): NovaMemoryDb =
            instance ?: synchronized(this) {
                instance ?: NovaMemoryDb(context.applicationContext).also { db ->
                    instance = db
                    db.migrateLegacyPrefsIfNeeded(context.applicationContext)
                }
            }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text_enc TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'general',
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_memories_cat ON memories(category)")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS command_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                heard TEXT NOT NULL,
                reply TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_history_time ON command_history(created_at DESC)")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS command_frequency (
                cmd_key TEXT PRIMARY KEY,
                count INTEGER NOT NULL DEFAULT 1,
                last_used INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS study_progress (
                topic TEXT PRIMARY KEY,
                correct INTEGER NOT NULL DEFAULT 0,
                total INTEGER NOT NULL DEFAULT 0,
                last_practiced INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS workflow_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                status TEXT NOT NULL,
                summary TEXT NOT NULL,
                run_at INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL NOT NULL,
                category TEXT NOT NULL DEFAULT 'general',
                note TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_expenses_time ON expenses(created_at DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onCreate(db)
    }

    private fun migrateLegacyPrefsIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences("nova_memory", Context.MODE_PRIVATE)
        if (prefs.getBoolean("migrated_v10_db", false)) return
        runCatching {
            val memRaw = prefs.getString("memories_json", "[]") ?: "[]"
            val arr = JSONArray(memRaw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val txt = o.optString("text", "").trim()
                val time = o.optLong("time", System.currentTimeMillis())
                if (txt.isNotEmpty() && !SmartMemory.isSensitive(txt)) {
                    insertMemory(txt, SmartMemory.inferCategory(txt), time, 0L)
                }
            }
            val histRaw = prefs.getString("history_json", "[]") ?: "[]"
            val harr = JSONArray(histRaw)
            for (i in 0 until harr.length()) {
                val o = harr.optJSONObject(i) ?: continue
                val heard = o.optString("heard", "").trim()
                val reply = o.optString("reply", "").trim()
                val time = o.optLong("time", System.currentTimeMillis())
                if (heard.isNotEmpty()) insertHistory(heard, reply, time)
            }
        }
        prefs.edit().putBoolean("migrated_v10_db", true).apply()
    }

    // ---- Memories ----
    fun insertMemory(plainText: String, category: String, createdAt: Long, expiresAt: Long): Long {
        val cv = ContentValues().apply {
            put("text_enc", SecureVault.encrypt(plainText))
            put("category", category.ifBlank { "general" })
            put("created_at", createdAt)
            put("expires_at", expiresAt)
        }
        return writableDatabase.insert("memories", null, cv)
    }

    fun getActiveMemories(nowMs: Long = System.currentTimeMillis()): List<MemoryRecord> {
        runCatching {
            writableDatabase.delete("memories", "expires_at > 0 AND expires_at <= ?", arrayOf(nowMs.toString()))
        }
        val out = ArrayList<MemoryRecord>()
        readableDatabase.rawQuery(
            "SELECT id, text_enc, category, created_at, expires_at FROM memories ORDER BY created_at DESC LIMIT 200",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val plain = SecureVault.decrypt(c.getString(1)).trim()
                if (plain.isNotEmpty()) {
                    out.add(MemoryRecord(c.getLong(0), plain, c.getString(2), c.getLong(3), c.getLong(4)))
                }
            }
        }
        return out
    }

    fun updateMemory(id: Long, newPlainText: String, category: String): Boolean {
        val cv = ContentValues().apply {
            put("text_enc", SecureVault.encrypt(newPlainText))
            put("category", category)
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.update("memories", cv, "id = ?", arrayOf(id.toString())) > 0
    }

    fun deleteMemory(id: Long) {
        writableDatabase.delete("memories", "id = ?", arrayOf(id.toString()))
    }

    fun clearMemories() {
        writableDatabase.delete("memories", null, null)
    }

    // ---- History & Frequency ----
    fun insertHistory(heard: String, reply: String, createdAt: Long = System.currentTimeMillis()) {
        val cv = ContentValues().apply {
            put("heard", heard)
            put("reply", reply)
            put("created_at", createdAt)
        }
        writableDatabase.insert("command_history", null, cv)
        runCatching {
            writableDatabase.execSQL(
                "DELETE FROM command_history WHERE id NOT IN (SELECT id FROM command_history ORDER BY created_at DESC LIMIT 120)"
            )
        }
    }

    fun getHistory(limit: Int = 50): List<HistoryItem> {
        val out = ArrayList<HistoryItem>()
        readableDatabase.rawQuery(
            "SELECT heard, reply, created_at FROM command_history ORDER BY created_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(HistoryItem(c.getString(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun clearHistory() {
        writableDatabase.delete("command_history", null, null)
        writableDatabase.delete("command_frequency", null, null)
    }

    fun incrementFrequency(cmd: String) {
        val key = cmd.trim().lowercase(Locale.ROOT).take(100)
        if (key.isEmpty()) return
        val now = System.currentTimeMillis()
        writableDatabase.execSQL(
            "INSERT INTO command_frequency(cmd_key, count, last_used) VALUES(?, 1, ?) " +
                "ON CONFLICT(cmd_key) DO UPDATE SET count = count + 1, last_used = excluded.last_used",
            arrayOf(key, now)
        )
    }

    fun topFrequentCommands(limit: Int = 6): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        readableDatabase.rawQuery(
            "SELECT cmd_key, count FROM command_frequency ORDER BY count DESC, last_used DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(c.getString(0) to c.getInt(1))
        }
        return out
    }

    // ---- Study Progress ----
    fun recordStudyOutcome(topic: String, correctDelta: Int, totalDelta: Int) {
        val clean = topic.trim().lowercase(Locale.ROOT).ifEmpty { "general" }
        val now = System.currentTimeMillis()
        writableDatabase.execSQL(
            "INSERT INTO study_progress(topic, correct, total, last_practiced) VALUES(?, ?, ?, ?) " +
                "ON CONFLICT(topic) DO UPDATE SET correct = correct + excluded.correct, total = total + excluded.total, last_practiced = excluded.last_practiced",
            arrayOf(clean, correctDelta, totalDelta, now)
        )
    }

    fun getStudyStats(): List<StudyTopicStat> {
        val out = ArrayList<StudyTopicStat>()
        readableDatabase.rawQuery(
            "SELECT topic, correct, total, last_practiced FROM study_progress ORDER BY last_practiced DESC",
            null
        ).use { c ->
            while (c.moveToNext()) out.add(StudyTopicStat(c.getString(0), c.getInt(1), c.getInt(2), c.getLong(3)))
        }
        return out
    }

    // ---- Workflow Runs ----
    fun insertWorkflowRun(name: String, status: String, summary: String) {
        val cv = ContentValues().apply {
            put("name", name)
            put("status", status)
            put("summary", summary.take(300))
            put("run_at", System.currentTimeMillis())
        }
        writableDatabase.insert("workflow_runs", null, cv)
        runCatching {
            writableDatabase.execSQL(
                "DELETE FROM workflow_runs WHERE id NOT IN (SELECT id FROM workflow_runs ORDER BY run_at DESC LIMIT 40)"
            )
        }
    }

    fun getRecentWorkflowRuns(limit: Int = 10): List<WorkflowRunRecord> {
        val out = ArrayList<WorkflowRunRecord>()
        readableDatabase.rawQuery(
            "SELECT id, name, status, summary, run_at FROM workflow_runs ORDER BY run_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(WorkflowRunRecord(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4)))
        }
        return out
    }

    // ---- Offline Voice Expense Ledger ----
    fun insertExpense(amount: Double, category: String, note: String, createdAt: Long = System.currentTimeMillis()): Long {
        val cv = ContentValues().apply {
            put("amount", amount)
            put("category", category)
            put("note", note.take(120))
            put("created_at", createdAt)
        }
        return writableDatabase.insert("expenses", null, cv)
    }

    fun getExpensesSince(sinceMs: Long, limit: Int = 100): List<ExpenseRecord> {
        val out = ArrayList<ExpenseRecord>()
        readableDatabase.rawQuery(
            "SELECT id, amount, category, note, created_at FROM expenses WHERE created_at >= ? ORDER BY created_at DESC LIMIT ?",
            arrayOf(sinceMs.toString(), limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(ExpenseRecord(c.getLong(0), c.getDouble(1), c.getString(2), c.getString(3), c.getLong(4)))
        }
        return out
    }

    fun clearExpenses() {
        writableDatabase.delete("expenses", null, null)
    }
}
