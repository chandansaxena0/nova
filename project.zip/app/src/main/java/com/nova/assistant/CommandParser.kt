package com.nova.assistant

import java.util.Locale

enum class Kind {
    // Creative & Conversational AI
    STORY, JOKE, SHAYARI, CHAT, CLARIFY,
    // Apps, Search & Media
    OPEN, SEARCH, PLAY, ROBLOX, MUSIC_CONTROL,
    // Communication & Notifications
    CALL, MESSAGE, REPLY, READ_WHATSAPP, SUMMARIZE_NOTIFICATIONS,
    // Phone Control & Screen
    FLASHLIGHT, OPEN_SETTINGS, PHONE_INFO, SCREEN_ANALYZE, CLIPBOARD,
    // Travel & Commute
    NEARBY, TRAIN_STATUS, TRAVEL_CHECKLIST, WEATHER,
    // Daily Planner
    TIMER, REMINDER, ALARM, DAILY_BRIEFING, DATE_TIME, TASK_MANAGE, ROUTINE_RUN, CALENDAR,
    // Study, Research & Files
    STUDY, TRANSLATE, VOICE_FLASHCARD, WEB_RESEARCH, FILE_ANALYZE,
    // Memory, Safety & Privacy
    MEMORY_SAVE, MEMORY_LIST, EMERGENCY, PRIVACY_PAUSE,
    // Nova v9.0 Perfection: Connectivity Toggles, Smart TV Control, Voice Macros & Ultimate Device Actions
    CONNECTIVITY, SMART_TV, MACRO_SAVE, WORKFLOW_HISTORY, TRAVEL_PLAN, STUDY_PROGRESS, EXPENSE, MEMORY_SEARCH, CAMERA_LENS, SCREEN_TRANSLATE, SCREEN_REPLY, VIVA_INTERVIEW, CALL_CONTROL, UNREAD_DIGEST, KB_SAVE, KB_QUERY, KB_LIST, DEVICE_ACTION, NAVIGATE, UTILITY, NOTE,
    // Accessibility Agent & Unknown
    AGENT, UNKNOWN
}

data class Command(
    val kind: Kind,
    val app: AppInfo? = null,
    val query: String = "",
    val heard: String = "",
    val contact: String = "",
    val contactKey: String = "",
    val body: String = "",
    val sms: Boolean = false,
    val extraMinutes: Int = 0,
    val extraHour: Int = -1,
    val extraMinute: Int = -1,
    val candidateApps: List<AppInfo> = emptyList()
)

data class Tok(val text: String, val m: String, val orig: String = text)

/**
 * Intent-first Command Parser (English, Hindi & Hinglish -> clean Roman Hinglish).
 * - Distinguishes creative AI narration ("Nova kahani sunao", "joke sunao", "shayari sunao")
 *   from explicit app searches ("YouTube par kahani search karo") and music playback ("gaana chalao").
 * - Never blindly maps "sunao" to YouTube.
 */
class CommandParser(private val index: AppIndex) {

    // NOTE: "sunao"/"suna" intentionally REMOVED from generic playVerbs so stories/jokes/shayari/news never hijack to YouTube!
    private val playVerbs = setOf(
        "play", "chalao", "chala", "chalaiye", "bajao", "baja", "lagao", "laga", "chalado"
    )
    private val searchVerbs = setOf(
        "search", "dhundo", "dhoondo", "dhundh", "khojo", "khoj",
        "find", "dikhao", "dikha", "lookup", "google"
    )
    private val openVerbs = setOf(
        "open", "kholo", "khol", "khole", "kholiye", "launch", "start", "chalu", "shuru"
    )
    private val preps = setOf(
        "par", "pe", "me", "mein", "mai", "on", "in", "se", "per",
        "ke", "ki", "ka", "ko", "for", "liye", "to"
    )
    private val fillers = setOf(
        "karo", "kar", "kardo", "karna", "do", "de", "dena", "dijiye", "please", "plz",
        "zara", "mujhe", "mere", "meri", "mera", "app", "application", "aur", "and",
        "the", "a", "ek", "hai", "wala", "wali", "wale", "na", "ya", "jo",
        "kuch", "bhi", "ab", "abhi", "can", "you", "i", "want", "ji",
        "hey", "hi", "he", "hay", "hello", "helo", "okay", "ok", "nova"
    )
    private val weak = setOf(
        "gaana", "gaane", "gana", "gane", "song", "songs",
        "music", "video", "videos", "vedio", "gaano", "game", "games"
    )

    private val stopWords: Set<String> = playVerbs + searchVerbs + openVerbs + preps + fillers

    private val callWords = setOf("call", "dial", "calling", "kol")
    private val replyWords = setOf("reply", "replay", "jawab", "jawaab", "jabab")
    private val msgWords = setOf("message", "messages", "msg", "text", "sms", "sandesh")
    private val sendVerbs = setOf("bhejo", "bhej", "send", "likho", "bolo", "bol")
    private val bodyMarkers = setOf("ki", "that", "saying")
    private val phoneDo = setOf("lagao", "laga", "karo", "kar", "kardo", "milao", "mila")
    private val videoWords = setOf("video", "videos", "vedio")
    private val verbBlock: Set<String> =
        replyWords + msgWords + sendVerbs + setOf("karo", "kar", "kardo", "do", "de", "dena", "dijiye", "please", "plz")

    fun stripWake(raw: String): String? = WakeStopDetector.stripWake(raw, isPartial = false)
    fun transliterate(s: String): String = HinglishConverter.transliterate(s)

    fun parse(rawInput: String): Command {
        val hinglish = HinglishConverter.toHinglish(rawInput)
        val lower = hinglish.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
        if (lower.isEmpty()) return Command(Kind.UNKNOWN, heard = "")

        // 0) Privacy & Pause Everything
        parsePrivacyPause(hinglish, lower)?.let { return it }

        // 1) Emergency & Safety
        parseEmergency(hinglish, lower)?.let { return it }

        // 2) Explicit App Search check FIRST when user explicitly names YouTube/Spotify/Google + search
        //    e.g., "YouTube par kahani search karo" MUST search YouTube, NOT trigger AI Story!
        parseExplicitAppSearch(hinglish, lower)?.let { return it }

        // 3) Creative AI Narration: Story, Joke, Shayari/Poem (BEFORE Play/Media!)
        parseCreativeIntent(hinglish, lower)?.let { return it }

        // 4) Custom Voice Shortcuts, Smart TV Voice Control, Connectivity ON/OFF & Hardware Controls
        parseMacroSave(hinglish, lower)?.let { return it }
        parseTravelPlan(hinglish, lower)?.let { return it }
        parseStudyProgress(hinglish, lower)?.let { return it }
        parseExpenseVoice(hinglish, lower)?.let { return it }
        parseWorkflowHistory(hinglish, lower)?.let { return it }
        parseMemorySearch(hinglish, lower)?.let { return it }
        parseCameraLens(hinglish, lower)?.let { return it }
        parseContextualScreenOverlay(hinglish, lower)?.let { return it }
        parseVivaInterview(hinglish, lower)?.let { return it }
        parseCallControl(hinglish, lower)?.let { return it }
        parseUnreadDigest(hinglish, lower)?.let { return it }
        parseKnowledgeVault(hinglish, lower)?.let { return it }
        parseSmartTv(hinglish, lower)?.let { return it }
        parseFlashlight(hinglish, lower)?.let { return it }
        parseConnectivityToggle(hinglish, lower)?.let { return it }
        parseOpenSettings(hinglish, lower)?.let { return it }
        parseUltimateDeviceAction(hinglish, lower)?.let { return it }
        parseNavigation(hinglish, lower)?.let { return it }
        parseUtility(hinglish, lower)?.let { return it }
        parseVoiceNotes(hinglish, lower)?.let { return it }

        // 5) Countdown Timers ("10 minute ka timer lagao")
        parseTimer(hinglish, lower)?.let { return it }

        // 6) Notification Intelligence ("mere notifications summarize karo")
        parseNotifications(hinglish, lower)?.let { return it }

        // 7) Screen Understanding & File Assistant
        parseScreenAnalyze(hinglish, lower)?.let { return it }
        parseFileAnalyze(hinglish, lower)?.let { return it }

        // 8) Voice Flashcards & Quick Revision
        parseVoiceFlashcards(hinglish, lower)?.let { return it }

        // 9) Smart Commute: Travel Checklist & Voice-Only Live Train Status (RailRadar)
        parseTravelChecklist(hinglish, lower)?.let { return it }
        parseTrainStatus(hinglish, lower)?.let { return it }

        // 10) Daily Planner: Tasks, Routines, Calendar, Reminders & Alarms
        parseTasks(hinglish, lower)?.let { return it }
        parseRoutine(hinglish, lower)?.let { return it }
        parseCalendar(hinglish, lower)?.let { return it }
        parseReminderOrAlarm(hinglish, lower)?.let { return it }

        // 11) Smart Memory (save / list)
        parseMemory(hinglish, lower)?.let { return it }

        // 12) Nearby Places
        parseNearby(hinglish, lower)?.let { return it }

        // 13) Music & Volume Controls (including "gaana sunao" / "song chalao")
        parseMusicControl(hinglish, lower)?.let { return it }

        // 14) Clipboard Assistant
        parseClipboard(hinglish, lower)?.let { return it }

        // 15) Daily Assistant: Briefing, Weather, Date/Time
        parseDailyAssistant(hinglish, lower)?.let { return it }

        // 16) Phone Information
        parsePhoneInfo(hinglish, lower)?.let { return it }

        // 17) Web Research & Latest News
        parseWebResearch(hinglish, lower)?.let { return it }

        // 18) Follow-up Conversation cues
        parseFollowUp(hinglish, lower)?.let { return it }

        // 19) Translation & Grammar Correction
        parseTranslation(hinglish, lower)?.let { return it }

        // 20) Study Assistant (Offline Math + Science/Study/Summary)
        parseStudy(hinglish, lower)?.let { return it }

        // 21) Roblox Game Search / Launch
        parseRoblox(hinglish, lower)?.let { return it }

        // 22) Tokenized Call / Message / Reply / Open / Search / Play
        val tokens = tokenize(hinglish)
        specialComm(tokens, hinglish)?.let { return it }

        var kind = when {
            tokens.any { it.m in playVerbs } -> Kind.PLAY
            tokens.any { it.m in searchVerbs } -> Kind.SEARCH
            tokens.any { it.m in openVerbs } -> Kind.OPEN
            else -> Kind.UNKNOWN
        }

        val (app, appRange, candidates) = findAppWithCandidates(tokens)

        val resolvedApp = if (kind == Kind.PLAY && app == null && tokens.any { it.m in videoWords }) {
            index.byPackage("com.google.android.youtube")
        } else app

        val query = tokens.withIndex()
            .filter { (i, t) -> i !in appRange && t.m !in stopWords && t.m !in weak }
            .joinToString(" ") { it.value.orig }
            .trim()

        // Guard: if kind is PLAY with no music/video cue and no app, treat as UNKNOWN so Resolver routes to AI instead of YouTube!
        if (kind == Kind.PLAY && resolvedApp == null && tokens.none { it.m in weak }) {
            kind = Kind.UNKNOWN
        }

        if (kind == Kind.UNKNOWN) {
            kind = when {
                resolvedApp != null && query.isEmpty() -> Kind.OPEN
                resolvedApp != null -> Kind.SEARCH
                else -> Kind.UNKNOWN
            }
        }

        var finalApp = resolvedApp
        var finalCandidates = candidates
        if (kind == Kind.OPEN && finalApp == null) {
            val looseKey = Normalizer.key(tokens.filter { it.m !in stopWords }.joinToString("") { it.m })
            val top = index.topMatches(looseKey, minScore = 0.68, limit = 3)
            if (top.isNotEmpty()) {
                finalApp = top.first().first
                if (top.size >= 2 && top[0].second - top[1].second <= 0.12 && top[0].second < 0.96) {
                    finalCandidates = top.map { it.first }
                }
            }
        }

        return Command(
            kind = kind,
            app = finalApp,
            query = query,
            heard = hinglish,
            candidateApps = finalCandidates
        )
    }

    private fun parseExplicitAppSearch(raw: String, lower: String): Command? {
        val hasSearchVerb = lower.contains("search") || lower.contains("dhundo") || lower.contains("dhoondo") || lower.contains("khojo")
        if (!hasSearchVerb) return null
        val tokens = tokenize(raw)
        val (app, appRange, _) = findAppWithCandidates(tokens)
        if (app == null) return null
        val query = tokens.withIndex()
            .filter { (i, t) -> i !in appRange && t.m !in stopWords && t.m !in weak }
            .joinToString(" ") { it.value.orig }
            .trim()
        return Command(Kind.SEARCH, app = app, query = query, heard = raw)
    }

    private fun parseCreativeIntent(raw: String, lower: String): Command? {
        if (lower.contains("kahani") || lower.contains("kahaani") || lower.contains("story")) {
            return Command(Kind.STORY, query = raw, heard = raw)
        }
        if (lower.contains("joke") || lower.contains("chutkula") || lower.contains("latifa") || lower.contains("funny")) {
            return Command(Kind.JOKE, query = raw, heard = raw)
        }
        if (lower.contains("shayari") || lower.contains("shairi") || lower.contains("kavita") || lower.contains("poem") || lower.contains("poetry")) {
            return Command(Kind.SHAYARI, query = raw, heard = raw)
        }
        return null
    }

    private fun parseFlashlight(raw: String, lower: String): Command? {
        if (!lower.contains("flashlight") && !lower.contains("torch") && !lower.contains("flash light")) return null
        val mode = if (lower.contains("off") || lower.contains("band") || lower.contains("bujha")) "off" else "on"
        return Command(Kind.FLASHLIGHT, query = mode, heard = raw)
    }

    private fun parseOpenSettings(raw: String, lower: String): Command? {
        val mentionsSettings = lower.contains("settings") || lower.contains("setting")
        val wantsOpen = lower.contains("kholo") || lower.contains("open") || lower.contains("khol") || lower.contains("jao") || lower.contains("on karo") || lower.contains("off karo")
        if (!mentionsSettings && !((lower.contains("wi-fi") || lower.contains("wifi") || lower.contains("bluetooth") || lower.contains("mobile data")) && (lower.contains("on karo") || lower.contains("off karo") || lower.contains("kholo") || lower.contains("open")))) {
            return null
        }
        if (!wantsOpen && !mentionsSettings) return null
        val topic = when {
            lower.contains("wi-fi") || lower.contains("wifi") -> "wifi"
            lower.contains("bluetooth") -> "bluetooth"
            lower.contains("data") || lower.contains("network") || lower.contains("sim") -> "data"
            lower.contains("display") || lower.contains("brightness") -> "display"
            lower.contains("sound") || lower.contains("ringtone") -> "sound"
            lower.contains("battery") -> "battery"
            lower.contains("location") || lower.contains("gps") -> "location"
            lower.contains("storage") -> "storage"
            lower.contains("notification") -> "notification"
            lower.contains("app") -> "apps"
            else -> "main"
        }
        return Command(Kind.OPEN_SETTINGS, query = topic, heard = raw)
    }

    private fun parseTimer(raw: String, lower: String): Command? {
        if (!lower.contains("timer")) return null
        var mins = 0
        Regex("(\\d+)\\s*(?:min|mins|minute|minutes)").find(lower)?.let {
            mins = it.groupValues[1].toIntOrNull() ?: 0
        }
        return Command(Kind.TIMER, query = raw, heard = raw, extraMinutes = mins)
    }

    private fun parseNotifications(raw: String, lower: String): Command? {
        if ((lower.contains("notification") || lower.contains("notifications")) &&
            (lower.contains("summar") || lower.contains("batao") || lower.contains("padho") || lower.contains("read") || lower.contains("check") || lower.contains("kitne"))
        ) {
            return Command(Kind.SUMMARIZE_NOTIFICATIONS, query = raw, heard = raw)
        }
        if ((lower.contains("whatsapp") || lower.contains("message")) &&
            (lower.contains("padho") || lower.contains("read") || lower.contains("sunao") || lower.contains("naya") || lower.contains("aaya")) &&
            !lower.contains("bhejo") && !lower.contains("send") && !lower.contains("reply")
        ) {
            return Command(Kind.READ_WHATSAPP, heard = raw)
        }
        return null
    }

    private fun parseScreenAnalyze(raw: String, lower: String): Command? {
        if (lower.contains("screen") && !lower.contains("screen time") && !lower.contains("brightness") &&
            (lower.contains("samjhao") || lower.contains("explain") || lower.contains("analy") || lower.contains("padho") || lower.contains("kya hai") || lower.contains("kya dikh") || lower.contains("read"))
        ) {
            return Command(Kind.SCREEN_ANALYZE, query = raw, heard = raw)
        }
        return null
    }

    private fun parseFileAnalyze(raw: String, lower: String): Command? {
        val mentionsDoc = lower.contains("file") || lower.contains("pdf") || lower.contains("document") || lower.contains("docx") || lower.contains("image") || lower.contains("photo")
        val asksAnalyze = lower.contains("summar") || lower.contains("padho") || lower.contains("read") || lower.contains("explain") || lower.contains("samjhao") || lower.contains("kya likha") || lower.contains("question")
        if (mentionsDoc && asksAnalyze) {
            return Command(Kind.FILE_ANALYZE, query = raw, heard = raw)
        }
        // "is text ka summary banao" -> if active doc loaded, use FileAssistant, else Clipboard/AI!
        if ((lower.contains("is text ka summary") || lower.contains("text ka summary") || lower.contains("summarize this text")) && !lower.contains("clipboard")) {
            return if (FileAssistant.activeDoc != null) Command(Kind.FILE_ANALYZE, query = raw, heard = raw)
            else Command(Kind.CLIPBOARD, query = "summarize", heard = raw)
        }
        return null
    }

    private fun parseTasks(raw: String, lower: String): Command? {
        if ((lower.contains("task") || lower.contains("to-do") || lower.contains("todo")) && !lower.contains("aaj ke task")) {
            return Command(Kind.TASK_MANAGE, query = raw, heard = raw)
        }
        return null
    }

    private fun parseRoutine(raw: String, lower: String): Command? {
        if (lower.contains("routine") || lower.contains("study mode") || lower.contains("sleep mode") || lower.contains("good night routine") || lower.contains("morning routine")) {
            return Command(Kind.ROUTINE_RUN, query = raw, heard = raw)
        }
        return null
    }

    private fun parseCalendar(raw: String, lower: String): Command? {
        if (lower.contains("calendar") || lower.contains("schedule") && (lower.contains("aaj") || lower.contains("event") || lower.contains("meeting"))) {
            return Command(Kind.CALENDAR, query = raw, heard = raw)
        }
        return null
    }

    private fun parseWebResearch(raw: String, lower: String): Command? {
        if (lower.contains("research") || lower.contains("latest news") || lower.contains("aaj ki news") ||
            lower.contains("news batao") || lower.contains("fact check") || lower.contains("web par")
        ) {
            return Command(Kind.WEB_RESEARCH, query = raw, heard = raw)
        }
        return null
    }

    private fun parsePrivacyPause(raw: String, lower: String): Command? {
        val isPrivacy = lower.contains("pause everything") || lower.contains("sab pause") ||
            lower.contains("sab kuch pause") || lower.contains("privacy mode") ||
            lower.contains("sab band kar do") || lower.contains("resume nova") ||
            lower.contains("privacy off")
        if (!isPrivacy) return null
        val mode = if (lower.contains("off") || lower.contains("resume") || (lower.contains("band karo") && lower.contains("privacy"))) {
            "off"
        } else "on"
        return Command(Kind.PRIVACY_PAUSE, query = mode, heard = raw)
    }

    private fun parseVoiceFlashcards(raw: String, lower: String): Command? {
        if (lower.contains("flashcard") || lower.contains("flash card") ||
            (lower.contains("revision") && (lower.contains("shuru") || lower.contains("start") || lower.contains("voice"))) ||
            (lower.contains("quiz") && (lower.contains("shuru") || lower.contains("start") || lower.contains("khelo") || lower.contains("voice")))
        ) {
            return Command(Kind.VOICE_FLASHCARD, query = raw, heard = raw)
        }
        return null
    }

    private fun parseTravelChecklist(raw: String, lower: String): Command? {
        if (lower.contains("checklist") || lower.contains("check list") ||
            ((lower.contains("travel") || lower.contains("departure") || lower.contains("safar") || lower.contains("packing")) &&
                (lower.contains("list") || lower.contains("pack") || lower.contains("samaan")))
        ) {
            return Command(Kind.TRAVEL_CHECKLIST, query = raw, heard = raw)
        }
        return null
    }

    private fun parseTrainStatus(raw: String, lower: String): Command? {
        if (lower.contains("railway station") && (lower.contains("paas") || lower.contains("near") || lower.contains("sabse"))) {
            return null
        }
        val has5Digit = RailRadarHelper.extractTrainNumber(raw) != null
        val mentionsTrain = lower.contains("train") || lower.contains("express") ||
            lower.contains("vande bharat") || lower.contains("shatabdi") ||
            lower.contains("rajdhani") || lower.contains("superfast") || lower.contains("passenger") ||
            lower.contains("mail") || lower.contains("gaadi") || lower.contains("gadi")
        val asksStatus = lower.contains("kahan") || lower.contains("kaha") || lower.contains("pahunch") ||
            lower.contains("pohch") || lower.contains("depart") || lower.contains("arrival") ||
            lower.contains("status") || lower.contains("running") || lower.contains("late") ||
            lower.contains("time") || lower.contains("timing") || lower.contains("location") ||
            lower.contains("live") || lower.contains("kab") || lower.contains("niklegi") || lower.contains("aayegi")

        if ((mentionsTrain && asksStatus) || (has5Digit && (mentionsTrain || asksStatus))) {
            return Command(Kind.TRAIN_STATUS, query = raw, heard = raw)
        }
        // Follow-up about the train asked just before: "woh kahan pahunchi", "kitni late hai", "agla station"
        if (!has5Digit && RailRadarHelper.recentTrainNo() != null) {
            val pronoun = Regex("\\b(woh|wo|vo|voh|wohi|us|usi|wahi|vahi|iski|uski|same)\\b").containsMatchIn(lower)
            val where = lower.contains("kahan") || lower.contains("kaha ") || lower.endsWith("kaha")
            val strong = lower.contains("pahunch") || lower.contains("pohch") || lower.contains("delay") ||
                Regex("\\blate\\b").containsMatchIn(lower) ||
                lower.contains("agla station") || lower.contains("next station")
            if ((pronoun && (where || strong)) || strong) {
                return Command(Kind.TRAIN_STATUS, query = raw, heard = raw)
            }
        }
        return null
    }

    private fun parseFollowUp(raw: String, lower: String): Command? {
        val explicitFollowUps = listOf(
            "isko aur simple", "aur simple samjhao", "simple me samjhao", "aasan bhasha me samjhao",
            "iska example", "ek example do", "example do", "aur detail me", "detail me batao",
            "short me batao", "aage batao", "is par aur", "iske baare me aur", "explain more",
            "give an example", "tell me more", "make it simpler", "in english", "in hindi",
            "isko english me", "isko hindi me", "summarize that", "repeat that"
        )
        if (explicitFollowUps.any { lower.contains(it) }) {
            return Command(Kind.CHAT, query = raw, heard = raw)
        }
        if (FollowUpTracker.isRecent()) {
            val shortFollowUpWords = setOf("kyun", "kyu", "kaise", "why", "how", "example", "more", "aur", "matlab", "really")
            val words = lower.split(" ").filter { it.isNotBlank() }
            if (words.size <= 4 && words.any { it in shortFollowUpWords }) {
                return Command(Kind.CHAT, query = raw, heard = raw)
            }
        }
        return null
    }

    private fun parseEmergency(raw: String, lower: String): Command? {
        if (lower.contains("emergency") || lower.contains("sos") || lower.contains("bachao") ||
            lower.contains("police call") || lower.contains("ambulance") || lower.contains("112")
        ) {
            val mode = when {
                lower.contains("location") || lower.contains("share") -> "location"
                lower.contains("contact") || lower.contains("call") -> "call"
                else -> "sos"
            }
            return Command(Kind.EMERGENCY, query = mode, heard = raw)
        }
        return null
    }

    private fun parseMemory(raw: String, lower: String): Command? {
        val savePrefixes = listOf("yaad rakho", "yaad rakhna", "remember that", "remember ", "save memory", "memory save")
        for (p in savePrefixes) {
            val idx = lower.indexOf(p)
            if (idx >= 0) {
                val body = raw.substring(idx + p.length).replace(Regex("^(ki|that|:)\\s*", RegexOption.IGNORE_CASE), "").trim()
                if (body.isNotEmpty()) {
                    return Command(Kind.MEMORY_SAVE, body = body, heard = raw)
                }
            }
        }
        if ((lower.contains("memory") || lower.contains("yaad")) &&
            (lower.contains("dikhao") || lower.contains("batao") || lower.contains("list") || lower.contains("show") || lower.contains("kya yaad"))
        ) {
            return Command(Kind.MEMORY_LIST, heard = raw)
        }
        return null
    }

    private fun parseReminderOrAlarm(raw: String, lower: String): Command? {
        val isAlarm = lower.contains("alarm")
        val isReminder = lower.contains("remind") || lower.contains("yaad dilana") || lower.contains("yaad dila")
        if (!isAlarm && !isReminder) return null

        var mins = 0
        Regex("(\\d+)\\s*(?:min|mins|minute|minutes)").find(lower)?.let {
            mins += it.groupValues[1].toIntOrNull() ?: 0
        }
        Regex("(\\d+)\\s*(?:hr|hrs|hour|hours|ghante|ghanta)").find(lower)?.let {
            mins += (it.groupValues[1].toIntOrNull() ?: 0) * 60
        }

        var hour = -1
        var minute = 0
        val colonMatch = Regex("(\\d{1,2}):(\\d{2})\\s*(am|pm)?").find(lower)
        val bajeMatch = Regex("(\\d{1,2})\\s*(?:baje|am|pm)").find(lower)
        when {
            colonMatch != null -> {
                hour = colonMatch.groupValues[1].toIntOrNull() ?: -1
                minute = colonMatch.groupValues[2].toIntOrNull() ?: 0
                val ap = colonMatch.groupValues[3]
                if (ap == "pm" && hour in 1..11) hour += 12
                if (ap == "am" && hour == 12) hour = 0
            }
            bajeMatch != null -> {
                hour = bajeMatch.groupValues[1].toIntOrNull() ?: -1
                val ap = when {
                    lower.contains("pm") || lower.contains("shaam") || lower.contains("raat") -> "pm"
                    lower.contains("am") || lower.contains("subah") -> "am"
                    else -> ""
                }
                if (ap == "pm" && hour in 1..11) hour += 12
                if (ap == "am" && hour == 12) hour = 0
            }
            lower.contains("kal subah") || lower.contains("tomorrow morning") -> {
                hour = 8
                minute = 0
            }
        }

        val cleanTitle = raw
            .replace(Regex("\\b(set|create|lagao|laga|karo|kar|do|ek|a|an|alarm|reminder|remind|me|mujhe|yaad|dilana|dila|dena|baad|after|in|at|for|ka|ki|ke|kal|tomorrow|subah|morning|shaam|raat|baje|am|pm|minutes?|mins?|hours?|hrs?|ghante|ghanta)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\b\\d{1,2}(:\\d{2})?\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifEmpty { if (isAlarm) "Nova Alarm" else "Nova Reminder" }

        return if (isAlarm) {
            Command(Kind.ALARM, body = cleanTitle, heard = raw, extraMinutes = mins, extraHour = hour, extraMinute = minute)
        } else {
            Command(Kind.REMINDER, body = cleanTitle, heard = raw, extraMinutes = mins, extraHour = hour, extraMinute = minute)
        }
    }

    private fun parseNearby(raw: String, lower: String): Command? {
        val place = NearbyPlacesHelper.detectPlaceType(lower) ?: return null
        val hasIntent = lower.contains("paas") || lower.contains("pass") || lower.contains("near") ||
            lower.contains("closest") || lower.contains("nearest") || lower.contains("sabse") ||
            lower.contains("kahan") || lower.contains("kaha") || lower.contains("dhundo") ||
            lower.contains("find") || lower.contains("map") || lower.contains("distance") ||
            lower.contains("door") || lower.contains("dur") || lower.contains("route")
        return if (hasIntent) Command(Kind.NEARBY, query = place.label, heard = raw) else null
    }

    private fun parseMusicControl(raw: String, lower: String): Command? {
        val cleanNoWake = lower.replace(Regex("^(hey|hi|hello|okay|ok)?\\s*nova\\s*"), "").trim()
        return when {
            lower.contains("volume") || lower.contains("awaz") || lower.contains("awaaz") || lower.contains("sound") -> {
                val ctrl = when {
                    lower.contains("mute") || lower.contains("silent") || lower.contains("band") || lower.contains("zero") -> "mute"
                    lower.contains("full") || lower.contains("max") || lower.contains("100") -> "volume_max"
                    lower.contains("up") || lower.contains("badha") || lower.contains("zyada") || lower.contains("tez") || lower.contains("increase") || lower.contains("high") -> "volume_up"
                    lower.contains("down") || lower.contains("kam") || lower.contains("slow") || lower.contains("decrease") || lower.contains("low") -> "volume_down"
                    else -> return null
                }
                Command(Kind.MUSIC_CONTROL, query = ctrl, heard = raw)
            }
            cleanNoWake in setOf("pause", "pause music", "music pause", "gaana roko", "song pause", "music band karo") ||
                (lower.contains("pause") && (lower.contains("music") || lower.contains("song") || lower.contains("gaana"))) ->
                Command(Kind.MUSIC_CONTROL, query = "pause", heard = raw)
            cleanNoWake in setOf("resume", "resume music", "play music", "music play", "music chalao", "gaana chalao", "gaana bajao", "gaana sunao", "song chalao") ->
                Command(Kind.PLAY, query = "", heard = raw)
            (lower.contains("next") || lower.contains("agla") || lower.contains("skip")) &&
                (lower.contains("song") || lower.contains("music") || lower.contains("gaana") || lower.contains("track") || cleanNoWake == "next song" || cleanNoWake == "next") ->
                Command(Kind.MUSIC_CONTROL, query = "next", heard = raw)
            (lower.contains("previous") || lower.contains("pichla") || lower.contains("back")) &&
                (lower.contains("song") || lower.contains("music") || lower.contains("gaana") || lower.contains("track")) ->
                Command(Kind.MUSIC_CONTROL, query = "previous", heard = raw)
            else -> null
        }
    }

    private fun parseClipboard(raw: String, lower: String): Command? {
        if (!lower.contains("clipboard") && !lower.contains("copied") && !lower.contains("copy kiya")) return null
        val op = when {
            lower.contains("summar") || lower.contains("short") || lower.contains("chhota") -> "summarize"
            lower.contains("translat") || lower.contains("anuvad") || lower.contains("hindi") || lower.contains("english") -> "translate"
            lower.contains("grammar") || lower.contains("correct") || lower.contains("sahi") -> "grammar"
            lower.contains("reply") || lower.contains("jawab") -> "reply"
            else -> "read"
        }
        return Command(Kind.CLIPBOARD, query = op, heard = raw)
    }

    private fun parseDailyAssistant(raw: String, lower: String): Command? {
        if (lower.contains("daily briefing") || lower.contains("aaj ka briefing") || lower.contains("subah ka update") || lower.contains("morning briefing") || lower.contains("aaj ke task")) {
            return Command(Kind.DAILY_BRIEFING, heard = raw)
        }
        if (lower.contains("weather") || lower.contains("mausam") || lower.contains("temperature") || lower.contains("temp ") || lower.endsWith("temp") || lower.contains("baarish")) {
            return Command(Kind.WEATHER, heard = raw)
        }
        if (lower.contains("aaj ki tarikh") || lower.contains("tarikh kya") || lower.contains("date kya") || lower.contains("what is the date") ||
            lower.contains("today's date") || lower.contains("aaj kaun sa din") || lower.contains("what day is") ||
            lower.contains("time kya") || lower.contains("kitne baje") || lower.contains("what time") || lower.contains("samay kya")
        ) {
            return Command(Kind.DATE_TIME, heard = raw)
        }
        return null
    }

    private fun parsePhoneInfo(raw: String, lower: String): Command? {
        val asksStatus = lower.contains("status") || lower.contains("kitni") || lower.contains("kitna") ||
            lower.contains("batao") || lower.contains("check") || lower.contains("kya") ||
            lower.contains("info") || lower.contains("health") || lower.contains("free") ||
            lower.contains("available") || lower.contains("usage") || lower.contains("screen time") ||
            lower.contains("percent") || lower.contains("%")
        if (!asksStatus && lower !in setOf("battery", "storage", "screen time", "wifi status", "bluetooth status", "phone info")) {
            return null
        }
        return when {
            lower.contains("phone info") || lower.contains("device info") || lower.contains("system info") || lower.contains("diagnostic") ->
                Command(Kind.PHONE_INFO, query = "all", heard = raw)
            lower.contains("battery") -> Command(Kind.PHONE_INFO, query = "battery", heard = raw)
            lower.contains("wi-fi") || lower.contains("wifi") -> Command(Kind.PHONE_INFO, query = "wifi", heard = raw)
            lower.contains("bluetooth") -> Command(Kind.PHONE_INFO, query = "bluetooth", heard = raw)
            lower.contains("internet") || lower.contains("network") -> Command(Kind.PHONE_INFO, query = "internet", heard = raw)
            lower.contains("storage") || lower.contains("space") || lower.contains("memory kitni") ->
                Command(Kind.PHONE_INFO, query = "storage", heard = raw)
            lower.contains("screen time") || lower.contains("app usage") ->
                Command(Kind.PHONE_INFO, query = "screentime", heard = raw)
            else -> null
        }
    }

    private fun parseTranslation(raw: String, lower: String): Command? {
        if (lower.contains("translate") || lower.contains("translation") || lower.contains("english mein bolo") ||
            lower.contains("hindi mein bolo") || lower.contains("grammar") || lower.contains("rewrite") ||
            lower.contains("simple language") || lower.contains("aasan bhasha")
        ) {
            return Command(Kind.TRANSLATE, query = raw, heard = raw)
        }
        return null
    }

    private fun parseStudy(raw: String, lower: String): Command? {
        if (MathEvaluator.trySolve(raw) != null) {
            return Command(Kind.STUDY, query = raw, heard = raw)
        }
        if (lower.contains("explain") || lower.contains("samjhao") || lower.contains("quiz") ||
            lower.contains("practice question") || lower.contains("revision") || lower.contains("summarize") ||
            lower.contains("summary") || lower.contains("solve ") || lower.contains("formula") ||
            lower.contains("physics") || lower.contains("chemistry") || lower.contains("biology") ||
            lower.contains("calculus") || lower.contains("maths")
        ) {
            return Command(Kind.STUDY, query = raw, heard = raw)
        }
        return null
    }

    private fun parseRoblox(raw: String, lower: String): Command? {
        if (!lower.contains("roblox")) return null
        val cleaned = raw
            .replace(Regex("\\b(roblox|mein|me|par|pe|in|on|open|kholo|play|chalao|search|dhundo|find|game|games|karo|do|launch|start)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        return Command(Kind.ROBLOX, app = index.byPackage(RobloxHelper.ROBLOX_PKG), query = cleaned, heard = raw)
    }

    private fun specialComm(tokens: List<Tok>, raw: String): Command? {
        val ms = tokens.map { it.m }
        if (ms.isEmpty()) return null
        val firstOpen = ms.indexOfFirst { it in openVerbs }
        val hasKo = "ko" in ms

        if (ms.any { it in replyWords }) return messageLike(Kind.REPLY, tokens, raw)

        val callIdx = ms.indexOfFirst { it in callWords }
        val msgIdx = ms.indexOfFirst { it in msgWords || it in sendVerbs }
        val hasSend = ms.any { it in sendVerbs }
        val msgLike = msgIdx >= 0 && (hasKo || hasSend) && (firstOpen < 0 || msgIdx < firstOpen)

        if (msgLike && (callIdx < 0 || msgIdx < callIdx)) return messageLike(Kind.MESSAGE, tokens, raw)

        val phoneCall = "phone" in ms && hasKo && ms.any { it in phoneDo } && firstOpen < 0
        if ((callIdx >= 0 && (firstOpen < 0 || callIdx < firstOpen)) || phoneCall) {
            val skip = stopWords + callWords + weak + setOf("phone", "ko")
            val nameToks = tokens.filter { it.m !in skip }
            val contactStr = nameToks.joinToString(" ") { it.orig }.trim()
            return Command(
                kind = Kind.CALL,
                heard = raw,
                contact = contactStr,
                contactKey = Normalizer.key(nameToks.joinToString("") { it.m })
            )
        }
        return null
    }

    private fun messageLike(kind: Kind, tokens: List<Tok>, raw: String): Command {
        val ms = tokens.map { it.m }
        val nameEnd = ms.indexOfFirst { it == "ko" || it == "ke" }
        val from = if (nameEnd >= 0) nameEnd + 1 else 0

        var bodyStart = -1
        val ki = (from until ms.size).firstOrNull { ms[it] in bodyMarkers }
        if (ki != null) {
            bodyStart = ki + 1
        } else {
            val v = (from until ms.size).firstOrNull { ms[it] in verbBlock }
            if (v != null) {
                var k = v
                while (k < ms.size && ms[k] in verbBlock) k++
                bodyStart = k
            }
        }
        if (bodyStart < 0) bodyStart = ms.size

        val head = tokens.subList(0, bodyStart)
        val body = HinglishConverter.toHinglish(tokens.drop(bodyStart).joinToString(" ") { it.orig })
        val (app, range, _) = findAppWithCandidates(head, verbBlock)

        val nameBase = if (nameEnd >= 0) tokens.subList(0, nameEnd) else head
        val nameToks = nameBase.withIndex()
            .filter { (i, t) ->
                i !in range && t.m !in stopWords && t.m !in verbBlock && t.m !in weak &&
                    t.m !in bodyMarkers && t.m != "ko" && t.m != "ke"
            }
            .map { it.value }

        return Command(
            kind = kind,
            app = app,
            heard = raw,
            contact = nameToks.joinToString(" ") { it.orig }.trim(),
            contactKey = Normalizer.key(nameToks.joinToString("") { it.m }),
            body = body,
            sms = ms.any { it == "sms" }
        )
    }

    private fun findAppWithCandidates(
        tokens: List<Tok>,
        skip: Set<String> = emptySet()
    ): Triple<AppInfo?, IntRange, List<AppInfo>> {
        var bestApp: AppInfo? = null
        var bestScore = 0.0
        var bestRange: IntRange = IntRange.EMPTY
        var bestCandidates: List<AppInfo> = emptyList()

        for (start in tokens.indices) {
            if (tokens[start].m in stopWords || tokens[start].m in skip) continue
            var joined = ""
            for (end in start until minOf(tokens.size, start + 3)) {
                if (tokens[end].m in stopWords || tokens[end].m in skip) break
                joined += tokens[end].m
                val top = index.topMatches(Normalizer.key(joined), minScore = 0.80, limit = 3)
                if (top.isEmpty()) continue
                val match = top.first()
                var s = match.second + 0.002 * (end - start)
                if (start > 0 && tokens[start - 1].m in preps) s += 0.05
                if (end + 1 < tokens.size && tokens[end + 1].m in preps) s += 0.05
                if (s > bestScore) {
                    bestScore = s
                    bestApp = match.first
                    bestRange = start..end
                    bestCandidates = if (top.size >= 2 && top[0].second - top[1].second <= 0.09 && top[0].second < 0.98) {
                        top.map { it.first }
                    } else emptyList()
                }
            }
        }
        return Triple(bestApp, bestRange, bestCandidates)
    }

    private fun tokenize(hinglish: String): List<Tok> {
        val rawWords = hinglish.split(Regex("\\s+")).filter { it.isNotBlank() }
        return rawWords.mapNotNull { orig ->
            val cleaned = orig.replace(Regex("[^\\p{L}\\p{N}]+"), "")
            if (cleaned.isEmpty()) return@mapNotNull null
            val m = cleaned.lowercase(Locale.ROOT)
            Tok(cleaned, m, orig)
        }
    }

    private fun parseUltimateDeviceAction(raw: String, lower: String): Command? {
        Regex("(?:volume|awaaz|awaz).*?(\\d{1,3})\\s*(?:%|percent)?").find(lower)?.let {
            return Command(Kind.DEVICE_ACTION, query = "volume_percent", body = it.groupValues[1], heard = raw)
        }
        if (lower.contains("unmute")) return Command(Kind.DEVICE_ACTION, query = "unmute", heard = raw)
        if (lower.contains("silent mode") || lower.contains("phone silent")) return Command(Kind.DEVICE_ACTION, query = "ringer_silent", heard = raw)
        if (lower.contains("vibrate mode") || lower.contains("phone vibrate")) return Command(Kind.DEVICE_ACTION, query = "ringer_vibrate", heard = raw)
        if (lower.contains("normal mode") || lower.contains("ring mode")) return Command(Kind.DEVICE_ACTION, query = "ringer_normal", heard = raw)

        if (lower.contains("brightness") || lower.contains("roshni")) {
            val pct = Regex("(\\d{1,3})").find(lower)?.groupValues?.get(1)
            return when {
                pct != null -> Command(Kind.DEVICE_ACTION, query = "brightness_set", body = pct, heard = raw)
                lower.contains("full") || lower.contains("max") -> Command(Kind.DEVICE_ACTION, query = "brightness_set", body = "100", heard = raw)
                lower.contains("kam") || lower.contains("low") || lower.contains("down") -> Command(Kind.DEVICE_ACTION, query = "brightness_down", heard = raw)
                else -> Command(Kind.DEVICE_ACTION, query = "brightness_up", heard = raw)
            }
        }
        if (lower.contains("screenshot")) return Command(Kind.DEVICE_ACTION, query = "screenshot", heard = raw)
        if (lower.contains("screen lock") || lower.contains("phone lock") || lower == "lock screen") {
            return Command(Kind.DEVICE_ACTION, query = "lock_screen", heard = raw)
        }
        if (lower.contains("back jao") || lower == "go back" || lower == "back") {
            return Command(Kind.DEVICE_ACTION, query = "nav_back", heard = raw)
        }
        if (lower.contains("home screen") || lower == "go home" || lower == "home jao") {
            return Command(Kind.DEVICE_ACTION, query = "nav_home", heard = raw)
        }
        if (lower.contains("recent apps") || lower.contains("recents")) {
            return Command(Kind.DEVICE_ACTION, query = "nav_recents", heard = raw)
        }
        if (lower.contains("notification panel") || lower.contains("notifications kholo")) {
            return Command(Kind.DEVICE_ACTION, query = "nav_notifs", heard = raw)
        }
        if (lower.contains("quick settings")) {
            return Command(Kind.DEVICE_ACTION, query = "nav_quick_settings", heard = raw)
        }
        if (lower.contains("scroll down") || lower.contains("niche scroll") || lower.contains("neeche scroll")) {
            return Command(Kind.DEVICE_ACTION, query = "scroll_down", heard = raw)
        }
        if (lower.contains("scroll up") || lower.contains("upar scroll")) {
            return Command(Kind.DEVICE_ACTION, query = "scroll_up", heard = raw)
        }
        Regex("^(?:nova\\s+)?(?:click|tap|dabao)\\s+(.+)$").find(lower)?.let {
            return Command(Kind.DEVICE_ACTION, query = "tap_text", body = it.groupValues[1].trim(), heard = raw)
        }
        Regex("^(?:nova\\s+)?(?:type|likh do)\\s+(.+)$").find(lower)?.let {
            return Command(Kind.DEVICE_ACTION, query = "type_text", body = it.groupValues[1].trim(), heard = raw)
        }
        if (lower.contains("selfie")) return Command(Kind.DEVICE_ACTION, query = "camera_selfie", heard = raw)
        if (lower.contains("video record") || lower.contains("video camera")) return Command(Kind.DEVICE_ACTION, query = "camera_video", heard = raw)
        if (lower.contains("camera kholo") || lower.contains("open camera") || lower.contains("photo khincho")) {
            return Command(Kind.DEVICE_ACTION, query = "camera_photo", heard = raw)
        }
        if (lower.contains("sos flash") || lower.contains("flash blink") || lower.contains("beacon")) {
            return Command(Kind.DEVICE_ACTION, query = "sos_flash", heard = raw)
        }
        if (lower.contains("upi kholo") || lower.contains("qr scan")) {
            return Command(Kind.DEVICE_ACTION, query = "open_upi", heard = raw)
        }
        if (lower.contains("email bhejo") || lower.contains("send email")) {
            val subj = raw.replace(Regex("(?i)email bhejo|send email|nova"), "").trim()
            return Command(Kind.DEVICE_ACTION, query = "compose_email", body = subj, heard = raw)
        }
        Regex("\\b([a-z0-9-]+\\.(?:com|in|org|net|ai|io))\\b").find(lower)?.let {
            if (lower.contains("open") || lower.contains("kholo") || lower.contains("website")) {
                return Command(Kind.DEVICE_ACTION, query = "open_website", body = it.groupValues[1], heard = raw)
            }
        }
        return null
    }

    private fun parseNavigation(raw: String, lower: String): Command? {
        val m1 = Regex("(?:navigate to|directions to|route to)\\s+(.+)").find(lower)
        val m2 = Regex("(.+?)\\s+(?:ka rasta|ke liye rasta|jaane ka rasta)").find(lower)
        val dest = (m1?.groupValues?.get(1) ?: m2?.groupValues?.get(1))
            ?.replace(Regex("\\b(dikhao|batao|chalo|nova|hey|hi|hello|okay)\\b"), "")
            ?.replace(Regex("\\s+"), " ")
            ?.trim()
        return if (!dest.isNullOrBlank()) Command(Kind.NAVIGATE, query = dest, heard = raw) else null
    }

    private fun parseUtility(raw: String, lower: String): Command? {
        if (lower.contains("coin toss") || lower.contains("flip a coin") || lower.contains("sikka uchhalo")) {
            return Command(Kind.UTILITY, query = "coin", heard = raw)
        }
        if (lower.contains("roll a dice") || lower.contains("dice roll") || lower.contains("pasa")) {
            return Command(Kind.UTILITY, query = "dice", heard = raw)
        }
        if (lower.contains("random number")) {
            return Command(Kind.UTILITY, query = "random", body = raw, heard = raw)
        }
        if (lower.contains("stopwatch")) {
            val op = when {
                lower.contains("stop") || lower.contains("band") -> "stopwatch_stop"
                lower.contains("kitna") || lower.contains("time") || lower.contains("check") -> "stopwatch_check"
                else -> "stopwatch_start"
            }
            return Command(Kind.UTILITY, query = op, heard = raw)
        }
        if (UltimatePowerHelper.convertUnitsOffline(lower) != null) {
            return Command(Kind.UTILITY, query = "unit_convert", body = raw, heard = raw)
        }
        return null
    }

    private fun parseVoiceNotes(raw: String, lower: String): Command? {
        if (lower.contains("notes clear") || lower.contains("notes delete")) {
            return Command(Kind.NOTE, query = "clear", heard = raw)
        }
        if (lower.contains("mere notes") || lower.contains("notes padho") || lower.contains("read notes")) {
            return Command(Kind.NOTE, query = "list", heard = raw)
        }
        Regex("(?:note likho|note save karo|take a note|add note)\\s+(.+)").find(lower)?.let {
            return Command(Kind.NOTE, query = "add", body = it.groupValues[1].trim(), heard = raw)
        }
        return null
    }


    private fun parseMacroSave(raw: String, lower: String): Command? {
        val m = Regex("(?:shortcut banao|macro banao|command save karo)[:\\s]+(.+?)\\s+(?:matlab|means|=|karne par)\\s+(.+)").find(lower)
            ?: return null
        val trigger = m.groupValues[1].trim()
        val actions = m.groupValues[2].trim()
        if (trigger.length < 2 || actions.length < 3) return null
        return Command(Kind.MACRO_SAVE, query = trigger, body = actions, heard = raw)
    }

    private fun parseConnectivityToggle(raw: String, lower: String): Command? {
        // Explicit "settings kholo" should still open Settings page instead of toggling
        if (lower.contains("settings") && !lower.contains("quick settings")) return null

        val wantsOff = Regex("\\b(off|band|disable|close|rok|bujha|turn off|switch off)\\b").containsMatchIn(lower)
        val wantsOn = Regex("\\b(on|chalu|enable|start|shuru|turn on|switch on)\\b").containsMatchIn(lower)
        val wantsToggle = lower.contains("toggle")
        if (!wantsOff && !wantsOn && !wantsToggle) {
            if (lower.contains("power menu") || lower.contains("power dialog")) {
                return Command(Kind.CONNECTIVITY, query = "power_menu", body = "toggle", heard = raw)
            }
            return null
        }
        val state = when {
            wantsOff && !wantsOn -> "off"
            wantsOn && !wantsOff -> "on"
            else -> "toggle"
        }

        val feature = when {
            lower.contains("hotspot") || lower.contains("tethering") -> "hotspot"
            lower.contains("wi-fi") || lower.contains("wifi") || lower.contains("wlan") -> "wifi"
            lower.contains("bluetooth") || lower.contains("blutooth") -> "bluetooth"
            lower.contains("mobile data") || lower.contains("cellular") || lower.contains("5g data") ||
                lower.contains("net ") || lower.endsWith(" net") ||
                (lower.contains("data") && !lower.contains("date")) ||
                (lower.contains("internet") && (wantsOn || wantsOff)) -> "mobile_data"
            lower.contains("airplane") || lower.contains("aeroplane") || lower.contains("flight mode") -> "airplane"
            lower.contains("auto rotate") || lower.contains("auto-rotate") || lower.contains("screen rotation") || lower.contains("rotation") -> "auto_rotate"
            lower.contains("do not disturb") || Regex("\\bdnd\\b").containsMatchIn(lower) -> "dnd"
            lower.contains("battery saver") || lower.contains("power saving") || lower.contains("power saver") -> "battery_saver"
            lower.contains("location") || Regex("\\bgps\\b").containsMatchIn(lower) -> "location"
            else -> return null
        }
        return Command(Kind.CONNECTIVITY, query = feature, body = state, heard = raw)
    }

    private fun parseSmartTv(raw: String, lower: String): Command? {
        val mentionsTv = Regex("\\b(tv|smart tv|television|mi tv|xiaomi tv|android tv|google tv)\\b").containsMatchIn(lower)
        if (!mentionsTv) return null

        if (lower.contains("scan") || lower.contains("dhundo") || lower.contains("find tv")) {
            return Command(Kind.SMART_TV, query = "scan", heard = raw)
        }
        if (lower.contains("connect") || lower.contains("pair")) {
            return Command(Kind.SMART_TV, query = "connect", heard = raw)
        }

        // Play / search on TV YouTube: "TV par arijit singh chalao" / "TV par comedy search karo"
        Regex("(?:tv|smart tv)\\s+(?:par|pe|me|mein|on)\\s+(.+?)\\s+(?:chalao|play|search|bajao|lagao)\\b").find(lower)?.let { m ->
            val q = m.groupValues[1]
                .replace(Regex("\\b(youtube|yt|par|pe|me|mein|gaana|song|video|karo|do)\\b"), " ")
                .replace(Regex("\\s+"), " ").trim()
            if (q.isNotEmpty()) {
                return Command(Kind.SMART_TV, query = "youtube_play", body = q, heard = raw)
            }
        }
        Regex("(?:play|search)\\s+(.+?)\\s+(?:on|in)\\s+(?:my\\s+)?(?:smart\\s+)?tv\\b").find(lower)?.let { m ->
            val q = m.groupValues[1].replace(Regex("\\b(youtube|on)\\b"), " ").replace(Regex("\\s+"), " ").trim()
            if (q.isNotEmpty()) {
                return Command(Kind.SMART_TV, query = "youtube_play", body = q, heard = raw)
            }
        }

        // Type text on TV
        Regex("(?:tv|smart tv)\\s+(?:par|pe|me|on)?\\s*(?:type|likho|likh do)\\s+(.+)").find(lower)?.let { m ->
            return Command(Kind.SMART_TV, query = "type_text", body = m.groupValues[1].trim(), heard = raw)
        }

        // Open specific TV apps
        val appMap = listOf(
            "youtube" to listOf("youtube", "yt"),
            "netflix" to listOf("netflix"),
            "prime" to listOf("prime video", "amazon prime", "prime"),
            "hotstar" to listOf("hotstar", "jiohotstar", "disney"),
            "jiocinema" to listOf("jiocinema", "jio cinema"),
            "sonyliv" to listOf("sonyliv", "sony liv"),
            "zee5" to listOf("zee5", "zee 5"),
            "spotify" to listOf("spotify"),
            "playstore" to listOf("play store", "playstore"),
            "settings" to listOf("settings", "setting")
        )
        for ((appKey, aliases) in appMap) {
            if (aliases.any { lower.contains(it) }) {
                return Command(Kind.SMART_TV, query = "open_app", body = appKey, heard = raw)
            }
        }

        // Volume controls
        if (lower.contains("mute") || lower.contains("unmute") || lower.contains("chup")) {
            return Command(Kind.SMART_TV, query = "mute", heard = raw)
        }
        if (lower.contains("volume") || lower.contains("awaaz") || lower.contains("awaz") || lower.contains("sound")) {
            val steps = Regex("\\b(\\d{1,2})\\b").find(lower)?.groupValues?.get(1) ?: "3"
            return if (lower.contains("kam") || lower.contains("down") || lower.contains("low") || lower.contains("ghatao") || lower.contains("decrease")) {
                Command(Kind.SMART_TV, query = "vol_down", body = steps, heard = raw)
            } else {
                Command(Kind.SMART_TV, query = "vol_up", body = steps, heard = raw)
            }
        }

        // Power / Sleep / Wake
        if (lower.contains("off") || lower.contains("band") || lower.contains("sleep") || lower.contains("shutdown")) {
            return Command(Kind.SMART_TV, query = "power_off", heard = raw)
        }
        if (lower.contains("on") || lower.contains("chalu") || lower.contains("wake") || lower.contains("start")) {
            return Command(Kind.SMART_TV, query = "power_on", heard = raw)
        }
        if (lower.contains("power")) {
            return Command(Kind.SMART_TV, query = "power_toggle", heard = raw)
        }

        // Media & Navigation
        return when {
            lower.contains("pause") || lower.contains("roko") -> Command(Kind.SMART_TV, query = "pause", heard = raw)
            lower.contains("play") || lower.contains("resume") -> Command(Kind.SMART_TV, query = "play", heard = raw)
            lower.contains("next") || lower.contains("agla") -> Command(Kind.SMART_TV, query = "next", heard = raw)
            lower.contains("previous") || lower.contains("pichla") -> Command(Kind.SMART_TV, query = "previous", heard = raw)
            lower.contains("channel up") || lower.contains("next channel") -> Command(Kind.SMART_TV, query = "ch_up", heard = raw)
            lower.contains("channel down") || lower.contains("previous channel") -> Command(Kind.SMART_TV, query = "ch_down", heard = raw)
            lower.contains("hdmi") || lower.contains("input") || lower.contains("source") -> Command(Kind.SMART_TV, query = "input", heard = raw)
            lower.contains("home") -> Command(Kind.SMART_TV, query = "home", heard = raw)
            lower.contains("back") -> Command(Kind.SMART_TV, query = "back", heard = raw)
            lower.contains("menu") -> Command(Kind.SMART_TV, query = "menu", heard = raw)
            lower.contains("upar") || lower.contains(" up") -> Command(Kind.SMART_TV, query = "up", heard = raw)
            lower.contains("niche") || lower.contains("neeche") || lower.contains("down") -> Command(Kind.SMART_TV, query = "down", heard = raw)
            lower.contains("left") || lower.contains("baye") -> Command(Kind.SMART_TV, query = "left", heard = raw)
            lower.contains("right") || lower.contains("daye") -> Command(Kind.SMART_TV, query = "right", heard = raw)
            lower.contains("ok") || lower.contains("select") || lower.contains("enter") -> Command(Kind.SMART_TV, query = "ok", heard = raw)
            else -> null
        }
    }


    private fun parseTravelPlan(raw: String, lower: String): Command? {
        if (!lower.contains("travel plan") && !lower.contains("trip plan") && !lower.contains("safar ka plan") && !lower.contains("yatra plan")) {
            return null
        }
        val dest = NovaOrchestrator.extractTravelDestination(raw)
        return Command(Kind.TRAVEL_PLAN, query = dest, heard = raw)
    }

    private fun parseStudyProgress(raw: String, lower: String): Command? {
        if (lower.contains("study progress") || lower.contains("weak topic") || lower.contains("revision schedule") || lower.contains("mera study score")) {
            return Command(Kind.STUDY_PROGRESS, query = raw, heard = raw)
        }
        return null
    }

    private fun parseExpenseVoice(raw: String, lower: String): Command? {
        if (lower.contains("kharcha clear") || lower.contains("expense clear") || lower.contains("delete expenses")) {
            return Command(Kind.EXPENSE, query = "clear", heard = raw)
        }
        if ((lower.contains("aaj") || lower.contains("today")) && (lower.contains("kharch") || lower.contains("expense") || lower.contains("spent"))) {
            if (!Regex("\\d").containsMatchIn(lower)) {
                return Command(Kind.EXPENSE, query = "summary_today", heard = raw)
            }
        }
        if ((lower.contains("mahine") || lower.contains("month") || lower.contains("total")) && (lower.contains("kharch") || lower.contains("expense") || lower.contains("spent"))) {
            if (!Regex("\\d").containsMatchIn(lower)) {
                return Command(Kind.EXPENSE, query = "summary_month", heard = raw)
            }
        }
        if (ExpenseTrackerStore.parseExpense(raw) != null) {
            return Command(Kind.EXPENSE, query = "add", body = raw, heard = raw)
        }
        return null
    }

    private fun parseWorkflowHistory(raw: String, lower: String): Command? {
        if (lower.contains("workflow history") || lower.contains("macro history") || lower.contains("shortcut history")) {
            return Command(Kind.WORKFLOW_HISTORY, query = raw, heard = raw)
        }
        return null
    }

    private fun parseMemorySearch(raw: String, lower: String): Command? {
        val m = Regex("(?:memory search|search memory|yaad me dhundo|kya yaad hai about)\\s+(.+)").find(lower)
            ?: return null
        val q = m.groupValues[1].trim()
        return if (q.isNotEmpty()) Command(Kind.MEMORY_SEARCH, query = q, heard = raw) else null
    }

    private fun parseCameraLens(raw: String, lower: String): Command? {
        if (lower.contains("camera lens") || lower.contains("camera se dekho") ||
            lower.contains("ye kya likha") || lower.contains("yeh kya likha") ||
            lower.contains("photo se solve") || lower.contains("scan karke batao") ||
            lower.contains("camera vision") || lower.contains("iska solution camera")
        ) {
            return Command(Kind.CAMERA_LENS, query = raw, heard = raw)
        }
        return null
    }

    private fun parseContextualScreenOverlay(raw: String, lower: String): Command? {
        if (lower.contains("screen translate") || lower.contains("isko translate karo") ||
            lower.contains("screen ko translate") || lower.contains("translate this screen")
        ) {
            return Command(Kind.SCREEN_TRANSLATE, query = raw, heard = raw)
        }
        if (lower.contains("iska reply draft") || lower.contains("screen reply") ||
            lower.contains("reply draft karo") || lower.contains("draft reply for this") ||
            lower.contains("iska reply banao")
        ) {
            return Command(Kind.SCREEN_REPLY, query = raw, heard = raw)
        }
        return null
    }

    private fun parseVivaInterview(raw: String, lower: String): Command? {
        if (lower.contains("viva") || lower.contains("mock interview") ||
            lower.contains("interview practice") || lower.contains("interview shuru") ||
            lower.contains("interview start") || lower.contains("roleplay interview")
        ) {
            return Command(Kind.VIVA_INTERVIEW, query = raw, heard = raw)
        }
        return null
    }

    private fun parseCallControl(raw: String, lower: String): Command? {
        if (lower.contains("call uthao") || lower.contains("phone uthao") ||
            lower.contains("answer call") || lower.contains("receive call") || lower.contains("pick up call")
        ) {
            return Command(Kind.CALL_CONTROL, query = "answer", heard = raw)
        }
        if (lower.contains("call cut") || lower.contains("call kaat") || lower.contains("phone kaat") ||
            lower.contains("reject call") || lower.contains("end call") || lower.contains("disconnect call")
        ) {
            return Command(Kind.CALL_CONTROL, query = "reject", heard = raw)
        }
        return null
    }

    private fun parseUnreadDigest(raw: String, lower: String): Command? {
        if (lower.contains("kis kis ke message") || lower.contains("kiske message") ||
            lower.contains("unread message") || lower.contains("message digest") ||
            lower.contains("who messaged") || lower.contains("unread chats")
        ) {
            return Command(Kind.UNREAD_DIGEST, query = raw, heard = raw)
        }
        return null
    }

    private fun parseKnowledgeVault(raw: String, lower: String): Command? {
        if (lower.contains("vault me save") || lower.contains("save to vault") || lower.contains("knowledge vault save")) {
            return Command(Kind.KB_SAVE, query = raw, heard = raw)
        }
        if (lower.contains("vault files") || lower.contains("vault list") || lower.contains("saved files list") || lower.contains("vault me kya")) {
            return Command(Kind.KB_LIST, query = raw, heard = raw)
        }
        if (lower.contains("saved notes me se") || lower.contains("vault me se") ||
            lower.contains("knowledge vault") || lower.contains("ask vault") ||
            lower.contains("mere saved pdf") || lower.contains("from my vault")
        ) {
            return Command(Kind.KB_QUERY, query = raw, heard = raw)
        }
        return null
    }
}
