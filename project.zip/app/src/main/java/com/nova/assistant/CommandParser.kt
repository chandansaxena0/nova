package com.nova.assistant

import java.util.Locale

enum class Kind {
    OPEN, SEARCH, PLAY, ROBLOX,
    CALL, MESSAGE, REPLY, READ_WHATSAPP,
    NEARBY, MUSIC_CONTROL,
    REMINDER, ALARM,
    PHONE_INFO, WEATHER, DAILY_BRIEFING, DATE_TIME,
    CLIPBOARD, TRANSLATE, STUDY,
    MEMORY_SAVE, MEMORY_LIST,
    EMERGENCY,
    CHAT, AGENT, UNKNOWN
}

data class Command(
    val kind: Kind,
    val app: AppInfo? = null,
    val query: String = "",
    val heard: String = "",
    val contact: String = "",
    val contactKey: String = "",
    val body: String = "",
    val sms: Boolean = false,
    val extraMinutes: Int = 0,
    val extraHour: Int = -1,
    val extraMinute: Int = -1,
    val candidateApps: List<AppInfo> = emptyList()
)

data class Tok(val text: String, val m: String, val orig: String = text)

/**
 * Local-first Smart Command Parser (English, Hindi & Hinglish -> clean Roman Hinglish).
 * Runs completely offline in < 2 ms without unnecessary internet requests.
 */
class CommandParser(private val index: AppIndex) {

    private val playVerbs = setOf(
        "play", "chalao", "chala", "chalaiye", "bajao", "baja",
        "sunao", "suna", "lagao", "laga", "chalado"
    )
    private val searchVerbs = setOf(
        "search", "dhundo", "dhoondo", "dhundh", "khojo", "khoj",
        "find", "dikhao", "dikha", "lookup", "google"
    )
    private val openVerbs = setOf(
        "open", "kholo", "khol", "khole", "kholiye", "launch", "start", "chalu", "shuru"
    )
    private val preps = setOf(
        "par", "pe", "me", "mein", "mai", "on", "in", "se", "per",
        "ke", "ki", "ka", "ko", "for", "liye", "to"
    )
    private val fillers = setOf(
        "karo", "kar", "kardo", "karna", "do", "de", "dena", "dijiye", "please", "plz",
        "zara", "mujhe", "mere", "meri", "mera", "app", "application", "aur", "and",
        "the", "a", "ek", "hai", "wala", "wali", "wale", "na", "ya", "jo",
        "kuch", "bhi", "ab", "abhi", "can", "you", "i", "want", "ji",
        "hey", "hi", "he", "hay", "hello", "helo", "okay", "ok", "nova"
    )
    private val weak = setOf(
        "gaana", "gaane", "gana", "gane", "song", "songs",
        "music", "video", "videos", "vedio", "gaano", "game", "games"
    )

    private val stopWords: Set<String> = playVerbs + searchVerbs + openVerbs + preps + fillers

    private val callWords = setOf("call", "dial", "calling", "kol")
    private val replyWords = setOf("reply", "replay", "jawab", "jawaab", "jabab")
    private val msgWords = setOf("message", "messages", "msg", "text", "sms", "sandesh")
    private val sendVerbs = setOf("bhejo", "bhej", "send", "likho", "bolo", "bol")
    private val bodyMarkers = setOf("ki", "that", "saying")
    private val phoneDo = setOf("lagao", "laga", "karo", "kar", "kardo", "milao", "mila")
    private val videoWords = setOf("video", "videos", "vedio")
    private val verbBlock: Set<String> =
        replyWords + msgWords + sendVerbs + setOf("karo", "kar", "kardo", "do", "de", "dena", "dijiye", "please", "plz")

    fun stripWake(raw: String): String? = WakeStopDetector.stripWake(raw, isPartial = false)

    fun transliterate(s: String): String = HinglishConverter.transliterate(s)

    fun parse(rawInput: String): Command {
        val hinglish = HinglishConverter.toHinglish(rawInput)
        val lower = hinglish.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
        if (lower.isEmpty()) return Command(Kind.UNKNOWN, heard = "")

        // 1) Emergency & Safety
        parseEmergency(hinglish, lower)?.let { return it }

        // 2) Smart Memory (save / list)
        parseMemory(hinglish, lower)?.let { return it }

        // 3) Reminders & Alarms
        parseReminderOrAlarm(hinglish, lower)?.let { return it }

        // 4) Nearby Places (Petrol Pump, Hospital, ATM, Railway Station, Medical Store, Restaurant)
        parseNearby(hinglish, lower)?.let { return it }

        // 5) Music & Volume Controls (without opening a new app)
        parseMusicControl(hinglish, lower)?.let { return it }

        // 6) Read incoming WhatsApp notifications
        if ((lower.contains("whatsapp") || lower.contains("message") || lower.contains("notification")) &&
            (lower.contains("padho") || lower.contains("read") || lower.contains("sunao") || lower.contains("naya") || lower.contains("aaya")) &&
            !lower.contains("bhejo") && !lower.contains("send") && !lower.contains("reply")
        ) {
            return Command(Kind.READ_WHATSAPP, heard = hinglish)
        }

        // 7) Clipboard Assistant
        parseClipboard(hinglish, lower)?.let { return it }

        // 8) Daily Assistant: Briefing, Weather, Date/Time
        parseDailyAssistant(hinglish, lower)?.let { return it }

        // 9) Phone Information (Battery, Wi-Fi, Bluetooth, Storage, Internet, Screen Time)
        parsePhoneInfo(hinglish, lower)?.let { return it }

        // 10) Translation & Grammar Correction
        parseTranslation(hinglish, lower)?.let { return it }

        // 11) Study Assistant (Offline Math + Science/Study/Quiz/Summary)
        parseStudy(hinglish, lower)?.let { return it }

        // 12) Roblox Game Search / Launch
        parseRoblox(hinglish, lower)?.let { return it }

        // 13) Tokenized Call / Message / Reply / Open / Search / Play
        val tokens = tokenize(hinglish)
        specialComm(tokens, hinglish)?.let { return it }

        var kind = when {
            tokens.any { it.m in playVerbs } -> Kind.PLAY
            tokens.any { it.m in searchVerbs } -> Kind.SEARCH
            tokens.any { it.m in openVerbs } -> Kind.OPEN
            else -> Kind.UNKNOWN
        }

        val (app, appRange, candidates) = findAppWithCandidates(tokens)

        // "<topic> video chalao" -> YouTube
        val resolvedApp = if (kind == Kind.PLAY && app == null && tokens.any { it.m in videoWords }) {
            index.byPackage("com.google.android.youtube")
        } else app

        val query = tokens.withIndex()
            .filter { (i, t) -> i !in appRange && t.m !in stopWords && t.m !in weak }
            .joinToString(" ") { it.value.orig }
            .trim()

        if (kind == Kind.UNKNOWN) {
            kind = when {
                resolvedApp != null && query.isEmpty() -> Kind.OPEN
                resolvedApp != null -> Kind.SEARCH
                else -> Kind.UNKNOWN
            }
        }

        // Looser app match for explicit "open <app>"
        var finalApp = resolvedApp
        var finalCandidates = candidates
        if (kind == Kind.OPEN && finalApp == null) {
            val looseKey = Normalizer.key(tokens.filter { it.m !in stopWords }.joinToString("") { it.m })
            val top = index.topMatches(looseKey, minScore = 0.62, limit = 3)
            if (top.isNotEmpty()) {
                finalApp = top.first().first
                if (top.size >= 2 && top[0].second - top[1].second <= 0.12 && top[0].second < 0.96) {
                    finalCandidates = top.map { it.first }
                }
            }
        }

        return Command(
            kind = kind,
            app = finalApp,
            query = query,
            heard = hinglish,
            candidateApps = finalCandidates
        )
    }

    private fun parseEmergency(raw: String, lower: String): Command? {
        if (lower.contains("emergency") || lower.contains("sos") || lower.contains("bachao") ||
            lower.contains("police call") || lower.contains("ambulance") || lower.contains("112")
        ) {
            val mode = when {
                lower.contains("location") || lower.contains("share") -> "location"
                lower.contains("contact") || lower.contains("call") -> "call"
                else -> "sos"
            }
            return Command(Kind.EMERGENCY, query = mode, heard = raw)
        }
        return null
    }

    private fun parseMemory(raw: String, lower: String): Command? {
        val savePrefixes = listOf("yaad rakho", "yaad rakhna", "remember that", "remember ", "save memory", "memory save")
        for (p in savePrefixes) {
            val idx = lower.indexOf(p)
            if (idx >= 0) {
                val body = raw.substring(idx + p.length).replace(Regex("^(ki|that|:)\\s*", RegexOption.IGNORE_CASE), "").trim()
                if (body.isNotEmpty()) {
                    return Command(Kind.MEMORY_SAVE, body = body, heard = raw)
                }
            }
        }
        if ((lower.contains("memory") || lower.contains("yaad")) &&
            (lower.contains("dikhao") || lower.contains("batao") || lower.contains("list") || lower.contains("show") || lower.contains("kya yaad"))
        ) {
            return Command(Kind.MEMORY_LIST, heard = raw)
        }
        return null
    }

    private fun parseReminderOrAlarm(raw: String, lower: String): Command? {
        val isAlarm = lower.contains("alarm")
        val isReminder = lower.contains("remind") || lower.contains("yaad dilana") || lower.contains("yaad dila")
        if (!isAlarm && !isReminder) return null

        // Parse relative minutes/hours: "10 minute baad", "in 15 minutes", "2 ghante baad"
        var mins = 0
        Regex("(\\d+)\\s*(?:min|mins|minute|minutes)").find(lower)?.let {
            mins += it.groupValues[1].toIntOrNull() ?: 0
        }
        Regex("(\\d+)\\s*(?:hr|hrs|hour|hours|ghante|ghanta)").find(lower)?.let {
            mins += (it.groupValues[1].toIntOrNull() ?: 0) * 60
        }

        // Parse clock time: "7:30", "subah 7 baje", "at 6 pm"
        var hour = -1
        var minute = 0
        val colonMatch = Regex("(\\d{1,2}):(\\d{2})\\s*(am|pm)?").find(lower)
        val bajeMatch = Regex("(\\d{1,2})\\s*(?:baje|am|pm)").find(lower)
        when {
            colonMatch != null -> {
                hour = colonMatch.groupValues[1].toIntOrNull() ?: -1
                minute = colonMatch.groupValues[2].toIntOrNull() ?: 0
                val ap = colonMatch.groupValues[3]
                if (ap == "pm" && hour in 1..11) hour += 12
                if (ap == "am" && hour == 12) hour = 0
            }
            bajeMatch != null -> {
                hour = bajeMatch.groupValues[1].toIntOrNull() ?: -1
                val ap = when {
                    lower.contains("pm") || lower.contains("shaam") || lower.contains("raat") -> "pm"
                    lower.contains("am") || lower.contains("subah") -> "am"
                    else -> ""
                }
                if (ap == "pm" && hour in 1..11) hour += 12
                if (ap == "am" && hour == 12) hour = 0
            }
        }

        val cleanTitle = raw
            .replace(Regex("\\b(set|create|lagao|laga|karo|kar|do|ek|a|an|alarm|reminder|remind|me|mujhe|yaad|dilana|dila|dena|baad|after|in|at|for|ka|ki|ke|subah|shaam|raat|baje|am|pm|minutes?|mins?|hours?|hrs?|ghante|ghanta)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\b\\d{1,2}(:\\d{2})?\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifEmpty { if (isAlarm) "Nova Alarm" else "Nova Reminder" }

        return if (isAlarm) {
            Command(Kind.ALARM, body = cleanTitle, heard = raw, extraMinutes = mins, extraHour = hour, extraMinute = minute)
        } else {
            Command(Kind.REMINDER, body = cleanTitle, heard = raw, extraMinutes = mins, extraHour = hour, extraMinute = minute)
        }
    }

    private fun parseNearby(raw: String, lower: String): Command? {
        val place = NearbyPlacesHelper.detectPlaceType(lower) ?: return null
        val hasIntent = lower.contains("paas") || lower.contains("pass") || lower.contains("near") ||
            lower.contains("closest") || lower.contains("nearest") || lower.contains("sabse") ||
            lower.contains("kahan") || lower.contains("kaha") || lower.contains("dhundo") ||
            lower.contains("find") || lower.contains("map") || lower.contains("distance") ||
            lower.contains("door") || lower.contains("dur") || lower.contains("route")
        return if (hasIntent) Command(Kind.NEARBY, query = place.label, heard = raw) else null
    }

    private fun parseMusicControl(raw: String, lower: String): Command? {
        return when {
            lower.contains("volume") || lower.contains("awaz") || lower.contains("awaaz") || lower.contains("sound") -> {
                val ctrl = when {
                    lower.contains("mute") || lower.contains("silent") || lower.contains("band") || lower.contains("zero") -> "mute"
                    lower.contains("full") || lower.contains("max") || lower.contains("100") -> "volume_max"
                    lower.contains("up") || lower.contains("badha") || lower.contains("zyada") || lower.contains("tez") || lower.contains("increase") || lower.contains("high") -> "volume_up"
                    lower.contains("down") || lower.contains("kam") || lower.contains("slow") || lower.contains("decrease") || lower.contains("low") -> "volume_down"
                    else -> return null
                }
                Command(Kind.MUSIC_CONTROL, query = ctrl, heard = raw)
            }
            lower in setOf("pause", "pause music", "music pause", "gaana roko", "song pause", "music band karo") ||
                (lower.contains("pause") && (lower.contains("music") || lower.contains("song") || lower.contains("gaana"))) ->
                Command(Kind.MUSIC_CONTROL, query = "pause", heard = raw)
            lower in setOf("resume", "resume music", "play music", "music play", "music chalao", "gaana chalao") ->
                Command(Kind.MUSIC_CONTROL, query = "play_resume", heard = raw)
            (lower.contains("next") || lower.contains("agla") || lower.contains("skip")) &&
                (lower.contains("song") || lower.contains("music") || lower.contains("gaana") || lower.contains("track") || lower == "next song" || lower == "next") ->
                Command(Kind.MUSIC_CONTROL, query = "next", heard = raw)
            (lower.contains("previous") || lower.contains("pichla") || lower.contains("back")) &&
                (lower.contains("song") || lower.contains("music") || lower.contains("gaana") || lower.contains("track")) ->
                Command(Kind.MUSIC_CONTROL, query = "previous", heard = raw)
            else -> null
        }
    }

    private fun parseClipboard(raw: String, lower: String): Command? {
        if (!lower.contains("clipboard") && !lower.contains("copied") && !lower.contains("copy kiya")) return null
        val op = when {
            lower.contains("summar") || lower.contains("short") || lower.contains("chhota") -> "summarize"
            lower.contains("translat") || lower.contains("anuvad") || lower.contains("hindi") || lower.contains("english") -> "translate"
            lower.contains("grammar") || lower.contains("correct") || lower.contains("sahi") -> "grammar"
            lower.contains("reply") || lower.contains("jawab") -> "reply"
            else -> "read"
        }
        return Command(Kind.CLIPBOARD, query = op, heard = raw)
    }

    private fun parseDailyAssistant(raw: String, lower: String): Command? {
        if (lower.contains("daily briefing") || lower.contains("aaj ka briefing") || lower.contains("subah ka update") || lower.contains("morning briefing") || lower.contains("aaj ke task")) {
            return Command(Kind.DAILY_BRIEFING, heard = raw)
        }
        if (lower.contains("weather") || lower.contains("mausam") || lower.contains("temperature") || lower.contains("temp ") || lower.endsWith("temp") || lower.contains("baarish")) {
            return Command(Kind.WEATHER, heard = raw)
        }
        if (lower.contains("aaj ki tarikh") || lower.contains("tarikh kya") || lower.contains("date kya") || lower.contains("what is the date") ||
            lower.contains("today's date") || lower.contains("aaj kaun sa din") || lower.contains("what day is") ||
            lower.contains("time kya") || lower.contains("kitne baje") || lower.contains("what time") || lower.contains("samay kya")
        ) {
            return Command(Kind.DATE_TIME, heard = raw)
        }
        return null
    }

    private fun parsePhoneInfo(raw: String, lower: String): Command? {
        val asksStatus = lower.contains("status") || lower.contains("kitni") || lower.contains("kitna") ||
            lower.contains("batao") || lower.contains("check") || lower.contains("kya") ||
            lower.contains("info") || lower.contains("health") || lower.contains("free") ||
            lower.contains("available") || lower.contains("usage") || lower.contains("screen time") ||
            lower.contains("percent") || lower.contains("%")
        if (!asksStatus && lower !in setOf("battery", "storage", "screen time", "wifi status", "bluetooth status", "phone info")) {
            return null
        }
        return when {
            lower.contains("phone info") || lower.contains("device info") || lower.contains("system info") ->
                Command(Kind.PHONE_INFO, query = "all", heard = raw)
            lower.contains("battery") -> Command(Kind.PHONE_INFO, query = "battery", heard = raw)
            lower.contains("wi-fi") || lower.contains("wifi") -> Command(Kind.PHONE_INFO, query = "wifi", heard = raw)
            lower.contains("bluetooth") -> Command(Kind.PHONE_INFO, query = "bluetooth", heard = raw)
            lower.contains("internet") || lower.contains("network") -> Command(Kind.PHONE_INFO, query = "internet", heard = raw)
            lower.contains("storage") || lower.contains("space") || lower.contains("memory kitni") ->
                Command(Kind.PHONE_INFO, query = "storage", heard = raw)
            lower.contains("screen time") || lower.contains("app usage") ->
                Command(Kind.PHONE_INFO, query = "screentime", heard = raw)
            else -> null
        }
    }

    private fun parseTranslation(raw: String, lower: String): Command? {
        if (lower.contains("translate") || lower.contains("translation") || lower.contains("english mein bolo") ||
            lower.contains("hindi mein bolo") || lower.contains("grammar") || lower.contains("simple language") ||
            lower.contains("aasan bhasha")
        ) {
            return Command(Kind.TRANSLATE, query = raw, heard = raw)
        }
        return null
    }

    private fun parseStudy(raw: String, lower: String): Command? {
        // Offline math check first
        if (MathEvaluator.trySolve(raw) != null) {
            return Command(Kind.STUDY, query = raw, heard = raw)
        }
        if (lower.contains("explain") || lower.contains("samjhao") || lower.contains("quiz") ||
            lower.contains("practice question") || lower.contains("revision") || lower.contains("summarize") ||
            lower.contains("summary") || lower.contains("solve ") || lower.contains("formula") ||
            lower.contains("physics") || lower.contains("chemistry") || lower.contains("biology") ||
            lower.contains("calculus") || lower.contains("maths")
        ) {
            return Command(Kind.STUDY, query = raw, heard = raw)
        }
        return null
    }

    private fun parseRoblox(raw: String, lower: String): Command? {
        if (!lower.contains("roblox")) return null
        val cleaned = raw
            .replace(Regex("\\b(roblox|mein|me|par|pe|in|on|open|kholo|play|chalao|search|dhundo|find|game|games|karo|do|launch|start)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        return Command(Kind.ROBLOX, app = index.byPackage(RobloxHelper.ROBLOX_PKG), query = cleaned, heard = raw)
    }

    private fun specialComm(tokens: List<Tok>, raw: String): Command? {
        val ms = tokens.map { it.m }
        if (ms.isEmpty()) return null
        val firstOpen = ms.indexOfFirst { it in openVerbs }
        val hasKo = "ko" in ms

        if (ms.any { it in replyWords }) return messageLike(Kind.REPLY, tokens, raw)

        val callIdx = ms.indexOfFirst { it in callWords }
        val msgIdx = ms.indexOfFirst { it in msgWords || it in sendVerbs }
        val hasSend = ms.any { it in sendVerbs }
        val msgLike = msgIdx >= 0 && (hasKo || hasSend) && (firstOpen < 0 || msgIdx < firstOpen)

        if (msgLike && (callIdx < 0 || msgIdx < callIdx)) return messageLike(Kind.MESSAGE, tokens, raw)

        val phoneCall = "phone" in ms && hasKo && ms.any { it in phoneDo } && firstOpen < 0
        if ((callIdx >= 0 && (firstOpen < 0 || callIdx < firstOpen)) || phoneCall) {
            val skip = stopWords + callWords + weak + setOf("phone", "ko")
            val nameToks = tokens.filter { it.m !in skip }
            val contactStr = nameToks.joinToString(" ") { it.orig }.trim()
            return Command(
                kind = Kind.CALL,
                heard = raw,
                contact = contactStr,
                contactKey = Normalizer.key(nameToks.joinToString("") { it.m })
            )
        }
        return null
    }

    private fun messageLike(kind: Kind, tokens: List<Tok>, raw: String): Command {
        val ms = tokens.map { it.m }
        val nameEnd = ms.indexOfFirst { it == "ko" || it == "ke" }
        val from = if (nameEnd >= 0) nameEnd + 1 else 0

        var bodyStart = -1
        val ki = (from until ms.size).firstOrNull { ms[it] in bodyMarkers }
        if (ki != null) {
            bodyStart = ki + 1
        } else {
            val v = (from until ms.size).firstOrNull { ms[it] in verbBlock }
            if (v != null) {
                var k = v
                while (k < ms.size && ms[k] in verbBlock) k++
                bodyStart = k
            }
        }
        if (bodyStart < 0) bodyStart = ms.size

        val head = tokens.subList(0, bodyStart)
        val body = HinglishConverter.toHinglish(tokens.drop(bodyStart).joinToString(" ") { it.orig })
        val (app, range, _) = findAppWithCandidates(head, verbBlock)

        val nameBase = if (nameEnd >= 0) tokens.subList(0, nameEnd) else head
        val nameToks = nameBase.withIndex()
            .filter { (i, t) ->
                i !in range && t.m !in stopWords && t.m !in verbBlock && t.m !in weak &&
                    t.m !in bodyMarkers && t.m != "ko" && t.m != "ke"
            }
            .map { it.value }

        return Command(
            kind = kind,
            app = app,
            heard = raw,
            contact = nameToks.joinToString(" ") { it.orig }.trim(),
            contactKey = Normalizer.key(nameToks.joinToString("") { it.m }),
            body = body,
            sms = ms.any { it == "sms" }
        )
    }

    private fun findAppWithCandidates(
        tokens: List<Tok>,
        skip: Set<String> = emptySet()
    ): Triple<AppInfo?, IntRange, List<AppInfo>> {
        var bestApp: AppInfo? = null
        var bestScore = 0.0
        var bestRange: IntRange = IntRange.EMPTY
        var bestCandidates: List<AppInfo> = emptyList()

        for (start in tokens.indices) {
            if (tokens[start].m in stopWords || tokens[start].m in skip) continue
            var joined = ""
            for (end in start until minOf(tokens.size, start + 3)) {
                if (tokens[end].m in stopWords || tokens[end].m in skip) break
                joined += tokens[end].m
                val top = index.topMatches(Normalizer.key(joined), minScore = 0.80, limit = 3)
                if (top.isEmpty()) continue
                val match = top.first()
                var s = match.second + 0.002 * (end - start)
                if (start > 0 && tokens[start - 1].m in preps) s += 0.05
                if (end + 1 < tokens.size && tokens[end + 1].m in preps) s += 0.05
                if (s > bestScore) {
                    bestScore = s
                    bestApp = match.first
                    bestRange = start..end
                    bestCandidates = if (top.size >= 2 && top[0].second - top[1].second <= 0.09 && top[0].second < 0.98) {
                        top.map { it.first }
                    } else emptyList()
                }
            }
        }
        return Triple(bestApp, bestRange, bestCandidates)
    }

    private fun tokenize(hinglish: String): List<Tok> {
        val rawWords = hinglish.split(Regex("\\s+")).filter { it.isNotBlank() }
        return rawWords.mapNotNull { orig ->
            val cleaned = orig.replace(Regex("[^\\p{L}\\p{N}]+"), "")
            if (cleaned.isEmpty()) return@mapNotNull null
            val m = cleaned.lowercase(Locale.ROOT)
            Tok(cleaned, m, orig)
        }
    }
}
