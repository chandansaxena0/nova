package com.nova.assistant

import android.content.Context
import kotlin.random.Random

/**
 * Generates and narrates Stories ("Nova kahani sunao"), Jokes ("Nova joke sunao"),
 * and Shayari/Poems ("Nova shayari sunao") via Gemini when online, with curated
 * offline Hindi/Hinglish/English fallbacks when offline or without an API key.
 */
object CreativeContentHelper {

    private val offlineStories = listOf(
        "Ek baar Rajasthan ke ek chhote gaon mein ek ladka rehta tha jise aasman ke taaron ko dekhne ka bada shauk tha. Har shaam wo chhat par baithkar sochta ki kya kabhi wo bhi aasman mein ud paayega. Usne roz thoda-thoda seekhna shuru kiya, kabhi haar nahi maani, aur ek din apni mehnat ke dum par pilot ban kar wahi aasman chhoo liya. Seekh: chhote kadam roz chalne se bade sapne poore hote hain.",
        "Ek jungle mein ek kachhua aur ek khargosh dost the. Khargosh ko apni tez raftaar par ghamand tha, par kachhua bina ruke apni dhun mein chalta raha. Race ke beech khargosh aaram karne baith gaya aur so gaya, jabki kachhua lagatar chal kar finish line par pahunch gaya. Seekh: consistency hamesha speed se badi hoti hai.",
        "Ek baar ek chidiya ke ghosle mein aag lagne wali thi. Sab bade jaanwar dekh kar bhaag gaye, par ek nanhi gauraiya apni chonch mein paani ki boond laakar aag par daalti rahi. Jab sabne kaha ki teri ek boond se kya hoga, to usne kaha ki jab itihaas likha jaayega, mera naam aag lagane walon mein nahi balki bujhane walon mein hoga."
    )

    private val offlineJokes = listOf(
        "Teacher ne pucha: batao Newton ka sabse bada niyam kya hai? Student bola: sir, jab tak phone ki battery 1 percent par na aa jaaye, insaan charger ke paas nahi jaata!",
        "Ek dost dusre se bola: yaar maine kal raat sapne mein dekha ki main exam mein top kar gaya! Dusra dost bola: bhai subah uth kar alarm mat band karna, warna sapna adhoora reh jaayega!",
        "Doctor ne patient se kaha: aapko aaram ki zaroorat hai, ye neend ki goliyaan le lijiye. Patient bola: doctor sahab, inhe kab khana hai? Doctor bola: ye aapke liye nahi, aapke phone ko rakh kar sone ke liye hain!"
    )

    private val offlineShayari = listOf(
        "Manzil unhi ko milti hai jinke sapno mein jaan hoti hai, pankh se kuch nahi hota, hauslon se udaan hoti hai.",
        "Waqt se ladkar jo naseeb badal de, insaan wahi jo apni taqdeer badal de. Kal kya hoga kabhi mat socho, kya pata kal waqt khud apni tasveer badal de.",
        "Mushkilein dil ke iraade aazmati hain, khwabon ke parde nigaahon se hatati hain. Hausla mat haar gir kar ae musafir, thokarein hi insaan ko chalna sikhati hain."
    )

    fun tellStory(context: Context, userRequest: String): String {
        if (Prefs.hasAi(context) && PhoneInfoHelper.isOnline(context)) {
            val lang = if (Prefs.replyLanguage(context) == "english") "Indian English" else "warm, natural Roman Hinglish (no Devanagari script, no markdown)"
            val sys = "You are Nova, a warm storyteller. Narrate an engaging, original short story (6 to 9 short spoken sentences) with a nice ending in $lang. No markdown symbols."
            return GeminiClient.askWithAgentPrompt(context, sys, "Narrate a story for: $userRequest", keepContext = true, maxTokens = 700)
        }
        return offlineStories[Random.nextInt(offlineStories.size)]
    }

    fun tellJoke(context: Context, userRequest: String): String {
        if (Prefs.hasAi(context) && PhoneInfoHelper.isOnline(context)) {
            val lang = if (Prefs.replyLanguage(context) == "english") "clean Indian English" else "clean, funny Roman Hinglish (no Devanagari script, no markdown)"
            val sys = "You are Nova, a witty Indian AI friend. Tell ONE fresh, clean, genuinely funny short joke (2 to 4 sentences) in $lang. No markdown."
            return GeminiClient.askWithAgentPrompt(context, sys, "Tell a joke for: $userRequest", keepContext = true, maxTokens = 300)
        }
        return offlineJokes[Random.nextInt(offlineJokes.size)]
    }

    fun tellShayari(context: Context, userRequest: String): String {
        if (Prefs.hasAi(context) && PhoneInfoHelper.isOnline(context)) {
            val lang = if (Prefs.replyLanguage(context) == "english") "expressive English poetry" else "soulful Roman Hinglish Urdu/Hindi shayari (no Devanagari script, no markdown)"
            val sys = "You are Nova, a poetic AI assistant. Compose and recite ONE beautiful 4-line shayari or short poem in $lang matching the user's request. No markdown."
            return GeminiClient.askWithAgentPrompt(context, sys, "Write shayari/poem for: $userRequest", keepContext = true, maxTokens = 300)
        }
        return offlineShayari[Random.nextInt(offlineShayari.size)]
    }
}
