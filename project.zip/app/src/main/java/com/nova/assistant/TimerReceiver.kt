package com.nova.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/** Fires countdown timer completion alert + voice announcement. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 1001)
        val label = intent.getStringExtra("label")?.ifBlank { "Nova Timer" } ?: "Nova Timer"

        TimerManager.cancelTimer(context, id)

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nova_timers", "Nova Timers", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            context, id,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            7000 + (id % 1000),
            NotificationCompat.Builder(context, "nova_timers")
                .setSmallIcon(R.drawable.ic_mic)
                .setContentTitle("Timer Complete")
                .setContentText("$label poora ho gaya!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
        )

        if (ListenService.running) {
            runCatching {
                context.startService(
                    Intent(context, ListenService::class.java)
                        .setAction(ListenService.ACTION_SPEAK_ALERT)
                        .putExtra("message", "Timer complete! $label poora ho gaya hai.")
                )
            }
        }
    }
}
