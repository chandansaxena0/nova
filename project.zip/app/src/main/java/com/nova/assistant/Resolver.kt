package com.nova.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

/**
 * Intent-Safe Command Resolver:
 *   1) Clear local match -> executes immediately offline (zero latency, zero network).
 *   2) Online + Gemini configured -> AI tool selection & conversational intelligence.
 *   3) Offline / no API key -> asks a polite clarification question (NEVER randomly opens Google or YouTube!).
 */
object Resolver {

    fun resolve(
        context: Context,
        index: AppIndex,
        parser: CommandParser,
        rawText: String,
        done: (Command) -> Unit
    ) {
        val cleanText = HinglishConverter.toHinglish(rawText)
        val local = parser.parse(cleanText)

        if (!needsAi(local)) {
            done(local)
            return
        }

        val key = Prefs.geminiKey(context)
        val online = PhoneInfoHelper.isOnline(context)

        if (key.isNotEmpty() && online) {
            val model = Prefs.geminiModel(context)
            val apps = index.apps
            val main = Handler(Looper.getMainLooper())
            thread {
                val aiCmd = try {
                    GeminiClient.interpret(key, model, cleanText, apps)
                } catch (_: Exception) {
                    null
                }
                main.post {
                    when {
                        aiCmd != null && usable(aiCmd) -> done(aiCmd)
                        else -> done(Command(Kind.CHAT, query = cleanText, heard = cleanText))
                    }
                }
            }
            return
        }

        // Offline or without API key: ask for clarification instead of randomly launching Google or YouTube
        val clarify = Command(
            kind = Kind.CLARIFY,
            query = cleanText,
            heard = cleanText,
            body = if (!online) {
                "Abhi internet band hai, isliye '$cleanText' ka AI jawab nahi la paya. Aap offline commands (battery, storage, flashlight, timer, reminder, math, offline story/joke) bol sakte ho."
            } else {
                "Mujhe '$cleanText' ka exact intent clear nahi hua. Kya aap koi app kholna, web search karna, ya AI se sawal puchhna chahte ho? (AI chat ke liye Settings me Gemini API key save karo.)"
            }
        )
        done(clarify)
    }

    private fun needsAi(c: Command): Boolean = when (c.kind) {
        Kind.UNKNOWN -> true
        Kind.OPEN -> c.app == null
        Kind.CALL -> c.contact.isBlank()
        Kind.MESSAGE -> c.contact.isBlank() || c.body.isBlank()
        Kind.REPLY -> c.body.isBlank()
        else -> false
    }

    private fun usable(c: Command): Boolean = when (c.kind) {
        Kind.UNKNOWN -> false
        Kind.OPEN -> c.app != null
        Kind.CALL -> c.contact.isNotBlank()
        Kind.MESSAGE -> c.contact.isNotBlank() && c.body.isNotBlank()
        Kind.REPLY -> c.body.isNotBlank()
        Kind.AGENT -> c.body.isNotBlank()
        else -> true
    }
}
