package com.nova.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

/**
 * Decides what a spoken/typed command means.
 * 1) The offline parser always goes first (fast, free, private).
 * 2) Only if it is unsure AND you saved a Gemini key, Gemini is asked.
 * If Gemini fails (no internet, wrong key, limit), the offline answer is used.
 * [done] is always called on the main thread.
 */
object Resolver {
    fun resolve(
        context: Context,
        index: AppIndex,
        parser: CommandParser,
        text: String,
        done: (Command) -> Unit
    ) {
        val first = parser.parse(text)
        val key = Prefs.geminiKey(context)
        if (!unsure(first) || key.isEmpty()) {
            done(first)
            return
        }

        val model = Prefs.geminiModel(context)
        val apps = index.apps
        val main = Handler(Looper.getMainLooper())
        thread {
            val g = try {
                GeminiClient.interpret(key, model, text, apps)
            } catch (e: Exception) {
                null
            }
            main.post { done(if (g != null && usable(g)) g else first) }
        }
    }

    private fun unsure(c: Command): Boolean = when (c.kind) {
        Kind.UNKNOWN -> true
        Kind.OPEN -> c.app == null
        Kind.CALL -> c.contact.isBlank()
        Kind.MESSAGE -> c.contact.isBlank() || c.body.isBlank()
        Kind.REPLY -> c.body.isBlank()
        else -> false
    }

    private fun usable(c: Command): Boolean = when (c.kind) {
        Kind.UNKNOWN -> false
        Kind.OPEN -> c.app != null
        Kind.CALL -> c.contact.isNotBlank()
        Kind.MESSAGE -> c.contact.isNotBlank() && c.body.isNotBlank()
        Kind.REPLY -> c.body.isNotBlank()
        Kind.AGENT -> c.body.isNotBlank()
        else -> true
    }
}
