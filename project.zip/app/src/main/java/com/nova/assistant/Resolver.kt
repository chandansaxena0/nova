package com.nova.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

/**
 * Decides what a spoken/typed command means.
 * 1) The offline parser always goes first (fast, free, private).
 * 2) Only if it is unsure AND you saved a Gemini key, Gemini is asked.
 * If Gemini fails (no internet, wrong key, limit), the offline answer is used.
 * [done] is always called on the main thread.
 */
object Resolver {
    fun resolve(
        context: Context,
        index: AppIndex,
        parser: CommandParser,
        text: String,
        done: (Command) -> Unit
    ) {
        val first = parser.parse(text)
        val unsure = first.kind == Kind.UNKNOWN || (first.kind == Kind.OPEN && first.app == null)
        val key = Prefs.geminiKey(context)
        if (!unsure || key.isEmpty()) {
            done(first)
            return
        }

        val model = Prefs.geminiModel(context)
        val apps = index.apps
        val main = Handler(Looper.getMainLooper())
        thread {
            val g = try {
                GeminiClient.interpret(key, model, text, apps)
            } catch (e: Exception) {
                null
            }
            val good = g != null && g.kind != Kind.UNKNOWN && !(g.kind == Kind.OPEN && g.app == null)
            main.post { done(if (good && g != null) g else first) }
        }
    }
}
