package com.nova.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

/**
 * Strict Priority Command Resolver:
 *   1) Local Commands & Installed Apps (instant, offline, zero network)
 *   2) Gemini AI (smart understanding & conversational Q&A when API key + internet exist)
 *   3) Google Search fallback (when neither local match nor Gemini can solve it)
 */
object Resolver {

    fun resolve(
        context: Context,
        index: AppIndex,
        parser: CommandParser,
        rawText: String,
        done: (Command) -> Unit
    ) {
        val cleanText = HinglishConverter.toHinglish(rawText)
        val local = parser.parse(cleanText)

        // Priority 1: Clear local match -> execute immediately without internet
        if (!needsAi(local)) {
            done(local)
            return
        }

        val key = Prefs.geminiKey(context)
        val online = PhoneInfoHelper.isOnline(context)

        // Priority 2: Gemini AI if API key is configured and internet is available
        if (key.isNotEmpty() && online) {
            val model = Prefs.geminiModel(context)
            val apps = index.apps
            val main = Handler(Looper.getMainLooper())
            thread {
                val aiCmd = try {
                    GeminiClient.interpret(key, model, cleanText, apps)
                } catch (_: Exception) {
                    null
                }
                main.post {
                    when {
                        aiCmd != null && usable(aiCmd) -> done(aiCmd)
                        else -> done(Command(Kind.CHAT, query = cleanText, heard = cleanText))
                    }
                }
            }
            return
        }

        // Priority 3: Google Search fallback when local command didn't match and Gemini isn't available
        val fallback = if (local.kind == Kind.UNKNOWN && cleanText.isNotBlank()) {
            Command(Kind.SEARCH, app = null, query = cleanText, heard = cleanText)
        } else {
            local
        }
        done(fallback)
    }

    private fun needsAi(c: Command): Boolean = when (c.kind) {
        Kind.UNKNOWN -> true
        Kind.OPEN -> c.app == null
        Kind.CALL -> c.contact.isBlank()
        Kind.MESSAGE -> c.contact.isBlank() || c.body.isBlank()
        Kind.REPLY -> c.body.isBlank()
        else -> false
    }

    private fun usable(c: Command): Boolean = when (c.kind) {
        Kind.UNKNOWN -> false
        Kind.OPEN -> c.app != null
        Kind.CALL -> c.contact.isNotBlank()
        Kind.MESSAGE -> c.contact.isNotBlank() && c.body.isNotBlank()
        Kind.REPLY -> c.body.isNotBlank()
        Kind.AGENT -> c.body.isNotBlank()
        else -> true
    }
}
