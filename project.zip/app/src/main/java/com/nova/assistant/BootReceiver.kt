package com.nova.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/**
 * After the phone restarts, Android 14+ does not let a microphone service start by itself.
 * So we show one notification: tap it once and "Hey Nova" is on again.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("nova", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("wake", false)) return

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nova_boot", "Nova shuru karo", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            context, 10,
            Intent(context, MainActivity::class.java).putExtra("autostart", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            20,
            NotificationCompat.Builder(context, "nova_boot")
                .setSmallIcon(R.drawable.ic_mic)
                .setContentTitle("Nova")
                .setContentText("\"Hey Nova\" chalu karne ke liye yahan tap karo.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
    }
}
