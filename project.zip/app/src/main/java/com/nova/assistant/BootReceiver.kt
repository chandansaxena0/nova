package com.nova.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Restores scheduled Reminders & Timers after reboot or package update.
 * On Android < 14, attempts direct foreground service restore when Wake is enabled.
 * On Android 14+, respects OS boot-time microphone FGS restrictions by showing a 1-tap restore notification.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        ReminderStore.rescheduleAll(context)
        TimerManager.rescheduleAll(context)

        if (!Prefs.wake(context) || Prefs.privacyPaused(context)) return

        val micOk = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (Build.VERSION.SDK_INT < 34 && micOk) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, ListenService::class.java))
                return
            } catch (_: Exception) {}
        }

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nova_boot", "Nova Restart", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            context, 10,
            Intent(context, MainActivity::class.java).putExtra("autostart", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            20,
            NotificationCompat.Builder(context, "nova_boot")
                .setSmallIcon(R.drawable.ic_mic)
                .setContentTitle("Nova v10.0 Ultimate")
                .setContentText("Tap to resume background wake listening (Hey / Hi / Hello / Okay Nova).")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
    }
}
