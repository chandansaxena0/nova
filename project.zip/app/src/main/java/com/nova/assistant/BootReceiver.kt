package com.nova.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/** Reschedules saved Reminders on boot and prompts one-tap wake-word restart (Android 14+ policy). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        // Always restore scheduled reminders/alarms after reboot
        ReminderStore.rescheduleAll(context)

        if (!Prefs.wake(context)) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nova_boot", "Nova Restart", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            context, 10,
            Intent(context, MainActivity::class.java).putExtra("autostart", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            20,
            NotificationCompat.Builder(context, "nova_boot")
                .setSmallIcon(R.drawable.ic_mic)
                .setContentTitle("Nova v6")
                .setContentText("\"Hey Nova\" background listener chalu karne ke liye tap karo.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
    }
}
