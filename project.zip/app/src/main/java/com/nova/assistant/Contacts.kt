package com.nova.assistant

import android.content.Context
import android.provider.ContactsContract

data class ContactHit(val name: String, val number: String, val score: Double)

object Contacts {

    /**
     * Finds up to [limit] best-matching contacts for [key] (normalized Latin name).
     * Handles both English and Devanagari contact names and detects duplicate matches.
     */
    fun findAll(context: Context, key: String, limit: Int = 3): List<ContactHit> {
        if (key.length < 2) return emptyList()
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER

        val byName = LinkedHashMap<String, ContactHit>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(nameCol, numCol), null, null, null
            )?.use { c ->
                val ni = c.getColumnIndex(nameCol)
                val pi = c.getColumnIndex(numCol)
                while (c.moveToNext()) {
                    val name = c.getString(ni)?.trim() ?: continue
                    val number = c.getString(pi)?.trim() ?: continue
                    if (number.isEmpty()) continue
                    val latin = if (HinglishConverter.hasDevanagari(name)) {
                        HinglishConverter.transliterate(name)
                    } else name
                    val fullKey = Normalizer.key(latin)
                    val firstWordKey = Normalizer.key(latin.substringBefore(" "))
                    val sFull = Normalizer.similarity(key, fullKey)
                    val sFirst = if (firstWordKey.length >= 2) Normalizer.similarity(key, firstWordKey) * 0.96 else 0.0
                    val s = maxOf(sFull, sFirst)
                    if (s >= 0.70) {
                        val dedupKey = "${name.lowercase()}_${number.filter { it.isDigit() }.takeLast(10)}"
                        val existing = byName[dedupKey]
                        if (existing == null || s > existing.score) {
                            byName[dedupKey] = ContactHit(name, number, s)
                        }
                    }
                }
            }
        } catch (_: SecurityException) {
            return emptyList()
        }

        val sorted = byName.values.sortedByDescending { it.score }
        if (sorted.isEmpty()) return emptyList()
        // If top match is an exact match (1.0) and next match is significantly lower, return exact match only
        val top = sorted.first()
        if (top.score >= 0.99 && (sorted.size == 1 || sorted[1].score < 0.92)) {
            return listOf(top)
        }
        return sorted.take(limit)
    }

    fun find(context: Context, key: String): ContactHit? = findAll(context, key, 1).firstOrNull()

    /** Reverse lookup contact display name from incoming phone number (last 10 digits match). */
    fun findNameByNumber(context: Context, incomingNumber: String): String? {
        val targetDigits = incomingNumber.filter { it.isDigit() }.takeLast(10)
        if (targetDigits.length < 7) return null
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(nameCol, numCol), null, null, null
            )?.use { c ->
                val ni = c.getColumnIndex(nameCol)
                val pi = c.getColumnIndex(numCol)
                while (c.moveToNext()) {
                    val num = c.getString(pi)?.filter { it.isDigit() }?.takeLast(10) ?: continue
                    if (num == targetDigits) {
                        val name = c.getString(ni)?.trim()
                        if (!name.isNullOrEmpty()) return HinglishConverter.toHinglish(name)
                    }
                }
            }
        } catch (_: SecurityException) {
            return null
        }
        return null
    }
}
