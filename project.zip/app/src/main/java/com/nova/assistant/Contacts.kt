package com.nova.assistant

import android.content.Context
import android.provider.ContactsContract

object Contacts {

    /**
     * Finds the contact whose name is closest to [key] (a normalized Latin name).
     * Returns (display name, phone number) or null.
     * [translit] turns a Hindi (Devanagari) contact name into Latin letters for matching.
     */
    fun find(context: Context, key: String, translit: (String) -> String): Pair<String, String>? {
        if (key.length < 2) return null
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER

        var best: Pair<String, String>? = null
        var bestScore = 0.0
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(nameCol, numCol), null, null, null
            )?.use { c ->
                val ni = c.getColumnIndex(nameCol)
                val pi = c.getColumnIndex(numCol)
                while (c.moveToNext()) {
                    val name = c.getString(ni) ?: continue
                    val number = c.getString(pi) ?: continue
                    val latin = if (name.any { it in 'ऀ'..'ॿ' }) translit(name) else name
                    val s = Normalizer.similarity(key, Normalizer.key(latin))
                    if (s > bestScore) {
                        bestScore = s
                        best = name to number
                    }
                }
            }
        } catch (e: SecurityException) {
            return null
        }
        return if (bestScore >= 0.7) best else null
    }
}
