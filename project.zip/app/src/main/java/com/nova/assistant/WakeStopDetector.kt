package com.nova.assistant

import java.util.Locale

/**
 * Dedicated high-reliability Wake Word & Priority #0 Stop Command detector.
 *
 * Wake words:
 *   - Hey Nova, Hi Nova, Hello Nova, Okay Nova (Ok Nova), Nova
 *
 * Stop commands:
 *   - Stop, Stop Listening, Nova Stop, Nova Band Ho Jao,
 *     Band Karo, Band Ho Jao, Listening Band Karo, Bas Nova
 */
object WakeStopDetector {

    /**
     * Constrained Vosk grammar for always-on Wake Mode.
     * Restricting the acoustic graph to wake phrases + stop phrases + [unk]
     * drastically increases first-try recognition and cuts room-noise false triggers.
     */
    const val WAKE_GRAMMAR_JSON = """[
        "hey nova", "hi nova", "hello nova", "okay nova", "ok nova", "nova",
        "stop", "stop listening", "nova stop", "band karo", "band ho jao",
        "nova band ho jao", "listening band karo", "bas nova",
        "hey", "hi", "hello", "okay", "ok", "[unk]"
    ]"""

    private val wakePrefixes = setOf(
        "hey", "hi", "he", "hay", "hai", "hello", "helo", "hallo", "hye", "haye", "hae",
        "okay", "ok", "okey", "oke", "o", "oye", "ae", "ay", "a"
    )

    private val novaVariants = setOf(
        "nova", "nowa", "nava", "novo", "noba", "norva", "novaa", "noua", "noa", "nover", "noah", "novah"
    )

    private val joinedWakePrefixes = listOf("hello", "okay", "hey", "hay", "hi", "he", "hai", "ok")

    private val exactStopForms = setOf(
        "stop",
        "stoplistening",
        "novastop",
        "stopnova",
        "novabandhojao",
        "novabandkaro",
        "novaband",
        "bandkaro",
        "bandhojao",
        "listeningbandkaro",
        "sunnabandkaro",
        "basnova",
        "novabas",
        "rukjao",
        "rukjanova",
        "chuphojao",
        "novachup"
    )

    private val containsStopPhrases = listOf(
        "stop listening",
        "nova stop",
        "stop nova",
        "nova band ho jao",
        "nova band karo",
        "listening band karo",
        "sunna band karo",
        "band ho jao",
        "bas nova",
        "nova bas"
    )

    private val nonNovaWords = setOf(
        "not", "now", "new", "non", "one", "over", "move", "love", "none", "more", "note", "name", "home", "open"
    )

    fun isNovaToken(rawToken: String): Boolean {
        val m = rawToken.lowercase(Locale.ROOT).filter { it.isLetter() }
        if (m.length < 3 || m.length > 6) return false
        if (m in novaVariants) return true
        if (m in nonNovaWords) return false
        return Normalizer.levenshtein(m, "nova") <= 1
    }

    /**
     * Checks if [raw] contains a Wake Word.
     * @param isPartial In streaming partial results, standalone "nova" requires exact match
     *                  to minimize false triggers from background talk, while two-word phrases
     *                  ("hey nova", "hi nova", "hello nova", "okay nova") trigger immediately.
     * @return Words spoken AFTER the wake phrase (may be empty), or null if no wake phrase found.
     */
    fun stripWake(raw: String, isPartial: Boolean = false): String? {
        val clean = HinglishConverter.toHinglish(raw)
        if (clean.isBlank()) return null
        val words = clean.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return null
        val lower = words.map { it.lowercase(Locale.ROOT) }

        for (i in lower.indices) {
            val tok = lower[i]

            // 1) Two-word wake phrase: "hey nova", "hi nova", "hello nova", "okay nova", "ok nova"
            if (i > 0 && isNovaToken(tok) && lower[i - 1] in wakePrefixes) {
                return words.drop(i + 1).joinToString(" ").trim()
            }

            // 2) Split "o k nova"
            if (i >= 2 && isNovaToken(tok) && lower[i - 2] == "o" && (lower[i - 1] == "k" || lower[i - 1] == "kay")) {
                return words.drop(i + 1).joinToString(" ").trim()
            }

            // 3) Joined word: "heynova", "hinova", "okaynova", "hellonova"
            for (p in joinedWakePrefixes) {
                if (tok.startsWith(p) && isNovaToken(tok.removePrefix(p))) {
                    return words.drop(i + 1).joinToString(" ").trim()
                }
            }

            // 4) Standalone "Nova" (at start of utterance)
            if (i == 0) {
                val standaloneHit = if (isPartial) (tok == "nova" || tok == "nowa") else isNovaToken(tok)
                if (standaloneHit) {
                    return words.drop(1).joinToString(" ").trim()
                }
            }
        }
        return null
    }

    /**
     * Priority #0 Stop Command detector.
     * Intercepted BEFORE parser/Gemini/Google Search while guarding against false stop triggers
     * on normal queries like "bus stop near me" or "non stop songs".
     */
    fun isStopCommand(raw: String): Boolean {
        val clean = HinglishConverter.toHinglish(raw)
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9\\s]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (clean.isEmpty()) return false

        if (clean.contains("bus stop") || clean.contains("non stop") || clean.contains("nonstop") ||
            clean.contains("pit stop") || clean.contains("stop watch") || clean.contains("stopwatch") ||
            clean.contains("near me") || clean.contains("paas") || clean.contains("kahan") ||
            clean.contains("search") || clean.contains("play") || clean.contains("youtube")
        ) {
            if (!clean.contains("nova stop") && !clean.contains("stop listening") && !clean.contains("band karo")) {
                return false
            }
        }

        val compact = clean.replace(" ", "")
        if (compact in exactStopForms) return true

        val strippedPolite = clean
            .replace(Regex("\\b(please|plz|yaar|abhi|now|ji|kar|do)\\b"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (strippedPolite.replace(" ", "") in exactStopForms) return true

        val wordCount = clean.split(" ").size
        if (wordCount <= 5 && containsStopPhrases.any { clean.contains(it) }) {
            return true
        }

        if (wordCount == 1 && clean == "stop") return true
        if (wordCount == 2 && clean == "band karo") return true

        return false
    }

    enum class ConfirmAnswer { YES, NO, NEITHER }

    fun parseConfirmation(raw: String): ConfirmAnswer {
        val clean = HinglishConverter.toHinglish(raw)
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z\\s]+"), " ")
            .trim()
        val toks = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (toks.isEmpty()) return ConfirmAnswer.NEITHER

        val yesWords = setOf(
            "yes", "haan", "han", "ha", "ji", "ok", "okay", "confirm", "bhejo",
            "karo", "call", "send", "sure", "bilkul", "theek", "thik", "right", "sahi"
        )
        val noWords = setOf(
            "no", "nahi", "nahin", "na", "mat", "cancel", "ruko", "stop", "band", "chhodo", "rehne", "nope"
        )

        if (toks.any { it in noWords }) return ConfirmAnswer.NO
        if (toks.any { it in yesWords }) return ConfirmAnswer.YES
        return ConfirmAnswer.NEITHER
    }
}
