package com.nova.assistant

import java.util.Locale

/**
 * High-reliability Wake Word & Priority #0 Stop Command detector for Indian accents.
 *
 * Works with full-vocabulary Vosk (both Indian-English en-in-0.4 AND Hindi models)
 * without OOV grammar failures, catching real Vosk phonetic outputs for:
 *   - Hey Nova, Hi Nova, Hello Nova, Okay Nova (Ok Nova), Nova
 *
 * Stop commands:
 *   - Stop, Stop Listening, Nova Stop, Nova Band Ho Jao,
 *     Band Karo, Band Ho Jao, Listening Band Karo, Bas Nova
 */
object WakeStopDetector {

    private val wakePrefixes = setOf(
        "hey", "hi", "he", "hay", "hai", "high", "hello", "helo", "hallo",
        "hye", "haye", "hae", "okay", "ok", "okey", "oke", "o", "oye", "ae", "ay", "a"
    )

    // Single-word phonetic outputs Vosk produces when an Indian user says "Nova"
    private val novaStrongVariants = setOf(
        "nova", "nowa", "nava", "novo", "noba", "norva", "novaa", "noua",
        "noa", "nover", "noah", "novah", "noma", "nora", "nawab"
    )

    // Words that count as "Nova" ONLY when immediately preceded by Hey / Hi / Hello / Okay
    private val novaAfterPrefixVariants = novaStrongVariants + setOf(
        "over", "lower", "know", "no", "nor", "now", "sofa", "gova", "goa", "nobel", "noble", "lover"
    )

    // Two-word Vosk splits for "Nova" after a wake prefix (e.g. "hey no war", "hey know a", "hey no va")
    private val novaTwoWordSplits = setOf(
        "no war", "no a", "know a", "now a", "no va", "na va", "no bar", "no one", "no way", "no what"
    )

    private val joinedWakePrefixes = listOf("hello", "okay", "hey", "hay", "hi", "he", "hai", "ok")

    private val exactStopForms = setOf(
        "stop",
        "stoplistening",
        "novastop",
        "stopnova",
        "novabandhojao",
        "novabandkaro",
        "novaband",
        "bandkaro",
        "bandhojao",
        "listeningbandkaro",
        "sunnabandkaro",
        "basnova",
        "novabas",
        "rukjao",
        "rukjanova",
        "chuphojao",
        "novachup"
    )

    private val containsStopPhrases = listOf(
        "stop listening",
        "nova stop",
        "stop nova",
        "nova band ho jao",
        "nova band karo",
        "listening band karo",
        "sunna band karo",
        "band ho jao",
        "bas nova",
        "nova bas"
    )

    private val nonNovaWords = setOf(
        "not", "now", "new", "non", "one", "over", "move", "love", "none", "more", "note", "name", "home", "open"
    )

    fun isNovaToken(rawToken: String, hasPrefix: Boolean = false): Boolean {
        val m = rawToken.lowercase(Locale.ROOT).filter { it.isLetter() }
        if (m.length < 2 || m.length > 7) return false
        if (hasPrefix && m in novaAfterPrefixVariants) return true
        if (m in novaStrongVariants) return true
        if (m in nonNovaWords) return false
        return m.length >= 3 && Normalizer.levenshtein(m, "nova") <= 1
    }

    /**
     * Checks if [raw] contains a Wake Word (handles repeated "Hey Nova Hey Nova ..." too).
     * @param isPartial In streaming partial results, standalone "nova" requires exact match
     *                  to suppress room chatter, while prefixed wake phrases ("hey nova",
     *                  "hi nova", "hello nova", "okay nova" & phonetic matches) trigger immediately.
     * @return Words spoken AFTER the last wake phrase (may be empty), or null if no wake phrase found.
     */
    fun stripWake(raw: String, isPartial: Boolean = false): String? {
        val clean = HinglishConverter.toHinglish(raw)
        if (clean.isBlank()) return null
        val words = clean.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return null
        val lower = words.map { it.lowercase(Locale.ROOT) }

        var matchedEndIdx = -1

        var i = 0
        while (i < lower.size) {
            val tok = lower[i]

            // 1) Prefix + two-word Vosk split: "hey no war", "hey know a", "okay no va"
            if (i + 2 < lower.size && tok in wakePrefixes) {
                val pair = "${lower[i + 1]} ${lower[i + 2]}"
                if (pair in novaTwoWordSplits) {
                    matchedEndIdx = i + 3
                    i += 3
                    continue
                }
            }

            // 2) Split "o k nova" / "o kay nova"
            if (i + 2 < lower.size && tok == "o" && (lower[i + 1] == "k" || lower[i + 1] == "kay") &&
                isNovaToken(lower[i + 2], hasPrefix = true)
            ) {
                matchedEndIdx = i + 3
                i += 3
                continue
            }

            // 3) Standard two-word wake phrase: "hey nova", "hi nova", "hello nova", "okay nova", "ok nova"
            if (i + 1 < lower.size && tok in wakePrefixes && isNovaToken(lower[i + 1], hasPrefix = true)) {
                // Guard: avoid triggering on plain "hey no" or "a no" unless it's clearly "hey nova/noah/over"
                val nextTok = lower[i + 1]
                val tooGeneric = (tok == "a" || tok == "he" || tok == "o") && nextTok in setOf("no", "now", "know", "over", "lower", "nor")
                if (!tooGeneric) {
                    matchedEndIdx = i + 2
                    i += 2
                    continue
                }
            }

            // 4) Joined word: "heynova", "hinova", "okaynova", "hellonova"
            var joinedMatched = false
            for (p in joinedWakePrefixes) {
                if (tok.startsWith(p) && isNovaToken(tok.removePrefix(p), hasPrefix = true)) {
                    matchedEndIdx = i + 1
                    joinedMatched = true
                    break
                }
            }
            if (joinedMatched) {
                i += 1
                continue
            }

            // 5) Standalone "Nova" (at start, or immediately following another wake phrase)
            if (i == 0 || i == matchedEndIdx) {
                val standaloneHit = if (isPartial) {
                    tok in setOf("nova", "nowa", "noah", "nava")
                } else {
                    isNovaToken(tok, hasPrefix = false)
                }
                if (standaloneHit) {
                    matchedEndIdx = i + 1
                    i += 1
                    continue
                }
            }

            i++
        }

        if (matchedEndIdx < 0) return null
        return words.drop(matchedEndIdx).joinToString(" ").trim()
    }

    /**
     * Priority #0 Stop Command detector.
     * Intercepted BEFORE parser/Gemini/Google Search while guarding against false stop triggers.
     */
    fun isStopCommand(raw: String): Boolean {
        val clean = HinglishConverter.toHinglish(raw)
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9\\s]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (clean.isEmpty()) return false

        if (clean.contains("bus stop") || clean.contains("non stop") || clean.contains("nonstop") ||
            clean.contains("pit stop") || clean.contains("stop watch") || clean.contains("stopwatch") ||
            clean.contains("near me") || clean.contains("paas") || clean.contains("kahan") ||
            clean.contains("search") || clean.contains("play") || clean.contains("youtube")
        ) {
            if (!clean.contains("nova stop") && !clean.contains("stop listening") && !clean.contains("band karo")) {
                return false
            }
        }

        val compact = clean.replace(" ", "")
        if (compact in exactStopForms) return true

        val strippedPolite = clean
            .replace(Regex("\\b(please|plz|yaar|abhi|now|ji|kar|do)\\b"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (strippedPolite.replace(" ", "") in exactStopForms) return true

        val wordCount = clean.split(" ").size
        if (wordCount <= 5 && containsStopPhrases.any { clean.contains(it) }) {
            return true
        }

        if (wordCount == 1 && clean == "stop") return true
        if (wordCount == 2 && clean == "band karo") return true

        return false
    }

    enum class ConfirmAnswer { YES, NO, NEITHER }

    fun parseConfirmation(raw: String): ConfirmAnswer {
        val clean = HinglishConverter.toHinglish(raw)
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z\\s]+"), " ")
            .trim()
        val toks = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (toks.isEmpty()) return ConfirmAnswer.NEITHER

        val yesWords = setOf(
            "yes", "haan", "han", "ha", "ji", "ok", "okay", "confirm", "bhejo",
            "karo", "call", "send", "sure", "bilkul", "theek", "thik", "right", "sahi"
        )
        val noWords = setOf(
            "no", "nahi", "nahin", "na", "mat", "cancel", "ruko", "stop", "band", "chhodo", "rehne", "nope"
        )

        if (toks.any { it in noWords }) return ConfirmAnswer.NO
        if (toks.any { it in yesWords }) return ConfirmAnswer.YES
        return ConfirmAnswer.NEITHER
    }
}
