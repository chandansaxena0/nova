package com.nova.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat

/**
 * Android Quick Settings Tile ("Nova Listen") — 1-tap voice command trigger from notification shade anywhere!
 */
class NovaQuickTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTileState()
    }

    override fun onClick() {
        super.onClick()
        if (Prefs.privacyPaused(this)) {
            val open = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            launchCompat(open)
            return
        }
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) {
            runCatching {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, ListenService::class.java).setAction(ListenService.ACTION_INTERRUPT_AND_LISTEN)
                )
            }.onFailure {
                launchCompat(Intent(this, AssistActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else {
            launchCompat(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        refreshTileState()
    }

    private fun launchCompat(intent: Intent) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = android.app.PendingIntent.getActivity(
                    this, 44, intent,
                    android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                )
                startActivityAndCollapse(pi)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        } catch (_: Exception) {
            runCatching { startActivity(intent) }
        }
    }

    private fun refreshTileState() {
        val tile = qsTile ?: return
        tile.label = "Nova Listen"
        tile.state = when {
            Prefs.privacyPaused(this) -> Tile.STATE_UNAVAILABLE
            ListenService.running -> Tile.STATE_ACTIVE
            else -> Tile.STATE_INACTIVE
        }
        tile.updateTile()
    }
}
