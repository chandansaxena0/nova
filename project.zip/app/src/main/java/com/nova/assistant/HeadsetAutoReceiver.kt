package com.nova.assistant

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

/**
 * Detects Bluetooth earbuds & wired headset connections and executes user-enabled auto-actions:
 *   - Updates `NovaState.headsetConnected` (enables echo-safe Hands-Free Barge-In & Headset Notification Announce).
 *   - Optionally launches user's favorite music app (Spotify / YT Music / JioSaavn) when earbuds connect.
 */
class HeadsetAutoReceiver : BroadcastReceiver() {

    companion object {
        private val defaultMusicPkgs = listOf(
            "com.spotify.music",
            "com.google.android.apps.youtube.music",
            "com.jio.media.jiobeats",
            "com.gaana",
            "com.amazon.mp3"
        )

        fun isAudioHeadsetConnected(context: Context): Boolean {
            return try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                outs.any { dev ->
                    dev.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                        dev.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        dev.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                        dev.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                        dev.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                        (Build.VERSION.SDK_INT >= 31 && dev.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
                }
            } catch (_: Exception) {
                false
            }
        }

        fun launchFavoriteMusicIfEnabled(context: Context) {
            if (Prefs.privacyPaused(context) || !Prefs.headsetAutoMusic(context)) return
            val pref = Prefs.preferredMusicPkg(context)
            val candidates = if (pref.isNotEmpty()) listOf(pref) + defaultMusicPkgs else defaultMusicPkgs
            val pm = context.packageManager
            for (pkg in candidates) {
                val launch = pm.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    runCatching {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launch)
                    }
                    return
                }
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        var newlyConnected = false
        when (action) {
            Intent.ACTION_HEADSET_PLUG -> {
                val state = intent.getIntExtra("state", -1)
                if (state == 1) newlyConnected = true
            }
            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                newlyConnected = true
            }
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                NovaState.headsetConnected = isAudioHeadsetConnected(context)
                return
            }
        }
        val connected = newlyConnected || isAudioHeadsetConnected(context)
        val wasConnected = NovaState.headsetConnected
        NovaState.headsetConnected = connected
        if (connected && !wasConnected) {
            launchFavoriteMusicIfEnabled(context)
        }
    }
}
