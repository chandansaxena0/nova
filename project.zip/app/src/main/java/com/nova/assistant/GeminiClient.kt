package com.nova.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * OPTIONAL helper. Only used when you paste your own Gemini key in the app
 * AND the offline parser could not understand the command.
 * The key stays on the phone. It is sent only to Google, in a header.
 */
object GeminiClient {

    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"

    private fun systemPrompt(labels: List<String>): String = """
You convert one phone voice command (Hindi, English or Hinglish) into ONE JSON object.
Schema: {"action":"open"|"search"|"play"|"unknown","app":"<exact name from the list, or empty>","query":"<text to search or play, or empty>"}
Rules:
- "open" = just open the app. "search" = search inside the app (if app is empty, a Google search). "play" = play music or video; if no app is named, leave app empty.
- "app" must be copied EXACTLY from this list of installed apps, or be empty: ${labels.joinToString(", ")}
- Keep song, artist and place names in the language they were spoken. Fix obvious speech-recognition spelling mistakes.
- If the command cannot be done with these actions, use "unknown".
Output only the JSON object.
""".trimIndent()

    /** Returns null if the answer could not be read. Throws on network / key errors. */
    fun interpret(key: String, model: String, text: String, apps: List<AppInfo>): Command? {
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt(apps.map { it.label })))
                )
            )
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("temperature", 0).put("responseMimeType", "application/json")
            )

        val response = post(key, model, body)
        val answer = JSONObject(response)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")

        val start = answer.indexOf('{')
        val end = answer.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val j = JSONObject(answer.substring(start, end + 1))

        val kind = when (j.optString("action").lowercase()) {
            "open" -> Kind.OPEN
            "search" -> Kind.SEARCH
            "play" -> Kind.PLAY
            else -> Kind.UNKNOWN
        }
        val appKey = Normalizer.key(j.optString("app"))
        val app = if (appKey.isEmpty()) null else apps.firstOrNull { it.key == appKey }
        return Command(kind, app, j.optString("query").trim(), text)
    }

    /** Used by the "Save" button to tell the user if the key works. */
    fun test(key: String, model: String, apps: List<AppInfo>): String = try {
        val c = interpret(key, model, "WhatsApp kholo", apps)
        if (c != null && c.kind != Kind.UNKNOWN) "Gemini theek chal raha hai."
        else "Gemini jawab de raha hai, par command samajh nahi paya."
    } catch (e: Exception) {
        "Gemini error: ${e.message}"
    }

    private fun post(key: String, model: String, body: JSONObject): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text
            }
            throw RuntimeException("HTTP $code: ${msg.take(160)}")
        }
        return text
    }
}
