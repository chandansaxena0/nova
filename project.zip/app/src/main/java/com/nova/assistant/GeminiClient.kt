package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Gemini AI client for Nova v7.0.
 * - Preserves working 3.x-first fallback (`gemini-3.5-flash-lite`, `gemini-3.8-flash`, `gemini-3.6-flash`,
 *   `gemini-2.5-flash-lite`, `gemini-2.5-flash`) and dual auth (`x-goog-api-key` + `Authorization: Bearer`)
 *   for both `AQ...` and `AIza...` Google AI Studio keys.
 * - Supports Multi-Agent system prompts, Google Search Grounding with source links, and Multimodal Vision.
 */
object GeminiClient {

    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
    private val FALLBACK_MODELS = listOf(
        "gemini-3.5-flash-lite",
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.5-flash"
    )

    data class TestOutcome(val ok: Boolean, val workingModel: String, val message: String)
    data class GroundedReply(val text: String, val sources: List<Pair<String, String>>)

    private data class ChatTurn(val role: String, val text: String)
    private val chatHistory = ArrayList<ChatTurn>()

    fun clearChatHistory() {
        synchronized(chatHistory) { chatHistory.clear() }
    }

    private fun generationConfig(model: String, temp: Double, maxTokens: Int, jsonMode: Boolean = false): JSONObject {
        val cfg = JSONObject()
            .put("temperature", temp)
            .put("maxOutputTokens", if (model.contains("2.5")) maxTokens else maxOf(maxTokens, 1024))
        if (jsonMode) cfg.put("responseMimeType", "application/json")
        if (model.contains("2.5")) {
            cfg.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }
        return cfg
    }

    private fun commandPrompt(labels: List<String>): String = """
You convert ONE Indian user's voice command (English, Hindi, or Hinglish) into ONE JSON object.
ALWAYS write query, contact, body, and reply in clean Roman Hinglish or English (NEVER Devanagari Hindi script).
Fix obvious voice-recognition errors (e.g. "mr beast" -> "MrBeast", "rob locks" -> "Roblox").

Schema:
{"action":"story|joke|shayari|open|search|play|roblox|call|message|reply|notifications|flashlight|open_settings|timer|reminder|alarm|task|routine|calendar|nearby|train|checklist|flashcard|research|file|screen|privacy_pause|music|phone_info|weather|briefing|translate|study|clipboard|memory_save|emergency|chat|agent|clarify","app":"","query":"","contact":"","body":"","sms":false,"goal":"","minutes":0}

CRITICAL INTENT RULES:
- story: user wants a story/kahani narrated ("kahani sunao", "tell me a story"). NEVER route this to YouTube unless user explicitly mentions YouTube.
- joke: user wants a joke/chutkula ("joke sunao", "tell a joke").
- shayari: user wants shayari/poem/kavita ("shayari sunao", "poem sunao").
- open: open an installed app.
- search: search ONLY when user explicitly asks to search inside an app or Google ("YouTube par kahani search karo").
- play: play music/song/video ONLY when user wants media playback ("gaana chalao", "play song").
- flashlight: turn flashlight/torch on or off (query = "on" or "off").
- open_settings: open Android settings page (query = "wifi", "bluetooth", "battery", "display", "sound", "location", "data", "apps", "main").
- timer: set/check/cancel countdown timer (minutes = number of minutes, query = full request).
- notifications: summarize or read phone notifications.
- research: web research, latest news, or fact lookup with sources.
- train: live train running status/arrival/departure (query = train number or name).
- checklist: travel checklist view/tick/add/reset.
- flashcard: voice flashcards / quiz revision (query = topic).
- task / routine / calendar: manage to-do tasks, daily routines, or calendar events.
- file: summarize or answer questions about loaded PDF/TXT/DOCX/Image document.
- screen: analyze/explain current screen content.
- privacy_pause: pause everything / privacy mode (query = "on" or "off").
- chat: general conversational question, explanation, follow-up, or reasoning.
- clarify: when user intent is genuinely ambiguous and needs a brief clarification question (body = clarification question).
- "app" MUST be copied EXACTLY from this installed app list, or be empty: ${labels.joinToString(", ")}
Output ONLY valid JSON.
""".trimIndent()

    private val AGENT_PROMPT = """
You control an Android phone through its accessibility tree to finish ONE goal for the user.
Reply with ONE JSON object: {"action":"click|type|scroll_down|scroll_up|enter|back|home|wait|done|fail","index":-1,"text":"","reason":"short, in Hinglish"}
Rules:
- click: index = element to tap. type: index = editable element (or -1 for first editable), text = text to type in Roman Hinglish/English.
- Never enter passwords, OTPs, bank or UPI details. Never confirm payments, transfers, purchases, or deletions -> use "fail".
- Send messages only with exact text in the goal.
Output ONLY the JSON object.
""".trimIndent()

    fun defaultChatSystemPrompt(context: Context, queryHint: String = ""): String {
        val langPref = Prefs.replyLanguage(context)
        val langRule = when (langPref) {
            "english" -> "Reply in clear, warm, concise Indian English."
            "hindi" -> "Reply in natural spoken Hinglish (Roman script, easy to read and speak aloud)."
            else -> "Reply in natural, friendly Roman Hinglish (no Devanagari script, no markdown symbols like ** or ##)."
        }
        val mem = SmartMemory.relevantMemorySummary(context, queryHint)
        return """
You are Nova, an intelligent, warm personal AI voice assistant on an Android phone in India.
$langRule
Remember previous turns in this conversation so follow-up questions work seamlessly.
Keep replies concise (2 to 4 short sentences) unless the user asks for a story, detailed explanation, study notes, or step-by-step math.
Do NOT use markdown stars, hashtags, or bullet symbols because your reply is read aloud by Text-to-Speech.
$mem
""".trimIndent()
    }

    fun interpret(key: String, model: String, text: String, apps: List<AppInfo>): Command? {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", commandPrompt(apps.map { it.label })))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", generationConfig(model, 0.0, 256, jsonMode = true))

        val j = extractJson(postWithRetry(key.trim(), model, body)) ?: return null

        val appKey = Normalizer.key(j.optString("app"))
        val app = if (appKey.isEmpty()) null else apps.firstOrNull { it.key == appKey }
        val query = HinglishConverter.toHinglish(j.optString("query").trim())
        val contact = HinglishConverter.toHinglish(j.optString("contact").trim())
        val contactKey = Normalizer.key(contact)
        val msgBody = HinglishConverter.toHinglish(j.optString("body").trim())
        val goal = j.optString("goal").trim()
        val minutes = j.optInt("minutes", 0)

        return when (j.optString("action").lowercase()) {
            "story" -> Command(Kind.STORY, null, query.ifEmpty { text }, text)
            "joke" -> Command(Kind.JOKE, null, query.ifEmpty { text }, text)
            "shayari" -> Command(Kind.SHAYARI, null, query.ifEmpty { text }, text)
            "open" -> Command(Kind.OPEN, app, query, text)
            "search" -> Command(Kind.SEARCH, app, query, text)
            "play" -> Command(Kind.PLAY, app, query, text)
            "roblox" -> Command(Kind.ROBLOX, app, query, text)
            "call" -> Command(Kind.CALL, null, "", text, contact = contact, contactKey = contactKey)
            "message" -> Command(Kind.MESSAGE, app, "", text, contact = contact, contactKey = contactKey, body = msgBody, sms = j.optBoolean("sms", false))
            "reply" -> Command(Kind.REPLY, null, "", text, contact = contact, contactKey = contactKey, body = msgBody)
            "notifications" -> Command(Kind.SUMMARIZE_NOTIFICATIONS, null, query, text)
            "flashlight" -> Command(Kind.FLASHLIGHT, null, query.ifEmpty { "on" }, text)
            "open_settings" -> Command(Kind.OPEN_SETTINGS, null, query.ifEmpty { "main" }, text)
            "timer" -> Command(Kind.TIMER, null, query.ifEmpty { text }, text, extraMinutes = minutes)
            "nearby" -> Command(Kind.NEARBY, null, query.ifEmpty { text }, text)
            "train" -> Command(Kind.TRAIN_STATUS, null, query.ifEmpty { text }, text)
            "checklist" -> Command(Kind.TRAVEL_CHECKLIST, null, query.ifEmpty { text }, text)
            "flashcard" -> Command(Kind.VOICE_FLASHCARD, null, query.ifEmpty { text }, text)
            "research" -> Command(Kind.WEB_RESEARCH, null, query.ifEmpty { text }, text)
            "file" -> Command(Kind.FILE_ANALYZE, null, query.ifEmpty { text }, text)
            "screen" -> Command(Kind.SCREEN_ANALYZE, null, query.ifEmpty { text }, text)
            "task" -> Command(Kind.TASK_MANAGE, null, query.ifEmpty { text }, text, body = msgBody)
            "routine" -> Command(Kind.ROUTINE_RUN, null, query.ifEmpty { text }, text)
            "calendar" -> Command(Kind.CALENDAR, null, query.ifEmpty { text }, text, body = msgBody)
            "privacy_pause" -> Command(Kind.PRIVACY_PAUSE, null, query.ifEmpty { "on" }, text)
            "reminder" -> Command(Kind.REMINDER, null, "", text, body = msgBody.ifEmpty { query }, extraMinutes = minutes)
            "alarm" -> Command(Kind.ALARM, null, "", text, body = msgBody.ifEmpty { query }, extraMinutes = minutes)
            "music" -> Command(Kind.MUSIC_CONTROL, app, query, text)
            "phone_info" -> Command(Kind.PHONE_INFO, null, query.ifEmpty { "all" }, text)
            "weather" -> Command(Kind.WEATHER, null, "", text)
            "briefing" -> Command(Kind.DAILY_BRIEFING, null, "", text)
            "translate" -> Command(Kind.TRANSLATE, null, query.ifEmpty { text }, text)
            "study" -> Command(Kind.STUDY, null, query.ifEmpty { text }, text)
            "clipboard" -> Command(Kind.CLIPBOARD, null, query.ifEmpty { "read" }, text)
            "memory_save" -> Command(Kind.MEMORY_SAVE, null, "", text, body = msgBody.ifEmpty { query })
            "emergency" -> Command(Kind.EMERGENCY, null, query, text)
            "agent" -> Command(Kind.AGENT, null, "", text, body = goal)
            "clarify" -> Command(Kind.CLARIFY, null, text, text, body = msgBody)
            else -> Command(Kind.CHAT, null, text, text)
        }
    }

    fun ask(context: Context, userMessage: String, keepContext: Boolean = true): String =
        askWithAgentPrompt(context, defaultChatSystemPrompt(context, userMessage), userMessage, keepContext)

    fun askWithAgentPrompt(
        context: Context,
        systemPrompt: String,
        userMessage: String,
        keepContext: Boolean = true,
        maxTokens: Int = 700
    ): String {
        val key = Prefs.geminiKey(context)
        if (key.isEmpty()) {
            return "Gemini API key save nahi hai. Settings tab me apni Google AI Studio key save karo."
        }
        if (!PhoneInfoHelper.isOnline(context)) {
            return "Internet band hai. Is sawal ke liye internet ON karo, ya offline commands (battery, timer, reminders, math, offline story/joke) use karo."
        }

        val contents = JSONArray()
        synchronized(chatHistory) {
            if (keepContext && !Prefs.privacyPaused(context)) {
                chatHistory.takeLast(10).forEach { turn ->
                    contents.put(
                        JSONObject()
                            .put("role", turn.role)
                            .put("parts", JSONArray().put(JSONObject().put("text", turn.text)))
                    )
                }
            }
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
        )

        val model = Prefs.geminiModel(context)
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("generationConfig", generationConfig(model, 0.55, maxTokens))

        return try {
            val raw = postWithRetry(key, model, body)
            val reply = cleanForVoice(extractText(raw))
            if (reply.isBlank()) {
                "Gemini se jawab khali aaya. Dobara try karo."
            } else {
                if (keepContext && !Prefs.privacyPaused(context)) {
                    FollowUpTracker.markActive()
                    synchronized(chatHistory) {
                        chatHistory.add(ChatTurn("user", userMessage))
                        chatHistory.add(ChatTurn("model", reply))
                        while (chatHistory.size > 14) chatHistory.removeAt(0)
                    }
                }
                reply
            }
        } catch (_: UnknownHostException) {
            "Internet connection nahi mil raha. Network check karo."
        } catch (_: SocketTimeoutException) {
            "Gemini response me zyada samay lag gaya. Dobara try karo."
        } catch (e: Exception) {
            friendlyError(e.message)
        }
    }

    /** Real-time web research using Gemini Google Search Grounding + extracts verified source URLs. */
    fun askWithSearchGrounding(context: Context, systemPrompt: String, userMessage: String): GroundedReply? {
        val key = Prefs.geminiKey(context)
        if (key.isEmpty() || !PhoneInfoHelper.isOnline(context)) return null
        val model = Prefs.geminiModel(context)
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userMessage)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .put("generationConfig", generationConfig(model, 0.25, 700))

        return try {
            val raw = postWithRetry(key, model, body)
            val text = cleanForVoice(extractText(raw))
            if (text.isBlank()) return null
            val sources = extractGroundingSources(raw)
            GroundedReply(text, sources)
        } catch (_: Exception) {
            null
        }
    }

    /** Multimodal image/PDF-page analysis using Gemini Vision. */
    fun askWithImageBase64(context: Context, mimeType: String, base64Data: String, prompt: String): String {
        val key = Prefs.geminiKey(context)
        if (key.isEmpty()) return "Image ya screen samajhne ke liye Settings me Gemini API key save karo."
        if (!PhoneInfoHelper.isOnline(context)) return "Internet band hai. Image analysis ke liye internet ON karo."

        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", mimeType).put("data", base64Data)
                )
            )
        val model = Prefs.geminiModel(context)
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", defaultChatSystemPrompt(context)))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", generationConfig(model, 0.35, 700))

        return try {
            val raw = postWithRetry(key, model, body)
            val reply = cleanForVoice(extractText(raw))
            if (reply.isBlank()) "Image ka jawab khali aaya. Dobara try karo." else reply
        } catch (_: UnknownHostException) {
            "Internet connection nahi mil raha."
        } catch (_: SocketTimeoutException) {
            "Image analysis me timeout ho gaya. Dobara try karo."
        } catch (e: Exception) {
            friendlyError(e.message)
        }
    }

    fun agentStep(key: String, model: String, goal: String, history: List<String>, screen: String): JSONObject? {
        val user = buildString {
            append("Goal: ").append(goal).append("\n\nPrevious steps:\n")
            if (history.isEmpty()) append("(none)\n")
            else history.takeLast(8).forEach { append("- ").append(it).append('\n') }
            append("\nCurrent screen:\n").append(screen)
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", AGENT_PROMPT))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
            .put("generationConfig", generationConfig(model, 0.0, 256, jsonMode = true))
        return extractJson(postWithRetry(key, model, body))
    }

    fun testAndResolveModel(rawKey: String, preferredModel: String): TestOutcome {
        val key = rawKey.trim().replace("\"", "").replace("'", "").replace("\\s+".toRegex(), "")
        if (key.isEmpty()) return TestOutcome(false, preferredModel, "API key khali hai.")

        val candidates = (listOf(preferredModel.trim().ifEmpty { DEFAULT_MODEL }) + FALLBACK_MODELS).distinct()
        var lastErr = ""

        for (m in candidates) {
            try {
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "Say OK")))))
                    .put("generationConfig", generationConfig(m, 0.0, 64))
                val resp = post(key, m, body)
                val txt = extractText(resp)
                if (txt.isNotBlank()) {
                    return TestOutcome(true, m, "Connected! Gemini ($m) theek kaam kar raha hai.")
                }
            } catch (_: UnknownHostException) {
                return TestOutcome(false, preferredModel, "Internet band hai. Network check karo.")
            } catch (e: Exception) {
                val msg = e.message.orEmpty()
                lastErr = msg
                if (!msg.contains("HTTP 404")) {
                    return TestOutcome(false, preferredModel, friendlyError(msg))
                }
            }
        }
        return TestOutcome(false, preferredModel, friendlyError(lastErr))
    }

    private fun extractGroundingSources(response: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val cand = JSONObject(response).optJSONArray("candidates")?.optJSONObject(0) ?: return out
            val meta = cand.optJSONObject("groundingMetadata") ?: return out
            val chunks = meta.optJSONArray("groundingChunks") ?: return out
            for (i in 0 until chunks.length()) {
                val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                val title = web.optString("title", "").trim()
                val uri = web.optString("uri", "").trim()
                if (uri.isNotEmpty() && out.none { it.second == uri }) {
                    out.add((title.ifEmpty { uri }) to uri)
                }
            }
        } catch (_: Exception) {}
        return out.take(4)
    }

    private fun cleanForVoice(raw: String): String =
        raw.replace("**", "").replace("##", "").replace("`", "").replace("* ", "").trim()

    private fun friendlyError(raw: String?): String {
        val m = raw.orEmpty()
        return when {
            m.contains("API_KEY_INVALID", true) || m.contains("API key not valid", true) ->
                "API key invalid ya expired hai. aistudio.google.com/apikey par jakar nayi Gemini API key banao."
            m.contains("API key expired", true) ->
                "Aapki purani Gemini API key expire ho chuki hai. aistudio.google.com/apikey se nayi key banao."
            m.contains("HTTP 403") || m.contains("PERMISSION_DENIED", true) ->
                "Key ko permission nahi hai (HTTP 403). Google AI Studio se fresh key check karo."
            m.contains("HTTP 429") || m.contains("RESOURCE_EXHAUSTED", true) || m.contains("quota", true) ->
                "Is key ka free quota/limit abhi khatam ho gaya hai (HTTP 429). Thodi der baad try karo."
            m.contains("HTTP 404") ->
                "Selected model uplabdh nahi hai (HTTP 404). Model box me 'gemini-3.5-flash-lite' likhkar save karo."
            else -> "Gemini error: ${m.take(150)}"
        }
    }

    private fun extractText(response: String): String {
        val candidates = JSONObject(response).optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            if (!part.optBoolean("thought", false)) {
                sb.append(part.optString("text", ""))
            }
        }
        return sb.toString().trim()
    }

    private fun extractJson(response: String): JSONObject? {
        val answer = extractText(response)
        val start = answer.indexOf('{')
        val end = answer.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return JSONObject(answer.substring(start, end + 1))
    }

    private fun postWithRetry(key: String, model: String, body: JSONObject): String {
        var lastError: Exception? = null
        for (attempt in 0..1) {
            try {
                return try {
                    post(key, model, body)
                } catch (e: Exception) {
                    if (e.message?.contains("HTTP 404") != true) throw e
                    var found: String? = null
                    for (m in FALLBACK_MODELS) {
                        if (m == model.trim()) continue
                        try { found = post(key, m, body); break } catch (e2: Exception) {
                            if (e2.message?.contains("HTTP 404") != true) throw e2
                        }
                    }
                    found ?: throw e
                }
            } catch (e: Exception) {
                lastError = e
                val retryable = e is SocketTimeoutException || e.message?.contains("429") == true || e.message?.contains("503") == true
                if (attempt == 1 || !retryable) throw e
                Thread.sleep(2500)
            }
        }
        throw lastError ?: RuntimeException("Request failed")
    }

    private fun post(key: String, model: String, body: JSONObject): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
        val payload = body.toString().toByteArray(Charsets.UTF_8)

        // Attempt 1: standard x-goog-api-key header
        val first = attemptHttpPost(url, payload) { conn ->
            conn.setRequestProperty("x-goog-api-key", key)
        }
        if (first.code in 200..299) return first.body

        // Attempt 2: for newer AQ. Authorization keys that expect Bearer auth
        if (first.code == 401 || first.code == 403 || first.body.contains("ACCESS_TOKEN_TYPE_UNSUPPORTED", true)) {
            val second = attemptHttpPost(url, payload) { conn ->
                conn.setRequestProperty("Authorization", "Bearer $key")
            }
            if (second.code in 200..299) return second.body
            throwRuntimeError(second.code, second.body)
        }

        throwRuntimeError(first.code, first.body)
        return ""
    }

    private data class HttpResp(val code: Int, val body: String)

    private fun attemptHttpPost(url: URL, payload: ByteArray, configureAuth: (HttpURLConnection) -> Unit): HttpResp {
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 25000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            configureAuth(this)
        }
        try {
            conn.outputStream.use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return HttpResp(code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun throwRuntimeError(code: Int, text: String) {
        val msg = try {
            JSONObject(text).getJSONObject("error").getString("message")
        } catch (_: Exception) {
            text
        }
        throw RuntimeException("HTTP $code: ${msg.take(200)}")
    }
}
