package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Gemini AI client for Nova v6.
 * - Uses valid fast model `gemini-2.5-flash` by default.
 * - Supports Smart Command Interpretation, Multi-Turn Context Chat, Study Assistant,
 *   Translation/Grammar/Summarization, and Accessibility Agent steps.
 * - All responses are cleanly formatted for Roman Hinglish / English voice playback.
 */
object GeminiClient {

    const val DEFAULT_MODEL = "gemini-2.5-flash"

    private data class ChatTurn(val role: String, val text: String)
    private val chatHistory = ArrayList<ChatTurn>()

    fun clearChatHistory() {
        synchronized(chatHistory) { chatHistory.clear() }
    }

    private fun commandPrompt(labels: List<String>): String = """
You convert ONE Indian user's voice command (English, Hindi, or Hinglish) into ONE JSON object.
ALWAYS write query, contact, body, and reply in clean Roman Hinglish or English (NEVER Devanagari Hindi script).
Fix obvious voice-recognition errors (e.g. "mr beast" -> "MrBeast", "rob locks" -> "Roblox").

Schema:
{"action":"open|search|play|roblox|call|message|reply|nearby|reminder|music|phone_info|weather|briefing|translate|study|clipboard|memory_save|emergency|chat|agent|unknown","app":"","query":"","contact":"","body":"","sms":false,"goal":"","minutes":0}

Rules:
- open: open an installed app.
- search: search inside an app (or empty app = Google search).
- play: play music/video (empty app = music app or YouTube).
- roblox: search/launch a Roblox game (query = game name).
- call: phone call (contact = name or digits).
- message: send WhatsApp/SMS (contact = person, body = clean Roman Hinglish text, sms = true only if SMS requested).
- reply: reply to latest WhatsApp/chat notification (body = clean Roman Hinglish reply).
- nearby: nearest petrol pump/hospital/atm/railway station/medical store/restaurant (query = place type).
- reminder: set reminder/alarm (body = task, minutes = minutes from now if mentioned).
- music: pause, resume, next, previous, volume_up, volume_down, mute (query = control keyword).
- phone_info: battery, wifi, bluetooth, storage, internet, screen_time (query = topic).
- weather / briefing: current weather or daily briefing.
- translate / study / chat: if the user asks a general question, maths/science explanation, quiz, or translation.
- agent: multi-step UI tapping inside an app (goal = clear English instruction including app name).
- "app" MUST be copied EXACTLY from this installed app list, or be empty: ${labels.joinToString(", ")}
Output ONLY valid JSON.
""".trimIndent()

    private val AGENT_PROMPT = """
You control an Android phone through its accessibility tree to finish ONE goal for the user.
Reply with ONE JSON object: {"action":"click|type|scroll_down|scroll_up|enter|back|home|wait|done|fail","index":-1,"text":"","reason":"short, in Hinglish"}
Rules:
- click: index = element to tap. type: index = editable element (or -1 for first editable), text = text to type in Roman Hinglish/English.
- Never enter passwords, OTPs, bank or UPI details. Never confirm payments, transfers, purchases, or deletions -> use "fail".
- Send messages only with exact text in the goal.
Output ONLY the JSON object.
""".trimIndent()

    private fun chatSystemPrompt(context: Context): String {
        val langPref = Prefs.replyLanguage(context)
        val langRule = when (langPref) {
            "english" -> "Reply in clear, concise Indian English."
            "hindi" -> "Reply in natural spoken Hinglish (Roman script, easy to read and speak aloud)."
            else -> "Reply in natural, friendly Roman Hinglish (no Devanagari script, no markdown symbols like ** or ##)."
        }
        val mem = SmartMemory.memorySummaryForPrompt(context)
        return """
You are Nova, a fast, helpful, warm personal AI voice assistant on an Android phone in India.
$langRule
Keep answers concise (2 to 4 short sentences) unless the user asks for a detailed explanation, study notes, or practice quiz.
Do NOT use markdown stars, hashtags, or bullet symbols because your reply is read aloud by Text-to-Speech.
$mem
""".trimIndent()
    }

    /** Interprets ambiguous voice commands into structured Command objects. */
    fun interpret(key: String, model: String, text: String, apps: List<AppInfo>): Command? {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", commandPrompt(apps.map { it.label })))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject().put("temperature", 0.0).put("responseMimeType", "application/json"))

        val j = extractJson(postWithRetry(key, model, body)) ?: return null

        val appKey = Normalizer.key(j.optString("app"))
        val app = if (appKey.isEmpty()) null else apps.firstOrNull { it.key == appKey }
        val query = HinglishConverter.toHinglish(j.optString("query").trim())
        val contact = HinglishConverter.toHinglish(j.optString("contact").trim())
        val contactKey = Normalizer.key(contact)
        val msgBody = HinglishConverter.toHinglish(j.optString("body").trim())
        val goal = j.optString("goal").trim()
        val minutes = j.optInt("minutes", 0)

        return when (j.optString("action").lowercase()) {
            "open" -> Command(Kind.OPEN, app, query, text)
            "search" -> Command(Kind.SEARCH, app, query, text)
            "play" -> Command(Kind.PLAY, app, query, text)
            "roblox" -> Command(Kind.ROBLOX, app, query, text)
            "call" -> Command(Kind.CALL, null, "", text, contact = contact, contactKey = contactKey)
            "message" -> Command(Kind.MESSAGE, app, "", text, contact = contact, contactKey = contactKey, body = msgBody, sms = j.optBoolean("sms", false))
            "reply" -> Command(Kind.REPLY, null, "", text, contact = contact, contactKey = contactKey, body = msgBody)
            "nearby" -> Command(Kind.NEARBY, null, query.ifEmpty { text }, text)
            "reminder" -> Command(Kind.REMINDER, null, "", text, body = msgBody.ifEmpty { query }, extraMinutes = minutes)
            "music" -> Command(Kind.MUSIC_CONTROL, app, query, text)
            "phone_info" -> Command(Kind.PHONE_INFO, null, query.ifEmpty { "all" }, text)
            "weather" -> Command(Kind.WEATHER, null, "", text)
            "briefing" -> Command(Kind.DAILY_BRIEFING, null, "", text)
            "translate" -> Command(Kind.TRANSLATE, null, query.ifEmpty { text }, text)
            "study" -> Command(Kind.STUDY, null, query.ifEmpty { text }, text)
            "clipboard" -> Command(Kind.CLIPBOARD, null, query.ifEmpty { "read" }, text)
            "memory_save" -> Command(Kind.MEMORY_SAVE, null, "", text, body = msgBody.ifEmpty { query })
            "emergency" -> Command(Kind.EMERGENCY, null, query, text)
            "agent" -> Command(Kind.AGENT, null, "", text, body = goal)
            "chat" -> Command(Kind.CHAT, null, text, text)
            else -> Command(Kind.CHAT, null, text, text)
        }
    }

    /** Context-aware conversational response (General Q&A, Study, Translation, Clipboard). */
    fun ask(context: Context, userMessage: String, keepContext: Boolean = true): String {
        val key = Prefs.geminiKey(context)
        if (key.isEmpty()) {
            return "Iske liye Gemini API key chahiye. Nova ke Settings tab me apni Gemini key save karo."
        }
        if (!PhoneInfoHelper.isOnline(context)) {
            return "Internet connected nahi hai. Internet ON karke dobara pucho."
        }

        val contents = JSONArray()
        synchronized(chatHistory) {
            if (keepContext) {
                chatHistory.takeLast(8).forEach { turn ->
                    contents.put(
                        JSONObject()
                            .put("role", turn.role)
                            .put("parts", JSONArray().put(JSONObject().put("text", turn.text)))
                    )
                }
            }
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
        )

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", chatSystemPrompt(context)))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.5).put("maxOutputTokens", 400))

        return try {
            val raw = postWithRetry(key, Prefs.geminiModel(context), body)
            val reply = extractText(raw)
                .replace("**", "")
                .replace("##", "")
                .replace("`", "")
                .trim()
            if (reply.isBlank()) {
                "Gemini se jawab khali aaya. Dobara try karo."
            } else {
                if (keepContext) {
                    synchronized(chatHistory) {
                        chatHistory.add(ChatTurn("user", userMessage))
                        chatHistory.add(ChatTurn("model", reply))
                        while (chatHistory.size > 12) chatHistory.removeAt(0)
                    }
                }
                reply
            }
        } catch (_: UnknownHostException) {
            "Internet connection nahi mil raha. Network check karo."
        } catch (_: SocketTimeoutException) {
            "Gemini response me zyada samay lag gaya. Dobara try karo."
        } catch (e: Exception) {
            "Gemini error: ${e.message?.take(120) ?: "unknown"}"
        }
    }

    /** One step of the Accessibility UI Agent. */
    fun agentStep(key: String, model: String, goal: String, history: List<String>, screen: String): JSONObject? {
        val user = buildString {
            append("Goal: ").append(goal).append("\n\nPrevious steps:\n")
            if (history.isEmpty()) append("(none)\n")
            else history.takeLast(8).forEach { append("- ").append(it).append('\n') }
            append("\nCurrent screen:\n").append(screen)
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", AGENT_PROMPT))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
            .put("generationConfig", JSONObject().put("temperature", 0.0).put("responseMimeType", "application/json"))
        return extractJson(postWithRetry(key, model, body))
    }

    fun test(key: String, model: String): String = try {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "Reply with just OK")))))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 10))
        val text = extractText(postWithRetry(key, model, body))
        if (text.isNotBlank()) "Connected! Gemini ($model) theek kaam kar raha hai."
        else "Gemini connected hai par empty response mila."
    } catch (_: UnknownHostException) {
        "Internet band hai. Network check karo."
    } catch (e: Exception) {
        "Gemini error: ${e.message?.take(140)}"
    }

    private fun extractText(response: String): String {
        val candidates = JSONObject(response).optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text", ""))
        }
        return sb.toString().trim()
    }

    private fun extractJson(response: String): JSONObject? {
        val answer = extractText(response)
        val start = answer.indexOf('{')
        val end = answer.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return JSONObject(answer.substring(start, end + 1))
    }

    private fun postWithRetry(key: String, model: String, body: JSONObject): String {
        var lastError: Exception? = null
        for (attempt in 0..1) {
            try {
                return post(key, model, body)
            } catch (e: Exception) {
                lastError = e
                val retryable = e is SocketTimeoutException || e.message?.contains("429") == true || e.message?.contains("503") == true
                if (attempt == 1 || !retryable) throw e
                Thread.sleep(2500)
            }
        }
        throw lastError ?: RuntimeException("Request failed")
    }

    private fun post(key: String, model: String, body: JSONObject): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(text).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    text
                }
                throw RuntimeException("HTTP $code: ${msg.take(160)}")
            }
            return text
        } finally {
            conn.disconnect()
        }
    }
}
