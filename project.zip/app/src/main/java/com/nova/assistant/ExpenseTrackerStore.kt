package com.nova.assistant

import android.content.Context
import java.util.Calendar
import java.util.Locale

/**
 * Bonus Powerhouse Feature: Offline Indian INR Voice Expense Tracker.
 * Examples:
 *   - "250 rupaye kharch kiye chai nashta par"
 *   - "Spent 1200 on petrol"
 *   - "Aaj kitna kharch hua"
 *   - "Is mahine ka kharcha batao"
 */
object ExpenseTrackerStore {

    data class ParsedExpense(val amount: Double, val category: String, val note: String)

    fun parseExpense(raw: String): ParsedExpense? {
        val clean = HinglishConverter.toHinglish(raw).trim()
        val lower = clean.lowercase(Locale.ROOT)
        val hasSpendCue = Regex("\\b(kharch|kharcha|spent|spend|expense|paid|diye|lagaye|rs|rupaye|rupees|inr)\\b")
            .containsMatchIn(lower)
        if (!hasSpendCue) return null

        val amtMatch = Regex("(?:rs\\.?|inr|₹)?\\s*(\\d+(?:\\.\\d{1,2})?)\\s*(?:rs\\.?|rupaye|rupees|inr)?").find(lower)
            ?: return null
        val amount = amtMatch.groupValues[1].toDoubleOrNull() ?: return null
        if (amount <= 0.0 || amount > 10_000_000.0) return null

        val note = clean
            .replace(Regex("(?i)\\b(nova|maine|i|spent|spend|paid|kharch|kharcha|kiye|kiya|hua|rs\\.?|rupaye|rupees|inr|par|pe|on|for|me|mein|add|expense|log)\\b"), " ")
            .replace(Regex("\\b\\d+(?:\\.\\d{1,2})?\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifEmpty { "General expense" }

        val cat = inferExpenseCategory(note)
        return ParsedExpense(amount, cat, note)
    }

    fun inferExpenseCategory(note: String): String {
        val l = note.lowercase(Locale.ROOT)
        return when {
            l.contains("chai") || l.contains("nashta") || l.contains("food") || l.contains("khana") || l.contains("lunch") || l.contains("dinner") || l.contains("snack") || l.contains("maggi") || l.contains("paneer") -> "Food"
            l.contains("petrol") || l.contains("diesel") || l.contains("auto") || l.contains("bus") || l.contains("train") || l.contains("ticket") || l.contains("cab") -> "Travel"
            l.contains("book") || l.contains("copy") || l.contains("pen") || l.contains("fees") || l.contains("exam") || l.contains("coaching") -> "Study"
            l.contains("recharge") || l.contains("bill") || l.contains("wifi") || l.contains("electricity") || l.contains("rent") -> "Bills"
            l.contains("cloth") || l.contains("shoes") || l.contains("amazon") || l.contains("flipkart") || l.contains("shopping") -> "Shopping"
            else -> "General"
        }
    }

    fun handleVoice(context: Context, op: String, raw: String): String {
        val db = NovaMemoryDb.get(context)
        return when (op) {
            "clear" -> {
                db.clearExpenses()
                "Saara expense record clear kar diya hai."
            }
            "summary_today" -> buildSummary(db.getExpensesSince(startOfDayMs()), "Aaj")
            "summary_month" -> buildSummary(db.getExpensesSince(startOfMonthMs()), "Is mahine")
            else -> {
                val parsed = parseExpense(raw) ?: return "Amount clear nahi hua. Bolo jaise: '250 rupaye kharch kiye chai nashta par'."
                db.insertExpense(parsed.amount, parsed.category, parsed.note)
                val amtStr = fmtAmount(parsed.amount)
                val todayTotal = db.getExpensesSince(startOfDayMs()).sumOf { it.amount }
                "Rs $amtStr (${parsed.category}: ${parsed.note}) record kar liya. Aaj ka total kharcha: Rs ${fmtAmount(todayTotal)}."
            }
        }
    }

    fun quickDashboardSummary(context: Context): String {
        val db = NovaMemoryDb.get(context)
        val today = db.getExpensesSince(startOfDayMs()).sumOf { it.amount }
        val month = db.getExpensesSince(startOfMonthMs()).sumOf { it.amount }
        return "Today: Rs ${fmtAmount(today)} | This Month: Rs ${fmtAmount(month)}"
    }

    private fun buildSummary(items: List<ExpenseRecord>, periodLabel: String): String {
        if (items.isEmpty()) return "$periodLabel koi kharcha record nahi hua hai."
        val total = items.sumOf { it.amount }
        val byCat = items.groupBy { it.category }.entries
            .sortedByDescending { e -> e.value.sumOf { it.amount } }
            .take(4)
            .joinToString(", ") { (c, list) -> "$c Rs ${fmtAmount(list.sumOf { it.amount })}" }
        return "$periodLabel total kharcha Rs ${fmtAmount(total)} (${items.size} entries). Breakdown: $byCat."
    }

    private fun startOfDayMs(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun startOfMonthMs(): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun fmtAmount(v: Double): String =
        if (v % 1.0 == 0.0) v.toLong().toString() else String.format(Locale.US, "%.2f", v)
}
