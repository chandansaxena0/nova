package com.nova.assistant

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

enum class ListenMode {
    STOPPED,
    LOADING_MODEL,
    WAKE_LISTENING,
    COMMAND_LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR_RECOVERING
}

/** Lightweight observable state bus connecting ListenService and MainActivity dashboard. */
object NovaState {
    @Volatile var mode: ListenMode = ListenMode.STOPPED
    @Volatile var statusMessage: String = "Band hai"
    @Volatile var lastHeard: String = ""
    @Volatile var lastReply: String = ""
    @Volatile var sessionRemainingSec: Int = 0
    @Volatile var micActive: Boolean = false
    @Volatile var modelProgress: Int = -1 // -1 = not downloading, 0..100 = downloading

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<() -> Unit>()

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun update(
        mode: ListenMode = this.mode,
        status: String = this.statusMessage,
        heard: String = this.lastHeard,
        reply: String = this.lastReply,
        remainingSec: Int = this.sessionRemainingSec,
        micActive: Boolean = this.micActive,
        modelProgress: Int = this.modelProgress
    ) {
        this.mode = mode
        this.statusMessage = status
        this.lastHeard = heard
        this.lastReply = reply
        this.sessionRemainingSec = remainingSec
        this.micActive = micActive
        this.modelProgress = modelProgress
        main.post {
            listeners.forEach {
                try { it() } catch (_: Exception) {}
            }
        }
    }
}
