package com.nova.assistant

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

enum class ListenMode {
    STOPPED,
    LOADING_MODEL,
    WAKE_LISTENING,
    COMMAND_LISTENING,
    PROCESSING,
    SPEAKING,
    MIC_CONFLICT,
    ERROR_RECOVERING
}

/** Lightweight observable state bus connecting ListenService, Agents, and MainActivity dashboard. */
object NovaState {
    @Volatile var mode: ListenMode = ListenMode.STOPPED
    @Volatile var statusMessage: String = "Stopped"
    @Volatile var lastHeard: String = ""
    @Volatile var lastReply: String = ""
    @Volatile var activeAgent: String = "Main Assistant"
    @Volatile var sessionRemainingSec: Int = 0
    @Volatile var micActive: Boolean = false
    @Volatile var modelProgress: Int = -1
    @Volatile var neuralWakeReady: Boolean = false
    @Volatile var multiPhraseWakeReady: Boolean = false
    @Volatile var lastWakePhrase: String = ""
    @Volatile var lastErrorReason: String = ""
    @Volatile var serviceStartedAtMs: Long = 0L
    @Volatile var batteryAtStartPct: Int = -1
    @Volatile var wakeTriggerCount: Int = 0
    @Volatile var falseTriggersBlockedCount: Int = 0
    @Volatile var noiseFloorRms: Int = 0

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<() -> Unit>()

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun update(
        mode: ListenMode = this.mode,
        status: String = this.statusMessage,
        heard: String = this.lastHeard,
        reply: String = this.lastReply,
        activeAgent: String = this.activeAgent,
        remainingSec: Int = this.sessionRemainingSec,
        micActive: Boolean = this.micActive,
        modelProgress: Int = this.modelProgress,
        lastErrorReason: String = this.lastErrorReason
    ) {
        this.mode = mode
        this.statusMessage = status
        this.lastHeard = heard
        this.lastReply = reply
        this.activeAgent = activeAgent
        this.sessionRemainingSec = remainingSec
        this.micActive = micActive
        this.modelProgress = modelProgress
        this.lastErrorReason = lastErrorReason
        main.post {
            listeners.forEach {
                try { it() } catch (_: Exception) {}
            }
        }
    }
}
