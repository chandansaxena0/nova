package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * Accessibility helper for user-requested UI tasks:
 * - Play the first YouTube search result video
 * - Tap Send in WhatsApp ONLY after explicit user confirmation
 * - Optional Gemini screen agent with strict payment/password safety blocks
 */
class NovaAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NovaAccessibility? = null

        private val blockedGoal = Regex(
            "\\b(upi|paytm|phonepe|gpay|google pay|bank|payment|transfer|password|otp|paise|recharge|purchase|buy|delete account)\\b"
        )
        private val payApps = listOf("paytm", "phonepe", "paisa", "bhim", "bank", "upi", "razorpay")
    }

    private class Snap(val pkg: String, val text: String, val nodes: List<AccessibilityNodeInfo>)

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var agentRunning = false
    @Volatile private var agentStop = false
    private var volDownLongPressFired = false
    private val volDownLongPressRunnable = Runnable {
        volDownLongPressFired = true
        if (!Prefs.privacyPaused(this@NovaAccessibility)) {
            runCatching {
                ContextCompat.startForegroundService(
                    this@NovaAccessibility,
                    Intent(this@NovaAccessibility, ListenService::class.java)
                        .setAction(ListenService.ACTION_INTERRUPT_AND_LISTEN)
                )
            }.onFailure {
                runCatching {
                    startActivity(Intent(this@NovaAccessibility, AssistActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!Prefs.volumeTriggerEnabled(this) || Prefs.privacyPaused(this)) {
            return super.onKeyEvent(event)
        }
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            when (event.action) {
                KeyEvent.ACTION_DOWN -> {
                    if (event.repeatCount == 0) {
                        volDownLongPressFired = false
                        main.removeCallbacks(volDownLongPressRunnable)
                        main.postDelayed(volDownLongPressRunnable, 580L)
                    }
                    // Allow normal short press volume change unless long-press already fired
                    return volDownLongPressFired
                }
                KeyEvent.ACTION_UP -> {
                    main.removeCallbacks(volDownLongPressRunnable)
                    val consumed = volDownLongPressFired
                    volDownLongPressFired = false
                    return consumed
                }
            }
        }
        return super.onKeyEvent(event)
    }

    private fun say(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    fun playFirstYoutubeVideo() {
        pollClick(14000, 2200, { root ->
            val pkg = root.packageName?.toString() ?: ""
            if (pkg != "com.google.android.youtube") return@pollClick null
            findNode(root) { n ->
                val d = n.contentDescription?.toString()?.lowercase().orEmpty()
                d.contains("play video") || (d.contains("minute") && d.contains("views") && n.isClickable)
            }
        }) { ok ->
            if (!ok) say("YouTube results khul gaye hain, pasand ka video tap kar lo.")
        }
    }

    fun sendWhatsApp() {
        pollClick(12000, 2200, { root ->
            val pkg = root.packageName?.toString() ?: ""
            if (!pkg.startsWith("com.whatsapp")) null
            else {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/send")?.firstOrNull()
                    ?: findNode(root) { it.contentDescription?.toString()?.equals("send", true) == true }
            }
        }) { ok ->
            if (!ok) say("Message type ho gaya hai, Send button tap kar do.")
        }
    }

    private fun pollClick(
        timeoutMs: Long,
        startDelay: Long,
        finder: (AccessibilityNodeInfo) -> AccessibilityNodeInfo?,
        onResult: (Boolean) -> Unit = {}
    ) {
        val t0 = System.currentTimeMillis()
        val r = object : Runnable {
            override fun run() {
                val root = rootInActiveWindow
                val hit = if (root != null) finder(root) else null
                if (hit != null) {
                    onResult(click(hit))
                    return
                }
                if (System.currentTimeMillis() - t0 > timeoutMs) {
                    onResult(false)
                    return
                }
                main.postDelayed(this, 650)
            }
        }
        main.postDelayed(r, startDelay)
    }

    /** Returns a privacy-filtered readable snapshot of visible UI elements (skips password fields). */
    fun captureReadableScreen(): String? = snapshot()?.text

    fun stopAgent() {
        agentStop = true
    }

    fun startAgent(goal: String, key: String, model: String) {
        if (agentRunning) {
            say("Pehla kaam abhi chal raha hai.")
            return
        }
        if (blockedGoal.containsMatchIn(goal.lowercase())) {
            say("Paise, bank, password jaise kaam Nova nahi karta.")
            return
        }
        agentRunning = true
        agentStop = false

        thread {
            val history = ArrayList<String>()
            var outcome = "Kaam poora nahi hua."
            try {
                loop@ for (step in 1..12) {
                    if (agentStop) {
                        outcome = "Agent rok diya."
                        break@loop
                    }
                    Thread.sleep(1800)

                    val snap = snapshot() ?: continue@loop
                    if (payApps.any { snap.pkg.contains(it) }) {
                        outcome = "Payment screen aa gayi, safety ke liye ruk gaya."
                        break@loop
                    }
                    val answer = GeminiClient.agentStep(key, model, goal, history, snap.text, Prefs.aiProvider(this@NovaAccessibility)) ?: continue@loop
                    val action = answer.optString("action").lowercase()
                    val reason = answer.optString("reason")
                    val idx = answer.optInt("index", -1)
                    val text = HinglishConverter.toHinglish(answer.optString("text"))
                    history.add("step $step: $action [$idx]")

                    when (action) {
                        "click" -> snap.nodes.getOrNull(idx)?.let { click(it) }
                        "type" -> {
                            val n = if (idx >= 0) snap.nodes.getOrNull(idx) else snap.nodes.firstOrNull { it.isEditable }
                            if (n != null) {
                                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                                val b = Bundle()
                                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                                n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                            }
                        }
                        "scroll_down" -> snap.nodes.firstOrNull { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                        "scroll_up" -> snap.nodes.firstOrNull { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                        "enter" -> if (Build.VERSION.SDK_INT >= 30) {
                            val n = snap.nodes.firstOrNull { it.isEditable && it.isFocused } ?: snap.nodes.firstOrNull { it.isEditable }
                            n?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                        }
                        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                        "done" -> { outcome = "Ho gaya. $reason"; break@loop }
                        "fail" -> { outcome = "Nahi ho paya: $reason"; break@loop }
                    }
                }
            } catch (e: Exception) {
                outcome = "Error: ${e.message}"
            }
            agentRunning = false
            say(outcome)
        }
    }

    private fun snapshot(): Snap? {
        val root = rootInActiveWindow ?: return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()

        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 85 || !n.isVisibleToUser) return
            val text = n.text?.toString()?.take(60)
            val desc = n.contentDescription?.toString()?.take(60)
            val id = n.viewIdResourceName?.substringAfter(":id/")
            val useful = n.isClickable || n.isEditable || n.isScrollable || !text.isNullOrBlank() || !desc.isNullOrBlank()
            if (useful && !n.isPassword) {
                sb.append('[').append(nodes.size).append("] ")
                    .append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                if (!text.isNullOrBlank()) sb.append(" text=\"").append(text).append('"')
                if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc).append('"')
                if (!id.isNullOrBlank()) sb.append(" id=").append(id)
                if (n.isClickable) sb.append(" clickable")
                if (n.isEditable) sb.append(" editable")
                if (n.isScrollable) sb.append(" scrollable")
                sb.append('\n')
                nodes.add(n)
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }

        walk(root)
        return Snap(root.packageName?.toString() ?: "", "app=${root.packageName}\n$sb", nodes)
    }

    private fun findNode(root: AccessibilityNodeInfo, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (match(root)) return root
        for (i in 0 until root.childCount) {
            val c = root.getChild(i) ?: continue
            val f = findNode(c, match)
            if (f != null) return f
        }
        return null
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return if (r.width() > 0 && r.height() > 0) tap(r.exactCenterX(), r.exactCenterY()) else false
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    // ---- Nova v8.0 Ultimate Hands-Free System & Screen Control ----
    fun performBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun performQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    fun performScreenshot(): Boolean =
        if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) else false

    fun performLockScreen(): Boolean =
        if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false

    fun scrollScreen(down: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findNode(root) { it.isScrollable }
        if (scrollable != null) {
            val act = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (scrollable.performAction(act)) return true
        }
        val dm = resources.displayMetrics
        val cx = dm.widthPixels * 0.5f
        val y1 = dm.heightPixels * (if (down) 0.72f else 0.28f)
        val y2 = dm.heightPixels * (if (down) 0.28f else 0.72f)
        val p = Path().apply { moveTo(cx, y1); lineTo(cx, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 260))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun clickByText(query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return false
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString()?.lowercase().orEmpty()
        if (payApps.any { pkg.contains(it) }) return false
        val exact = findNode(root) { n ->
            val t = n.text?.toString()?.trim()?.lowercase().orEmpty()
            val d = n.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
            (t == q || d == q) && !n.isPassword
        }
        val fuzzy = exact ?: findNode(root) { n ->
            val t = n.text?.toString()?.trim()?.lowercase().orEmpty()
            val d = n.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
            (t.contains(q) || d.contains(q)) && !n.isPassword
        }
        return if (fuzzy != null) click(fuzzy) else false
    }

    fun typeIntoFocused(textToType: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString()?.lowercase().orEmpty()
        if (payApps.any { pkg.contains(it) }) return false
        val target = findNode(root) { it.isEditable && it.isFocused && !it.isPassword }
            ?: findNode(root) { it.isEditable && !it.isPassword }
            ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }


    fun performPowerDialog(): Boolean = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)

    /**
     * Hands-free Quick Settings Tile toggle for Android 10-16 (OriginOS, FuntouchOS, MIUI, OneUI, AOSP):
     *   1) Opens Quick Settings shade
     *   2) Searches page 1 (and swipes to page 2 if not found) for any matching tile alias
     *   3) Inspects current ON/OFF state (checked/selected/stateDescription/subtitle)
     *   4) Toggles ONLY if needed, supports Android 12+ combined "Internet" panel for Wi-Fi / Mobile Data,
     *      and closes the shade cleanly back to the user's app.
     */
    fun toggleQuickSettingTile(
        aliases: List<String>,
        label: String,
        desiredOn: Boolean?,
        tryInternetSubmenu: Boolean = false
    ): String {
        return try {
            performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            Thread.sleep(620)

            var tile = findTileInCurrentWindow(aliases)
            if (tile == null) {
                swipeQuickSettingsNextPage()
                Thread.sleep(480)
                tile = findTileInCurrentWindow(aliases)
            }

            // Android 12+ combined "Internet" tile fallback for Wi-Fi / Mobile Data
            if (tile == null && tryInternetSubmenu) {
                val internetTile = findTileInCurrentWindow(listOf("internet"))
                if (internetTile != null) {
                    click(internetTile)
                    Thread.sleep(580)
                    val subTarget = findTileInCurrentWindow(aliases)
                    if (subTarget != null) {
                        val res = applyTileDesiredState(subTarget, label, desiredOn)
                        Thread.sleep(320)
                        closeShadeCleanly()
                        return res
                    }
                }
            }

            if (tile == null) {
                closeShadeCleanly()
                return "Quick Settings me $label tile nahi mila. Quick Settings edit karke $label tile upar pin kar lo."
            }

            val result = applyTileDesiredState(tile, label, desiredOn)
            Thread.sleep(360)
            closeShadeCleanly()
            result
        } catch (e: Exception) {
            runCatching { closeShadeCleanly() }
            "$label toggle nahi ho paya: ${e.message?.take(60)}"
        }
    }

    private fun applyTileDesiredState(tile: AccessibilityNodeInfo, label: String, desiredOn: Boolean?): String {
        val currentOn = detectTileOnState(tile)
        if (desiredOn != null && currentOn != null && currentOn == desiredOn) {
            return "$label pehle se ${if (desiredOn) "ON" else "OFF"} hai."
        }
        val clicked = click(tile)
        if (!clicked) return "$label par tap nahi ho paya."
        return when (desiredOn) {
            true -> "$label ON kar diya hai."
            false -> "$label OFF kar diya hai."
            null -> "$label toggle kar diya hai."
        }
    }

    private fun detectTileOnState(node: AccessibilityNodeInfo): Boolean? {
        if (node.isCheckable) return node.isChecked
        val stateDesc = if (Build.VERSION.SDK_INT >= 30) {
            node.stateDescription?.toString()?.lowercase().orEmpty()
        } else ""
        val combined = buildString {
            append(stateDesc).append(' ')
            append(node.contentDescription?.toString()?.lowercase().orEmpty()).append(' ')
            append(collectNodeTexts(node))
        }
        if (Regex("\\b(not activated|turned off|disabled|disconnected|unavailable|off)\\b").containsMatchIn(combined)) {
            return false
        }
        if (Regex("\\b(activated|turned on|enabled|connected|active|on)\\b").containsMatchIn(combined)) {
            return true
        }
        if (node.isSelected) return true
        return null
    }

    private fun collectNodeTexts(n: AccessibilityNodeInfo, depth: Int = 0): String {
        if (depth > 3) return ""
        val sb = StringBuilder()
        n.text?.toString()?.let { sb.append(it.lowercase()).append(' ') }
        n.contentDescription?.toString()?.let { sb.append(it.lowercase()).append(' ') }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            sb.append(collectNodeTexts(c, depth + 1))
        }
        return sb.toString()
    }

    private fun findTileInCurrentWindow(aliases: List<String>): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val lowerAliases = aliases.map { it.lowercase() }
        // First pass: clickable tile whose own text/desc matches
        val exact = findNode(root) { n ->
            if (!n.isVisibleToUser || n.isPassword) return@findNode false
            val t = n.text?.toString()?.trim()?.lowercase().orEmpty()
            val d = n.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
            lowerAliases.any { a -> t == a || d == a || d.startsWith("$a,") || d.startsWith("$a ") || t.startsWith("$a ") }
        }
        if (exact != null) return exact
        // Second pass: substring match
        return findNode(root) { n ->
            if (!n.isVisibleToUser || n.isPassword) return@findNode false
            val t = n.text?.toString()?.trim()?.lowercase().orEmpty()
            val d = n.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
            lowerAliases.any { a -> t.contains(a) || d.contains(a) }
        }
    }

    private fun swipeQuickSettingsNextPage() {
        val dm = resources.displayMetrics
        val y = dm.heightPixels * 0.28f
        val x1 = dm.widthPixels * 0.84f
        val x2 = dm.widthPixels * 0.16f
        val p = Path().apply { moveTo(x1, y); lineTo(x2, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 260))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun closeShadeCleanly() {
        performGlobalAction(GLOBAL_ACTION_BACK)
        Thread.sleep(220)
        val pkg = rootInActiveWindow?.packageName?.toString().orEmpty()
        if (pkg.contains("systemui")) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

}
