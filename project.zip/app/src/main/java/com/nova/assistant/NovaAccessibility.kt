package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * Accessibility helper for user-requested UI tasks:
 * - Play the first YouTube search result video
 * - Tap Send in WhatsApp ONLY after explicit user confirmation
 * - Optional Gemini screen agent with strict payment/password safety blocks
 */
class NovaAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NovaAccessibility? = null

        private val blockedGoal = Regex(
            "\\b(upi|paytm|phonepe|gpay|google pay|bank|payment|transfer|password|otp|paise|recharge|purchase|buy|delete account)\\b"
        )
        private val payApps = listOf("paytm", "phonepe", "paisa", "bhim", "bank", "upi", "razorpay")
    }

    private class Snap(val pkg: String, val text: String, val nodes: List<AccessibilityNodeInfo>)

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var agentRunning = false
    @Volatile private var agentStop = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun say(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    fun playFirstYoutubeVideo() {
        pollClick(14000, 2200, { root ->
            val pkg = root.packageName?.toString() ?: ""
            if (pkg != "com.google.android.youtube") return@pollClick null
            findNode(root) { n ->
                val d = n.contentDescription?.toString()?.lowercase().orEmpty()
                d.contains("play video") || (d.contains("minute") && d.contains("views") && n.isClickable)
            }
        }) { ok ->
            if (!ok) say("YouTube results khul gaye hain, pasand ka video tap kar lo.")
        }
    }

    fun sendWhatsApp() {
        pollClick(12000, 2200, { root ->
            val pkg = root.packageName?.toString() ?: ""
            if (!pkg.startsWith("com.whatsapp")) null
            else {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/send")?.firstOrNull()
                    ?: findNode(root) { it.contentDescription?.toString()?.equals("send", true) == true }
            }
        }) { ok ->
            if (!ok) say("Message type ho gaya hai, Send button tap kar do.")
        }
    }

    private fun pollClick(
        timeoutMs: Long,
        startDelay: Long,
        finder: (AccessibilityNodeInfo) -> AccessibilityNodeInfo?,
        onResult: (Boolean) -> Unit = {}
    ) {
        val t0 = System.currentTimeMillis()
        val r = object : Runnable {
            override fun run() {
                val root = rootInActiveWindow
                val hit = if (root != null) finder(root) else null
                if (hit != null) {
                    onResult(click(hit))
                    return
                }
                if (System.currentTimeMillis() - t0 > timeoutMs) {
                    onResult(false)
                    return
                }
                main.postDelayed(this, 650)
            }
        }
        main.postDelayed(r, startDelay)
    }

    fun stopAgent() {
        agentStop = true
    }

    fun startAgent(goal: String, key: String, model: String) {
        if (agentRunning) {
            say("Pehla kaam abhi chal raha hai.")
            return
        }
        if (blockedGoal.containsMatchIn(goal.lowercase())) {
            say("Paise, bank, password jaise kaam Nova nahi karta.")
            return
        }
        agentRunning = true
        agentStop = false

        thread {
            val history = ArrayList<String>()
            var outcome = "Kaam poora nahi hua."
            try {
                loop@ for (step in 1..12) {
                    if (agentStop) {
                        outcome = "Agent rok diya."
                        break@loop
                    }
                    Thread.sleep(1800)

                    val snap = snapshot() ?: continue@loop
                    if (payApps.any { snap.pkg.contains(it) }) {
                        outcome = "Payment screen aa gayi, safety ke liye ruk gaya."
                        break@loop
                    }
                    val answer = GeminiClient.agentStep(key, model, goal, history, snap.text) ?: continue@loop
                    val action = answer.optString("action").lowercase()
                    val reason = answer.optString("reason")
                    val idx = answer.optInt("index", -1)
                    val text = HinglishConverter.toHinglish(answer.optString("text"))
                    history.add("step $step: $action [$idx]")

                    when (action) {
                        "click" -> snap.nodes.getOrNull(idx)?.let { click(it) }
                        "type" -> {
                            val n = if (idx >= 0) snap.nodes.getOrNull(idx) else snap.nodes.firstOrNull { it.isEditable }
                            if (n != null) {
                                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                                val b = Bundle()
                                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                                n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                            }
                        }
                        "scroll_down" -> snap.nodes.firstOrNull { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                        "scroll_up" -> snap.nodes.firstOrNull { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                        "enter" -> if (Build.VERSION.SDK_INT >= 30) {
                            val n = snap.nodes.firstOrNull { it.isEditable && it.isFocused } ?: snap.nodes.firstOrNull { it.isEditable }
                            n?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                        }
                        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                        "done" -> { outcome = "Ho gaya. $reason"; break@loop }
                        "fail" -> { outcome = "Nahi ho paya: $reason"; break@loop }
                    }
                }
            } catch (e: Exception) {
                outcome = "Error: ${e.message}"
            }
            agentRunning = false
            say(outcome)
        }
    }

    private fun snapshot(): Snap? {
        val root = rootInActiveWindow ?: return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()

        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 85 || !n.isVisibleToUser) return
            val text = n.text?.toString()?.take(60)
            val desc = n.contentDescription?.toString()?.take(60)
            val id = n.viewIdResourceName?.substringAfter(":id/")
            val useful = n.isClickable || n.isEditable || n.isScrollable || !text.isNullOrBlank() || !desc.isNullOrBlank()
            if (useful && !n.isPassword) {
                sb.append('[').append(nodes.size).append("] ")
                    .append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                if (!text.isNullOrBlank()) sb.append(" text=\"").append(text).append('"')
                if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc).append('"')
                if (!id.isNullOrBlank()) sb.append(" id=").append(id)
                if (n.isClickable) sb.append(" clickable")
                if (n.isEditable) sb.append(" editable")
                if (n.isScrollable) sb.append(" scrollable")
                sb.append('\n')
                nodes.add(n)
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }

        walk(root)
        return Snap(root.packageName?.toString() ?: "", "app=${root.packageName}\n$sb", nodes)
    }

    private fun findNode(root: AccessibilityNodeInfo, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (match(root)) return root
        for (i in 0 until root.childCount) {
            val c = root.getChild(i) ?: continue
            val f = findNode(c, match)
            if (f != null) return f
        }
        return null
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return if (r.width() > 0 && r.height() > 0) tap(r.exactCenterX(), r.exactCenterY()) else false
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }
}
