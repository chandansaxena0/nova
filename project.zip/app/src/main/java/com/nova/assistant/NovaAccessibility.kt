package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * Lets Nova tap and type on the screen for you (only when YOU ask for a task):
 *  - press the first YouTube result
 *  - press Send in WhatsApp
 *  - the optional Gemini "agent" that does other tasks step by step
 */
class NovaAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NovaAccessibility? = null

        // The agent refuses money / security tasks.
        private val blockedGoal = Regex(
            "\\b(upi|paytm|phonepe|gpay|google pay|bank|payment|transfer|password|otp|paise|recharge|purchase|buy|delete account)\\b"
        )
        private val payApps = listOf("paytm", "phonepe", "paisa", "bhim", "bank", "upi", "razorpay")
    }

    private class Snap(val pkg: String, val text: String, val nodes: List<AccessibilityNodeInfo>)

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var agentRunning = false

    @Volatile
    private var agentStop = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private fun say(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    // ---------------------------------------------------------------- ready-made tasks

    /** After a YouTube search page opened: press the first video. */
    fun playFirstYoutubeVideo() {
        pollClick(15000, 2500, { root ->
            findNode(root) { n ->
                n.contentDescription?.toString()?.lowercase()?.contains("play video") == true
            }
        }) { ok -> if (!ok) say("Video nahi mila. Pehla result khud dabao.") }
    }

    /** After a WhatsApp chat opened with the text filled in: press Send. */
    fun sendWhatsApp() {
        pollClick(12000, 2500, { root ->
            val pkg = root.packageName?.toString() ?: ""
            if (!pkg.startsWith("com.whatsapp")) {
                null
            } else {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/send")?.firstOrNull()
                    ?: findNode(root) { it.contentDescription?.toString()?.equals("send", true) == true }
            }
        }) { ok -> if (!ok) say("Send button nahi mila. Khud Send dabao.") }
    }

    private fun pollClick(
        timeoutMs: Long,
        startDelay: Long,
        finder: (AccessibilityNodeInfo) -> AccessibilityNodeInfo?,
        onResult: (Boolean) -> Unit = {}
    ) {
        val t0 = System.currentTimeMillis()
        val r = object : Runnable {
            override fun run() {
                val root = rootInActiveWindow
                val hit = if (root != null) finder(root) else null
                if (hit != null) {
                    onResult(click(hit))
                    return
                }
                if (System.currentTimeMillis() - t0 > timeoutMs) {
                    onResult(false)
                    return
                }
                main.postDelayed(this, 700)
            }
        }
        main.postDelayed(r, startDelay)
    }

    // ---------------------------------------------------------------- the Gemini agent

    fun stopAgent() {
        agentStop = true
    }

    fun startAgent(goal: String, key: String, model: String) {
        if (agentRunning) {
            say("Pehla kaam abhi chal raha hai.")
            return
        }
        if (blockedGoal.containsMatchIn(goal.lowercase())) {
            say("Paise, bank, password jaise kaam Nova nahi karta.")
            return
        }
        agentRunning = true
        agentStop = false

        thread {
            val history = ArrayList<String>()
            var outcome = "Kaam poora nahi hua (steps khatam ho gaye)."
            var nodes: List<AccessibilityNodeInfo> = emptyList()
            try {
                loop@ for (step in 1..15) {
                    if (agentStop) {
                        outcome = "Rok diya."
                        break@loop
                    }
                    Thread.sleep(2000)

                    val snap = snapshot()
                    if (snap == null) {
                        history.add("screen nahi mili")
                        continue@loop
                    }
                    nodes = snap.nodes
                    if (payApps.any { snap.pkg.contains(it) }) {
                        outcome = "Payment wali screen aa gayi, isliye ruk gaya."
                        break@loop
                    }

                    val answer = GeminiClient.agentStep(key, model, goal, history, snap.text)
                    if (answer == null) {
                        history.add("jawab samajh nahi aaya")
                        continue@loop
                    }
                    val action = answer.optString("action").lowercase()
                    val reason = answer.optString("reason")
                    val idx = answer.optInt("index", -1)
                    val text = answer.optString("text")
                    history.add(
                        "step $step: $action" +
                            (if (idx >= 0) " [$idx]" else "") +
                            (if (text.isNotEmpty()) " \"$text\"" else "")
                    )

                    when (action) {
                        "click" -> {
                            val n = nodes.getOrNull(idx)
                            if (n == null || !click(n)) history.add("  (click nahi hua)")
                        }
                        "type" -> {
                            val n = if (idx >= 0) nodes.getOrNull(idx) else nodes.firstOrNull { it.isEditable }
                            if (n != null) {
                                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                                val b = Bundle()
                                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                                n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                            } else {
                                history.add("  (type ke liye box nahi mila)")
                            }
                        }
                        "scroll_down" ->
                            nodes.firstOrNull { it.isScrollable }
                                ?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                        "scroll_up" ->
                            nodes.firstOrNull { it.isScrollable }
                                ?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                        "enter" -> {
                            if (Build.VERSION.SDK_INT >= 30) {
                                val n = nodes.firstOrNull { it.isEditable && it.isFocused }
                                    ?: nodes.firstOrNull { it.isEditable }
                                n?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                            }
                        }
                        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                        "wait" -> {}
                        "done" -> {
                            outcome = "Ho gaya. $reason"
                            break@loop
                        }
                        "fail" -> {
                            outcome = "Nahi ho paya: $reason"
                            break@loop
                        }
                        else -> {}
                    }
                }
            } catch (e: Exception) {
                outcome = "Error: ${e.message}"
            }
            agentRunning = false
            say(outcome)
        }
    }

    /** The current screen as a short numbered list the AI can read. Password boxes are skipped. */
    private fun snapshot(): Snap? {
        val root = rootInActiveWindow ?: return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()

        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 90) return
            if (!n.isVisibleToUser) return
            val text = n.text?.toString()?.take(60)
            val desc = n.contentDescription?.toString()?.take(60)
            val id = n.viewIdResourceName?.substringAfter(":id/")
            val useful = n.isClickable || n.isEditable || n.isScrollable ||
                !text.isNullOrBlank() || !desc.isNullOrBlank()
            if (useful && !n.isPassword) {
                sb.append('[').append(nodes.size).append("] ")
                    .append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                if (!text.isNullOrBlank()) sb.append(" text=\"").append(text).append('"')
                if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc).append('"')
                if (!id.isNullOrBlank()) sb.append(" id=").append(id)
                if (n.isClickable) sb.append(" clickable")
                if (n.isEditable) sb.append(" editable")
                if (n.isScrollable) sb.append(" scrollable")
                sb.append('\n')
                nodes.add(n)
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c)
            }
        }

        walk(root)
        val pkg = root.packageName?.toString() ?: ""
        return Snap(pkg, "app=$pkg\n$sb", nodes)
    }

    // ---------------------------------------------------------------- helpers

    private fun findNode(
        root: AccessibilityNodeInfo,
        match: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (match(root)) return root
        for (i in 0 until root.childCount) {
            val c = root.getChild(i) ?: continue
            val f = findNode(c, match)
            if (f != null) return f
        }
        return null
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return if (r.width() > 0 && r.height() > 0) tap(r.exactCenterX(), r.exactCenterY()) else false
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }
}
