package com.nova.assistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Siri-style Neural Wake Word Engine running the openWakeWord ONNX pipeline on Android:
 *   16 kHz AudioRecord (80 ms / 1280 samples)
 *     -> melspectrogram.onnx  (x / 10 + 2)
 *     -> embedding_model.onnx (76 mel frames -> 96-dim speech embedding)
 *     -> hey_nova.onnx        (16 embeddings [1, 16, 96] -> wake probability 0..1)
 *
 * Uses the user's bundled `assets/wake/hey_nova.onnx` model.
 * Backbone models (`melspectrogram.onnx`, `embedding_model.onnx`) are loaded from
 * `assets/wake/` if bundled by CI, or auto-downloaded once (~2.5 MB) to `filesDir/wake_models/`.
 */
class OpenWakeWordEngine(
    private val context: Context,
    private val threshold: Float = 0.50f,
    private val onWakeDetected: (Float) -> Unit,
    private val onError: (String) -> Unit
) {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val FRAME_SAMPLES = 1280 // 80 ms
        private const val MEL_BINS = 32
        private const val MEL_WINDOW = 76
        private const val EMBED_DIM = 96
        private const val EMBED_WINDOW = 16
        private const val COOLDOWN_MS = 1800L

        private const val MEL_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.onnx"
        private const val EMBED_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.onnx"
    }

    private var env: OrtEnvironment? = null
    private var melSession: OrtSession? = null
    private var embedSession: OrtSession? = null
    private var wakeSession: OrtSession? = null

    private var melInputName = "input"
    private var embedInputName = "input_1"
    private var wakeInputName = "onnx::Flatten_0"

    private var audioRecord: AudioRecord? = null
    private var workerThread: Thread? = null
    private val running = AtomicBoolean(false)
    private var initialized = false
    private var lastTriggerMs = 0L

    /** Prepares ONNX sessions (call on background thread). */
    fun init(): Boolean {
        if (initialized) return true
        return try {
            val dir = File(context.filesDir, "wake_models").apply { mkdirs() }
            val heyFile = ensureModelFile(dir, "hey_nova.onnx", null)
            val melFile = ensureModelFile(dir, "melspectrogram.onnx", MEL_URL)
            val embedFile = ensureModelFile(dir, "embedding_model.onnx", EMBED_URL)

            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(2)
            }
            val ms = e.createSession(melFile.absolutePath, opts)
            val es = e.createSession(embedFile.absolutePath, opts)
            val ws = e.createSession(heyFile.absolutePath, opts)

            melInputName = ms.inputNames.firstOrNull() ?: melInputName
            embedInputName = es.inputNames.firstOrNull() ?: embedInputName
            wakeInputName = ws.inputNames.firstOrNull() ?: wakeInputName

            env = e
            melSession = ms
            embedSession = es
            wakeSession = ws
            initialized = true
            true
        } catch (ex: Exception) {
            onError("Neural wake init failed: ${ex.message}")
            false
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (!initialized || running.get()) return
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufBytes = maxOf(minBuf, FRAME_SAMPLES * 2 * 4)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufBytes
            )
        } catch (e: Exception) {
            onError("AudioRecord error: ${e.message}")
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            onError("Mic initialize nahi hua")
            return
        }

        audioRecord = rec
        running.set(true)
        workerThread = Thread({ runAudioLoop(rec) }, "nova-oww-thread").apply { start() }
    }

    fun stop() {
        running.set(false)
        try {
            audioRecord?.stop()
        } catch (_: Exception) {}
        try {
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
        try {
            workerThread?.join(400)
        } catch (_: Exception) {}
        workerThread = null
    }

    fun release() {
        stop()
        runCatching { melSession?.close() }
        runCatching { embedSession?.close() }
        runCatching { wakeSession?.close() }
        melSession = null
        embedSession = null
        wakeSession = null
        initialized = false
    }

    private fun runAudioLoop(rec: AudioRecord) {
        val pcm = ShortArray(FRAME_SAMPLES)
        val floatAudio = FloatArray(FRAME_SAMPLES)

        // Rolling buffers for melspectrogram frames (max ~120) and embeddings (16 x 96)
        val melBuffer = ArrayDeque<FloatArray>(128)
        val embedBuffer = ArrayDeque<FloatArray>(EMBED_WINDOW + 2)
        // Pre-fill 16 zero embeddings so wake classifier warms up cleanly
        repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }

        var framesSinceEmbed = 0
        // Anti false-trigger: the classifier must see 16 REAL embeddings (~1.3 s of audio) before
        // any score counts (zero-filled buffer made it fire right after every restart), and the
        // score must stay above the threshold for 2 frames in a row.
        var realEmbeds = 0
        var hits = 0

        try {
            rec.startRecording()
            while (running.get()) {
                var readTotal = 0
                while (readTotal < FRAME_SAMPLES && running.get()) {
                    val n = rec.read(pcm, readTotal, FRAME_SAMPLES - readTotal)
                    if (n > 0) readTotal += n
                    else if (n < 0) break
                }
                if (!running.get() || readTotal < FRAME_SAMPLES) continue

                for (i in 0 until FRAME_SAMPLES) {
                    floatAudio[i] = pcm[i].toFloat()
                }

                // 1) Melspectrogram step
                val newMels = runMel(floatAudio) ?: continue
                for (frame in newMels) {
                    melBuffer.addLast(frame)
                    if (melBuffer.size > 110) melBuffer.removeFirst()
                }
                framesSinceEmbed += newMels.size

                // 2) Embedding step every 8 mel frames (~80 ms) once we have 76 frames
                if (melBuffer.size >= MEL_WINDOW && framesSinceEmbed >= 8) {
                    framesSinceEmbed = 0
                    val emb = runEmbedding(melBuffer) ?: continue
                    embedBuffer.addLast(emb)
                    while (embedBuffer.size > EMBED_WINDOW) embedBuffer.removeFirst()
                    if (realEmbeds < EMBED_WINDOW) {
                        realEmbeds++
                        continue
                    }

                    // 3) Wake word classifier step (hey_nova.onnx)
                    val score = runWakeClassifier(embedBuffer)
                    if (score >= threshold) hits++ else hits = 0
                    if (hits >= 2) {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastTriggerMs >= COOLDOWN_MS) {
                            lastTriggerMs = now
                            // Reset rolling buffers so next session starts clean
                            melBuffer.clear()
                            embedBuffer.clear()
                            repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }
                            realEmbeds = 0
                            hits = 0
                            onWakeDetected(score)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            if (running.get()) onError("Wake audio loop error: ${e.message}")
        } finally {
            runCatching { rec.stop() }
        }
    }

    private fun runMel(audio: FloatArray): List<FloatArray>? {
        val e = env ?: return null
        val sess = melSession ?: return null
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(audio), longArrayOf(1L, audio.size.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(melInputName, tensor)).use { res ->
                    val out = res[0].value
                    val frames = ArrayList<FloatArray>(8)
                    // Typical output shape: [1, 1, T, 32]
                    @Suppress("UNCHECKED_CAST")
                    when (out) {
                        is Array<*> -> {
                            val d1 = out[0]
                            if (d1 is Array<*>) {
                                val d2 = d1[0]
                                if (d2 is Array<*>) {
                                    for (row in d2) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            val scaled = FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f }
                                            frames.add(scaled)
                                        }
                                    }
                                } else if (d2 is FloatArray && d2.size == MEL_BINS) {
                                    for (row in d1) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            val scaled = FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f }
                                            frames.add(scaled)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    frames
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runEmbedding(melBuffer: ArrayDeque<FloatArray>): FloatArray? {
        val e = env ?: return null
        val sess = embedSession ?: return null
        val flat = FloatArray(MEL_WINDOW * MEL_BINS)
        val start = melBuffer.size - MEL_WINDOW
        var idx = 0
        for (i in start until melBuffer.size) {
            val row = melBuffer[i]
            System.arraycopy(row, 0, flat, idx, MEL_BINS)
            idx += MEL_BINS
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, MEL_WINDOW.toLong(), MEL_BINS.toLong(), 1L)).use { tensor ->
                sess.run(Collections.singletonMap(embedInputName, tensor)).use { res ->
                    extractFlatFloats(res[0].value, EMBED_DIM)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runWakeClassifier(embedBuffer: ArrayDeque<FloatArray>): Float {
        val e = env ?: return 0f
        val sess = wakeSession ?: return 0f
        val flat = FloatArray(EMBED_WINDOW * EMBED_DIM)
        var idx = 0
        for (row in embedBuffer) {
            System.arraycopy(row, 0, flat, idx, EMBED_DIM)
            idx += EMBED_DIM
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, EMBED_WINDOW.toLong(), EMBED_DIM.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(wakeInputName, tensor)).use { res ->
                    val arr = extractFlatFloats(res[0].value, 1)
                    arr?.firstOrNull() ?: 0f
                }
            }
        } catch (_: Exception) {
            0f
        }
    }

    private fun extractFlatFloats(value: Any?, expectedLen: Int): FloatArray? {
        val out = FloatArray(expectedLen)
        var pos = 0
        fun walk(v: Any?) {
            if (pos >= expectedLen || v == null) return
            when (v) {
                is Float -> out[pos++] = v
                is FloatArray -> {
                    val copy = minOf(v.size, expectedLen - pos)
                    System.arraycopy(v, 0, out, pos, copy)
                    pos += copy
                }
                is Array<*> -> for (item in v) walk(item)
            }
        }
        walk(value)
        return if (pos >= expectedLen) out else null
    }

    private fun ensureModelFile(dir: File, filename: String, downloadUrl: String?): File {
        val out = File(dir, filename)
        if (out.exists() && out.length() > 10_000L) return out

        // 1) Try copying from bundled assets/wake/
        val assetPath = "wake/$filename"
        val copied = try {
            context.assets.open(assetPath).use { input ->
                out.outputStream().buffered().use { output -> input.copyTo(output) }
            }
            out.exists() && out.length() > 10_000L
        } catch (_: Exception) {
            false
        }
        if (copied) return out

        // 2) Download once from official openWakeWord release if not bundled
        if (downloadUrl == null) {
            throw IllegalStateException("Bundled $filename missing in assets/wake/")
        }
        val tmp = File(dir, "$filename.tmp")
        val conn = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 45000
            instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode} downloading $filename")
            }
            conn.inputStream.use { input ->
                tmp.outputStream().buffered().use { output -> input.copyTo(output) }
            }
        } finally {
            conn.disconnect()
        }
        if (!tmp.exists() || tmp.length() < 10_000L) {
            tmp.delete()
            throw IllegalStateException("$filename download incomplete")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        return out
    }
}
