package com.nova.assistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.Collections
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * Battery-Efficient Single-AudioRecord Multi-Phrase Wake Word Engine for Nova v8.0 Ultimate.
 *
 * Strictly requires the FULL two-word wake phrase ("Hello Nova", "Hey Nova", "Hi Nova", "Okay Nova").
 * Standalone "Hello", "Hey", "Hi", "Okay" and common greetings are placed in negative distractor grammar
 * AND verified with word-level confidence + duration checks so standalone "Hello" NEVER false-triggers.
 */
class OpenWakeWordEngine(
    private val context: Context,
    initialThreshold: Float = 0.65f,
    private val onWakeDetected: (phrase: String, score: Float) -> Unit,
    private val onError: (String) -> Unit
) {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val FRAME_SAMPLES = 1280 // 80 ms
        private const val MEL_BINS = 32
        private const val MEL_WINDOW = 76
        private const val EMBED_DIM = 96
        private const val EMBED_WINDOW = 16
        private const val COOLDOWN_MS = 2000L

        private const val MEL_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.onnx"
        private const val EMBED_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.onnx"

        private val GRAMMAR_PREFIXES = listOf("hey", "hi", "hello", "okay", "ok")
        private val GRAMMAR_NAMES = listOf("nova", "noah", "nava")

        private val GRAMMAR_DISTRACTORS = listOf(
            "hello", "hey", "hi", "okay", "ok",
            "hello bhai", "hello sir", "hello ji", "hello there", "hello how are you",
            "hello everyone", "hello friend", "hey there", "hey bro", "hi there",
            "okay bye", "ok fine", "yes", "no", "haan", "nahi", "stop", "wait",
            "what", "who", "thank you", "good morning", "bye"
        )

        val MULTI_PHRASE_GRAMMAR: String = "[" +
            (GRAMMAR_PREFIXES.flatMap { p -> GRAMMAR_NAMES.map { n -> "\"$p $n\"" } } +
                GRAMMAR_DISTRACTORS.map { "\"$it\"" } +
                "\"[unk]\"")
                .joinToString(", ") + "]"
    }

    @Volatile private var threshold: Float = initialThreshold.coerceIn(0.45f, 0.85f)
    @Volatile private var batterySaver: Boolean = false

    private var env: OrtEnvironment? = null
    private var melSession: OrtSession? = null
    private var embedSession: OrtSession? = null
    private var wakeSession: OrtSession? = null

    private var melInputName = "input"
    private var embedInputName = "input_1"
    private var wakeInputName = "onnx::Flatten_0"

    @Volatile private var neuralInitialized = false
    @Volatile private var voskModelRef: Model? = null
    private var voskSpotter: Recognizer? = null
    private val voskLock = Any()

    private var audioRecord: AudioRecord? = null
    private var workerThread: Thread? = null
    private val running = AtomicBoolean(false)
    private var lastTriggerMs = 0L

    fun isNeuralReady(): Boolean = neuralInitialized
    fun isMultiPhraseReady(): Boolean = voskModelRef != null

    fun setThreshold(value: Float) {
        threshold = value.coerceIn(0.45f, 0.85f)
    }

    fun setBatterySaver(enabled: Boolean) {
        batterySaver = enabled
    }

    fun attachVoskModel(model: Model?) {
        synchronized(voskLock) {
            voskModelRef = model
            runCatching { voskSpotter?.close() }
            voskSpotter = if (model != null) {
                try {
                    Recognizer(model, SAMPLE_RATE.toFloat(), MULTI_PHRASE_GRAMMAR).apply {
                        runCatching { setWords(true) }
                    }
                } catch (_: Exception) {
                    null
                }
            } else null
            NovaState.multiPhraseWakeReady = voskSpotter != null
        }
    }

    fun initNeural(): Boolean {
        if (neuralInitialized) return true
        return try {
            val dir = File(context.filesDir, "wake_models").apply { mkdirs() }
            val heyFile = ensureModelFile(dir, "hey_nova.onnx", null)
            val melFile = ensureModelFile(dir, "melspectrogram.onnx", MEL_URL)
            val embedFile = ensureModelFile(dir, "embedding_model.onnx", EMBED_URL)

            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(1)
            }
            val ms = e.createSession(melFile.absolutePath, opts)
            val es = e.createSession(embedFile.absolutePath, opts)
            val ws = e.createSession(heyFile.absolutePath, opts)

            melInputName = ms.inputNames.firstOrNull() ?: melInputName
            embedInputName = es.inputNames.firstOrNull() ?: embedInputName
            wakeInputName = ws.inputNames.firstOrNull() ?: wakeInputName

            env = e
            melSession = ms
            embedSession = es
            wakeSession = ws
            neuralInitialized = true
            NovaState.neuralWakeReady = true
            true
        } catch (ex: Exception) {
            NovaState.neuralWakeReady = false
            onError("Neural wake init failed: ${ex.message}")
            false
        }
    }

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if ((!neuralInitialized && voskModelRef == null) || running.get()) return running.get()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufBytes = maxOf(minBuf, FRAME_SAMPLES * 2 * 4)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufBytes
            )
        } catch (e: Exception) {
            onError("AudioRecord error: ${e.message}")
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            onError("Microphone initialize nahi hua (mic busy ya permission missing)")
            return false
        }

        audioRecord = rec
        running.set(true)
        workerThread = Thread({ runAudioLoop(rec) }, "nova-wake-thread").apply { start() }
        return true
    }

    fun stop() {
        running.set(false)
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { workerThread?.join(450) } catch (_: Exception) {}
        workerThread = null
    }

    fun release() {
        stop()
        synchronized(voskLock) {
            runCatching { voskSpotter?.close() }
            voskSpotter = null
            voskModelRef = null
            NovaState.multiPhraseWakeReady = false
        }
        runCatching { melSession?.close() }
        runCatching { embedSession?.close() }
        runCatching { wakeSession?.close() }
        melSession = null
        embedSession = null
        wakeSession = null
        neuralInitialized = false
        NovaState.neuralWakeReady = false
    }

    private fun runAudioLoop(rec: AudioRecord) {
        val pcm = ShortArray(FRAME_SAMPLES)
        val floatAudio = FloatArray(FRAME_SAMPLES)

        val melBuffer = ArrayDeque<FloatArray>(128)
        val embedBuffer = ArrayDeque<FloatArray>(EMBED_WINDOW + 2)
        repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }

        var framesSinceEmbed = 0
        var realEmbeds = 0
        var neuralHits = 0
        var speechHangoverFrames = 0
        var consecutiveZeroReads = 0

        try {
            rec.startRecording()
            while (running.get()) {
                var readTotal = 0
                while (readTotal < FRAME_SAMPLES && running.get()) {
                    val n = rec.read(pcm, readTotal, FRAME_SAMPLES - readTotal)
                    if (n > 0) {
                        readTotal += n
                        consecutiveZeroReads = 0
                    } else if (n < 0) {
                        onError("Microphone read failed (code $n)")
                        return
                    } else {
                        consecutiveZeroReads++
                        if (consecutiveZeroReads > 25) {
                            onError("Microphone stream stalled")
                            return
                        }
                    }
                }
                if (!running.get() || readTotal < FRAME_SAMPLES) continue

                var sumSq = 0.0
                for (i in 0 until FRAME_SAMPLES) {
                    val v = pcm[i].toFloat()
                    floatAudio[i] = v
                    sumSq += (v * v).toDouble()
                }
                val rms = sqrt(sumSq / FRAME_SAMPLES)
                val vadFloor = if (batterySaver) 200.0 else 75.0
                if (rms >= vadFloor) {
                    speechHangoverFrames = 22
                } else if (speechHangoverFrames > 0) {
                    speechHangoverFrames--
                }

                if (batterySaver && speechHangoverFrames == 0 && realEmbeds >= EMBED_WINDOW) {
                    neuralHits = 0
                    continue
                }

                var detectedPhrase: String? = null
                var detectedScore = 0f

                if (neuralInitialized) {
                    val newMels = runMel(floatAudio)
                    if (newMels != null) {
                        for (frame in newMels) {
                            melBuffer.addLast(frame)
                            if (melBuffer.size > 110) melBuffer.removeFirst()
                        }
                        framesSinceEmbed += newMels.size
                        if (melBuffer.size >= MEL_WINDOW && framesSinceEmbed >= 8) {
                            framesSinceEmbed = 0
                            val emb = runEmbedding(melBuffer)
                            if (emb != null) {
                                embedBuffer.addLast(emb)
                                while (embedBuffer.size > EMBED_WINDOW) embedBuffer.removeFirst()
                                if (realEmbeds < EMBED_WINDOW) {
                                    realEmbeds++
                                } else {
                                    val score = runWakeClassifier(embedBuffer)
                                    val requiredHits = if (threshold >= 0.70f) 3 else 2
                                    if (score >= threshold) neuralHits++ else neuralHits = 0
                                    if (neuralHits >= requiredHits) {
                                        detectedPhrase = "Hey Nova"
                                        detectedScore = score
                                    }
                                }
                            }
                        }
                    }
                }

                if (detectedPhrase == null && speechHangoverFrames > 0) {
                    val voskHit = feedVoskMultiPhrase(pcm)
                    if (voskHit != null) {
                        detectedPhrase = voskHit
                        detectedScore = 0.92f
                    }
                }

                if (detectedPhrase != null) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastTriggerMs >= COOLDOWN_MS) {
                        lastTriggerMs = now
                        melBuffer.clear()
                        embedBuffer.clear()
                        repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }
                        realEmbeds = 0
                        neuralHits = 0
                        speechHangoverFrames = 0
                        resetVoskSpotter()
                        onWakeDetected(detectedPhrase, detectedScore)
                    }
                }
            }
        } catch (e: Exception) {
            if (running.get()) onError("Wake audio loop error: ${e.message}")
        } finally {
            runCatching { rec.stop() }
        }
    }

    private fun feedVoskMultiPhrase(pcm: ShortArray): String? {
        synchronized(voskLock) {
            val rec = voskSpotter ?: return null
            return try {
                val isFinal = rec.acceptWaveForm(pcm, pcm.size)
                if (!isFinal) return null

                val obj = JSONObject(rec.result)
                val txt = obj.optString("text", "").lowercase(Locale.ROOT).trim()
                if (txt.isEmpty() || txt == "[unk]") return null

                val phrase = matchSupportedMultiPhrase(txt) ?: return null

                val wordsArr = obj.optJSONArray("result")
                if (wordsArr != null && wordsArr.length() >= 2) {
                    val minConf = if (threshold >= 0.72f) 0.78 else 0.65
                    var verified = false
                    for (i in 0 until wordsArr.length() - 1) {
                        val first = wordsArr.optJSONObject(i) ?: continue
                        val second = wordsArr.optJSONObject(i + 1) ?: continue
                        val w1 = first.optString("word", "").lowercase(Locale.ROOT)
                        val w2 = second.optString("word", "").lowercase(Locale.ROOT)
                        if (w1 in GRAMMAR_PREFIXES && w2 in GRAMMAR_NAMES) {
                            val conf1 = first.optDouble("conf", 1.0)
                            val conf2 = second.optDouble("conf", 1.0)
                            val novaDur = second.optDouble("end", 0.0) - second.optDouble("start", 0.0)
                            val gap = second.optDouble("start", 0.0) - first.optDouble("end", 0.0)
                            if (conf1 >= 0.55 && conf2 >= minConf && novaDur >= 0.16 && gap <= 0.45) {
                                verified = true
                                break
                            }
                        }
                    }
                    if (!verified) return null
                }
                phrase
            } catch (_: Exception) {
                null
            }
        }
    }

    private fun resetVoskSpotter() {
        synchronized(voskLock) {
            runCatching { voskSpotter?.reset() }
        }
    }

    private fun matchSupportedMultiPhrase(txt: String): String? {
        val w = txt.trim().split(Regex("\\s+"))
        if (w.size < 2) return null
        for (i in 0 until w.size - 1) {
            val first = w[i]
            val second = w[i + 1]
            if (first in GRAMMAR_PREFIXES && second in GRAMMAR_NAMES) {
                return when (first) {
                    "okay", "ok" -> "Okay Nova"
                    "hello" -> "Hello Nova"
                    "hi" -> "Hi Nova"
                    "hey" -> "Hey Nova"
                    else -> null
                }
            }
        }
        return null
    }

    private fun runMel(audio: FloatArray): List<FloatArray>? {
        val e = env ?: return null
        val sess = melSession ?: return null
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(audio), longArrayOf(1L, audio.size.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(melInputName, tensor)).use { res ->
                    val out = res[0].value
                    val frames = ArrayList<FloatArray>(8)
                    @Suppress("UNCHECKED_CAST")
                    when (out) {
                        is Array<*> -> {
                            val d1 = out[0]
                            if (d1 is Array<*>) {
                                val d2 = d1[0]
                                if (d2 is Array<*>) {
                                    for (row in d2) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            frames.add(FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f })
                                        }
                                    }
                                } else if (d2 is FloatArray && d2.size == MEL_BINS) {
                                    for (row in d1) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            frames.add(FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f })
                                        }
                                    }
                                }
                            }
                        }
                    }
                    frames
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runEmbedding(melBuffer: ArrayDeque<FloatArray>): FloatArray? {
        val e = env ?: return null
        val sess = embedSession ?: return null
        val flat = FloatArray(MEL_WINDOW * MEL_BINS)
        val start = melBuffer.size - MEL_WINDOW
        var idx = 0
        for (i in start until melBuffer.size) {
            System.arraycopy(melBuffer[i], 0, flat, idx, MEL_BINS)
            idx += MEL_BINS
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, MEL_WINDOW.toLong(), MEL_BINS.toLong(), 1L)).use { tensor ->
                sess.run(Collections.singletonMap(embedInputName, tensor)).use { res ->
                    extractFlatFloats(res[0].value, EMBED_DIM)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runWakeClassifier(embedBuffer: ArrayDeque<FloatArray>): Float {
        val e = env ?: return 0f
        val sess = wakeSession ?: return 0f
        val flat = FloatArray(EMBED_WINDOW * EMBED_DIM)
        var idx = 0
        for (row in embedBuffer) {
            System.arraycopy(row, 0, flat, idx, EMBED_DIM)
            idx += EMBED_DIM
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, EMBED_WINDOW.toLong(), EMBED_DIM.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(wakeInputName, tensor)).use { res ->
                    extractFlatFloats(res[0].value, 1)?.firstOrNull() ?: 0f
                }
            }
        } catch (_: Exception) {
            0f
        }
    }

    private fun extractFlatFloats(value: Any?, expectedLen: Int): FloatArray? {
        val out = FloatArray(expectedLen)
        var pos = 0
        fun walk(v: Any?) {
            if (pos >= expectedLen || v == null) return
            when (v) {
                is Float -> out[pos++] = v
                is FloatArray -> {
                    val copy = minOf(v.size, expectedLen - pos)
                    System.arraycopy(v, 0, out, pos, copy)
                    pos += copy
                }
                is Array<*> -> for (item in v) walk(item)
            }
        }
        walk(value)
        return if (pos >= expectedLen) out else null
    }

    private fun ensureModelFile(dir: File, filename: String, downloadUrl: String?): File {
        val out = File(dir, filename)
        if (out.exists() && out.length() > 10_000L) return out

        val assetPath = "wake/$filename"
        val copied = try {
            context.assets.open(assetPath).use { input ->
                out.outputStream().buffered().use { output -> input.copyTo(output) }
            }
            out.exists() && out.length() > 10_000L
        } catch (_: Exception) {
            false
        }
        if (copied) return out

        if (downloadUrl == null) {
            throw IllegalStateException("Bundled $filename missing in assets/wake/")
        }
        val tmp = File(dir, "$filename.tmp")
        val conn = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 45000
            instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode} downloading $filename")
            }
            conn.inputStream.use { input ->
                tmp.outputStream().buffered().use { output -> input.copyTo(output) }
            }
        } finally {
            conn.disconnect()
        }
        if (!tmp.exists() || tmp.length() < 10_000L) {
            tmp.delete()
            throw IllegalStateException("$filename download incomplete")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        return out
    }
}
