package com.nova.assistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.Collections
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * Nova v9.0 Ultra-Low-False-Trigger Two-Stage Hybrid Wake Word Engine.
 *
 * Eliminates false triggers from room noise, TV dialogue, music, and standalone "Hello/Hey/Hi/Okay" via 4 layers:
 *   1) Adaptive Room-Noise Floor SNR VAD: tracks ambient noise EMA and only processes clear foreground speech.
 *   2) Automatic Silence Reset: resets the Vosk decoder after 1.4s of silence so old words never stitch into fake phrases.
 *   3) Tightened Candidate Detectors:
 *        - Neural ONNX (`hey_nova.onnx`) gated by speech SNR, requiring 3 sustained consecutive frames.
 *        - Constrained Vosk spotter with rich Hindi/English negative distractors + strict word-level confidence & duration.
 *   4) Second-Stage Full-Vocabulary Ring-Buffer Verifier (2.2s rolling PCM buffer):
 *        - Whenever ANY candidate fires, the last 2.2 seconds of audio are verified once through a FULL-VOCABULARY
 *          Vosk recognizer (0% idle CPU). Unrelated speech ("hello bhai", "kya hua", TV sentences) is immediately blocked.
 */
class OpenWakeWordEngine(
    private val context: Context,
    initialThreshold: Float = 0.70f,
    private val onWakeDetected: (phrase: String, score: Float) -> Unit,
    private val onError: (String) -> Unit
) {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val FRAME_SAMPLES = 1280 // 80 ms
        private const val RING_BUFFER_SAMPLES = SAMPLE_RATE * 22 / 10 // 2.2 seconds rolling audio
        private const val MEL_BINS = 32
        private const val MEL_WINDOW = 76
        private const val EMBED_DIM = 96
        private const val EMBED_WINDOW = 16
        private const val COOLDOWN_MS = 2400L

        private const val MEL_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.onnx"
        private const val EMBED_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.onnx"

        private val GRAMMAR_PREFIXES = listOf("hey", "hi", "hello", "okay", "ok")
        // Tight positive names only ("nava" removed from constrained grammar because Hindi "na/hava/dava" caused false hits)
        private val GRAMMAR_NAMES = listOf("nova", "noah")

        // Extensive Hindi + English distractors so everyday speech maps to a distractor instead of forcing "nova"
        private val GRAMMAR_DISTRACTORS = listOf(
            "hello", "hey", "hi", "okay", "ok",
            "hello bhai", "hello sir", "hello ji", "hello there", "hello how are you",
            "hello everyone", "hello friend", "hello guys", "hello mummy", "hello papa",
            "hey there", "hey bro", "hey man", "hey guys", "hi there", "hi bro",
            "okay bye", "ok fine", "okay fine", "okay sir", "okay ji", "ok done",
            "yes", "no", "haan", "nahi", "kya", "kya hua", "accha", "theek hai",
            "stop", "wait", "what", "who", "thank you", "good morning", "bye",
            "sun", "suno", "arey", "bhai", "yaar", "chalo", "band karo"
        )

        val MULTI_PHRASE_GRAMMAR: String = "[" +
            (GRAMMAR_PREFIXES.flatMap { p -> GRAMMAR_NAMES.map { n -> "\"$p $n\"" } } +
                GRAMMAR_DISTRACTORS.map { "\"$it\"" } +
                "\"[unk]\"")
                .joinToString(", ") + "]"

        // Full-vocabulary verifier phonetic sets (Indian-English Vosk en-in-0.4)
        private val VERIFY_PREFIXES = setOf("hey", "hi", "hello", "helo", "hallo", "okay", "ok", "okey", "hay", "hai")
        private val VERIFY_NOVA_SINGLE = setOf("nova", "nowa", "noah", "nava", "noba", "noa", "novah", "norva", "novo")
        private val VERIFY_NOVA_SPLIT = setOf("no va", "no war", "know a", "na va")

        /**
         * Verifies a full-vocabulary Vosk transcript of the 2.2s wake buffer.
         * Rejects standalone "hello"/"hey"/"hi"/"okay", greetings ("hello bhai"), and long unrelated TV/room sentences.
         * Returns the canonical wake phrase if genuinely spoken, or null to block false trigger.
         */
        fun verifyFullVocabTranscript(rawTranscript: String): String? {
            val clean = HinglishConverter.toHinglish(rawTranscript)
                .lowercase(Locale.ROOT)
                .replace(Regex("[^a-z\\s]+"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            if (clean.isEmpty()) return null

            val words = clean.split(" ").filter { it.isNotBlank() }
            // A real wake phrase in a 2.2s buffer is 2-3 words (e.g. "hello nova", "o k nova", "hey no war").
            // Long background sentences (> 4 words) are rejected to prevent TV/conversation false triggers.
            if (words.size < 2 || words.size > 4) return null

            // Check "o k nova" / "o kay nova"
            if (words.size >= 3 && words[0] == "o" && (words[1] == "k" || words[1] == "kay")) {
                if (words[2] in VERIFY_NOVA_SINGLE || Normalizer.levenshtein(words[2], "nova") <= 1) {
                    return "Okay Nova"
                }
            }

            for (i in 0 until words.size - 1) {
                val p = words[i]
                if (p !in VERIFY_PREFIXES) continue

                // 2-word split for "Nova" (e.g. "hello no va", "hey no war")
                if (i + 2 < words.size) {
                    val pair = "${words[i + 1]} ${words[i + 2]}"
                    if (pair in VERIFY_NOVA_SPLIT) {
                        return canonicalPhrase(p)
                    }
                }

                // Single word "Nova" phonetic match (strict — excludes generic words like "no", "now", "know", "over")
                val nxt = words[i + 1]
                val isNova = nxt in VERIFY_NOVA_SINGLE ||
                    (nxt.length in 4..5 && Normalizer.levenshtein(nxt, "nova") <= 1 && nxt !in setOf("move", "love", "none", "note", "name", "over", "more"))
                if (isNova) {
                    return canonicalPhrase(p)
                }
            }
            return null
        }

        private fun canonicalPhrase(prefix: String): String = when (prefix) {
            "okay", "ok", "okey" -> "Okay Nova"
            "hello", "helo", "hallo" -> "Hello Nova"
            "hi", "hai" -> "Hi Nova"
            else -> "Hey Nova"
        }
    }

    @Volatile private var threshold: Float = initialThreshold.coerceIn(0.50f, 0.90f)
    @Volatile private var batterySaver: Boolean = false
    @Volatile private var strictVerify: Boolean = true

    private var env: OrtEnvironment? = null
    private var melSession: OrtSession? = null
    private var embedSession: OrtSession? = null
    private var wakeSession: OrtSession? = null

    private var melInputName = "input"
    private var embedInputName = "input_1"
    private var wakeInputName = "onnx::Flatten_0"

    @Volatile private var neuralInitialized = false
    @Volatile private var voskModelRef: Model? = null
    private var voskSpotter: Recognizer? = null
    private var voskVerifier: Recognizer? = null
    private val voskLock = Any()

    private var audioRecord: AudioRecord? = null
    private var workerThread: Thread? = null
    private val running = AtomicBoolean(false)
    private var lastTriggerMs = 0L

    fun isNeuralReady(): Boolean = neuralInitialized
    fun isMultiPhraseReady(): Boolean = voskModelRef != null

    fun setThreshold(value: Float) {
        threshold = value.coerceIn(0.50f, 0.90f)
    }

    fun setBatterySaver(enabled: Boolean) {
        batterySaver = enabled
    }

    fun setStrictVerify(enabled: Boolean) {
        strictVerify = enabled
    }

    /** Attaches Vosk model for BOTH constrained spotter AND full-vocabulary second-stage anti-false-trigger verifier. */
    fun attachVoskModel(model: Model?) {
        synchronized(voskLock) {
            voskModelRef = model
            runCatching { voskSpotter?.close() }
            runCatching { voskVerifier?.close() }
            voskSpotter = if (model != null) {
                try {
                    Recognizer(model, SAMPLE_RATE.toFloat(), MULTI_PHRASE_GRAMMAR).apply {
                        runCatching { setWords(true) }
                    }
                } catch (_: Exception) {
                    null
                }
            } else null
            voskVerifier = if (model != null) {
                try {
                    Recognizer(model, SAMPLE_RATE.toFloat())
                } catch (_: Exception) {
                    null
                }
            } else null
            NovaState.multiPhraseWakeReady = voskSpotter != null
        }
    }

    fun initNeural(): Boolean {
        if (neuralInitialized) return true
        return try {
            val dir = File(context.filesDir, "wake_models").apply { mkdirs() }
            val heyFile = ensureModelFile(dir, "hey_nova.onnx", null)
            val melFile = ensureModelFile(dir, "melspectrogram.onnx", MEL_URL)
            val embedFile = ensureModelFile(dir, "embedding_model.onnx", EMBED_URL)

            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(1)
            }
            val ms = e.createSession(melFile.absolutePath, opts)
            val es = e.createSession(embedFile.absolutePath, opts)
            val ws = e.createSession(heyFile.absolutePath, opts)

            melInputName = ms.inputNames.firstOrNull() ?: melInputName
            embedInputName = es.inputNames.firstOrNull() ?: embedInputName
            wakeInputName = ws.inputNames.firstOrNull() ?: wakeInputName

            env = e
            melSession = ms
            embedSession = es
            wakeSession = ws
            neuralInitialized = true
            NovaState.neuralWakeReady = true
            true
        } catch (ex: Exception) {
            NovaState.neuralWakeReady = false
            onError("Neural wake init failed: ${ex.message}")
            false
        }
    }

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if ((!neuralInitialized && voskModelRef == null) || running.get()) return running.get()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufBytes = maxOf(minBuf, FRAME_SAMPLES * 2 * 4)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufBytes
            )
        } catch (e: Exception) {
            onError("AudioRecord error: ${e.message}")
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            onError("Microphone initialize nahi hua (mic busy ya permission missing)")
            return false
        }

        audioRecord = rec
        running.set(true)
        workerThread = Thread({ runAudioLoop(rec) }, "nova-wake-thread").apply { start() }
        return true
    }

    fun stop() {
        running.set(false)
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { workerThread?.join(450) } catch (_: Exception) {}
        workerThread = null
    }

    fun release() {
        stop()
        synchronized(voskLock) {
            runCatching { voskSpotter?.close() }
            runCatching { voskVerifier?.close() }
            voskSpotter = null
            voskVerifier = null
            voskModelRef = null
            NovaState.multiPhraseWakeReady = false
        }
        runCatching { melSession?.close() }
        runCatching { embedSession?.close() }
        runCatching { wakeSession?.close() }
        melSession = null
        embedSession = null
        wakeSession = null
        neuralInitialized = false
        NovaState.neuralWakeReady = false
    }

    private fun runAudioLoop(rec: AudioRecord) {
        val pcm = ShortArray(FRAME_SAMPLES)
        val floatAudio = FloatArray(FRAME_SAMPLES)

        // Rolling 2.2-second circular PCM ring buffer for second-stage full-vocab verification
        val ringBuf = ShortArray(RING_BUFFER_SAMPLES)
        var ringPos = 0
        var ringFilled = false

        val melBuffer = ArrayDeque<FloatArray>(128)
        val embedBuffer = ArrayDeque<FloatArray>(EMBED_WINDOW + 2)
        repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }

        var framesSinceEmbed = 0
        var realEmbeds = 0
        var neuralHits = 0
        var speechHangoverFrames = 0
        var silentFrames = 0
        var noiseFloorRms = 140.0
        var consecutiveZeroReads = 0

        try {
            rec.startRecording()
            while (running.get()) {
                var readTotal = 0
                while (readTotal < FRAME_SAMPLES && running.get()) {
                    val n = rec.read(pcm, readTotal, FRAME_SAMPLES - readTotal)
                    if (n > 0) {
                        readTotal += n
                        consecutiveZeroReads = 0
                    } else if (n < 0) {
                        onError("Microphone read failed (code $n)")
                        return
                    } else {
                        consecutiveZeroReads++
                        if (consecutiveZeroReads > 25) {
                            onError("Microphone stream stalled")
                            return
                        }
                    }
                }
                if (!running.get() || readTotal < FRAME_SAMPLES) continue

                // Append frame into 2.2s rolling PCM ring buffer
                for (i in 0 until FRAME_SAMPLES) {
                    ringBuf[ringPos] = pcm[i]
                    ringPos++
                    if (ringPos >= RING_BUFFER_SAMPLES) {
                        ringPos = 0
                        ringFilled = true
                    }
                }

                // Compute RMS energy + Adaptive Noise Floor SNR Gate
                var sumSq = 0.0
                for (i in 0 until FRAME_SAMPLES) {
                    val v = pcm[i].toFloat()
                    floatAudio[i] = v
                    sumSq += (v * v).toDouble()
                }
                val rms = sqrt(sumSq / FRAME_SAMPLES)
                val minSpeechFloor = if (batterySaver) 260.0 else 160.0
                val adaptiveSpeechGate = maxOf(minSpeechFloor, noiseFloorRms * 2.25)

                if (rms >= adaptiveSpeechGate) {
                    speechHangoverFrames = 20 // ~1.6s hangover
                    silentFrames = 0
                } else {
                    // Slowly adapt room noise floor only during quiet non-speech frames
                    noiseFloorRms = (noiseFloorRms * 0.96 + rms * 0.04).coerceIn(55.0, 650.0)
                    NovaState.noiseFloorRms = noiseFloorRms.toInt()
                    if (speechHangoverFrames > 0) speechHangoverFrames--
                    silentFrames++
                    // Auto-reset spotter after 1.44s of silence so old words NEVER stitch with new words!
                    if (silentFrames == 18) {
                        neuralHits = 0
                        resetVoskSpotter()
                    }
                }

                // Skip heavy inference completely during silence (saves battery AND kills background noise triggers!)
                if (speechHangoverFrames == 0 && realEmbeds >= EMBED_WINDOW) {
                    neuralHits = 0
                    continue
                }

                var candidatePhrase: String? = null
                var candidateScore = 0f
                var fromNeural = false

                // Path 1: Neural openWakeWord ("Hey Nova") — requires 3 sustained consecutive frames above strict bar
                if (neuralInitialized) {
                    val newMels = runMel(floatAudio)
                    if (newMels != null) {
                        for (frame in newMels) {
                            melBuffer.addLast(frame)
                            if (melBuffer.size > 110) melBuffer.removeFirst()
                        }
                        framesSinceEmbed += newMels.size
                        if (melBuffer.size >= MEL_WINDOW && framesSinceEmbed >= 8) {
                            framesSinceEmbed = 0
                            val emb = runEmbedding(melBuffer)
                            if (emb != null) {
                                embedBuffer.addLast(emb)
                                while (embedBuffer.size > EMBED_WINDOW) embedBuffer.removeFirst()
                                if (realEmbeds < EMBED_WINDOW) {
                                    realEmbeds++
                                } else {
                                    val score = runWakeClassifier(embedBuffer)
                                    val neuralBar = if (strictVerify) maxOf(threshold, 0.72f) else threshold
                                    val requiredHits = if (strictVerify || threshold >= 0.70f) 3 else 2
                                    if (score >= neuralBar) neuralHits++ else neuralHits = 0
                                    if (neuralHits >= requiredHits) {
                                        candidatePhrase = "Hey Nova"
                                        candidateScore = score
                                        fromNeural = true
                                    }
                                }
                            }
                        }
                    }
                }

                // Path 2: Constrained Vosk Multi-Phrase Spotter ("Hello Nova", "Hey Nova", "Hi Nova", "Okay Nova")
                if (candidatePhrase == null && speechHangoverFrames > 0) {
                    val voskHit = feedVoskMultiPhrase(pcm)
                    if (voskHit != null) {
                        candidatePhrase = voskHit
                        candidateScore = 0.90f
                        fromNeural = false
                    }
                }

                if (candidatePhrase != null) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastTriggerMs >= COOLDOWN_MS) {
                        // Stage 2: Full-Vocabulary Ring-Buffer Anti-False-Trigger Verification
                        val finalPhrase = verifyCandidateAgainstRingBuffer(
                            candidatePhrase = candidatePhrase,
                            candidateScore = candidateScore,
                            fromNeural = fromNeural,
                            ringBuf = ringBuf,
                            ringPos = ringPos,
                            ringFilled = ringFilled
                        )
                        if (finalPhrase != null) {
                            lastTriggerMs = now
                            melBuffer.clear()
                            embedBuffer.clear()
                            repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }
                            realEmbeds = 0
                            neuralHits = 0
                            speechHangoverFrames = 0
                            silentFrames = 0
                            resetVoskSpotter()
                            onWakeDetected(finalPhrase, candidateScore)
                        } else {
                            // False trigger cleanly blocked!
                            NovaState.falseTriggersBlockedCount++
                            neuralHits = 0
                            resetVoskSpotter()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            if (running.get()) onError("Wake audio loop error: ${e.message}")
        } finally {
            runCatching { rec.stop() }
        }
    }

    private fun verifyCandidateAgainstRingBuffer(
        candidatePhrase: String,
        candidateScore: Float,
        fromNeural: Boolean,
        ringBuf: ShortArray,
        ringPos: Int,
        ringFilled: Boolean
    ): String? {
        if (!strictVerify) return candidatePhrase
        val ordered = extractOrderedRingPcm(ringBuf, ringPos, ringFilled)
        if (ordered.size < SAMPLE_RATE / 2) return null

        val fullText = runFullVocabVosk(ordered)
        if (fullText == null) {
            // Vosk model not downloaded/attached yet -> allow only very confident neural hit
            return if (fromNeural && candidateScore >= 0.85f) candidatePhrase else null
        }

        // 1) Direct full-vocabulary confirmation (highest accuracy!)
        verifyFullVocabTranscript(fullText)?.let { return it }

        // 2) If full-vocab heard empty/noise only, allow ultra-confident neural "Hey Nova" (>= 0.93f)
        if (fromNeural && candidateScore >= 0.93f && fullText.isBlank()) {
            return candidatePhrase
        }

        // Otherwise full-vocab heard unrelated speech ("hello", "hello bhai", "kya hua", TV dialogue) -> BLOCK!
        return null
    }

    private fun extractOrderedRingPcm(ringBuf: ShortArray, ringPos: Int, ringFilled: Boolean): ShortArray {
        if (!ringFilled) return ringBuf.copyOfRange(0, ringPos)
        val out = ShortArray(RING_BUFFER_SAMPLES)
        val tailLen = RING_BUFFER_SAMPLES - ringPos
        System.arraycopy(ringBuf, ringPos, out, 0, tailLen)
        System.arraycopy(ringBuf, 0, out, tailLen, ringPos)
        return out
    }

    private fun runFullVocabVosk(pcm: ShortArray): String? {
        synchronized(voskLock) {
            val ver = voskVerifier ?: return null
            return try {
                ver.reset()
                var offset = 0
                val chunk = 4000
                while (offset < pcm.size) {
                    val len = minOf(chunk, pcm.size - offset)
                    val slice = pcm.copyOfRange(offset, offset + len)
                    ver.acceptWaveForm(slice, len)
                    offset += len
                }
                val txt = JSONObject(ver.finalResult).optString("text", "").trim()
                ver.reset()
                txt
            } catch (_: Exception) {
                runCatching { ver.reset() }
                null
            }
        }
    }

    private fun feedVoskMultiPhrase(pcm: ShortArray): String? {
        synchronized(voskLock) {
            val rec = voskSpotter ?: return null
            return try {
                val isFinal = rec.acceptWaveForm(pcm, pcm.size)
                if (!isFinal) return null

                val obj = JSONObject(rec.result)
                val txt = obj.optString("text", "").lowercase(Locale.ROOT).trim()
                if (txt.isEmpty() || txt == "[unk]") return null

                val phrase = matchSupportedMultiPhrase(txt) ?: return null

                val wordsArr = obj.optJSONArray("result")
                if (wordsArr != null && wordsArr.length() >= 2) {
                    val minPrefixConf = if (strictVerify) 0.72 else 0.60
                    val minNovaConf = if (strictVerify || threshold >= 0.70f) 0.82 else 0.70
                    var verified = false
                    for (i in 0 until wordsArr.length() - 1) {
                        val first = wordsArr.optJSONObject(i) ?: continue
                        val second = wordsArr.optJSONObject(i + 1) ?: continue
                        val w1 = first.optString("word", "").lowercase(Locale.ROOT)
                        val w2 = second.optString("word", "").lowercase(Locale.ROOT)
                        if (w1 in GRAMMAR_PREFIXES && w2 in GRAMMAR_NAMES) {
                            val conf1 = first.optDouble("conf", 1.0)
                            val conf2 = second.optDouble("conf", 1.0)
                            val novaDur = second.optDouble("end", 0.0) - second.optDouble("start", 0.0)
                            val gap = second.optDouble("start", 0.0) - first.optDouble("end", 0.0)
                            if (conf1 >= minPrefixConf && conf2 >= minNovaConf && novaDur >= 0.18 && gap <= 0.35) {
                                verified = true
                                break
                            }
                        }
                    }
                    if (!verified) return null
                }
                phrase
            } catch (_: Exception) {
                null
            }
        }
    }

    private fun resetVoskSpotter() {
        synchronized(voskLock) {
            runCatching { voskSpotter?.reset() }
        }
    }

    private fun matchSupportedMultiPhrase(txt: String): String? {
        val w = txt.trim().split(Regex("\\s+"))
        if (w.size < 2 || w.size > 3) return null
        for (i in 0 until w.size - 1) {
            val first = w[i]
            val second = w[i + 1]
            if (first in GRAMMAR_PREFIXES && second in GRAMMAR_NAMES) {
                return when (first) {
                    "okay", "ok" -> "Okay Nova"
                    "hello" -> "Hello Nova"
                    "hi" -> "Hi Nova"
                    "hey" -> "Hey Nova"
                    else -> null
                }
            }
        }
        return null
    }

    private fun runMel(audio: FloatArray): List<FloatArray>? {
        val e = env ?: return null
        val sess = melSession ?: return null
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(audio), longArrayOf(1L, audio.size.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(melInputName, tensor)).use { res ->
                    val out = res[0].value
                    val frames = ArrayList<FloatArray>(8)
                    @Suppress("UNCHECKED_CAST")
                    when (out) {
                        is Array<*> -> {
                            val d1 = out[0]
                            if (d1 is Array<*>) {
                                val d2 = d1[0]
                                if (d2 is Array<*>) {
                                    for (row in d2) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            frames.add(FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f })
                                        }
                                    }
                                } else if (d2 is FloatArray && d2.size == MEL_BINS) {
                                    for (row in d1) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            frames.add(FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f })
                                        }
                                    }
                                }
                            }
                        }
                    }
                    frames
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runEmbedding(melBuffer: ArrayDeque<FloatArray>): FloatArray? {
        val e = env ?: return null
        val sess = embedSession ?: return null
        val flat = FloatArray(MEL_WINDOW * MEL_BINS)
        val start = melBuffer.size - MEL_WINDOW
        var idx = 0
        for (i in start until melBuffer.size) {
            System.arraycopy(melBuffer[i], 0, flat, idx, MEL_BINS)
            idx += MEL_BINS
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, MEL_WINDOW.toLong(), MEL_BINS.toLong(), 1L)).use { tensor ->
                sess.run(Collections.singletonMap(embedInputName, tensor)).use { res ->
                    extractFlatFloats(res[0].value, EMBED_DIM)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runWakeClassifier(embedBuffer: ArrayDeque<FloatArray>): Float {
        val e = env ?: return 0f
        val sess = wakeSession ?: return 0f
        val flat = FloatArray(EMBED_WINDOW * EMBED_DIM)
        var idx = 0
        for (row in embedBuffer) {
            System.arraycopy(row, 0, flat, idx, EMBED_DIM)
            idx += EMBED_DIM
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, EMBED_WINDOW.toLong(), EMBED_DIM.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(wakeInputName, tensor)).use { res ->
                    extractFlatFloats(res[0].value, 1)?.firstOrNull() ?: 0f
                }
            }
        } catch (_: Exception) {
            0f
        }
    }

    private fun extractFlatFloats(value: Any?, expectedLen: Int): FloatArray? {
        val out = FloatArray(expectedLen)
        var pos = 0
        fun walk(v: Any?) {
            if (pos >= expectedLen || v == null) return
            when (v) {
                is Float -> out[pos++] = v
                is FloatArray -> {
                    val copy = minOf(v.size, expectedLen - pos)
                    System.arraycopy(v, 0, out, pos, copy)
                    pos += copy
                }
                is Array<*> -> for (item in v) walk(item)
            }
        }
        walk(value)
        return if (pos >= expectedLen) out else null
    }

    private fun ensureModelFile(dir: File, filename: String, downloadUrl: String?): File {
        val out = File(dir, filename)
        if (out.exists() && out.length() > 10_000L) return out

        val assetPath = "wake/$filename"
        val copied = try {
            context.assets.open(assetPath).use { input ->
                out.outputStream().buffered().use { output -> input.copyTo(output) }
            }
            out.exists() && out.length() > 10_000L
        } catch (_: Exception) {
            false
        }
        if (copied) return out

        if (downloadUrl == null) {
            throw IllegalStateException("Bundled $filename missing in assets/wake/")
        }
        val tmp = File(dir, "$filename.tmp")
        val conn = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 45000
            instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode} downloading $filename")
            }
            conn.inputStream.use { input ->
                tmp.outputStream().buffered().use { output -> input.copyTo(output) }
            }
        } finally {
            conn.disconnect()
        }
        if (!tmp.exists() || tmp.length() < 10_000L) {
            tmp.delete()
            throw IllegalStateException("$filename download incomplete")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        return out
    }
}
