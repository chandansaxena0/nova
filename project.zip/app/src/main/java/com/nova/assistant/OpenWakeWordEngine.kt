package com.nova.assistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.Collections
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * Nova v10.0 Background-Reliable, Low-False-Trigger Hybrid Wake Engine.
 *
 * Fixes background missed triggers while keeping false triggers minimal:
 *   1) Calibrated Adaptive SNR VAD (Balanced min floor 75 RMS, High 50 RMS, Battery Saver 140 RMS)
 *      so arm's-length / background / locked-screen speech is never dropped.
 *   2) Automatic AudioSource Fallback: tries VOICE_RECOGNITION first, automatically falls back to MIC
 *      if OEM hardware silences or blocks VOICE_RECOGNITION in background.
 *   3) Continuous ONNX Neural Path ("Hey Nova") in Balanced/High modes so the opening syllable is never cut off.
 *   4) Fast Constrained Vosk Spotter ("Hello Nova", "Hey Nova", "Hi Nova", "Okay Nova") accepting both
 *      final utterances AND 2-frame stable partials — verified immediately via 2.2s full-vocabulary ring buffer.
 *   5) Smart Full-Vocab Verifier: supports wake phrase even when immediately followed by a command
 *      (e.g. "Hello Nova battery kitni hai"), while blocking standalone "Hello", "Hello bhai", and room chatter.
 */
class OpenWakeWordEngine(
    private val context: Context,
    initialThreshold: Float = 0.60f,
    private val onWakeDetected: (phrase: String, score: Float) -> Unit,
    private val onError: (String) -> Unit
) {

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val FRAME_SAMPLES = 1280 // 80 ms
        private const val RING_BUFFER_SAMPLES = SAMPLE_RATE * 24 / 10 // 2.4 seconds rolling audio
        private const val MEL_BINS = 32
        private const val MEL_WINDOW = 76
        private const val EMBED_DIM = 96
        private const val EMBED_WINDOW = 16
        private const val COOLDOWN_MS = 2100L

        private const val MEL_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.onnx"
        private const val EMBED_URL =
            "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.onnx"

        private val GRAMMAR_PREFIXES = listOf("hey", "hi", "hello", "okay", "ok")
        private val GRAMMAR_NAMES = listOf("nova", "noah")

        private val GRAMMAR_DISTRACTORS = listOf(
            "hello", "hey", "hi", "okay", "ok",
            "hello bhai", "hello sir", "hello ji", "hello there", "hello how are you",
            "hello everyone", "hello friend", "hello guys", "hello mummy", "hello papa",
            "hey there", "hey bro", "hey man", "hey guys", "hi there", "hi bro",
            "okay bye", "ok fine", "okay fine", "okay sir", "okay ji", "ok done",
            "yes", "no", "haan", "nahi", "kya", "kya hua", "accha", "theek hai",
            "stop", "wait", "what", "who", "thank you", "good morning", "bye",
            "sun", "suno", "arey", "bhai", "yaar", "chalo", "band karo"
        )

        val MULTI_PHRASE_GRAMMAR: String = "[" +
            (GRAMMAR_PREFIXES.flatMap { p -> GRAMMAR_NAMES.map { n -> "\"$p $n\"" } } +
                GRAMMAR_DISTRACTORS.map { "\"$it\"" } +
                "\"[unk]\"")
                .joinToString(", ") + "]"

        private val VERIFY_PREFIXES = setOf("hey", "hi", "hello", "helo", "hallo", "okay", "ok", "okey", "hay", "hai")
        private val VERIFY_NOVA_SINGLE = setOf("nova", "nowa", "noah", "nava", "noba", "noa", "novah", "norva", "novo")
        private val VERIFY_NOVA_SPLIT = setOf("no va", "no war", "know a", "na va")

        /**
         * Verifies a full-vocabulary Vosk transcript of the 2.4s rolling wake buffer.
         * - Accepts standalone 2-word wake phrases ("hello nova", "hey nova", "hi nova", "okay nova").
         * - Also accepts wake phrases immediately followed by a command ("hello nova open whatsapp", up to 7 words)
         *   as long as the wake phrase occurs near the start (within the first 3 word positions) or end of the window.
         * - Strictly rejects standalone "hello", "hey", "hi", "okay", greetings ("hello bhai"), "hello no",
         *   and long unrelated room/TV chatter (> 7 words).
         */
        fun verifyFullVocabTranscript(rawTranscript: String): String? {
            val clean = HinglishConverter.toHinglish(rawTranscript)
                .lowercase(Locale.ROOT)
                .replace(Regex("[^a-z\\s]+"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            if (clean.isEmpty()) return null

            val words = clean.split(" ").filter { it.isNotBlank() }
            if (words.size < 2 || words.size > 7) return null

            // Check "o k nova" / "o kay nova"
            for (i in 0 until words.size - 2) {
                if (words[i] == "o" && (words[i + 1] == "k" || words[i + 1] == "kay")) {
                    val nxt = words[i + 2]
                    if (nxt in VERIFY_NOVA_SINGLE || (nxt.length in 4..5 && Normalizer.levenshtein(nxt, "nova") <= 1)) {
                        return "Okay Nova"
                    }
                }
            }

            for (i in 0 until words.size - 1) {
                val p = words[i]
                if (p !in VERIFY_PREFIXES) continue

                // For longer utterances (5..7 words), require wake phrase to start the utterance or end it cleanly
                if (words.size >= 5 && i > 1 && i < words.size - 2) continue

                // 2-word split for "Nova" (e.g. "hello no va", "hey no war")
                if (i + 2 < words.size) {
                    val pair = "${words[i + 1]} ${words[i + 2]}"
                    if (pair in VERIFY_NOVA_SPLIT) {
                        return canonicalPhrase(p)
                    }
                }

                // Single word "Nova" phonetic match (strict — excludes "no", "now", "know", "over", "love", etc.)
                val nxt = words[i + 1]
                val isNova = nxt in VERIFY_NOVA_SINGLE ||
                    (nxt.length in 4..5 && Normalizer.levenshtein(nxt, "nova") <= 1 &&
                        nxt !in setOf("move", "love", "none", "note", "name", "over", "more", "home"))
                if (isNova) {
                    return canonicalPhrase(p)
                }
            }
            return null
        }

        private fun canonicalPhrase(prefix: String): String = when (prefix) {
            "okay", "ok", "okey" -> "Okay Nova"
            "hello", "helo", "hallo" -> "Hello Nova"
            "hi", "hai" -> "Hi Nova"
            else -> "Hey Nova"
        }
    }

    @Volatile private var threshold: Float = initialThreshold.coerceIn(0.45f, 0.85f)
    @Volatile private var batterySaver: Boolean = false
    @Volatile private var powerMode: String = Prefs.POWER_BALANCED
    @Volatile private var strictVerify: Boolean = true
    @Volatile private var preferMicSource: Boolean = false

    private var env: OrtEnvironment? = null
    private var melSession: OrtSession? = null
    private var embedSession: OrtSession? = null
    private var wakeSession: OrtSession? = null

    private var melInputName = "input"
    private var embedInputName = "input_1"
    private var wakeInputName = "onnx::Flatten_0"

    @Volatile private var neuralInitialized = false
    @Volatile private var voskModelRef: Model? = null
    private var voskSpotter: Recognizer? = null
    private var voskVerifier: Recognizer? = null
    private val voskLock = Any()

    private var audioRecord: AudioRecord? = null
    private var workerThread: Thread? = null
    private val running = AtomicBoolean(false)
    @Volatile private var lastReadTimestampMs = 0L
    private var lastTriggerMs = 0L

    fun isNeuralReady(): Boolean = neuralInitialized
    fun isMultiPhraseReady(): Boolean = voskModelRef != null

    /** True only when the audio thread is alive and actively receiving PCM frames within the last 4 seconds. */
    fun isActivelyRecording(): Boolean {
        if (!running.get()) return false
        val t = workerThread
        if (t == null || !t.isAlive) return false
        val now = SystemClock.elapsedRealtime()
        return lastReadTimestampMs == 0L || (now - lastReadTimestampMs) < 4500L
    }

    fun setThreshold(value: Float) {
        threshold = value.coerceIn(0.45f, 0.85f)
    }

    fun setBatterySaver(enabled: Boolean) {
        batterySaver = enabled
        powerMode = if (enabled) Prefs.POWER_BATTERY_SAVER else Prefs.POWER_BALANCED
    }

    fun setPowerMode(mode: String) {
        powerMode = mode
        batterySaver = (mode == Prefs.POWER_BATTERY_SAVER)
    }

    fun setStrictVerify(enabled: Boolean) {
        strictVerify = enabled
    }

    fun attachVoskModel(model: Model?) {
        synchronized(voskLock) {
            voskModelRef = model
            runCatching { voskSpotter?.close() }
            runCatching { voskVerifier?.close() }
            voskSpotter = if (model != null) {
                try {
                    Recognizer(model, SAMPLE_RATE.toFloat(), MULTI_PHRASE_GRAMMAR).apply {
                        runCatching { setWords(true) }
                    }
                } catch (_: Exception) {
                    null
                }
            } else null
            voskVerifier = if (model != null) {
                try {
                    Recognizer(model, SAMPLE_RATE.toFloat())
                } catch (_: Exception) {
                    null
                }
            } else null
            NovaState.multiPhraseWakeReady = voskSpotter != null
        }
    }

    fun initNeural(): Boolean {
        if (neuralInitialized) return true
        return try {
            val dir = File(context.filesDir, "wake_models").apply { mkdirs() }
            val heyFile = ensureModelFile(dir, "hey_nova.onnx", null)
            val melFile = ensureModelFile(dir, "melspectrogram.onnx", MEL_URL)
            val embedFile = ensureModelFile(dir, "embedding_model.onnx", EMBED_URL)

            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(1)
            }
            val ms = e.createSession(melFile.absolutePath, opts)
            val es = e.createSession(embedFile.absolutePath, opts)
            val ws = e.createSession(heyFile.absolutePath, opts)

            melInputName = ms.inputNames.firstOrNull() ?: melInputName
            embedInputName = es.inputNames.firstOrNull() ?: embedInputName
            wakeInputName = ws.inputNames.firstOrNull() ?: wakeInputName

            env = e
            melSession = ms
            embedSession = es
            wakeSession = ws
            neuralInitialized = true
            NovaState.neuralWakeReady = true
            true
        } catch (ex: Exception) {
            NovaState.neuralWakeReady = false
            onError("Neural wake init failed: ${ex.message}")
            false
        }
    }

    @SuppressLint("MissingPermission")
    private fun createAudioRecord(bufBytes: Int): AudioRecord? {
        val sources = if (preferMicSource) {
            listOf(MediaRecorder.AudioSource.MIC, MediaRecorder.AudioSource.VOICE_RECOGNITION)
        } else {
            listOf(MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)
        }
        for (src in sources) {
            val rec = try {
                AudioRecord(
                    src,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufBytes
                )
            } catch (_: Exception) {
                null
            }
            if (rec != null && rec.state == AudioRecord.STATE_INITIALIZED) {
                return rec
            }
            runCatching { rec?.release() }
        }
        return null
    }

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if ((!neuralInitialized && voskModelRef == null) || running.get()) return running.get()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufBytes = maxOf(minBuf, FRAME_SAMPLES * 2 * 4)
        val rec = createAudioRecord(bufBytes) ?: run {
            onError("Microphone initialize nahi hua (mic busy ya permission missing)")
            return false
        }

        audioRecord = rec
        lastReadTimestampMs = SystemClock.elapsedRealtime()
        running.set(true)
        workerThread = Thread({ runAudioLoop(rec) }, "nova-wake-thread").apply { start() }
        return true
    }

    fun stop() {
        running.set(false)
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { workerThread?.join(450) } catch (_: Exception) {}
        workerThread = null
    }

    fun release() {
        stop()
        synchronized(voskLock) {
            runCatching { voskSpotter?.close() }
            runCatching { voskVerifier?.close() }
            voskSpotter = null
            voskVerifier = null
            voskModelRef = null
            NovaState.multiPhraseWakeReady = false
        }
        runCatching { melSession?.close() }
        runCatching { embedSession?.close() }
        runCatching { wakeSession?.close() }
        melSession = null
        embedSession = null
        wakeSession = null
        neuralInitialized = false
        NovaState.neuralWakeReady = false
    }

    private fun runAudioLoop(rec: AudioRecord) {
        val pcm = ShortArray(FRAME_SAMPLES)
        val floatAudio = FloatArray(FRAME_SAMPLES)

        val ringBuf = ShortArray(RING_BUFFER_SAMPLES)
        var ringPos = 0
        var ringFilled = false

        val melBuffer = ArrayDeque<FloatArray>(128)
        val embedBuffer = ArrayDeque<FloatArray>(EMBED_WINDOW + 2)
        repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }

        var framesSinceEmbed = 0
        var realEmbeds = 0
        var neuralHits = 0
        var speechHangoverFrames = 0
        var silentFrames = 0
        var zeroEnergyFrames = 0
        var noiseFloorRms = 65.0
        var consecutiveZeroReads = 0
        var lastPartialPhrase = ""
        var partialConfirmCount = 0

        try {
            rec.startRecording()
            while (running.get()) {
                var readTotal = 0
                while (readTotal < FRAME_SAMPLES && running.get()) {
                    val n = rec.read(pcm, readTotal, FRAME_SAMPLES - readTotal)
                    if (n > 0) {
                        readTotal += n
                        consecutiveZeroReads = 0
                        lastReadTimestampMs = SystemClock.elapsedRealtime()
                    } else if (n < 0) {
                        onError("Microphone read failed (code $n)")
                        return
                    } else {
                        consecutiveZeroReads++
                        if (consecutiveZeroReads > 25) {
                            preferMicSource = !preferMicSource
                            onError("Microphone stream stalled — switching audio source")
                            return
                        }
                    }
                }
                if (!running.get() || readTotal < FRAME_SAMPLES) continue

                for (i in 0 until FRAME_SAMPLES) {
                    ringBuf[ringPos] = pcm[i]
                    ringPos++
                    if (ringPos >= RING_BUFFER_SAMPLES) {
                        ringPos = 0
                        ringFilled = true
                    }
                }

                var sumSq = 0.0
                for (i in 0 until FRAME_SAMPLES) {
                    val v = pcm[i].toFloat()
                    floatAudio[i] = v
                    sumSq += (v * v).toDouble()
                }
                val rms = sqrt(sumSq / FRAME_SAMPLES)

                // Detect OEM background mic silencing (pure zero PCM stream for > 4s) and switch source
                if (rms < 0.5) {
                    zeroEnergyFrames++
                    if (zeroEnergyFrames > 55) {
                        zeroEnergyFrames = 0
                        preferMicSource = !preferMicSource
                        onError("Mic stream muted by OS — recovering")
                        return
                    }
                } else {
                    zeroEnergyFrames = 0
                }

                val (minSpeechFloor, snrMult, hangoverMax) = when (powerMode) {
                    Prefs.POWER_BATTERY_SAVER -> Triple(140.0, 2.05, 16)
                    Prefs.POWER_HIGH -> Triple(50.0, 1.45, 26)
                    else -> Triple(75.0, 1.65, 22)
                }
                val adaptiveSpeechGate = maxOf(minSpeechFloor, noiseFloorRms * snrMult)

                if (rms >= adaptiveSpeechGate) {
                    speechHangoverFrames = hangoverMax
                    silentFrames = 0
                } else {
                    noiseFloorRms = (noiseFloorRms * 0.96 + rms * 0.04).coerceIn(25.0, 420.0)
                    NovaState.noiseFloorRms = noiseFloorRms.toInt()
                    if (speechHangoverFrames > 0) speechHangoverFrames--
                    silentFrames++
                    if (silentFrames == 24) { // ~1.92s silence -> cleanly reset decoder
                        neuralHits = 0
                        lastPartialPhrase = ""
                        partialConfirmCount = 0
                        resetVoskSpotter()
                    }
                }

                // Battery Saver mode skips inference during silence; Balanced & High keep neural warmup fresh
                if (powerMode == Prefs.POWER_BATTERY_SAVER && speechHangoverFrames == 0 && realEmbeds >= EMBED_WINDOW) {
                    neuralHits = 0
                    continue
                }

                var candidatePhrase: String? = null
                var candidateScore = 0f
                var fromNeural = false

                // Path 1: Neural openWakeWord ("Hey Nova")
                if (neuralInitialized) {
                    val newMels = runMel(floatAudio)
                    if (newMels != null) {
                        for (frame in newMels) {
                            melBuffer.addLast(frame)
                            if (melBuffer.size > 110) melBuffer.removeFirst()
                        }
                        framesSinceEmbed += newMels.size
                        if (melBuffer.size >= MEL_WINDOW && framesSinceEmbed >= 8) {
                            framesSinceEmbed = 0
                            val emb = runEmbedding(melBuffer)
                            if (emb != null) {
                                embedBuffer.addLast(emb)
                                while (embedBuffer.size > EMBED_WINDOW) embedBuffer.removeFirst()
                                if (realEmbeds < EMBED_WINDOW) {
                                    realEmbeds++
                                } else {
                                    val score = runWakeClassifier(embedBuffer)
                                    val requiredHits = if (threshold >= 0.75f) 3 else 2
                                    if (score >= threshold) neuralHits++ else neuralHits = 0
                                    if (neuralHits >= requiredHits) {
                                        candidatePhrase = "Hey Nova"
                                        candidateScore = score
                                        fromNeural = true
                                    }
                                }
                            }
                        }
                    }
                }

                // Path 2: Constrained Vosk Multi-Phrase Spotter ("Hello Nova", "Hey Nova", "Hi Nova", "Okay Nova")
                if (candidatePhrase == null && (speechHangoverFrames > 0 || powerMode == Prefs.POWER_HIGH)) {
                    val (voskPhrase, isFinalHit) = feedVoskMultiPhrase(pcm)
                    if (voskPhrase != null) {
                        if (isFinalHit) {
                            candidatePhrase = voskPhrase
                            candidateScore = 0.90f
                            fromNeural = false
                        } else {
                            // Partial hit: require 2 consecutive identical frames (~160ms) so fast speech triggers immediately
                            if (voskPhrase == lastPartialPhrase) {
                                partialConfirmCount++
                            } else {
                                lastPartialPhrase = voskPhrase
                                partialConfirmCount = 1
                            }
                            if (partialConfirmCount >= 2) {
                                candidatePhrase = voskPhrase
                                candidateScore = 0.84f
                                fromNeural = false
                            }
                        }
                    } else {
                        lastPartialPhrase = ""
                        partialConfirmCount = 0
                    }
                }

                if (candidatePhrase != null) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastTriggerMs >= COOLDOWN_MS) {
                        val finalPhrase = verifyCandidateAgainstRingBuffer(
                            candidatePhrase = candidatePhrase,
                            candidateScore = candidateScore,
                            fromNeural = fromNeural,
                            ringBuf = ringBuf,
                            ringPos = ringPos,
                            ringFilled = ringFilled
                        )
                        if (finalPhrase != null) {
                            lastTriggerMs = now
                            melBuffer.clear()
                            embedBuffer.clear()
                            repeat(EMBED_WINDOW) { embedBuffer.addLast(FloatArray(EMBED_DIM)) }
                            realEmbeds = 0
                            neuralHits = 0
                            speechHangoverFrames = 0
                            silentFrames = 0
                            lastPartialPhrase = ""
                            partialConfirmCount = 0
                            resetVoskSpotter()
                            onWakeDetected(finalPhrase, candidateScore)
                        } else {
                            NovaState.falseTriggersBlockedCount++
                            neuralHits = 0
                            lastPartialPhrase = ""
                            partialConfirmCount = 0
                            resetVoskSpotter()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            if (running.get()) onError("Wake audio loop error: ${e.message}")
        } finally {
            runCatching { rec.stop() }
        }
    }

    private fun verifyCandidateAgainstRingBuffer(
        candidatePhrase: String,
        candidateScore: Float,
        fromNeural: Boolean,
        ringBuf: ShortArray,
        ringPos: Int,
        ringFilled: Boolean
    ): String? {
        // Strong neural openWakeWord "Hey Nova" score (>= 0.78f) triggers immediately with low latency
        if (fromNeural && candidateScore >= 0.78f) return candidatePhrase
        if (!strictVerify) return candidatePhrase

        val ordered = extractOrderedRingPcm(ringBuf, ringPos, ringFilled)
        if (ordered.size < SAMPLE_RATE / 2) return null

        val fullText = runFullVocabVosk(ordered)
        if (fullText == null) {
            return if (fromNeural && candidateScore >= threshold) candidatePhrase else null
        }

        // Direct full-vocabulary confirmation (handles "Hello Nova" AND "Hello Nova open WhatsApp"!)
        verifyFullVocabTranscript(fullText)?.let { return it }

        // If full-vocab heard silence/blank only (e.g. quiet whisper) but neural was confident -> accept
        if (fromNeural && candidateScore >= maxOf(threshold, 0.68f) && fullText.isBlank()) {
            return candidatePhrase
        }

        return null
    }

    private fun extractOrderedRingPcm(ringBuf: ShortArray, ringPos: Int, ringFilled: Boolean): ShortArray {
        if (!ringFilled) return ringBuf.copyOfRange(0, ringPos)
        val out = ShortArray(RING_BUFFER_SAMPLES)
        val tailLen = RING_BUFFER_SAMPLES - ringPos
        System.arraycopy(ringBuf, ringPos, out, 0, tailLen)
        System.arraycopy(ringBuf, 0, out, tailLen, ringPos)
        return out
    }

    private fun runFullVocabVosk(pcm: ShortArray): String? {
        synchronized(voskLock) {
            val ver = voskVerifier ?: return null
            return try {
                ver.reset()
                var offset = 0
                val chunk = 4000
                while (offset < pcm.size) {
                    val len = minOf(chunk, pcm.size - offset)
                    val slice = pcm.copyOfRange(offset, offset + len)
                    ver.acceptWaveForm(slice, len)
                    offset += len
                }
                val txt = JSONObject(ver.finalResult).optString("text", "").trim()
                ver.reset()
                txt
            } catch (_: Exception) {
                runCatching { ver.reset() }
                null
            }
        }
    }

    /** Returns Pair(matchedPhrase, isFinalResult). */
    private fun feedVoskMultiPhrase(pcm: ShortArray): Pair<String?, Boolean> {
        synchronized(voskLock) {
            val rec = voskSpotter ?: return null to false
            return try {
                val isFinal = rec.acceptWaveForm(pcm, pcm.size)
                if (!isFinal) {
                    val partial = JSONObject(rec.partialResult).optString("partial", "").lowercase(Locale.ROOT).trim()
                    if (partial.isEmpty() || partial == "[unk]") return null to false
                    val hit = matchSupportedMultiPhrase(partial)
                    return hit to false
                }

                val obj = JSONObject(rec.result)
                val txt = obj.optString("text", "").lowercase(Locale.ROOT).trim()
                if (txt.isEmpty() || txt == "[unk]") return null to true

                val phrase = matchSupportedMultiPhrase(txt) ?: return null to true

                val wordsArr = obj.optJSONArray("result")
                if (wordsArr != null && wordsArr.length() >= 2) {
                    val minPrefixConf = if (strictVerify) 0.65 else 0.55
                    val minNovaConf = if (strictVerify || threshold >= 0.70f) 0.75 else 0.62
                    var verified = false
                    for (i in 0 until wordsArr.length() - 1) {
                        val first = wordsArr.optJSONObject(i) ?: continue
                        val second = wordsArr.optJSONObject(i + 1) ?: continue
                        val w1 = first.optString("word", "").lowercase(Locale.ROOT)
                        val w2 = second.optString("word", "").lowercase(Locale.ROOT)
                        if (w1 in GRAMMAR_PREFIXES && w2 in GRAMMAR_NAMES) {
                            val conf1 = first.optDouble("conf", 1.0)
                            val conf2 = second.optDouble("conf", 1.0)
                            val novaDur = second.optDouble("end", 0.0) - second.optDouble("start", 0.0)
                            val gap = second.optDouble("start", 0.0) - first.optDouble("end", 0.0)
                            if (conf1 >= minPrefixConf && conf2 >= minNovaConf && novaDur >= 0.15 && gap <= 0.45) {
                                verified = true
                                break
                            }
                        }
                    }
                    if (!verified) return null to true
                }
                phrase to true
            } catch (_: Exception) {
                null to false
            }
        }
    }

    private fun resetVoskSpotter() {
        synchronized(voskLock) {
            runCatching { voskSpotter?.reset() }
        }
    }

    private fun matchSupportedMultiPhrase(txt: String): String? {
        val w = txt.trim().split(Regex("\\s+"))
        if (w.size < 2 || w.size > 3) return null
        for (i in 0 until w.size - 1) {
            val first = w[i]
            val second = w[i + 1]
            if (first in GRAMMAR_PREFIXES && second in GRAMMAR_NAMES) {
                return when (first) {
                    "okay", "ok" -> "Okay Nova"
                    "hello" -> "Hello Nova"
                    "hi" -> "Hi Nova"
                    "hey" -> "Hey Nova"
                    else -> null
                }
            }
        }
        return null
    }

    private fun runMel(audio: FloatArray): List<FloatArray>? {
        val e = env ?: return null
        val sess = melSession ?: return null
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(audio), longArrayOf(1L, audio.size.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(melInputName, tensor)).use { res ->
                    val out = res[0].value
                    val frames = ArrayList<FloatArray>(8)
                    @Suppress("UNCHECKED_CAST")
                    when (out) {
                        is Array<*> -> {
                            val d1 = out[0]
                            if (d1 is Array<*>) {
                                val d2 = d1[0]
                                if (d2 is Array<*>) {
                                    for (row in d2) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            frames.add(FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f })
                                        }
                                    }
                                } else if (d2 is FloatArray && d2.size == MEL_BINS) {
                                    for (row in d1) {
                                        if (row is FloatArray && row.size == MEL_BINS) {
                                            frames.add(FloatArray(MEL_BINS) { idx -> row[idx] / 10.0f + 2.0f })
                                        }
                                    }
                                }
                            }
                        }
                    }
                    frames
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runEmbedding(melBuffer: ArrayDeque<FloatArray>): FloatArray? {
        val e = env ?: return null
        val sess = embedSession ?: return null
        val flat = FloatArray(MEL_WINDOW * MEL_BINS)
        val start = melBuffer.size - MEL_WINDOW
        var idx = 0
        for (i in start until melBuffer.size) {
            System.arraycopy(melBuffer[i], 0, flat, idx, MEL_BINS)
            idx += MEL_BINS
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, MEL_WINDOW.toLong(), MEL_BINS.toLong(), 1L)).use { tensor ->
                sess.run(Collections.singletonMap(embedInputName, tensor)).use { res ->
                    extractFlatFloats(res[0].value, EMBED_DIM)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun runWakeClassifier(embedBuffer: ArrayDeque<FloatArray>): Float {
        val e = env ?: return 0f
        val sess = wakeSession ?: return 0f
        val flat = FloatArray(EMBED_WINDOW * EMBED_DIM)
        var idx = 0
        for (row in embedBuffer) {
            System.arraycopy(row, 0, flat, idx, EMBED_DIM)
            idx += EMBED_DIM
        }
        return try {
            OnnxTensor.createTensor(e, FloatBuffer.wrap(flat), longArrayOf(1L, EMBED_WINDOW.toLong(), EMBED_DIM.toLong())).use { tensor ->
                sess.run(Collections.singletonMap(wakeInputName, tensor)).use { res ->
                    extractFlatFloats(res[0].value, 1)?.firstOrNull() ?: 0f
                }
            }
        } catch (_: Exception) {
            0f
        }
    }

    private fun extractFlatFloats(value: Any?, expectedLen: Int): FloatArray? {
        val out = FloatArray(expectedLen)
        var pos = 0
        fun walk(v: Any?) {
            if (pos >= expectedLen || v == null) return
            when (v) {
                is Float -> out[pos++] = v
                is FloatArray -> {
                    val copy = minOf(v.size, expectedLen - pos)
                    System.arraycopy(v, 0, out, pos, copy)
                    pos += copy
                }
                is Array<*> -> for (item in v) walk(item)
            }
        }
        walk(value)
        return if (pos >= expectedLen) out else null
    }

    private fun ensureModelFile(dir: File, filename: String, downloadUrl: String?): File {
        val out = File(dir, filename)
        if (out.exists() && out.length() > 10_000L) return out

        val assetPath = "wake/$filename"
        val copied = try {
            context.assets.open(assetPath).use { input ->
                out.outputStream().buffered().use { output -> input.copyTo(output) }
            }
            out.exists() && out.length() > 10_000L
        } catch (_: Exception) {
            false
        }
        if (copied) return out

        if (downloadUrl == null) {
            throw IllegalStateException("Bundled $filename missing in assets/wake/")
        }
        val tmp = File(dir, "$filename.tmp")
        val conn = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 45000
            instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode} downloading $filename")
            }
            conn.inputStream.use { input ->
                tmp.outputStream().buffered().use { output -> input.copyTo(output) }
            }
        } finally {
            conn.disconnect()
        }
        if (!tmp.exists() || tmp.length() < 10_000L) {
            tmp.delete()
            throw IllegalStateException("$filename download incomplete")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        return out
    }
}
