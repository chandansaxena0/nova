package com.nova.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import kotlin.concurrent.thread

/**
 * Instant Live Camera Lens Vision Activity for Nova v11.0:
 *   - Captures a real photo via Android system camera (using FileProvider URI for high-res OCR/math/object clarity).
 *   - Analyzes handwritten notes, math equations, objects, or printed text with Multimodal Vision AI.
 *   - Speaks result aloud via ListenService (or displays interactive dialog) and keeps the photo loaded in FileAssistant.
 */
class CameraLensActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROMPT = "nova_lens_prompt"
    }

    private var captureUri: Uri? = null
    private var lensPrompt: String = "Explain clearly what is visible in this photo. If there is text or a math/study question, read and solve it step by step."

    private val cameraPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchCameraCapture()
            else {
                Toast.makeText(this, "Camera permission required for Nova Camera Lens.", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val takePictureLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            val uri = captureUri
            if (ok && uri != null) {
                analyzeCapturedPhoto(uri)
            } else {
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent.getStringExtra(EXTRA_PROMPT)?.takeIf { it.isNotBlank() }?.let { lensPrompt = it }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchCameraCapture()
        } else {
            cameraPermLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchCameraCapture() {
        try {
            val dir = File(cacheDir, "nova_lens").apply { mkdirs() }
            val photoFile = File(dir, "lens_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)
            captureUri = uri
            takePictureLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(this, "Camera Lens launch error: ${e.message?.take(80)}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun analyzeCapturedPhoto(uri: Uri) {
        Toast.makeText(this, "Nova Vision analyzing photo...", Toast.LENGTH_SHORT).show()
        NovaState.update(mode = ListenMode.PROCESSING, status = "Analyzing Camera Lens photo...", activeAgent = "Vision Lens")
        thread {
            val summary = FileAssistant.loadAndSummarize(this, uri)
            val finalReply = if (!lensPrompt.startsWith("Explain clearly what is visible")) {
                FileAssistant.answerQuestion(this, lensPrompt)
            } else {
                summary
            }
            SmartMemory.recordCommand(this, "Camera Lens: ${lensPrompt.take(40)}", finalReply)
            NovaState.update(heard = "Camera Lens", reply = finalReply, status = finalReply, activeAgent = "Vision Lens")
            NovaAppWidgetProvider.requestUpdate(this)

            runOnUiThread {
                if (ListenService.running) {
                    startService(
                        Intent(this, ListenService::class.java)
                            .setAction(ListenService.ACTION_SPEAK_ALERT)
                            .putExtra("message", finalReply.take(500))
                    )
                }
                AlertDialog.Builder(this)
                    .setTitle("Nova Camera Lens")
                    .setMessage(finalReply)
                    .setPositiveButton("Done") { _, _ -> finish() }
                    .setNeutralButton("Open Nova") { _, _ ->
                        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
                        finish()
                    }
                    .setOnCancelListener { finish() }
                    .show()
            }
        }
    }
}
