package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

data class VoiceMacro(val trigger: String, val actions: String)

object MacroStore {
    private const val PREF = "nova_voice_macros"
    private const val KEY = "macros_json"

    private val cancelWorkflowFlag = AtomicBoolean(false)

    fun cancelActiveWorkflow() {
        cancelWorkflowFlag.set(true)
    }

    fun all(context: Context): List<VoiceMacro> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]").orEmpty()
        val out = ArrayList<VoiceMacro>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optString("trigger", "").trim()
                val a = o.optString("actions", "").trim()
                if (t.isNotEmpty() && a.isNotEmpty()) out.add(VoiceMacro(t, a))
            }
        }
        return out
    }

    fun save(context: Context, trigger: String, actions: String): Boolean {
        val cleanTrigger = HinglishConverter.toHinglish(trigger).lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
        val cleanActions = HinglishConverter.toHinglish(actions).trim()
        if (cleanTrigger.length < 2 || cleanActions.length < 3) return false
        val list = all(context).filterNot { it.trigger.equals(cleanTrigger, ignoreCase = true) }.toMutableList()
        list.add(VoiceMacro(cleanTrigger, cleanActions))
        persist(context, list)
        return true
    }

    fun delete(context: Context, trigger: String) {
        val list = all(context).filterNot { it.trigger.equals(trigger, ignoreCase = true) }
        persist(context, list)
    }

    fun findMatch(context: Context, spoken: String): VoiceMacro? {
        val clean = HinglishConverter.toHinglish(spoken)
            .lowercase(Locale.ROOT)
            .replace(Regex("^(?:nova|hey nova|hello nova|hi nova|okay nova)\\s+"), "")
            .replace(Regex("[^a-z0-9\\s]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (clean.isEmpty()) return null
        return all(context).firstOrNull { m ->
            val t = m.trigger.lowercase(Locale.ROOT).trim()
            clean == t || clean == "$t chalu karo" || clean == "$t on karo" || clean == "run $t"
        }
    }

    fun parseDelaySeconds(step: String): Int? {
        val m = Regex("^(?:wait|delay|ruko)\\s+(\\d{1,2})\\s*(?:s|sec|secs|second|seconds)?$", RegexOption.IGNORE_CASE)
            .matchEntire(step.trim()) ?: return null
        return m.groupValues[1].toIntOrNull()?.coerceIn(1, 10)
    }

    fun evaluateCondition(step: String, batteryPct: Int, charging: Boolean, hourOfDay: Int, isOnline: Boolean): Pair<Boolean, String> {
        val m = Regex("^if\\s+(.+?)(?::|\\s+then\\s+)\\s*(.+)$", RegexOption.IGNORE_CASE).matchEntire(step.trim())
            ?: return true to step.trim()
        val cond = m.groupValues[1].lowercase(Locale.ROOT).trim()
        val action = m.groupValues[2].trim()

        val passed = when {
            cond.contains("battery") -> {
                val thresh = Regex("(\\d{1,3})").find(cond)?.groupValues?.get(1)?.toIntOrNull() ?: 25
                when {
                    cond.contains("<") || cond.contains("below") || cond.contains("kam") -> batteryPct in 0 until thresh
                    cond.contains(">") || cond.contains("above") || cond.contains("zyada") -> batteryPct > thresh
                    else -> batteryPct <= thresh
                }
            }
            cond.contains("not charging") -> !charging
            cond.contains("charging") -> charging
            cond.contains("night") || cond.contains("raat") -> hourOfDay >= 21 || hourOfDay < 6
            cond.contains("morning") || cond.contains("subah") -> hourOfDay in 5..11
            cond.contains("offline") -> !isOnline
            cond.contains("online") -> isOnline
            else -> true
        }
        return passed to action
    }

    fun hasSensitiveStep(actions: String): Boolean =
        Regex("\\b(call|dial|message|whatsapp|sms|emergency|112)\\b", RegexOption.IGNORE_CASE).containsMatchIn(actions)

    fun splitWorkflowSteps(actions: String): List<String> {
        val bySemi = actions.split(";").map { it.trim() }.filter { it.isNotEmpty() }
        if (bySemi.size >= 2) return bySemi.take(8)
        return UltimatePowerHelper.splitChainedCommands(actions)
    }

    fun executeWorkflow(
        context: Context,
        name: String,
        actions: String,
        stepRunner: (String) -> String
    ): String {
        cancelWorkflowFlag.set(false)
        val steps = splitWorkflowSteps(actions)
        val bat = PhoneInfoHelper.battery(context)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val online = PhoneInfoHelper.isOnline(context)

        val results = ArrayList<String>()
        var cancelled = false
        for (rawStep in steps) {
            if (cancelWorkflowFlag.get()) {
                cancelled = true
                results.add("Workflow cancelled.")
                break
            }
            val delaySec = parseDelaySeconds(rawStep)
            if (delaySec != null) {
                try {
                    for (tick in 0 until delaySec * 5) {
                        if (cancelWorkflowFlag.get()) {
                            cancelled = true
                            break
                        }
                        Thread.sleep(200)
                    }
                } catch (_: InterruptedException) {}
                if (cancelled) {
                    results.add("Workflow cancelled during wait.")
                    break
                }
                continue
            }

            val (shouldRun, cleanStep) = evaluateCondition(rawStep, bat.percent, bat.charging, hour, online)
            if (!shouldRun) {
                results.add("Skipped (${rawStep.take(30)}).")
                continue
            }

            var out = runCatching { stepRunner(cleanStep) }.getOrElse { "Error: ${it.message?.take(60)}" }
            if (NovaOrchestrator.classifyOutcome(out) == ActionStatus.FAILED && !cancelWorkflowFlag.get()) {
                runCatching { Thread.sleep(350) }
                out = runCatching { stepRunner(cleanStep) }.getOrElse { out }
            }
            results.add(out)
        }

        val combined = results.joinToString(" ")
        val status = if (cancelled) "CANCELLED" else "COMPLETED"
        runCatching { NovaMemoryDb.get(context).insertWorkflowRun(name, status, combined) }
        return combined
    }

    fun recentRunsSummary(context: Context): String {
        val runs = runCatching { NovaMemoryDb.get(context).getRecentWorkflowRuns(5) }.getOrDefault(emptyList())
        if (runs.isEmpty()) return "Abhi koi workflow run history record nahi hui hai."
        return "Recent Workflow Runs:\n" + runs.joinToString("\n") {
            "• ${it.name} [${it.status}] (${SmartMemory.formatTime(it.runAt)}): ${it.summary.take(70)}"
        }
    }

    private fun persist(context: Context, list: List<VoiceMacro>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().put("trigger", m.trigger).put("actions", m.actions))
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
