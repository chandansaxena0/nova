package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class VoiceMacro(val trigger: String, val actions: String)

/**
 * Custom Voice Shortcuts / Macros Store for Nova v9.0.
 * Example:
 *   Trigger: "night mode"
 *   Actions: "wifi off karo aur brightness 15 percent karo aur silent mode"
 * Saying "night mode" automatically expands and runs all chained actions!
 */
object MacroStore {
    private const val PREF = "nova_voice_macros"
    private const val KEY = "macros_json"

    fun all(context: Context): List<VoiceMacro> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]").orEmpty()
        val out = ArrayList<VoiceMacro>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optString("trigger", "").trim()
                val a = o.optString("actions", "").trim()
                if (t.isNotEmpty() && a.isNotEmpty()) out.add(VoiceMacro(t, a))
            }
        }
        return out
    }

    fun save(context: Context, trigger: String, actions: String): Boolean {
        val cleanTrigger = HinglishConverter.toHinglish(trigger).lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
        val cleanActions = HinglishConverter.toHinglish(actions).trim()
        if (cleanTrigger.length < 2 || cleanActions.length < 3) return false
        val list = all(context).filterNot { it.trigger.equals(cleanTrigger, ignoreCase = true) }.toMutableList()
        list.add(VoiceMacro(cleanTrigger, cleanActions))
        persist(context, list)
        return true
    }

    fun delete(context: Context, trigger: String) {
        val list = all(context).filterNot { it.trigger.equals(trigger, ignoreCase = true) }
        persist(context, list)
    }

    fun findMatch(context: Context, spoken: String): VoiceMacro? {
        val clean = HinglishConverter.toHinglish(spoken)
            .lowercase(Locale.ROOT)
            .replace(Regex("^(?:nova|hey nova|hello nova|hi nova|okay nova)\\s+"), "")
            .replace(Regex("[^a-z0-9\\s]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (clean.isEmpty()) return null
        return all(context).firstOrNull { m ->
            val t = m.trigger.lowercase(Locale.ROOT).trim()
            clean == t || clean == "$t chalu karo" || clean == "$t on karo" || clean == "run $t"
        }
    }

    private fun persist(context: Context, list: List<VoiceMacro>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().put("trigger", m.trigger).put("actions", m.actions))
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
