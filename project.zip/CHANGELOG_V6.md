# Changelog

## v6.4 — Reliability Foundation
- Bumped Android version to 6.4 (versionCode 10).
- Improved GitHub Actions project validation, Gradle caching, test-before-build sequence and APK artifact upload.
- Added optional persistent release signing through GitHub Actions secrets; no signing material is stored in source control.
- Removed CI model downloads that previously used `|| true`; optional wake-word backbone models continue to be provisioned by the app at runtime.
- Added honest implementation status and Nova AI 7.0 roadmap documents.

## v6.3 / v6.0
See repository history and previous changelog entries for existing assistant features.
