# Nova V6 update notes

## Implemented in this archive
- Standalone Nova wake-word recognition.
- Priority stop-command interception before AI resolution.
- 30-second command session default with automatic timeout refresh.
- 30/40-second duration preference storage.
- Hindi TTS acknowledgement and spoken result feedback.
- Model provisioning supports bundled Vosk assets or first-run official model download.
- Android app version incremented to 1.2 (versionCode 3), package ID retained.

## Not yet implemented / not verified
- Full conversational Gemini voice interface.
- Weather/daily briefing, reminders and alarm CRUD.
- Clipboard tools and smart memory management UI.
- Complete dashboard and user-facing session-duration setting.
- Full Roblox integration and robust general YouTube playback.
- Full device status and screen-time dashboard.

No APK build has been run in this environment because Android SDK and Gradle are not installed here. Use the repository's existing GitHub Actions workflow and verify its run before installing.
