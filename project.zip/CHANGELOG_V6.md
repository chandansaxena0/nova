# Nova v6.0 Master Update Changelog

## Reliability & Voice Recognition Upgrades
- Replaced legacy Hindi-only Vosk model with Indian-English Vosk (`vosk-model-small-en-in-0.4`) + constrained Wake/Stop grammar for first-try recognition of `Hey Nova`, `Hi Nova`, `Hello Nova`, `Okay Nova`, and `Nova`.
- Added 2-stage Hybrid Command Mode using Android `SpeechRecognizer` (`en-IN`) with automatic offline Vosk fallback — fixes misrecognitions like "MrBeast" -> "best clip" and forces clean Roman Hinglish for searches and WhatsApp messages.
- Fixed Priority #0 Stop interception so stop commands end the active 30/40s Command Session and return cleanly to Wake Mode instead of killing the service.
- Fixed Devanagari range check bug (`\u0900..\u097F`), TTS echo-prevention cooldown, and Gemini default model (`gemini-3.5-flash-lite`).
- Updated `versionCode = 6`, `versionName = "6.0"` with preserved `debug.keystore`.

## New Features Implemented
- Minimalist Nova v6 Adaptive App Icon (Deep Midnight Slate + 4-point Star + Sonic Halo).
- 3-Tab Material 3 Dashboard, Hub & Settings UI with live telemetry and 30s/40s session selector.
- On-demand Nearby Places with real distance + Google Maps route (0% background GPS usage).
- Weather (Open-Meteo) & Daily Briefing, Reminders & Alarms Manager, Smart Memory Manager, Phone Diagnostics (Battery Health, Storage, Wi-Fi, Bluetooth, Screen Time), Music/Volume Controls, Roblox Place ID Direct Launcher, WhatsApp Notification Reader & Confirmed Inline Reply, Clipboard/Study/Translation/Emergency tools.
- Automated JUnit Test Suite (`NovaUnitTests.kt`) executed in GitHub Actions CI.
