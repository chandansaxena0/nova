# Nova v11.0 Pro Changelog

(Smart Morning/Commute Alerts and Smart Location Geofencing were intentionally skipped as requested.)

- **Headset & Bluetooth Earbuds Auto-Actions (`HeadsetAutoReceiver.kt`):** Auto-launch favorite music app on earbuds connect + read incoming chat alerts aloud on earbuds.
- **Live Camera Lens Vision & Contextual Screen Overlay (`CameraLensActivity.kt` + `ScreenAnalyzer.kt`):**
  - Instant full-res Camera Lens capture (`"Camera se dekho"`, `"Ye kya likha hai"`) via `FileProvider` -> Vision AI explanation & math/notes solver.
  - Contextual Screen Overlay Translate (`"Isko translate karo"`) and Smart Reply Draft (`"Iska reply draft karo"`) with automatic clipboard copy.
- **True Two-Way Voice Mode (`ListenService.kt` + `InterviewVivaManager.kt`):**
  - Echo-safe Hands-Free Barge-In during long TTS replies on earbuds/headset (`"Ruko"`, `"Skip"`, `"Stop"`, `"Bas"`).
  - Interactive 5-question Viva & Interview Roleplay mode (Airforce/Defence, Physics/Maths, HR) with per-answer 10-point scoring and final scorecard.
- **Deep Call & Messaging Automation (`CallerAnnounceReceiver.kt` + `NovaNotificationListener.kt`):**
  - Incoming Caller ID voice announcement (Off / Earbuds Only / Always) + hands-free `"Call uthao"` / `"Call cut karo"` via `TelecomManager`.
  - Unread Message Digest (`"Kis-kis ke message aaye hain"`) grouped by sender with OTP masking.
- **Home Screen 4x2 Bento Glass Widget & Volume-Key Trigger (`NovaAppWidgetProvider.kt` + `NovaAccessibility.kt`):**
  - OLED 4x2 widget with 1-tap Talk (Lime), Camera Lens (Lavender), TV Mute (Pink), and live Expense + Next Reminder bar.
  - Optional Volume-Down long-press (~0.6s) hardware trigger via Accessibility key filtering.
- **Personal Multi-File Knowledge Base Vault (`KnowledgeBaseStore.kt` + `NovaMemoryDb.kt` v2):**
  - Permanently index multiple PDF/DOCX/XLSX/PPTX/CSV/MD/TXT documents into SQLite and query across all saved notes with `[Doc • Page/Section]` citations.
