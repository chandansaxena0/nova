# Nova v7.1 — GitHub APK setup

## What this package does

This package preserves the Android source modules from the supplied Nova project and improves the build pipeline. It updates the app version to 7.1, adds a CI-signed release variant for direct testing, runs unit tests, and builds both Debug and Release APKs.

The Release APK is signed with the Android **debug signing key** so it can be installed for testing. It is not suitable for Google Play publication or secure public distribution. Keep the signing key consistent if you need in-place upgrades.

## Upload from an Android phone

1. Download this ZIP.
2. Open `github.com/chandansaxena0/nova` and select the `main` branch.
3. Upload the ZIP to the repository root with the exact name `project.zip`, replacing the previous `project.zip`.
4. Commit the change.
5. Open the repository's **Actions** tab and open the latest **Nova Android APK Build** run.
6. Wait for the **Test and build installable APKs** job to finish successfully.
7. Open the completed run, scroll to **Artifacts**, and download `Nova-v7.1-Android-APKs`.
8. Extract the downloaded artifact ZIP. Install `app-debug.apk` or `app-release-unsigned.apk` only if the release APK is not present; the configured release variant should normally be signed and installable.

## Important: activate the updated workflow

GitHub executes workflow files committed in `.github/workflows/` in the repository. A workflow file that exists only *inside* `project.zip` is extracted on the runner after the workflow has already started.

Therefore, for the new Debug + Release pipeline to become active, also commit this package's `.github/workflows/android.yml` at the same path in the repository. If the repository's existing workflow already has the same content, no extra action is needed. The ZIP contains the updated workflow file.

## What this build does not promise

- A successful GitHub build is not the same as testing on a physical phone.
- Android may restrict always-on microphone, overlays, background work, accessibility, notification access, screen capture, and OEM auto-start behavior.
- Features requiring third-party API keys, paid quotas, server infrastructure, or provider approval need their own configuration.
- The project does not claim that all proposed advanced features (general autonomous app control, full-duplex audio, live camera vision, vector RAG, macro recording, wireless ADB, or automatic UPI actions) are fully implemented.

## Safe installation

Install the Debug APK first for validation. Do not uninstall an existing Nova build until you confirm the package name and signing certificate are compatible; Android will reject an in-place update if the signing key differs.
