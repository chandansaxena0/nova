# Nova v7.1 — Feature inventory and honest status

This inventory distinguishes code already present in the supplied source from build-pipeline changes and capabilities that still need development/device testing.

## Existing source modules retained

- Multi-phrase wake-word engine and wake/stop phrase detection.
- Foreground microphone listening service and diagnostics.
- Intent-first command parser and resolver.
- Multi-agent routing for phone, research, study, travel, memory, files, and daily planning.
- App indexing and app launching.
- Flashlight, phone information, settings shortcuts, timers, reminders, tasks, and planner storage.
- Gemini client and OpenAI-compatible provider client.
- SecureVault using Android Keystore encryption.
- Smart memory with sensitive-content filtering.
- Accessibility-based screen understanding and automation helpers.
- Notification listener and notification summarization helpers.
- File assistant for supported document/image formats.
- RailRadar helper, nearby-place helper, Roblox helper, math evaluator, voice flashcards, and follow-up tracking.
- Unit tests covering selected parser, routing, wake/stop, math, memory-safety, train parsing, and provider helper behavior.

## Added in this package

- App version bumped to 7.1.
- Release build type configured for direct test installation using the debug signing configuration.
- GitHub Actions pipeline runs unit tests, builds Debug and Release APK variants, and uploads artifacts.
- Workflow creates the Gradle Wrapper when the repository does not contain it, then uses `./gradlew`.
- JDK 17, Android SDK setup, Gradle caching, build timeout, and artifact retention configured.
- `SETUP_GITHUB.md` explains upload/build/download steps.
- This feature inventory documents implementation boundaries.

## Still incomplete or requiring separate implementation

| Capability | Status |
|---|---|
| General autonomous multi-app visual agent with reliable planning/loop control | Partial; not a universal app agent |
| True full-duplex barge-in while TTS speaks | Not verified / incomplete |
| Sentence-by-sentence streamed TTS | Not verified / incomplete |
| Floating orb with live waveform and action HUD | Partial overlay only |
| Live CameraX vision | Not implemented in the supplied source |
| Full screen capture analysis across apps | Partial; Accessibility/screen analysis is not unrestricted capture |
| Multi-provider automatic quota/key failover | Partial provider clients; no complete failover guarantee |
| Local vector RAG over all PDFs/screenshots/conversations | Not implemented |
| Proactive device-state and notification routines | Partial |
| Visual macro recorder/replayer | Not implemented |
| Cross-device wireless ADB bridge | Not implemented |
| Full spaced-repetition study coach | Partial voice flashcards |
| Safe UPI intent helper | Not implemented |
| Full privacy shield for every banking/password/incognito app | Partial privacy controls; needs device validation |
| Self-healing permission doctor | Partial diagnostics; not automatic permission granting |
| In-app GitHub release updater | Not implemented |

## Platform and safety limits

- Android does not allow an ordinary app to silently grant itself runtime permissions, accessibility access, notification access, overlay access, or battery-optimization exemptions.
- Android 14+ foreground-service and microphone restrictions can prevent unattended always-on listening in some states.
- Accessibility automation must respect app security surfaces and user confirmation. It must not enter UPI PINs, passwords, or approve payments/orders/deletions autonomously.
- Wireless ADB requires explicit pairing on the target device and cannot bypass Android security.
- API-key failover does not avoid provider quotas or billing requirements.
- Real-world reliability and battery use must be measured on the target Vivo device.
