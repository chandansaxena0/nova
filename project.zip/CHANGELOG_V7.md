# Nova V7.1 changes

- Voice input in the app's speech prompt now requests English (India), avoiding Devanagari output from Android's speech recognizer.
- Wake-word speech results from the bundled Hindi Vosk model are transliterated into Roman characters before command parsing.
- Microphone recognition is stopped before Nova speaks an acknowledgement or command result.
- Recognition restarts only after the active Nova utterance finishes, followed by a short 450 ms cooldown.
- App version bumped to 1.3 (versionCode 4).

Notes:
- Roman transliteration is approximate; it cannot correct every speech-recognition mistake or preserve every proper noun.
- Hindi spoken replies remain enabled. The change is to recognized/displayed command text, not the TTS reply language.
- This source archive has not been compiled into an APK in this environment. Run the included GitHub Actions workflow to verify the build on GitHub.
