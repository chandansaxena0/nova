# Nova v7.0 Changelog (versionCode = 10)

## Phase 1: Critical Fixes
- **True Multi-Phrase Wake Detection**: Upgraded `OpenWakeWordEngine` to a single-`AudioRecord` dual-stage pipeline combining `hey_nova.onnx` (neural, with 16-frame warmup & 2-frame confirmation) and a VAD-gated constrained-grammar Vosk spotter (`Hey Nova`, `Hi Nova`, `Okay Nova`) with configurable sensitivity slider and spoken wake response.
- **Background Service Reliability**: Safe `START_STICKY` (when enabled) / `START_NOT_STICKY` (when OFF or Privacy Paused), `AudioRecordingCallback` mic-conflict pause/auto-resume, mic permission revocation detection, `NovaDiagnostics` live health + battery delta + exact failure reason, and Vivo/iQOO OriginOS background setup guide.
- **Command Routing Fix**: Removed `"sunao"` from generic media play verbs so `"Nova kahani sunao"`, `"Nova joke sunao"`, and `"Nova shayari sunao"` generate and narrate via AI/TTS (with offline fallbacks) instead of opening YouTube; unknown commands now clarify instead of randomly launching Google/YouTube.

## Phases 2–9: Multi-Agent Brain, Automation, Files, Daily Planner & Dark UI
- Added 8 specialized agents (`MainAssistantAgent`, `PhoneAgent`, `ResearchAgent`, `StudyAgent`, `TravelAgent`, `MemoryAgent`, `FileAgent`, `DailyPlannerAgent`).
- Added `PhoneControlHelper` (Flashlight via `CameraManager` + honest Settings page launchers), `TimerManager`/`TimerReceiver`, `DailyPlannerStore` (Tasks, Routines, Calendar), `FileAssistant` (PDF/TXT/DOCX/Image), `ScreenAnalyzer`, `WebResearchHelper` (Google Search Grounding + Wikipedia/DuckDuckGo sources), and upgraded `NovaNotificationListener` (grouping, importance, summarization, OTP masking).
- Upgraded `SmartMemory` with edit support, relevance retrieval, and sensitive-info filtering; added `SecureVault` (Android Keystore AES-256-GCM) for API keys.
- Redesigned UI to a battery-efficient dark Material 3 interface with zero continuous screen animations.


## v7.1 — Build pipeline and delivery
- Preserved the supplied Nova v7.0 Kotlin modules and resources.
- Added a CI test + Debug + Release build pipeline.
- Added CI Gradle Wrapper generation when wrapper files are absent.
- Added GitHub setup guide and feature implementation boundaries.
