# Nova Assistant v6.0

Smart, fast, Hinglish-first Personal AI Voice Assistant for Android.

## What's New in v6.0
- **Hybrid 2-Stage Voice Engine**:
  - **Wake Mode**: Offline Vosk Indian-English (`vosk-model-small-en-in-0.4`) with constrained wake/stop grammar + fast partial trigger for **Hey Nova, Hi Nova, Hello Nova, Okay Nova, Nova**.
  - **Command Mode (30s / 40s configurable)**: High-accuracy Android `SpeechRecognizer` (`en-IN`) for clean Roman Hinglish searches & WhatsApp typing (`MrBeast`, `Roblox`, Hinglish sentences), with automatic offline Vosk fallback.
- **Priority #0 Stop Interception**: `Stop`, `Stop Listening`, `Nova Stop`, `Nova Band Ho Jao`, `Band Karo`, `Band Ho Jao`, `Listening Band Karo`, `Bas Nova` intercept immediately and return Nova to Wake Mode cleanly.
- **Zero-Background-Drain Nearby Places**: On-demand one-shot GPS + OpenStreetMap Overpass API calculates real distance to the nearest Petrol Pump, Hospital, ATM, Railway Station, Medical Store, or Restaurant and opens Google Maps navigation.
- **Safety Confirmations**: Calls, WhatsApp/SMS sends, WhatsApp replies, duplicate contacts, similar apps, and emergency location sharing all ask for confirmation first.
- **Full Feature Hub**: Gemini AI (`gemini-2.5-flash`) with multi-turn context, Roblox Game ID launcher, Reminders/Alarms CRUD, Weather & Daily Briefing, Phone Diagnostics, Clipboard Assistant, Study & Translation Helper, Smart Memory, Emergency 112/SOS, and Minimalist Nova v6 App Icon.

## Build on GitHub Actions
Upload `project.zip` to your repository root (or push extracted files) and trigger the included `.github/workflows/android.yml` workflow. It automatically runs `:app:testDebugUnitTest` and builds `Nova-v6-debug-apk` signed with your existing `debug.keystore` so v6 installs smoothly over v5.
