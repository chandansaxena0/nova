# Nova Assistant

Android voice assistant project.

## V7.1 updates
- Speech input requests English (India) for Latin-script recognition.
- Hindi Vosk wake-listener transcripts are transliterated to Roman text.
- Mic capture pauses during Nova's spoken responses and resumes after speech completion plus a short cooldown.

## Build
Use the repository's GitHub Actions workflow to build the debug APK. This ZIP is source code, not an APK.
