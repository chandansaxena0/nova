# Nova Assistant v6.4 — Reliability Foundation

Nova is an Android voice-assistant project built with Kotlin. This package preserves the existing v6.3 feature implementation and adds a safer GitHub Actions build/signing workflow as the first reliability-focused update.

## Important: what this ZIP does and does not contain

This is **not yet the complete Nova AI 7.0 roadmap implementation**. It keeps the current app features and prepares a more reliable build/release path. Advanced multi-agent orchestration, true screen-vision analysis, document AI, proactive planning, and the expanded offline AI system are planned but are not falsely presented as finished features.

## Existing features in the source

- Wake/stop phrase handling and voice listening service.
- Hinglish conversion and local command parsing.
- Gemini-backed chat/command resolution (requires a valid API key and currently supported model).
- App launching, selected phone controls, contacts/call/message flows with confirmations.
- Reminders, alarms, memory, follow-up tracking and voice flashcards.
- Nearby-place lookup, weather-related flows and RailRadar integration (requires a working provider endpoint/API key).
- Accessibility-based UI interaction and notification-listener integration (requires the user to enable those Android services).
- Roblox launch helper, calculator, study and translation helpers.

Feature availability depends on Android version, OEM restrictions, permissions, network access, API credentials and the target app's UI.

## Build APK on GitHub

1. Create/open a GitHub repository.
2. Extract this ZIP and upload **the contents** to the repository root, keeping `.github/workflows/android.yml` and `app/` in place. Alternatively, upload this ZIP as `project.zip` in the repository root; the workflow can extract it.
3. Push to `main`, `master` or `nova-v6`, or run **Actions → Nova Android APK → Run workflow**.
4. Open the completed workflow run and download the `Nova-Android-APK-v6.4` artifact.
5. Extract the downloaded artifact to get the APK.

The workflow runs `:app:testDebugUnitTest` before building. It does not download optional ONNX backbone models during CI because the app already provisions those models at runtime; this avoids silently ignoring failed model downloads during an APK build.

## APK signing and updating an existing installation

Without signing secrets, GitHub builds a **debug-signed APK**. It may not install over an APK signed with a different key. Do not uninstall your current Nova if you need its local data; first check whether the new APK installs as an update.

For stable release signing, create a keystore and add these GitHub Actions repository secrets:

- `NOVA_KEYSTORE_BASE64` — base64-encoded keystore file.
- `NOVA_KEYSTORE_PASSWORD` — keystore password.
- `NOVA_KEY_ALIAS` — key alias.
- `NOVA_KEY_PASSWORD` — key password.

Keep the keystore and passwords private and backed up. Never commit them to GitHub. If you already have a signing key used for the installed Nova, use that exact key; a new key will not update the existing installation.

## Required API configuration

- Gemini: configure a valid Gemini API key and a model currently available to that key/account.
- RailRadar: configure a valid API key and the provider's correct base URL.

API keys stored by the current app are not yet protected by a complete Android Keystore-backed encrypted-storage migration. Avoid sharing your APK or device data with untrusted people.

## Android permissions and limitations

Microphone, notification access, accessibility, contacts, phone, SMS, location, exact alarms and other capabilities require the relevant Android permissions/settings. Android 14+ restricts starting microphone foreground services from the background; after reboot, user action may be needed to resume wake-word listening. OEM battery management can also stop background services.

## Version

- `versionCode`: 10
- `versionName`: 6.4
- `compileSdk`: 35
- `targetSdk`: 35
- Java/Kotlin target: 17

See `NOVA_AI_7_ROADMAP.md` and `IMPLEMENTATION_STATUS.md` before treating planned capabilities as implemented.
