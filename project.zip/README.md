# Nova AI Assistant v7.2

Battery-efficient, multi-agent Android personal AI assistant supporting Hindi, Hinglish, and English voice commands (online + offline hybrid).

## Key Capabilities in v7.0
- **Multi-Phrase Wake Word Engine (`OpenWakeWordEngine`)**: Single low-battery 16 kHz AudioRecord running `hey_nova.onnx` (neural) + VAD-gated constrained-grammar Vosk (`"Hey Nova"`, `"Hi Nova"`, `"Okay Nova"`), with sensitivity control and spoken acknowledgment (`"Yes, I'm listening."`).
- **Reliable Foreground Microphone Service (`ListenService`)**: Uses `START_STICKY` when wake is enabled, `START_NOT_STICKY` when disabled/paused, `AudioRecordingCallback` mic-conflict detection, permission revocation checks, Vivo/iQOO battery & autostart setup guide, and honest live diagnostics (`NovaDiagnostics`).
- **Intent-First Command Understanding**: Fixes `"Nova kahani sunao"` / `"Nova joke sunao"` / `"Nova shayari sunao"` so they generate and narrate via AI/TTS instead of opening YouTube, while `"YouTube par kahani search karo"` opens YouTube search and unknown commands ask for clarification rather than blindly launching Google/YouTube.
- **8-Agent Architecture (`NovaAgents`)**: Main Assistant, Phone, Research, Study, Travel, Memory, File, and Daily Planner agents selected automatically.
- **Phone Control, Files, Screen & Daily Planner**: Flashlight (`CameraManager`), Android Settings shortcuts, real Countdown Timers (`TimerManager`), Notification Intelligence (grouped + summarized + OTP-masked), PDF/TXT/DOCX/Image File Assistant, Screen Understanding (Accessibility + image), Tasks, Routines, Calendar, RailRadar Live Train Status, Travel Checklist, and Voice Flashcards.
- **Security & Dark Minimal UI**: Hardware-backed Android Keystore AES-256-GCM encryption (`SecureVault`) for API keys, Privacy Pause Everything switch, sensitive-memory filter, and OLED-friendly zero-animation dark UI.

## Build via GitHub Actions
Upload `project.zip` to your repository root and run `.github/workflows/android.yml`. It bundles `melspectrogram.onnx` + `embedding_model.onnx`, executes `:app:testDebugUnitTest`, and produces `Nova-v7.0-debug-apk`.


## v7.2 changes
- Vosk wake fallback now requires a Nova-like second word; saying only “Hello” will not activate Nova.
- OLED-friendly black UI refreshed with neon-lime and lavender accents, greeting, and a lightweight vector orb.
- Existing view IDs and navigation are preserved.
