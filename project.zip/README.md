# Nova Assistant V6 project

This ZIP contains the Android project at its root (not inside an extra parent folder).

## Easiest GitHub update path for this repository
Your repository already has a GitHub Actions workflow that reads `project.zip`, extracts it, downloads the Hindi Vosk model, and builds the APK. To use that existing workflow:
1. Replace the existing `project.zip` in the repository root with this ZIP, keeping the exact filename `project.zip`.
2. Commit the change to `main`.
3. Open GitHub → Actions → latest “Build Nova APK” run.
4. Wait for a successful run, then download the APK from the created Release.

Do not upload this ZIP as a nested folder. Replace the repository's existing `project.zip` file.

## Build configuration
- Application ID remains `com.nova.assistant`.
- Version: `1.2` / versionCode `3`.
- `app/debug.keystore` is retained for compatibility with earlier debug builds signed by the same key.
- The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, JDK 17 and compileSdk 35.

## Changes in this update
- Added standalone `Nova` wake phrase alongside existing Hey/Hi/Hello-style phrase recognition.
- Intercepts spoken stop phrases before Gemini/command resolution: Stop, Stop Listening, Nova Stop, Nova Band Ho Jao, Band Karo, Band Ho Jao, Listening Band Karo and Bas Nova.
- Default command session is now 30 seconds and refreshes after commands. Preference storage supports 30/40-second values.
- Added Hindi Text-to-Speech acknowledgements and spoken command results.
- ModelFiles now uses the bundled `assets/model` when the build workflow supplies it; otherwise it downloads the official small Hindi Vosk model on first start.

## Important limitations — read before installing
This is an incremental V6 foundation, **not every previously discussed feature is complete**. Existing code includes app launch/search/play, contacts/calls, messaging/reply integration, Gemini command interpretation and Accessibility-based UI actions. Full conversational Gemini voice chat, weather briefing, reminders/alarm manager, clipboard tools, smart-memory UI, complete dashboard/settings UI, and robust YouTube/Roblox integrations still need further implementation and testing.

Android may restrict background microphone use, app launching, calls, messages and notification replies. Nova needs the relevant permissions enabled by the user. If the previous installed APK was signed with a different key, Android will reject an in-place update. Do not uninstall the old app unless you have confirmed signing compatibility and backed up any data you need.

The debug keystore is for test/debug builds only; do not use it as a production Play Store signing key.
