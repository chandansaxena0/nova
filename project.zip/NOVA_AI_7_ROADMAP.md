# NOVA AI 7.0 — Implementation Roadmap

Goal: complete personal AI assistant with hybrid offline/online operation. Work incrementally; do not expose a feature as enabled until implementation, permissions, tests and device validation are complete.

## P0 — Reliability (first release gate)
- Build reproducibility, persistent signing, CI tests and artifact retention.
- Central diagnostics, structured logs and crash/error recovery.
- Voice-service lifecycle, mic permission checks, audio-resource cleanup and battery tests.
- API timeout/retry/rate-limit handling and explicit unavailable-state messaging.
- Action verification for high-impact operations.

## P1 — AI brain and memory
- Provider abstraction and capability-aware model router.
- Conversation/session manager with explicit context boundaries.
- Memory categories, user review/edit/delete, retention controls and encrypted local storage.
- Confidence/uncertainty handling and grounded source citations for web research.
- Durable task state and safe tool registry.

## P2 — Agent system
- Main orchestrator plus Research, Study, Phone, Travel, Memory and Planning agents.
- Typed tool schemas, bounded step counts, timeouts, cancellation and audit log.
- Permission gate before calls, messages, purchases, sharing, deletion or other consequential actions.
- Resume/retry only when idempotent; verify every action's actual result.

## P3 — Vision and files
- Explicit-consent screen capture using Android-supported APIs.
- On-device redaction where possible; disclose before sending screen content to a cloud model.
- OCR, screenshot understanding, PDF/document parsing and user-selected file indexing.
- Never scrape private app content or transmit it silently.

## P4 — Proactive assistant
- User-configured routines, daily briefing, reminders and task tracking.
- Notification summarization with opt-in, local-first processing and per-app controls.
- Quiet hours, rate limits and easy pause/disable controls.

## P5 — Hybrid offline/online
- Reliable local command set and offline speech recognition.
- Optional small on-device language model only after measuring RAM, storage, latency and battery on target devices.
- Automatic online fallback with clear offline/online status.
- Never claim cloud-level reasoning while offline.

## P6 — UX and release
- Dashboard for voice state, model/provider health, memory, agents, tools and audit history.
- Privacy dashboard, permission health and API usage diagnostics.
- Accessibility, localization, performance and battery tests across supported Android versions/OEMs.

## Definition of done for every feature
1. User-visible setting and permission explanation.
2. Real implementation (not placeholder UI or empty classes).
3. Unit tests for parsing/state/logic.
4. Instrumented or manual test on a real device for Android-specific behavior.
5. Failure, cancellation, privacy and recovery behavior documented.
6. Feature status updated honestly.
