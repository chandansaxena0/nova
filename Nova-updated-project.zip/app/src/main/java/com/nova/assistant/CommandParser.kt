package com.nova.assistant

enum class Kind { OPEN, SEARCH, PLAY, CALL, MESSAGE, REPLY, AGENT, UNKNOWN }

data class Command(
    val kind: Kind,
    val app: AppInfo?,
    val query: String,
    val heard: String,
    val contact: String = "",     // person to call / message / reply to (as spoken)
    val contactKey: String = "",  // same, normalized Latin letters for matching
    val body: String = "",        // message text, or the goal for the screen agent
    val sms: Boolean = false      // user asked for SMS specifically
)

/** text = what we show / search for. m = Latin form used for matching verbs and app names. */
data class Tok(val text: String, val m: String, val orig: String = text)

/**
 * Understands commands in English, Hindi and Hinglish WITHOUT any internet or AI service.
 * Idea: find the verb (open / search / play), find which installed app is named,
 * and treat whatever words are left as the thing to search or play.
 * Also detects the wake phrase ("Hey Nova" / "Hi Nova").
 */
class CommandParser(private val index: AppIndex) {

    // Multi-word names -> one word (applied first)
    private val phrases = listOf(
        "फोन पे" to "phonepe",
        "mr beast" to "MrBeast",
        "mister beast" to "MrBeast",
        "गूगल पे" to "google pay",
        "यू ट्यूब" to "youtube",
        "गूगल मैप्स" to "maps",
        "गूगल मैप" to "maps",
        "you tube music" to "youtube music",
        "you tube" to "youtube",
        "google maps" to "maps",
        "google map" to "maps",
        "whats app" to "whatsapp",
        "what s app" to "whatsapp",
        "play store" to "playstore",
        "jio saavn" to "jiosaavn",
        "jio savan" to "jiosaavn",
        "phone pe" to "phonepe",
        "pay tm" to "paytm",
        "face book" to "facebook",
        "insta gram" to "instagram",
        "tele gram" to "telegram"
    )

    // Hindi (Devanagari) word -> Latin word. Voice typing in Hindi often gives these.
    private val words = mapOf(
        // actions
        "ओके" to "okay", "ओकेय" to "okay", "हाय" to "hi", "हेलो" to "hello", "हैलो" to "hello", "हलो" to "hello", "हे" to "hey", "नोवा" to "nova",
        "मिस्टर" to "mr", "बीस्ट" to "beast", "बेस्ट" to "best", "क्लिप" to "clip",
        "स्टॉप" to "stop", "लिसनिंग" to "listening", "बंद" to "band", "हो" to "ho", "जाओ" to "jao", "सुनना" to "sunna",
        "खोलो" to "kholo", "खोल" to "khol", "खोलिए" to "kholo", "ओपन" to "open",
        "चलाओ" to "chalao", "चला" to "chala", "चलाइए" to "chalao",
        "बजाओ" to "bajao", "बजा" to "baja", "सुनाओ" to "sunao", "सुना" to "suna",
        "लगाओ" to "lagao", "लगा" to "laga", "प्ले" to "play",
        "सर्च" to "search", "ढूंढो" to "dhundo", "ढूँढो" to "dhundo",
        "खोजो" to "khojo", "दिखाओ" to "dikhao",
        // call / message / reply
        "कॉल" to "call", "रिप्लाई" to "reply", "जवाब" to "jawab",
        "भेजो" to "bhejo", "भेज" to "bhej", "लिखो" to "likho",
        "बोलो" to "bolo", "कहो" to "bolo", "कि" to "ki",
        // small words
        "पर" to "par", "पे" to "pe", "में" to "me", "से" to "se",
        "का" to "ka", "की" to "ki", "के" to "ke", "को" to "ko",
        "करो" to "karo", "कर" to "kar", "दो" to "do", "दे" to "de",
        "और" to "aur", "एक" to "ek", "ऐप" to "app", "एप" to "app", "ऐप्प" to "app",
        "गाना" to "gaana", "गाने" to "gaane", "गीत" to "gaane",
        "वीडियो" to "video", "म्यूजिक" to "music", "संगीत" to "music",
        // apps
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सऐप" to "whatsapp",
        "वॉट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "यूट्यूब" to "youtube", "स्पॉटिफाई" to "spotify", "स्पोटिफाई" to "spotify",
        "स्पोटीफाई" to "spotify", "इंस्टाग्राम" to "instagram", "गूगल" to "google",
        "क्रोम" to "chrome", "मैप्स" to "maps", "मैप" to "maps", "नक्शा" to "maps",
        "फेसबुक" to "facebook", "टेलीग्राम" to "telegram", "पेटीएम" to "paytm",
        "फोनपे" to "phonepe", "जीपे" to "google pay", "अमेज़न" to "amazon",
        "अमेजन" to "amazon", "अमेज़ॉन" to "amazon", "फ्लिपकार्ट" to "flipkart",
        "नेटफ्लिक्स" to "netflix", "जियोसावन" to "jiosaavn", "कैमरा" to "camera",
        "सेटिंग" to "settings", "सेटिंग्स" to "settings", "कैलकुलेटर" to "calculator",
        "गैलरी" to "gallery", "फोटो" to "photos", "फोटोज" to "photos", "घड़ी" to "clock",
        "मैसेज" to "messages", "मैसेजेस" to "messages", "फोन" to "phone",
        "जीमेल" to "gmail", "ड्राइव" to "drive", "स्नैपचैट" to "snapchat",
        "ट्विटर" to "twitter", "ज़ोमैटो" to "zomato", "जोमैटो" to "zomato",
        "स्विगी" to "swiggy", "ओला" to "ola", "उबर" to "uber",
        "लिंक्डइन" to "linkedin", "शेयरचैट" to "sharechat", "हॉटस्टार" to "hotstar"
    )

    private val playVerbs = setOf(
        "play", "chalao", "chala", "chalaiye", "bajao", "baja",
        "sunao", "suna", "lagao", "laga", "chalado"
    )
    private val searchVerbs = setOf(
        "search", "dhundo", "dhoondo", "dhundh", "khojo", "khoj",
        "find", "dikhao", "dikha", "lookup"
    )
    private val openVerbs = setOf(
        "open", "kholo", "khol", "khole", "kholiye", "launch", "start", "chalu", "shuru"
    )
    private val preps = setOf(
        "par", "pe", "me", "mein", "mai", "on", "in", "se", "per",
        "ke", "ki", "ka", "ko", "for", "liye"
    )
    private val fillers = setOf(
        "karo", "kar", "kardo", "karna", "do", "de", "dena", "dijiye", "please", "plz",
        "zara", "mujhe", "mere", "meri", "mera", "app", "application", "aur", "and",
        "the", "a", "ek", "hai", "wala", "wali", "wale", "to", "na", "ya", "jo",
        "kuch", "bhi", "ab", "abhi", "can", "you", "i", "want", "ji",
        "hey", "hi", "he", "hay", "hello", "helo", "nova"
    )
    // Words that describe the request but are not the name of the song/thing itself
    private val weak = setOf(
        "gaana", "gaane", "gana", "gane", "song", "songs",
        "music", "video", "videos", "vedio", "gaano"
    )

    private val stop: Set<String> = playVerbs + searchVerbs + openVerbs + preps + fillers

    // ---- wake phrase: "<hey-like word> nova" ----
    private val heyWords = setOf(
        "hey", "hi", "he", "hay", "hai", "hello", "helo", "hallo", "hye", "haye", "hae", "ae", "ay", "oye",
        "okay", "ok", "oke", "okk"
    )
    private val novaLike = setOf("nova", "nowa", "nava", "novo", "noba", "norva", "novaa", "noua")

    private fun isNova(m: String): Boolean =
        m.length >= 3 && (m in novaLike || Normalizer.levenshtein(m, "nova") <= 1)

    /**
     * If the text starts a wake phrase, returns the words spoken AFTER it
     * (maybe an empty string). Returns null if there is no wake phrase.
     */
    fun stripWake(raw: String): String? {
        val toks = tokenize(raw)
        for (i in toks.indices) {
            val m = toks[i].m
            // A standalone "Nova" is supported as requested. This can cause an occasional
            // false activation if the name is spoken in ordinary conversation.
            if (i == 0 && isNova(m)) return toks.drop(i + 1).joinToString(" ") { it.text }
            if (i > 0 && isNova(m) && toks[i - 1].m in heyWords) {
                return toks.drop(i + 1).joinToString(" ") { it.text }
            }
            for (h in listOf("hello", "hey", "hay", "hi", "he", "hai", "okay", "ok")) {
                if (m.startsWith(h) && isNova(m.removePrefix(h))) {
                    return toks.drop(i + 1).joinToString(" ") { it.text }
                }
            }
        }
        return null
    }

    // ---- call / message / reply ----
    private val callWords = setOf("call", "dial", "calling", "kol")
    private val replyWords = setOf("reply", "replay", "jawab", "jawaab", "jabab")
    private val msgWords = setOf("message", "messages", "msg", "text", "sms", "sandesh")
    private val sendVerbs = setOf("bhejo", "bhej", "send", "likho", "bolo", "bol", "batao")
    private val bodyMarkers = setOf("ki", "that", "saying")
    private val phoneDo = setOf("lagao", "laga", "karo", "kar", "kardo", "milao", "mila")
    private val videoWords = setOf("video", "videos", "vedio")
    private val verbBlock: Set<String> =
        replyWords + msgWords + sendVerbs + setOf("karo", "kar", "kardo", "do", "de", "dena", "dijiye", "please", "plz")

    /** Calls, messages and replies. Returns null if the words are not about those. */
    private fun special(tokens: List<Tok>, raw: String): Command? {
        val ms = tokens.map { it.m }
        if (ms.isEmpty()) return null
        val firstOpen = ms.indexOfFirst { it in openVerbs }
        val hasKo = "ko" in ms

        // reply
        if (ms.any { it in replyWords }) return messageLike(Kind.REPLY, tokens, raw)

        val callIdx = ms.indexOfFirst { it in callWords }
        val msgIdx = ms.indexOfFirst { it in msgWords || it in sendVerbs }
        val hasSend = ms.any { it in sendVerbs }
        val msgLike = msgIdx >= 0 && (hasKo || hasSend) && (firstOpen < 0 || msgIdx < firstOpen)

        // message first: "Rahul ko sms bhejo ki call kar do"
        if (msgLike && (callIdx < 0 || msgIdx < callIdx)) return messageLike(Kind.MESSAGE, tokens, raw)

        // call: "Rahul ko call karo", "call Rahul", "Mummy ko phone lagao"
        val phoneCall = "phone" in ms && hasKo && ms.any { it in phoneDo } && firstOpen < 0
        if ((callIdx >= 0 && (firstOpen < 0 || callIdx < firstOpen)) || phoneCall) {
            val skip = stop + callWords + weak + setOf("phone", "ko")
            val nameToks = tokens.filter { it.m !in skip }
            return Command(
                Kind.CALL, null, "", raw,
                contact = nameToks.joinToString(" ") { it.orig },
                contactKey = Normalizer.key(nameToks.joinToString("") { it.m })
            )
        }

        return null
    }

    /** Splits "<who> ko <app> par message bhejo ki <text>" into contact, app and body. */
    private fun messageLike(kind: Kind, tokens: List<Tok>, raw: String): Command {
        val ms = tokens.map { it.m }
        val nameEnd = ms.indexOfFirst { it == "ko" || it == "ke" }
        val from = if (nameEnd >= 0) nameEnd + 1 else 0

        var bodyStart = -1
        val ki = (from until ms.size).firstOrNull { ms[it] in bodyMarkers }
        if (ki != null) {
            bodyStart = ki + 1
        } else {
            val v = (from until ms.size).firstOrNull { ms[it] in verbBlock }
            if (v != null) {
                var k = v
                while (k < ms.size && ms[k] in verbBlock) k++
                bodyStart = k
            }
        }
        if (bodyStart < 0) bodyStart = ms.size

        val head = tokens.subList(0, bodyStart)
        val body = tokens.drop(bodyStart).joinToString(" ") { it.orig }
        val (app, range) = findApp(head, verbBlock)

        val nameBase = if (nameEnd >= 0) tokens.subList(0, nameEnd) else head
        val nameToks = nameBase.withIndex()
            .filter { (i, t) ->
                i !in range && t.m !in stop && t.m !in verbBlock && t.m !in weak &&
                    t.m !in bodyMarkers && t.m != "ko" && t.m != "ke"
            }
            .map { it.value }

        return Command(
            kind, app, "", raw,
            contact = nameToks.joinToString(" ") { it.orig },
            contactKey = Normalizer.key(nameToks.joinToString("") { it.m }),
            body = body,
            sms = ms.any { it == "sms" }
        )
    }

    /** Best matching installed app inside a list of words. */
    private fun findApp(tokens: List<Tok>, skip: Set<String> = emptySet()): Pair<AppInfo?, IntRange> {
        var app: AppInfo? = null
        var bestScore = 0.0
        var range: IntRange = IntRange.EMPTY
        for (start in tokens.indices) {
            if (tokens[start].m in stop || tokens[start].m in skip) continue
            var joined = ""
            for (end in start until minOf(tokens.size, start + 3)) {
                if (tokens[end].m in stop || tokens[end].m in skip) break
                joined += tokens[end].m
                val match = index.bestMatch(Normalizer.key(joined)) ?: continue
                if (match.second < 0.85) continue
                var s = match.second + 0.001 * (end - start)
                if (start > 0 && tokens[start - 1].m in preps) s += 0.05
                if (end + 1 < tokens.size && tokens[end + 1].m in preps) s += 0.05
                if (s > bestScore) {
                    bestScore = s
                    app = match.first
                    range = start..end
                }
            }
        }
        return app to range
    }

    fun parse(raw: String): Command {
        val tokens = tokenize(raw)
        special(tokens, raw)?.let { return it }

        var kind = when {
            tokens.any { it.m in playVerbs } -> Kind.PLAY
            tokens.any { it.m in searchVerbs } -> Kind.SEARCH
            tokens.any { it.m in openVerbs } -> Kind.OPEN
            else -> Kind.UNKNOWN
        }

        // Find the app name: the best matching group of 1 to 3 words
        var app: AppInfo? = null
        var bestScore = 0.0
        var appRange: IntRange = IntRange.EMPTY
        for (start in tokens.indices) {
            if (tokens[start].m in stop) continue
            var joined = ""
            for (end in start until minOf(tokens.size, start + 3)) {
                if (tokens[end].m in stop) break
                joined += tokens[end].m
                val match = index.bestMatch(Normalizer.key(joined)) ?: continue
                if (match.second < 0.85) continue
                var s = match.second + 0.001 * (end - start)
                if (start > 0 && tokens[start - 1].m in preps) s += 0.05
                if (end + 1 < tokens.size && tokens[end + 1].m in preps) s += 0.05
                if (s > bestScore) {
                    bestScore = s
                    app = match.first
                    appRange = start..end
                }
            }
        }

        // "<song> video chalao" with no app named: use YouTube
        if (kind == Kind.PLAY && app == null && tokens.any { it.m in videoWords }) {
            app = index.apps.firstOrNull { it.pkg == "com.google.android.youtube" }
        }

        // Everything that is not the app, a verb or a filler = what to search / play
        val query = tokens.withIndex()
            .filter { (i, t) -> i !in appRange && t.m !in stop && t.m !in weak }
            .joinToString(" ") { it.value.text }

        if (kind == Kind.UNKNOWN) {
            kind = when {
                app != null && query.isEmpty() -> Kind.OPEN
                app != null -> Kind.SEARCH
                else -> Kind.UNKNOWN
            }
        }

        // For "open": try a looser match if nothing matched well
        if (kind == Kind.OPEN && app == null) {
            val key = Normalizer.key(tokens.filter { it.m !in stop }.joinToString("") { it.m })
            val m = index.bestMatch(key)
            if (m != null && m.second >= 0.6) app = m.first
        }

        return Command(kind, app, query, tokens.joinToString(" ") { it.text })
    }

    /**
     * Convert Hindi-script recognition output to Roman Hinglish before parsing or
     * sending text to Search/WhatsApp. Latin words keep their original casing so
     * names such as MrBeast are not lowercased.
     */
    fun toHinglish(raw: String): String {
        var normalized = tokenize(raw).joinToString(" ") { it.text }
        normalized = Regex("(?i)\\b(mr|mister)\\s+beast\\b").replace(normalized, "MrBeast")
        val lower = normalized.lowercase()
        // Scoped correction for the reported YouTube ASR error:
        // "MrBeast" sometimes arrives as "best clip".
        return if ((lower.contains("youtube") || lower.contains("you tube")) &&
            (lower.contains("search") || lower.contains("dhundo") || lower.contains("khojo")) &&
            Regex("(?i)\\b(best\\s+clip|bestclip)\\b").containsMatchIn(normalized)) {
            Regex("(?i)\\b(best\\s+clip|bestclip)\\b").replace(normalized, "MrBeast")
        } else normalized
    }

    private fun tokenize(raw: String): List<Tok> {
        var value = raw.replace(Regex("[^\\p{L}\\p{M}\\p{N}]+"), " ").trim()
        for ((from, to) in phrases.sortedByDescending { it.first.length }) {
            value = value.replace(Regex("(?i)\\b${Regex.escape(from)}\\b"), to)
        }
        if (value.isBlank()) return emptyList()
        return value.split(Regex("\\s+")).filter { it.isNotBlank() }.map { original ->
            val lower = original.lowercase()
            val mapped = words[lower]
            when {
                mapped != null -> Tok(mapped, mapped.lowercase(), mapped)
                hasDevanagari(original) -> {
                    val roman = transliterate(original)
                    Tok(roman, roman.lowercase(), roman)
                }
                else -> Tok(original, lower, original)
            }
        }
    }

    private fun hasDevanagari(s: String) = s.any { it in 'ऀ'..'ॿ' }

    // ---- rough Devanagari -> Latin, only used for matching (never shown) ----
    private val consonants = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
        'ष' to "sh", 'स' to "s", 'ह' to "h",
        'क़' to "q", 'ख़' to "kh", 'ग़' to "g", 'ज़' to "z",
        'ड़' to "d", 'ढ़' to "dh", 'फ़' to "f", 'य़' to "y"
    )
    private val nukta = mapOf('ज' to "z", 'फ' to "f", 'क' to "q", 'ख' to "kh", 'ग' to "g", 'ड' to "d", 'ढ' to "dh")
    private val matras = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u",
        'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
        'ॉ' to "o", 'ॅ' to "e"
    )
    private val vowels = mapOf(
        'अ' to "a", 'आ' to "a", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u",
        'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ऋ' to "ri"
    )

    fun transliterate(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val cons = consonants[c]
            when {
                cons != null -> {
                    var b: String = cons
                    var j = i + 1
                    if (j < s.length && s[j] == '़') {
                        b = nukta[c] ?: b
                        j++
                    }
                    val mat = if (j < s.length) matras[s[j]] else null
                    when {
                        mat != null -> { sb.append(b).append(mat); i = j + 1 }
                        j < s.length && s[j] == '्' -> { sb.append(b); i = j + 1 }
                        else -> {
                            sb.append(b)
                            if (j < s.length) sb.append('a') // inherent "a", dropped at word end
                            i = j
                        }
                    }
                }
                vowels[c] != null -> { sb.append(vowels[c]); i++ }
                c == 'ं' || c == 'ँ' -> { sb.append('n'); i++ }
                c == 'ः' -> { sb.append('h'); i++ }
                c in 'ऀ'..'ॿ' -> i++ // anything else in Devanagari: skip
                else -> { sb.append(c); i++ }
            }
        }
        return sb.toString()
    }
}
