package com.nova.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * OPTIONAL helper. Only used when you paste your own Gemini key in the app.
 * The key stays on the phone. It is sent only to Google, in a header.
 */
object GeminiClient {

    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"

    private fun commandPrompt(labels: List<String>): String = """
You convert one phone voice command (Hindi, English or Hinglish) into ONE JSON object.
Schema: {"action":"open"|"search"|"play"|"call"|"message"|"reply"|"agent"|"unknown","app":"","query":"","contact":"","body":"","sms":false,"goal":""}
Rules:
- open = just open an app. search = search inside an app (empty app = Google search). play = play music or video (empty app = default music app).
- call = phone call. contact = the person's name exactly as spoken (or digits).
- message = send a text. contact = person, body = exact message text, app = messaging app if named, sms = true only if the user said SMS.
- reply = reply to the latest received chat message. body = the reply text, contact = person if named.
- agent = anything else that needs tapping through an app (start a game, change a setting, order something). goal = one clear English instruction that includes the app name.
- "app" must be copied EXACTLY from this list of installed apps, or be empty: ${labels.joinToString(", ")}
- Input text is already Roman Hinglish. Keep the output query and message body in Roman Hinglish; NEVER convert it to Devanagari Hindi and NEVER translate it to formal English.
- Preserve English brand/person/product names and their original spelling/casing (for example MrBeast).
- For message: body must be the user's intended message, transliterated into Roman Hinglish if spoken in Hindi; do not paraphrase, embellish, or translate.
- Fix only obvious ASR spelling mistakes when context is strong; if uncertain, preserve the heard wording.
- If nothing fits, use "unknown".
Output only the JSON object.
""".trimIndent()

    private val AGENT_PROMPT = """
You control an Android phone through its accessibility tree to finish ONE goal for the user.
Each turn you get the goal, your previous steps, and the current screen as a numbered list of elements.
Reply with ONE JSON object: {"action":"click|type|scroll_down|scroll_up|enter|back|home|wait|done|fail","index":-1,"text":"","reason":"short, in Hinglish"}
Rules:
- click: index = element to tap. type: index = an editable element (or -1 for the first editable) and text = what to type. enter: press the keyboard search/enter key after typing.
- Use "done" only when the goal is clearly finished (the video or game is playing, the message is sent). Use "fail" if it is impossible or you are stuck.
- Never enter passwords, OTPs, card or bank details. Never confirm payments, transfers, purchases or deletions. If asked for any of these, use "fail".
- Send a message only with the exact text the goal gives. Never invent messages.
- Prefer search fields and visible buttons. If the element you need is not visible, scroll.
Output only the JSON object.
""".trimIndent()

    private fun requestBody(system: String, user: String): JSONObject = JSONObject()
        .put(
            "systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
        )
        .put(
            "contents",
            JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", user)))
            )
        )
        .put(
            "generationConfig",
            JSONObject().put("temperature", 0).put("responseMimeType", "application/json")
        )

    private fun answerJson(response: String): JSONObject? {
        val answer = JSONObject(response)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")
        val start = answer.indexOf('{')
        val end = answer.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return JSONObject(answer.substring(start, end + 1))
    }

    /** Returns null if the answer could not be read. Throws on network / key errors. */
    fun interpret(key: String, model: String, text: String, apps: List<AppInfo>): Command? {
        val j = answerJson(post(key, model, requestBody(commandPrompt(apps.map { it.label }), text)))
            ?: return null

        val appKey = Normalizer.key(j.optString("app"))
        val app = if (appKey.isEmpty()) null else apps.firstOrNull { it.key == appKey }
        val contact = j.optString("contact").trim()
        val contactKey = Normalizer.key(contact)
        val body = j.optString("body").trim()

        return when (j.optString("action").lowercase()) {
            "open" -> Command(Kind.OPEN, app, "", text)
            "search" -> Command(Kind.SEARCH, app, j.optString("query").trim(), text)
            "play" -> Command(Kind.PLAY, app, j.optString("query").trim(), text)
            "call" -> Command(Kind.CALL, null, "", text, contact, contactKey)
            "message" -> Command(Kind.MESSAGE, app, "", text, contact, contactKey, body, j.optBoolean("sms", false))
            "reply" -> Command(Kind.REPLY, null, "", text, contact, contactKey, body)
            "agent" -> Command(Kind.AGENT, null, "", text, body = j.optString("goal").trim())
            else -> Command(Kind.UNKNOWN, null, "", text)
        }
    }

    /** One step of the screen agent. Returns null if the answer could not be read. */
    fun agentStep(
        key: String,
        model: String,
        goal: String,
        history: List<String>,
        screen: String
    ): JSONObject? {
        val user = buildString {
            append("Goal: ").append(goal).append("\n\nPrevious steps:\n")
            if (history.isEmpty()) append("(none)\n")
            else history.takeLast(8).forEach { append("- ").append(it).append('\n') }
            append("\nCurrent screen:\n").append(screen)
        }
        val body = requestBody(AGENT_PROMPT, user)
        for (attempt in 0..1) {
            try {
                return answerJson(post(key, model, body))
            } catch (e: RuntimeException) {
                // free tier: too many requests, wait a little and try once more
                if (attempt == 1 || e.message?.contains("429") != true) throw e
                Thread.sleep(8000)
            }
        }
        return null
    }

    /** Used by the "Save" button to tell the user if the key works. */
    fun test(key: String, model: String, apps: List<AppInfo>): String = try {
        val c = interpret(key, model, "WhatsApp kholo", apps)
        if (c != null && c.kind != Kind.UNKNOWN) "Gemini theek chal raha hai."
        else "Gemini jawab de raha hai, par command samajh nahi paya."
    } catch (e: Exception) {
        "Gemini error: ${e.message}"
    }

    private fun post(key: String, model: String, body: JSONObject): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 25000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text
            }
            throw RuntimeException("HTTP $code: ${msg.take(160)}")
        }
        return text
    }
}
