package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Vibrator
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import kotlin.concurrent.thread

/**
 * Always-on listener. Runs as a foreground service (notification stays visible),
 * Offline Vosk handles wake words. Android SpeechRecognizer handles command dictation
 * only during the 30/40-second command session and may use the phone's speech provider.
 */
class ListenService : Service(), RecognitionListener {

    companion object {
        const val ACTION_LISTEN_NOW = "com.nova.assistant.LISTEN_NOW"
        const val ACTION_STOP = "com.nova.assistant.STOP"
        const val ACTION_STOP_AGENT = "com.nova.assistant.STOP_AGENT"
        const val CH_LISTEN = "nova_listen"
        const val CH_RESULT = "nova_result"
        const val NOTIF_ID = 1
        const val RESULT_ID = 2

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var commandRecognizer: SpeechRecognizer? = null
    private val commandRestart = Runnable { startCommandRecognition() }
    private val sessionTimeout = Runnable { endCommandSession() }
    private var wakeLock: PowerManager.WakeLock? = null
    private var foregroundStarted = false
    private var armedUntil = 0L
    private var sessionId = 0L
    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        index = AppIndex(this)
        parser = CommandParser(index)
        index.refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("nova", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_STOP_AGENT) {
            NovaAccessibility.instance?.stopAgent()
            return START_STICKY
        }

        if (!foregroundStarted) {
            try {
                ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification("Taiyaar ho raha hoon..."),
                    if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                )
                foregroundStarted = true
            } catch (e: Exception) {
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:listen").apply { acquire() }
            loadModelAndListen()
        }

        if (intent?.action == ACTION_LISTEN_NOW) arm()
        return START_STICKY
    }

    private fun loadModelAndListen() {
        thread {
            try {
                val dir = ModelFiles.ensure(this)
                val m = Model(dir.absolutePath)
                main.post {
                    if (!running) {
                        m.close()
                        return@post
                    }
                    model = m
                    startRecognizer()
                }
            } catch (e: Exception) {
                main.post { fail("Voice model load nahi hua: ${e.message}") }
            }
        }
    }

    private fun startRecognizer() {
        if (!running || armedUntil != 0L) return
        try {
            val rec = Recognizer(model, 16000.0f)
            val s = SpeechService(rec, 16000.0f)
            s.startListening(this)
            speech = s
            updateNotification("Wake-word mode: Hi Nova / Hey Nova / Okay Nova")
        } catch (e: Exception) {
            fail("Wake-word mic shuru nahi hua: ${e.message}")
        }
    }

    private fun stopWakeRecognizer() {
        try { speech?.stop(); speech?.shutdown() } catch (_: Exception) {}
        speech = null
    }

    // Vosk is used only for the offline wake-word stage.
    override fun onResult(hypothesis: String?) {
        if (armedUntil != 0L) return
        val raw = try {
            JSONObject(hypothesis ?: return).optString("text", "").trim()
        } catch (_: Exception) { "" }
        if (raw.isNotEmpty()) handleWakeText(raw)
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) {
        if (armedUntil == 0L && running) {
            fail("Wake-word recognition restart ho raha hai...")
            stopWakeRecognizer()
            main.postDelayed({ if (running && armedUntil == 0L) startRecognizer() }, 900L)
        }
    }
    override fun onTimeout() {}

    private fun handleWakeText(raw: String) {
        val text = parser.toHinglish(raw)
        val afterWake = parser.stripWake(text) ?: return
        arm()
        if (afterWake.isNotBlank()) runCommand(afterWake)
    }

    private fun sessionMs(): Long =
        (getSharedPreferences("nova", MODE_PRIVATE).getInt("session_seconds", 30).let {
            if (it == 40) 40 else 30
        }) * 1000L

    /** Start Android's higher-accuracy recognizer only after the offline wake word. */
    private fun arm() {
        sessionId++
        armedUntil = SystemClock.elapsedRealtime() + sessionMs()
        main.removeCallbacks(sessionTimeout)
        main.postDelayed(sessionTimeout, sessionMs() + 100L)
        stopWakeRecognizer()
        try { commandRecognizer?.cancel() } catch (_: Exception) {}
        try { commandRecognizer?.destroy() } catch (_: Exception) {}
        commandRecognizer = null
        main.removeCallbacks(commandRestart)
        beep()
        updateNotification("Ji, boliye. Command mode active.")
        startCommandRecognition()
    }

    private fun startCommandRecognition() {
        if (!running || armedUntil == 0L) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Command speech service unavailable. Wake-word mode par laut raha hoon.")
            endCommandSession()
            return
        }
        try {
            if (commandRecognizer == null) {
                commandRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                    sr.setRecognitionListener(object : android.speech.RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(error: Int) {
                            if (armedUntil == 0L) return
                            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                                updateNotification("Mic permission missing. Wake-word mode par laut raha hoon.")
                                endCommandSession()
                            } else {
                                scheduleCommandRestart(
                                    if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 900L else 500L
                                )
                            }
                        }
                        override fun onResults(results: Bundle?) {
                            if (armedUntil == 0L) return
                            val candidates = results
                                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                .orEmpty()
                            val candidate = candidates.firstOrNull {
                                parser.toHinglish(it).contains("MrBeast", ignoreCase = true)
                            } ?: candidates.firstOrNull { isStopCommand(parser.toHinglish(it)) }
                                ?: candidates.firstOrNull()
                            if (!candidate.isNullOrBlank()) handleCommandText(candidate)
                            scheduleCommandRestart(250L)
                        }
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            commandRecognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleCommandRestart(900L)
        }
    }

    private fun scheduleCommandRestart(delay: Long) {
        main.removeCallbacks(commandRestart)
        if (running && armedUntil != 0L) main.postDelayed(commandRestart, delay)
    }

    private fun handleCommandText(raw: String) {
        val text = parser.toHinglish(raw).trim()
        if (text.isBlank()) return
        val afterWake = parser.stripWake(text)
        if (isStopCommand(text) || (afterWake != null && isStopCommand(afterWake))) {
            endCommandSession()
            beep()
            return
        }
        if (afterWake != null) {
            if (afterWake.isNotBlank()) runCommand(afterWake)
            else updateNotification("Ji, boliye...")
        } else {
            runCommand(text)
        }
    }

    private fun isStopCommand(raw: String): Boolean {
        val words = raw.lowercase().replace(Regex("[^a-z0-9 ]"), " ")
            .trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return false
        val phrase = words.joinToString(" ")
        if (phrase in setOf(
                "stop", "stop listening", "nova stop", "nova band ho jao",
                "band karo", "band ho jao", "listening band karo", "bas nova",
                "sunna band karo", "sunnna band karo"
            )) return true
        return ("stop" in words && words.size <= 4) ||
            ("band" in words && ("karo" in words || "jao" in words || "ho" in words)) ||
            ("bas" in words && "nova" in words)
    }

    private fun endCommandSession() {
        sessionId++ // invalidate any AI/local callback still pending from the previous session
        armedUntil = 0L
        main.removeCallbacks(sessionTimeout)
        main.removeCallbacks(commandRestart)
        try { commandRecognizer?.cancel() } catch (_: Exception) {}
        try { commandRecognizer?.destroy() } catch (_: Exception) {}
        commandRecognizer = null
        updateNotification("Wake-word mode: Hi Nova / Hey Nova / Hello Nova / Okay Nova / Nova")
        if (running && model != null) main.postDelayed({
            if (running && armedUntil == 0L) startRecognizer()
        }, 250L)
    }

    private fun runCommand(text: String) {
        val activeSession = sessionId
        armedUntil = SystemClock.elapsedRealtime() + sessionMs()
        main.removeCallbacks(sessionTimeout)
        main.postDelayed(sessionTimeout, sessionMs() + 100L)
        index.refresh()
        Resolver.resolve(this, index, parser, text) { cmd ->
            if (!running || activeSession != sessionId || armedUntil == 0L) return@resolve
            withOverlay {
                if (!running || activeSession != sessionId || armedUntil == 0L) return@withOverlay
                val msg = ActionExecutor.run(this, index, cmd)
                if (armedUntil != 0L) {
                    armedUntil = SystemClock.elapsedRealtime() + sessionMs()
                    main.removeCallbacks(sessionTimeout)
                    main.postDelayed(sessionTimeout, sessionMs() + 100L)
                }
                updateNotification("Suna: ${cmd.heard}")
                showResult(cmd, msg)
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Android blocks apps from opening other apps while in the background.
     * A tiny invisible window ("Display over other apps") lets this app do it.
     */
    private fun withOverlay(block: () -> Unit) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var view: View? = null
        if (Settings.canDrawOverlays(this)) {
            try {
                val v = View(this)
                val lp = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                wm.addView(v, lp)
                view = v
            } catch (e: Exception) {
                view = null
            }
        }
        main.postDelayed({
            block()
            view?.let { v ->
                main.postDelayed({
                    try {
                        wm.removeView(v)
                    } catch (e: Exception) {
                    }
                }, 2500)
            }
        }, if (view != null) 150L else 0L)
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ tg.release() }, 400)
        } catch (e: Exception) {
        }
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private fun fail(message: String) {
        updateNotification(message)
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    // ---- notifications ----
    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Nova sun raha hai", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RESULT, "Nova natija", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
            }
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listenNow = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_LISTEN_NOW),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAgent = PendingIntent.getService(
            this, 4, Intent(this, ListenService::class.java).setAction(ACTION_STOP_AGENT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Nova")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "Abhi suno", listenNow)
            .addAction(0, "Rok do", stopAgent)
            .addAction(0, "Band karo", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!foregroundStarted) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    /** If Android still blocks the launch, this notification opens the app with one tap. */
    private fun showResult(cmd: Command, msg: String) {
        val pkg = cmd.app?.pkg
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        val b = NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(msg)
            .setContentText(if (launch != null) "Nahi khula? Yahan tap karo." else "")
            .setAutoCancel(true)
            .setTimeoutAfter(15000)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (launch != null) {
            b.setContentIntent(
                PendingIntent.getActivity(
                    this, 3, launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        getSystemService(NotificationManager::class.java).notify(RESULT_ID, b.build())
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { commandRecognizer?.cancel() } catch (_: Exception) {}
        try { commandRecognizer?.destroy() } catch (_: Exception) {}
        commandRecognizer = null
        speech?.stop()
        speech?.shutdown()
        speech = null
        model?.close()
        model = null
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
