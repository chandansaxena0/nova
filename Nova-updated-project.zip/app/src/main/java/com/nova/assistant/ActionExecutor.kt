package com.nova.assistant

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import androidx.core.content.ContextCompat

/** Does the real work: opens apps, searches, plays, calls, messages, replies. */
object ActionExecutor {

    private const val YOUTUBE = "com.google.android.youtube"

    // Used when you say "gaana chalao" without naming an app: first one installed wins
    private val musicApps = listOf(
        "com.spotify.music",
        "com.google.android.apps.youtube.music",
        "com.jio.media.jiobeats",
        "com.gaana",
        "com.bsbportal.music",
        "com.amazon.mp3"
    )

    // Search links of popular apps. {q} becomes your text.
    private val searchLinks = mapOf(
        "com.google.android.youtube" to "https://www.youtube.com/results?search_query={q}",
        "com.google.android.apps.youtube.music" to "https://music.youtube.com/search?q={q}",
        "com.spotify.music" to "spotify:search:{q}",
        "com.google.android.apps.maps" to "geo:0,0?q={q}",
        "com.android.chrome" to "https://www.google.com/search?q={q}",
        "com.google.android.googlequicksearchbox" to "https://www.google.com/search?q={q}",
        "com.amazon.mShop.android.shopping" to "https://www.amazon.in/s?k={q}",
        "in.amazon.mShop.android.shopping" to "https://www.amazon.in/s?k={q}",
        "com.flipkart.android" to "https://www.flipkart.com/search?q={q}",
        "com.jio.media.jiobeats" to "https://www.jiosaavn.com/search/{q}"
    )

    private sealed class Who {
        class Found(val name: String, val number: String) : Who()
        class Error(val msg: String) : Who()
    }

    fun run(context: Context, index: AppIndex, c: Command): String = when (c.kind) {
        Kind.OPEN -> open(context, c)
        Kind.SEARCH -> search(context, c)
        Kind.PLAY -> play(context, index, c)
        Kind.CALL -> call(context, index, c)
        Kind.MESSAGE -> message(context, index, c)
        Kind.REPLY -> reply(context, c)
        Kind.AGENT -> agent(context, c.body)
        Kind.UNKNOWN ->
            "Samajh nahi aaya. Aise bolo: \"WhatsApp kholo\", \"Rahul ko call karo\" ya \"Spotify par Kesariya chalao\"."
    }

    // ------------------------------------------------------------------ open / search / play

    private fun open(context: Context, c: Command): String {
        val app = c.app ?: return "Is naam ka app nahi mila: \"${c.heard}\""
        return if (launch(context, app.pkg)) "${app.label} khul gaya."
        else "${app.label} khol nahi paya."
    }

    private fun search(context: Context, c: Command): String {
        val q = c.query
        val app = c.app

        if (q.isEmpty()) {
            return if (app != null) open(context, c)
            else "Kya search karun? Jaise: \"YouTube par Kishore Kumar search karo\"."
        }

        // No app named: normal Google search
        if (app == null) {
            return if (view(context, "https://www.google.com/search?q=${Uri.encode(q)}", null))
                "'$q' search kar raha hoon."
            else "Search nahi ho paya."
        }

        if (searchInApp(context, app, q)) return "${app.label} me '$q' search kar raha hoon."

        // This app has no search link. If Gemini + Accessibility are ready, Nova does it by tapping.
        if (Prefs.geminiKey(context).isNotEmpty() && NovaAccessibility.instance != null) {
            launch(context, app.pkg)
            val what = if (c.kind == Kind.PLAY) "find and start playing/launching" else "search for"
            return agent(context, "In the ${app.label} app, $what \"$q\".")
        }

        // Otherwise: open it and copy the text so you can paste it
        copy(context, q)
        launch(context, app.pkg)
        return "${app.label} khul gaya. '$q' copy ho gaya hai, search box me paste kar do."
    }

    private fun play(context: Context, index: AppIndex, c: Command): String {
        val q = c.query
        val app: AppInfo? = c.app
            ?: musicApps.firstOrNull { index.isInstalled(it) }
                ?.let { pkg -> index.apps.first { it.pkg == pkg } }

        if (q.isEmpty()) {
            if (app == null) return "Kaunsa gaana? Naam bolo, jaise: \"Kesariya chalao\"."
            launch(context, app.pkg)
            return "${app.label} khul gaya. Gaane ka naam bhi bolo, jaise: \"Kesariya chalao\"."
        }

        // YouTube: open the search and press the first video
        if (app?.pkg == YOUTUBE) return playYoutube(context, q)

        // No music app installed: fall back to YouTube
        if (app == null) {
            return if (view(context, "https://www.youtube.com/results?search_query=${Uri.encode(q)}", null))
                "YouTube par '$q' dhundh raha hoon."
            else "Koi music app nahi mila."
        }

        // Standard Android "play this" request, many music apps understand it
        val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(app.pkg)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (start(context, playIntent)) return "${app.label} me '$q' chala raha hoon."

        // App does not support it: search inside the app (or let the agent do it)
        return search(context, c.copy(app = app))
    }

    private fun playYoutube(context: Context, q: String): String {
        val ok = view(context, "https://www.youtube.com/results?search_query=${Uri.encode(q)}", YOUTUBE)
        if (!ok) return "YouTube nahi khul paya."
        val acc = NovaAccessibility.instance
        return if (acc != null) {
            acc.playFirstYoutubeVideo()
            "YouTube par '$q' ka pehla video chala raha hoon."
        } else {
            "YouTube me '$q' search khul gaya. Video khud chalane ke liye Nova me Accessibility ON karo."
        }
    }

    // ------------------------------------------------------------------ call / message / reply

    private fun who(context: Context, index: AppIndex, c: Command): Who {
        val raw = c.contact.trim()

        // A spoken phone number
        if (raw.isNotEmpty() && raw.none { it.isLetter() }) {
            val d = raw.filter { it.isDigit() || it == '+' }
            if (d.length >= 5) return Who.Found(d, d)
        }

        if (!granted(context, Manifest.permission.READ_CONTACTS)) {
            return Who.Error("Contacts ki permission chahiye. Nova app ke \"Permissions\" card se allow karo.")
        }
        val parser = CommandParser(index)
        val hit = Contacts.find(context, c.contactKey) { parser.transliterate(it) }
            ?: return Who.Error("\"$raw\" naam ka contact nahi mila.")
        return Who.Found(hit.first, hit.second)
    }

    private fun call(context: Context, index: AppIndex, c: Command): String {
        if (c.contact.isBlank()) return "Kisko call karun? Jaise: \"Rahul ko call karo\"."
        return when (val w = who(context, index, c)) {
            is Who.Error -> w.msg
            is Who.Found -> {
                val canCall = granted(context, Manifest.permission.CALL_PHONE)
                val i = Intent(
                    if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL,
                    Uri.parse("tel:" + Uri.encode(w.number))
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                when {
                    !start(context, i) -> "Call nahi lag paya."
                    canCall -> "${w.name} ko call laga raha hoon."
                    else -> "${w.name} ka number khul gaya, call button dabao. (Call permission doge to khud lagega.)"
                }
            }
        }
    }

    private fun message(context: Context, index: AppIndex, c: Command): String {
        if (c.contact.isBlank()) return "Kisko bhejun? Jaise: \"Rahul ko message bhejo ki main aa raha hoon\"."
        if (c.body.isBlank()) return "Kya likhun? Jaise: \"Rahul ko message bhejo ki main aa raha hoon\"."

        val app = c.app
        val appIsSms = app != null && app.label.lowercase().contains("messag")
        val appIsWa = app != null && app.pkg.startsWith("com.whatsapp")
        val waPkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { index.isInstalled(it) }

        // Some other chat app (Telegram, Instagram ...): the agent does it by tapping
        if (app != null && !appIsSms && !appIsWa && !c.sms) {
            launch(context, app.pkg)
            return agent(context, "In the ${app.label} app, send the message \"${c.body}\" to \"${c.contact}\".")
        }

        return when (val w = who(context, index, c)) {
            is Who.Error -> w.msg
            is Who.Found ->
                if (!c.sms && !appIsSms && waPkg != null) sendWhatsApp(context, w, c.body, waPkg)
                else sendSms(context, w, c.body)
        }
    }

    private fun sendWhatsApp(context: Context, w: Who.Found, body: String, pkg: String): String {
        val digits = waNumber(w.number)
        val ok = view(context, "https://wa.me/$digits?text=${Uri.encode(body)}", pkg)
        if (!ok) return "WhatsApp nahi khul paya."
        return "${w.name} ka WhatsApp chat khul gaya aur message Hinglish mein ready hai. Ek baar check karke Send dabao."
    }

    /** India is assumed when the number has no country code. */
    private fun waNumber(number: String): String {
        var d = number.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        else if (d.length == 11 && d.startsWith("0")) d = "91" + d.drop(1)
        else if (d.length == 10) d = "91$d"
        return d
    }

    private fun sendSms(context: Context, w: Who.Found, body: String): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(w.number)))
            .putExtra("sms_body", body)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (start(context, i)) "${w.name} ka SMS draft ready hai. Check karke Send dabao."
        else "SMS app nahi khul paya."
    }

    private fun reply(context: Context, c: Command): String {
        if (c.body.isBlank()) return "Kya reply bhejun? Jaise: \"Reply karo main thodi der me aata hoon\"."
        if (!NovaNotificationListener.connected) {
            return "Reply ke liye Nova me \"Notification access\" ON karo."
        }
        return NovaNotificationListener.replyTo(context, c.contactKey, c.contact, c.body)
    }

    private fun agent(context: Context, goal: String): String {
        val key = Prefs.geminiKey(context)
        val acc = NovaAccessibility.instance
        return when {
            goal.isBlank() -> "Kya karna hai samajh nahi aaya."
            key.isEmpty() -> "Ye kaam karne ke liye Nova me Gemini key daalo."
            acc == null -> "Ye kaam karne ke liye Nova me Accessibility ON karo."
            else -> {
                acc.startAgent(goal, key, Prefs.geminiModel(context))
                "Nova ye kaam kar raha hai: $goal"
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun granted(context: Context, p: String): Boolean =
        ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    private fun searchInApp(context: Context, app: AppInfo, q: String): Boolean {
        val link = searchLinks[app.pkg]
        if (link != null && view(context, link.replace("{q}", Uri.encode(q)), app.pkg)) return true

        val i = Intent(Intent.ACTION_SEARCH).apply {
            setPackage(app.pkg)
            putExtra(SearchManager.QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return start(context, i)
    }

    private fun launch(context: Context, pkg: String): Boolean {
        val i = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return start(context, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun view(context: Context, url: String, pkg: String?): Boolean {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        return start(context, i)
    }

    private fun start(context: Context, i: Intent): Boolean = try {
        context.startActivity(i)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun copy(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("nova", text))
    }
}
