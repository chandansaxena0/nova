NOVA - UPDATED PROJECT

Is archive mein tumhara original project hai, aur neeche diye gaye fixes add kiye gaye hain:
- Hey Nova / Hi Nova ke baad continuous command session.
- Voice command "Stop", "Stop listening", "Band karo" par session end hota hai; wake-word listener phir bhi chalta rahega.
- Nova apna result Android TextToSpeech se bolta hai.
- TTS bolte waqt microphone recognition pause hoti hai, taaki Nova apni awaaz ko command na samjhe.
- Recognition/service error par listener restart ki koshish hoti hai.
- Unknown command: local app matching -> Gemini (agar API key configured ho) -> Google Search.
- Gemini key ke accidental Android backup ko rokne ke liye allowBackup=false.
- GitHub Actions workflow ko .github/workflows/android.yml mein rakha gaya hai.

IMPORT:
1. ZIP extract karo.
2. Android Studio > Open > extracted Nova folder select karo (jahan settings.gradle.kts hai).
3. Gradle Sync complete hone do.
4. Phone par install karke microphone + notification permissions do.
5. Nova app kholo, Hey Nova switch ON karo, required setup permissions allow karo.
6. App ko foreground mein rakhkar pehle test karo: "Hey Nova" -> "WhatsApp kholo" -> "YouTube kholo" -> "Stop".

IMPORTANT LIMITATIONS:
- 100% speech recognition accuracy guarantee nahi hoti.
- Bundled Vosk model Hindi model hai; English-only app names aur accents ki recognition inconsistent ho sakti hai.
- Hey Nova background listening Android foreground microphone service par depend karti hai. Android/OEM battery management, force-stop, reboot, microphone privacy toggle aur system restrictions ise rok sakte hain. Reboot ke baad notification se manually resume karna pad sakta hai.
- Android ke restrictions ki wajah se app har doosre app ko har haal mein background se launch nahi kar sakta. Overlay permission is restriction ko bypass karne ki guaranteed/official solution nahi hai; host OS behaviour alag ho sakta hai.
- Gemini API key app ke SharedPreferences mein local save hoti hai; allowBackup=false backup risk ko kam karta hai, lekin APK reverse engineering se key ko fully secure nahi banata. Public distribution se pehle backend proxy use karo.
- Google Search fallback internet/browser par depend karta hai.

GITHUB ACTIONS:
Project root ko GitHub repository mein upload karo. Workflow .github/workflows/android.yml se APK build karega aur Actions run ke Artifacts section mein nova-debug-apk upload karega.

Build environment available na hone ki wajah se is archive ka Gradle build yahan execute karke verify nahi kiya gaya. Android Studio mein Sync/Build karke pehle compile test zaroor karo.
