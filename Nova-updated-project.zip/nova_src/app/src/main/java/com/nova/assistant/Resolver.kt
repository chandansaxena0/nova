package com.nova.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

/** Resolution order: local parser/app index -> Gemini (if configured) -> Google Search fallback. */
object Resolver {
    fun resolve(
        context: Context,
        index: AppIndex,
        parser: CommandParser,
        text: String,
        done: (Command) -> Unit
    ) {
        val main = Handler(Looper.getMainLooper())
        val local = parser.parse(text)

        // First attempt: exact/strong local app matching, including a likely app name
        // when speech recognition has omitted the word "open".
        val appCandidate = if (local.kind == Kind.UNKNOWN && local.app == null) {
            likelyApp(text, index)
        } else null
        val localResult = if (appCandidate != null) {
            Command(Kind.OPEN, appCandidate, "", text)
        } else local

        if (localResult.kind != Kind.UNKNOWN && !(localResult.kind == Kind.OPEN && localResult.app == null)) {
            main.post { done(localResult) }
            return
        }

        val key = Prefs.geminiKey(context)
        if (key.isBlank()) {
            main.post { done(localResult) } // ActionExecutor sends unresolved text to Google Search.
            return
        }

        val model = Prefs.geminiModel(context)
        val installedApps = index.apps.toList()
        thread(name = "nova-gemini-resolve") {
            val aiCommand = try {
                GeminiClient.interpret(key, model, text, installedApps)
            } catch (_: Exception) { null }
            val usable = aiCommand != null && aiCommand.kind != Kind.UNKNOWN &&
                !(aiCommand.kind == Kind.OPEN && aiCommand.app == null)
            main.post { done(if (usable) aiCommand!! else localResult) }
        }
    }

    private fun likelyApp(text: String, index: AppIndex): AppInfo? {
        val ignored = setOf(
            "open", "kholo", "khol", "app", "application", "please", "plz",
            "hey", "hi", "hello", "nova", "start", "launch", "chalu", "shuru",
            "mujhe", "mera", "meri", "karo", "kar", "do", "please"
        )
        val query = text.lowercase()
            .replace(Regex("[^\\p{L}\\p{M}\\p{N} ]+"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in ignored }
            .joinToString("")
        if (query.length < 3) return null
        val match = index.bestMatch(Normalizer.key(query)) ?: return null
        // Deliberately conservative: avoid launching a random app for ordinary speech.
        return match.first.takeIf { match.second >= 0.78 }
    }
}
