# Nova Assistant v6

## v6 focus
- The supplied ZIP had no `app/src/main/assets/model` folder even though the old app tried to load it. The GitHub Actions workflow now downloads the official Vosk small Hindi model and packages it into the APK.
- Offline Vosk is used only for wake-word detection, reducing the amount of full-sentence transcription it has to do.
- After wake-up, Android SpeechRecognizer handles the command session in Hindi (`hi-IN`); recognized Devanagari words are normalized to Roman Hinglish before local parsing, YouTube/Google search, and WhatsApp message composition.
- Latin words keep their spelling/casing when the phone recognizer returns them (for example `MrBeast`).
- A scoped correction handles the reported `best clip` → `MrBeast` ASR confusion in YouTube search commands.
- Wake phrases include Hi Nova, Hey Nova, Hello Nova, Okay Nova, and standalone Nova.
- Command session is continuous for 30 seconds by default; tap the duration button to switch to 40 seconds. Each accepted command refreshes the timer.
- Stop phrases are intercepted before search/AI routing and return the app to offline wake-word mode.
- App version is 6.0 / versionCode 6.
- Updated Nova launcher mark.

## Important limitations
- Speech accuracy is not 100% guaranteed. Android SpeechRecognizer quality depends on the installed speech provider, network, microphone, accent, noise, and OEM behavior.
- Vosk small Hindi is an offline wake-word model, not a high-accuracy general transcription engine. The official model listing reports 20.89 / 24.72 word-error figures on its listed test sets; actual results vary. See the Vosk model page: https://alphacephei.com/vosk/models
- Android SpeechRecognizer may use network depending on the phone's provider. It is used only during the 30/40-second command session, not continuously.
- The wake-word stage is offline, but OEM battery management and Android microphone/foreground-service rules can still interrupt background operation.
- `best clip` is mapped to `MrBeast` only in a YouTube search context. This is a targeted correction, not a universal speech-correction model.
- Nearby Places still opens Maps search only. It does not calculate or speak verified distance. This was intentionally not added in v6 to avoid inventing distances or adding always-on GPS usage.
- WhatsApp message text is prefilled for review; the user must press Send. SMS opens a draft for review instead of silently sending.
- WhatsApp/Roblox/other automation remains subject to app UI changes and Android accessibility restrictions.
- Gemini API key remains user-provided and stored locally by the existing app code. Do not publish an APK with a personal key embedded. For a public app, use a secure backend.
- Build verification could not be run in this environment because Gradle/Android SDK dependencies are not installed and network access is unavailable. GitHub Actions is configured to build and upload the APK artifact.

## Build
GitHub Actions workflow `.github/workflows/android.yml` downloads the Vosk model, runs `gradle assembleDebug`, and uploads `app-debug.apk` as the `Nova-v6-debug-apk` artifact.
