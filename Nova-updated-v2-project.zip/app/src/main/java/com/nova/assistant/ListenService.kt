package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Foreground microphone service. Wake phrase activates a continuous command session.
 * The service remains in wake-word mode after the user says Stop; Stop ends only the
 * command session. The notification's Band karo action stops the service completely.
 */
class ListenService : Service(), RecognitionListener {

    companion object {
        const val ACTION_LISTEN_NOW = "com.nova.assistant.LISTEN_NOW"
        const val ACTION_STOP = "com.nova.assistant.STOP"
        const val CH_LISTEN = "nova_listen"
        const val CH_RESULT = "nova_result"
        const val NOTIF_ID = 1
        const val RESULT_ID = 2

        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var foregroundStarted = false
    private var sessionActive = false
    private var processing = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        index = AppIndex(this)
        parser = CommandParser(index)
        index.refresh()
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val result = tts?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.getDefault()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setWake(this, false)
            stopSelf()
            return START_NOT_STICKY
        }

        if (!foregroundStarted) {
            try {
                ServiceCompat.startForeground(
                    this,
                    NOTIF_ID,
                    buildNotification("Taiyaar ho raha hoon..."),
                    if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                )
                foregroundStarted = true
            } catch (e: Exception) {
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:listen").apply {
                setReferenceCounted(false)
                acquire()
            }
            loadModelAndListen()
        }

        if (intent?.action == ACTION_LISTEN_NOW) {
            sessionActive = true
            processing = true
            stopRecognizer()
            sayAndResume("Ji, boliye")
        }
        return START_STICKY
    }

    private fun loadModelAndListen() {
        thread(name = "nova-model-load") {
            try {
                val dir = ModelFiles.ensure(this)
                val loaded = Model(dir.absolutePath)
                main.post {
                    if (!running) loaded.close() else {
                        model = loaded
                        startRecognizer()
                    }
                }
            } catch (e: Exception) {
                main.post { fail("Voice model load nahi hua: ${e.message ?: "unknown error"}") }
            }
        }
    }

    private fun startRecognizer() {
        val currentModel = model ?: return
        if (!running || processing || speech != null) return
        try {
            val recognizer = Recognizer(currentModel, 16000.0f)
            speech = SpeechService(recognizer, 16000.0f).also { it.startListening(this) }
            updateNotification(
                if (sessionActive) "Nova active hai. Commands bolte raho; Stop bolo band karne ke liye."
                else "Wake word ke liye sun raha hoon: Hey Nova / Hi Nova"
            )
        } catch (e: Exception) {
            fail("Mic shuru nahi hua: ${e.message ?: "unknown error"}")
            scheduleRecognizerRestart()
        }
    }

    private fun stopRecognizer() {
        val old = speech
        speech = null
        try { old?.stop() } catch (_: Exception) { }
        try { old?.shutdown() } catch (_: Exception) { }
    }

    private fun scheduleRecognizerRestart() {
        main.postDelayed({
            if (running && !processing && speech == null) startRecognizer()
        }, 1200L)
    }

    override fun onResult(hypothesis: String?) {
        val spoken = try {
            JSONObject(hypothesis ?: return).optString("text", "").trim()
        } catch (_: Exception) { "" }
        if (spoken.isNotEmpty()) main.post { handleText(spoken) }
    }

    override fun onPartialResult(hypothesis: String?) = Unit
    override fun onFinalResult(hypothesis: String?) = Unit

    override fun onError(exception: Exception?) {
        main.post {
            if (running && !processing) {
                stopRecognizer()
                scheduleRecognizerRestart()
            }
        }
    }

    override fun onTimeout() {
        main.post { if (running && !processing && speech == null) startRecognizer() }
    }

    private fun handleText(text: String) {
        if (processing) return

        // Global stop commands must be checked BEFORE wake-word stripping and routing.
        // Otherwise phrases such as "Nova band ho jao" can be mistaken for a wake phrase
        // or sent to Google Search instead of ending the active session.
        val normalizedFull = Normalizer.key(text)
        if (sessionActive && isStopPhrase(normalizedFull)) {
            sessionActive = false
            processing = true
            stopRecognizer()
            sayAndResume("Theek hai. Listening band. Dobara Hey Nova bolo.")
            return
        }

        val afterWake = parser.stripWake(text)
        val commandText = afterWake ?: text
        when {
            afterWake != null && afterWake.isBlank() -> {
                sessionActive = true
                beep()
                processing = true
                stopRecognizer()
                sayAndResume("Ji, boliye")
            }
            afterWake != null -> {
                sessionActive = true
                runCommand(afterWake)
            }
            sessionActive -> runCommand(text)
            else -> Unit // Ignore ordinary speech until the wake phrase is detected.
        }
    }

    private fun isStopPhrase(s: String): Boolean {
        // Normalizer.key removes spaces/punctuation, so match common Hindi/Hinglish variants.
        val compact = s.replace(" ", "")
        val exact = setOf(
            "stop", "stoplistening", "band", "bandkaro", "bandkardo", "bandkar",
            "bandhojao", "bandhoja", "bas", "baskaro", "sunnaband", "sunnabandkaro",
            "listeningband", "listeningbandkaro", "novastop", "novaband", "novabandkaro",
            "novabandhojao", "rukjao", "rukja", "rukkjao", "abbandkaro"
        )
        return compact in exact || compact.endsWith("bandkaro") || compact.endsWith("bandkardo") ||
            compact.endsWith("bandhojao") || compact.endsWith("stoplistening")
    }

    private fun runCommand(text: String) {
        if (processing) return
        processing = true
        stopRecognizer() // Prevent Nova's own spoken response from being recognized as a command.
        index.refresh()
        Resolver.resolve(this, index, parser, text) { command ->
            withOverlay {
                val result = try {
                    ActionExecutor.run(this, index, command)
                } catch (e: Exception) {
                    "Action execute nahi ho paya: ${e.message ?: "unknown error"}"
                }
                updateNotification("Command: ${command.heard.take(70)}")
                showResult(command, result)
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
                sayAndResume(result)
            }
        }
    }

    private fun sayAndResume(message: String) {
        if (!running) return
        if (!ttsReady || tts == null) {
            processing = false
            startRecognizer()
            return
        }
        val utteranceId = UUID.randomUUID().toString()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                main.post {
                    processing = false
                    if (running) startRecognizer()
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post {
                    processing = false
                    if (running) startRecognizer()
                }
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                main.post {
                    processing = false
                    if (running) startRecognizer()
                }
            }
        })
        val result = tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (result == TextToSpeech.ERROR) {
            processing = false
            startRecognizer()
        }
    }

    private fun withOverlay(block: () -> Unit) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var overlay: View? = null
        if (Settings.canDrawOverlays(this)) {
            try {
                val v = View(this)
                val lp = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                wm.addView(v, lp)
                overlay = v
            } catch (_: Exception) { overlay = null }
        }
        main.postDelayed({
            try { block() } finally {
                overlay?.let { v -> main.postDelayed({ try { wm.removeView(v) } catch (_: Exception) { } }, 1200L) }
            }
        }, if (overlay != null) 150L else 0L)
    }

    private fun beep() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ tone.release() }, 400L)
        } catch (_: Exception) { }
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) { }
    }

    private fun fail(message: String) {
        updateNotification(message)
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun createChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CH_LISTEN, "Nova sun raha hai", NotificationManager.IMPORTANCE_LOW))
        manager.createNotificationChannel(NotificationChannel(CH_RESULT, "Nova natija", NotificationManager.IMPORTANCE_DEFAULT).apply {
            setSound(null, null)
        })
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listenNow = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_LISTEN_NOW),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Nova")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "Abhi suno", listenNow)
            .addAction(0, "Band karo", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        if (foregroundStarted) getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    private fun showResult(command: Command, message: String) {
        val launch = command.app?.pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        val builder = NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(message)
            .setContentText(if (launch != null) "Agar app nahi khula to yahan tap karo." else "")
            .setAutoCancel(true)
            .setTimeoutAfter(15000)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (launch != null) builder.setContentIntent(PendingIntent.getActivity(
            this, 3, launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        ))
        getSystemService(NotificationManager::class.java).notify(RESULT_ID, builder.build())
    }

    override fun onDestroy() {
        running = false
        processing = false
        stopRecognizer()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        try { model?.close() } catch (_: Exception) { }
        model = null
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }
}
