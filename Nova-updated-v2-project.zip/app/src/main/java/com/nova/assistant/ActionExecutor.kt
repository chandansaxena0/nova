package com.nova.assistant

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore

/** Does the real work: opens the app, searches inside it, or plays music. */
object ActionExecutor {

    // Used when you say "gaana chalao" without naming an app: first one installed wins
    private val musicApps = listOf(
        "com.spotify.music",
        "com.google.android.apps.youtube.music",
        "com.jio.media.jiobeats",
        "com.gaana",
        "com.bsbportal.music",
        "com.amazon.mp3"
    )

    // Search links of popular apps. {q} becomes your text.
    // Any app NOT in this list still works (see searchInApp).
    private val searchLinks = mapOf(
        "com.google.android.youtube" to "https://www.youtube.com/results?search_query={q}",
        "com.google.android.apps.youtube.music" to "https://music.youtube.com/search?q={q}",
        "com.spotify.music" to "spotify:search:{q}",
        "com.google.android.apps.maps" to "geo:0,0?q={q}",
        "com.android.chrome" to "https://www.google.com/search?q={q}",
        "com.google.android.googlequicksearchbox" to "https://www.google.com/search?q={q}",
        "com.amazon.mShop.android.shopping" to "https://www.amazon.in/s?k={q}",
        "in.amazon.mShop.android.shopping" to "https://www.amazon.in/s?k={q}",
        "com.flipkart.android" to "https://www.flipkart.com/search?q={q}",
        "com.jio.media.jiobeats" to "https://www.jiosaavn.com/search/{q}"
    )

    fun run(context: Context, index: AppIndex, c: Command): String {
        // Handle intent-specific commands before the generic app launcher/parser.
        val raw = c.heard.trim()
        val compact = Normalizer.key(raw)

        if (compact.contains("roblox") || compact.contains("रोब्लॉक्स") || compact.contains("रोब्लोक्स")) {
            val game = extractTopic(raw, listOf("roblox", "रोब्लॉक्स", "रोब्लोक्स", "game", "गेम", "mein", "में", "me", "par", "पर", "pe", "पे", "open", "खोलो", "खोल", "chalao", "चलाओ", "start", "launch", "please", "karo", "करो", "कर", "do", "दो"))
            if (game.isBlank()) {
                return if (launch(context, "com.roblox.client")) "Roblox khol raha hoon. Game ka naam bhi batao." else googleSearch(context, raw)
            }
            val url = "https://www.roblox.com/search/experiences?keyword=${Uri.encode(game)}"
            return if (view(context, url, null)) "Roblox mein '$game' game search kar raha hoon. Result select karke Play dabao." else "Roblox game search nahi khul paya."
        }

        if (compact.contains("youtube") || compact.contains("youtub") || compact.contains("यूट्यूब")) {
            val topic = if (c.query.isNotBlank()) c.query else extractTopic(raw, listOf("youtube", "यूट्यूब", "video", "वीडियो", "videos", "par", "पर", "pe", "पे", "mein", "में", "me", "play", "चलाओ", "chalao", "chala", "start", "open", "खोलो", "खोल", "kholo", "khol", "search", "dhundo", "karo", "करो", "कर", "kar", "do", "दो", "please"))
            if (topic.isBlank()) return if (launch(context, "com.google.android.youtube")) "YouTube khol diya. Kaunsa video chalaun?" else "YouTube installed nahi hai."
            val url = "https://www.youtube.com/results?search_query=${Uri.encode(topic)}"
            return if (view(context, url, "com.google.android.youtube")) "YouTube par '$topic' ke videos dikha raha hoon. Video select karo; automatic playback har video par supported nahi hai." else if (view(context, url, null)) "YouTube par '$topic' search kar raha hoon." else "YouTube search nahi khul paya."
        }

        if (isNearbyRequest(compact)) {
            val category = when {
                compact.contains("petrol") || compact.contains("fuel") || compact.contains("petrolpump") || compact.contains("पेट्रोल") -> "petrol pump"
                compact.contains("hospital") || compact.contains("aspatal") || compact.contains("अस्पताल") -> "hospital"
                compact.contains("atm") || compact.contains("एटीएम") -> "ATM"
                compact.contains("railwaystation") || compact.contains("station") || compact.contains("रेलवे") -> "railway station"
                else -> "places"
            }
            val uri = Uri.parse("geo:0,0?q=${Uri.encode("$category near me")}")
            return if (view(context, uri.toString(), "com.google.android.apps.maps")) "Google Maps mein nearest $category search kar raha hoon. Wahan distance aur route dekh sakte ho." else if (view(context, "https://www.google.com/maps/search/?api=1&query=${Uri.encode("$category near me")}", null)) "Maps mein nearest $category search kar raha hoon." else "Maps open nahi ho paya."
        }

        return when (c.kind) {
            Kind.OPEN -> open(context, c)
            Kind.SEARCH -> search(context, c)
            Kind.PLAY -> play(context, index, c)
            Kind.UNKNOWN -> googleSearch(context, c.heard)
        }
    }

    private fun isNearbyRequest(s: String): Boolean {
        val hasNearby = listOf("nearest", "nearby", "nearestto", "merepaas", "paasmein", "sabsepaas", "aaspaas", "kitnidur", "distance", "सबसेपास", "मेरेपास", "नजदीक", "आसपास", "कितनीदूर").any { s.contains(it) }
        val hasPlace = listOf("petrol", "petrolpump", "fuel", "hospital", "aspatal", "atm", "railwaystation", "station", "पेट्रोल", "अस्पताल", "एटीएम", "रेलवे").any { s.contains(it) }
        return hasNearby && hasPlace
    }

    private fun extractTopic(raw: String, remove: List<String>): String {
        var value = raw.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]+"), " ")
        remove.forEach { word -> value = value.replace(Regex("(?i)\\b${Regex.escape(word)}\\b"), " ") }
        return value.replace(Regex("\\s+"), " ").trim()
    }

    private fun googleSearch(context: Context, raw: String): String {
        val query = raw.trim()
        if (query.isBlank()) return "Command samajh nahi aayi. Dobara boliye."
        return if (view(context, "https://www.google.com/search?q=${Uri.encode(query)}", null))
            "Command clear nahi thi, isliye Google par '$query' search kar raha hoon."
        else "Command samajh nahi aayi aur Google Search nahi khul paya."
    }

    private fun open(context: Context, c: Command): String {
        val app = c.app ?: return googleSearch(context, c.heard)
        return if (launch(context, app.pkg)) "${app.label} khul gaya."
        else "${app.label} khol nahi paya."
    }

    private fun search(context: Context, c: Command): String {
        val q = c.query
        val app = c.app

        if (q.isEmpty()) {
            return if (app != null) open(context, c)
            else "Kya search karun? Jaise: \"YouTube par Kishore Kumar search karo\"."
        }

        // No app named: normal Google search
        if (app == null) {
            return if (view(context, "https://www.google.com/search?q=${Uri.encode(q)}", null))
                "'$q' search kar raha hoon."
            else "Search nahi ho paya."
        }

        if (searchInApp(context, app, q)) return "${app.label} me '$q' search kar raha hoon."

        // This app has no search link: open it and copy the text so you can paste it
        copy(context, q)
        launch(context, app.pkg)
        return "${app.label} khul gaya. '$q' copy ho gaya hai, search box me paste kar do."
    }

    private fun play(context: Context, index: AppIndex, c: Command): String {
        val q = c.query
        val app: AppInfo? = c.app
            ?: musicApps.firstOrNull { index.isInstalled(it) }
                ?.let { pkg -> index.apps.first { it.pkg == pkg } }

        if (q.isEmpty()) {
            if (app == null) return "Kaunsa gaana? Naam bolo, jaise: \"Kesariya chalao\"."
            launch(context, app.pkg)
            return "${app.label} khul gaya. Gaane ka naam bhi bolo, jaise: \"Kesariya chalao\"."
        }

        // No music app installed: fall back to YouTube search
        if (app == null) {
            return if (view(context, "https://www.youtube.com/results?search_query=${Uri.encode(q)}", null))
                "YouTube par '$q' dhundh raha hoon."
            else "Koi music app nahi mila."
        }

        // Standard Android "play this" request, many music apps understand it
        val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(app.pkg)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (start(context, playIntent)) return "${app.label} me '$q' chala raha hoon."

        // App does not support it: search inside the app instead
        return search(context, c.copy(kind = Kind.SEARCH, app = app))
    }

    private fun searchInApp(context: Context, app: AppInfo, q: String): Boolean {
        val link = searchLinks[app.pkg]
        if (link != null && view(context, link.replace("{q}", Uri.encode(q)), app.pkg)) return true

        val i = Intent(Intent.ACTION_SEARCH).apply {
            setPackage(app.pkg)
            putExtra(SearchManager.QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return start(context, i)
    }

    private fun launch(context: Context, pkg: String): Boolean {
        val i = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return start(context, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun view(context: Context, url: String, pkg: String?): Boolean {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        return start(context, i)
    }

    private fun start(context: Context, i: Intent): Boolean = try {
        context.startActivity(i)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun copy(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("kholo", text))
    }
}
