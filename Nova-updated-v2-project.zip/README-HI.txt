NOVA - INCREMENTAL UPDATE (nova-update)

Is update mein source code ke ye fixes/features add hue hain:
- Stop command ko resolver/Google Search se pehle intercept kiya jata hai.
- Stop, Stop listening, band karo, band ho jao, Nova band ho jao jaise variants handle hote hain.
- Standalone "Nova" wake word aur "Okay Nova" style wake phrase support add hua.
- YouTube + topic command ko YouTube search results mein route karta hai. Automatic video autoplay ki guarantee nahi; user ko result select karna ho sakta hai.
- Roblox + game name command Roblox experience search page kholta hai. Exact game ko auto-launch karne ke liye placeId lookup/API abhi nahi hai.
- Nearby petrol pump/hospital/ATM/railway station command Google Maps mein "near me" search kholta hai. Spoken exact distance/route calculation abhi implemented nahi hai; Maps results distance/route dikhayenge.
- GitHub Actions workflow nova-update branch push par bhi trigger hota hai.

ABHI IMPLEMENT NAHI HUA:
- WhatsApp/other notification ka automatic reply. Iske liye NotificationListenerService, notification access aur supported inline reply actions chahiye.
- Contact lookup + call flow. Iske liye contacts permission aur dialer/call confirmation flow chahiye.
- Exact Roblox game launch.
- Nearby Places ki distance ko Nova ki awaaz mein bolna. Iske liye location permission aur Places/directions data source chahiye.
- Dedicated wake-word engine. Vosk abhi bhi recognition engine hai; single-utterance detection 100% guaranteed nahi.

BUILD:
GitHub par nova-update branch mein project root files upload/replace karo. Actions workflow run hone ke baad nova-debug-apk artifact download karo.

NOTE: Is environment mein Android SDK/Gradle build available hona confirm nahi hua; is ZIP ko compiled/tested APK nahi kaha ja raha. GitHub Actions se build karke compile errors aur phone par runtime behavior verify karo.
